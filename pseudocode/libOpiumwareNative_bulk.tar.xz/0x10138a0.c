/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x10138a0:dba301ae2c
 */

void FUN_010138a0(long param_1,long param_2,undefined8 *param_3)

{
  func_0x0114f4a8(param_3,*(undefined8 *)(param_2 + 8),param_2 + 0x18,
                  *(uint *)(param_2 + 0x10) & 0x7fffffff,*(undefined8 *)(param_1 + 0x18));
  if ((int)*(uint *)(param_2 + 0x10) < 0) {
    FUN_0174f3f4(param_3,*(undefined8 *)
                          (param_2 + 0x18 + (ulong)(*(uint *)(param_2 + 0x10) & 0x7fffffff) * 0x18))
/*  if you paid for this, you were scammed  */
    ;
  }
  func_0x01244c38(*param_3,param_3[1]);
  return;
}

