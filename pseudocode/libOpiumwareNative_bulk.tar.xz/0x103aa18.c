/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x103aa18:c0e4a3ec3c
 */

void FUN_0103aa18(long *param_1)

{
  undefined1 (*pauVar1) [16];
  long *plVar2;
  ulong uVar3;
  char cVar4;
  uint uVar5;
  undefined1 auVar6 [16];
  long lVar7;
  ulong uVar8;
  long *plVar9;
  long lVar10;
  long lVar11;
  undefined8 *puVar12;
  undefined8 *puVar13;
  undefined8 uVar14;
  char *pcVar15;
  undefined1 *puVar16;
  undefined4 *puVar17;
  undefined2 *puVar18;
  undefined1 uVar19;
  undefined4 uVar20;
  char *pcVar21;
  long lVar22;
  ulong uVar23;
  long lVar24;
  undefined1 auVar25 [16];
  
  plVar2 = (long *)*param_1;
  lVar7 = param_1[1];
  if (lVar7 == 0) {
    if ((char)plVar2[0x8d] != '\0') {
      (**(code **)(*(long *)*plVar2 + 0x28))((long *)*plVar2,4,0,0);
    }
    lVar7 = *plVar2;
    pcVar15 = *(char **)(lVar7 + 0x18);
    if ((ulong)(*(long *)(lVar7 + 0x10) - (long)pcVar15) < 10) {
      func_0x01770110(lVar7,"<<<NULL>>>",10);
/* WM - origin: github.com/pengussy */
      cVar4 = (char)plVar2[0x8d];
    }
    else {
      pcVar15[8] = '>';
      pcVar15[9] = '>';
      *(undefined8 *)pcVar15 = s_<<<NULL>>>_01cbd5c4._0_8_;
      *(long *)(lVar7 + 0x18) = *(long *)(lVar7 + 0x18) + 10;
      cVar4 = (char)plVar2[0x8d];
    }
    if (cVar4 == '\x01') {
      (**(code **)(*(long *)*plVar2 + 0x30))();
      return;
    }
    s_<<<NULL>>>_01cbd5c4[0] = s_<<<NULL>>>_01cbd5c4[0];
    s_<<<NULL>>>_01cbd5c4[1] = s_<<<NULL>>>_01cbd5c4[1];
    s_<<<NULL>>>_01cbd5c4[2] = s_<<<NULL>>>_01cbd5c4[2];
    s_<<<NULL>>>_01cbd5c4[3] = s_<<<NULL>>>_01cbd5c4[3];
    s_<<<NULL>>>_01cbd5c4[4] = s_<<<NULL>>>_01cbd5c4[4];
    s_<<<NULL>>>_01cbd5c4[5] = s_<<<NULL>>>_01cbd5c4[5];
    s_<<<NULL>>>_01cbd5c4[6] = s_<<<NULL>>>_01cbd5c4[6];
    s_<<<NULL>>>_01cbd5c4[7] = s_<<<NULL>>>_01cbd5c4[7];
    s_ParamIndex__01cbf1eb[0] = s_ParamIndex__01cbf1eb[0];
    s_ParamIndex__01cbf1eb[1] = s_ParamIndex__01cbf1eb[1];
    s_ParamIndex__01cbf1eb[2] = s_ParamIndex__01cbf1eb[2];
/* WM: proprietary - see LICENSE - do not sell @ discord.gg/sdkhDjTex */
    s_ParamIndex__01cbf1eb[3] = s_ParamIndex__01cbf1eb[3];
    s_ParamIndex__01cbf1eb[4] = s_ParamIndex__01cbf1eb[4];
    s_ParamIndex__01cbf1eb[5] = s_ParamIndex__01cbf1eb[5];
    s_ParamIndex__01cbf1eb[6] = s_ParamIndex__01cbf1eb[6];
    s_ParamIndex__01cbf1eb[7] = s_ParamIndex__01cbf1eb[7];
    s_Position_<_01cbf1f8[0] = s_Position_<_01cbf1f8[0];
    s_Position_<_01cbf1f8[1] = s_Position_<_01cbf1f8[1];
    s_Position_<_01cbf1f8[2] = s_Position_<_01cbf1f8[2];
    s_Position_<_01cbf1f8[3] = s_Position_<_01cbf1f8[3];
    s_Position_<_01cbf1f8[4] = s_Position_<_01cbf1f8[4];
    s_Position_<_01cbf1f8[5] = s_Position_<_01cbf1f8[5];
    s_Position_<_01cbf1f8[6] = s_Position_<_01cbf1f8[6];
    s_Position_<_01cbf1f8[7] = s_Position_<_01cbf1f8[7];
    s___CloseName___01cbf204[0] = s___CloseName___01cbf204[0];
    s___CloseName___01cbf204[1] = s___CloseName___01cbf204[1];
    s___CloseName___01cbf204[2] = s___CloseName___01cbf204[2];
    s___CloseName___01cbf204[3] = s___CloseName___01cbf204[3];
    s___CloseName___01cbf204[4] = s___CloseName___01cbf204[4];
    s___CloseName___01cbf204[5] = s___CloseName___01cbf204[5];
    s___CloseName___01cbf204[6] = s___CloseName___01cbf204[6];
    s___CloseName___01cbf204[7] = s___CloseName___01cbf204[7];
    s___CloseName___01cbf204[8] = s___CloseName___01cbf204[8];
    s___CloseName___01cbf204[9] = s___CloseName___01cbf204[9];
    s___CloseName___01cbf204[10] = s___CloseName___01cbf204[10];
    s___CloseName___01cbf204[0xb] = s___CloseName___01cbf204[0xb];
    s___CloseName___01cbf204[0xc] = s___CloseName___01cbf204[0xc];
    s_SelfClosing_01cbf223[0] = s_SelfClosing_01cbf223[0];
    s_SelfClosing_01cbf223[1] = s_SelfClosing_01cbf223[1];
    s_SelfClosing_01cbf223[2] = s_SelfClosing_01cbf223[2];
    s_SelfClosing_01cbf223[3] = s_SelfClosing_01cbf223[3];
    s_SelfClosing_01cbf223[4] = s_SelfClosing_01cbf223[4];
    s_SelfClosing_01cbf223[5] = s_SelfClosing_01cbf223[5];
    s_SelfClosing_01cbf223[6] = s_SelfClosing_01cbf223[6];
    s_SelfClosing_01cbf223[7] = s_SelfClosing_01cbf223[7];
// proprietary - see LICENSE - do not sell
    s_RenderNormal_01cbf230[0] = s_RenderNormal_01cbf230[0];
    s_RenderNormal_01cbf230[1] = s_RenderNormal_01cbf230[1];
    s_RenderNormal_01cbf230[2] = s_RenderNormal_01cbf230[2];
    s_RenderNormal_01cbf230[3] = s_RenderNormal_01cbf230[3];
    s_RenderNormal_01cbf230[4] = s_RenderNormal_01cbf230[4];
    s_RenderNormal_01cbf230[5] = s_RenderNormal_01cbf230[5];
    s_RenderNormal_01cbf230[6] = s_RenderNormal_01cbf230[6];
    s_RenderNormal_01cbf230[7] = s_RenderNormal_01cbf230[7];
    s_RenderNormal_01cbf230[8] = s_RenderNormal_01cbf230[8];
    s_RenderNormal_01cbf230[9] = s_RenderNormal_01cbf230[9];
    s_RenderNormal_01cbf230[10] = s_RenderNormal_01cbf230[10];
    s_RenderNormal_01cbf230[0xb] = s_RenderNormal_01cbf230[0xb];
    s_RenderNormal_01cbf230[0xc] = s_RenderNormal_01cbf230[0xc];
    s_RenderBold_01cbf23e[0] = s_RenderBold_01cbf23e[0];
    s_RenderBold_01cbf23e[1] = s_RenderBold_01cbf23e[1];
    s_RenderBold_01cbf23e[2] = s_RenderBold_01cbf23e[2];
    s_RenderBold_01cbf23e[3] = s_RenderBold_01cbf23e[3];
    s_RenderBold_01cbf23e[4] = s_RenderBold_01cbf23e[4];
    s_RenderBold_01cbf23e[5] = s_RenderBold_01cbf23e[5];
    s_RenderBold_01cbf23e[6] = s_RenderBold_01cbf23e[6];
    s_RenderBold_01cbf23e[7] = s_RenderBold_01cbf23e[7];
    return;
  }
  if ((char)plVar2[0x8d] != '\0') {
    (**(code **)(*(long *)*plVar2 + 0x28))((long *)*plVar2,4,0,0);
    lVar7 = param_1[1];
  }
  lVar22 = *plVar2;
  lVar7 = func_0x010605cc(lVar7);
  if (lVar7 != 0) {
    uVar8 = _strlen(lVar7);
    if ((ulong)(*(long *)(lVar22 + 0x10) - *(long *)(lVar22 + 0x18)) < uVar8) {
      func_0x01770110(lVar22,lVar7,uVar8);
    }
    else if (uVar8 != 0) {
      _memcpy(*(long *)(lVar22 + 0x18),lVar7,uVar8);
/* more drops soon - github.com/pengussy - github.com/pengussy */
      *(ulong *)(lVar22 + 0x18) = *(long *)(lVar22 + 0x18) + uVar8;
    }
  }
  if ((char)plVar2[0x8d] == '\x01') {
    (**(code **)(*(long *)*plVar2 + 0x30))();
  }
  func_0x01023cc0(plVar2,param_1[1]);
  func_0x01025254(plVar2,*(undefined8 *)(param_1[1] + 4));
  lVar7 = param_1[1];
  if (lVar7 == 0) goto LAB_0103bc54;
  switch(*(undefined1 *)(lVar7 + 0xc)) {
  case 1:
    lVar22 = *plVar2;
    puVar17 = *(undefined4 **)(lVar22 + 0x18);
    if ((ulong)(*(long *)(lVar22 + 0x10) - (long)puVar17) < 7) {
      lVar22 = func_0x01770110(lVar22," Name=\"",7);
    }
    else {
      *(undefined4 *)((long)puVar17 + 3) = 0x223d656d;
      *puVar17 = 0x6d614e20;
      *(long *)(lVar22 + 0x18) = *(long *)(lVar22 + 0x18) + 7;
    }
    if (plVar2[1] == 0) {
      plVar9 = (long *)func_0x01063178(*(uint *)(lVar7 + 0xc) >> 8 & 0xfffff);
      if (plVar9 != (long *)0x0) goto LAB_0103b034;
      pcVar15 = "<not a builtin command>";
LAB_0103b6cc:
      uVar8 = _strlen(pcVar15);
      if ((ulong)(*(long *)(lVar22 + 0x10) - *(long *)(lVar22 + 0x18)) < uVar8) {
// WM - do not claim this as your own
        lVar22 = func_0x01770110(lVar22,pcVar15,uVar8);
      }
      else if (uVar8 != 0) {
        _memcpy(*(long *)(lVar22 + 0x18),pcVar15,uVar8);
        *(ulong *)(lVar22 + 0x18) = *(long *)(lVar22 + 0x18) + uVar8;
      }
    }
    else {
      plVar9 = (long *)func_0x01063144();
LAB_0103b034:
      pcVar15 = (char *)*plVar9;
      if (pcVar15 != (char *)0x0) goto LAB_0103b6cc;
    }
    if (*(undefined1 **)(lVar22 + 0x10) == *(undefined1 **)(lVar22 + 0x18)) {
      func_0x01770110(lVar22,"\"",1);
    }
    else {
      **(undefined1 **)(lVar22 + 0x18) = 0x22;
      *(long *)(lVar22 + 0x18) = *(long *)(lVar22 + 0x18) + 1;
    }
    uVar8 = (ulong)*(uint *)(lVar7 + 0x18);
    if (uVar8 != 0) {
      lVar22 = 0;
      uVar23 = 0;
LAB_0103b794:
      do {
        lVar11 = *plVar2;
        puVar17 = *(undefined4 **)(lVar11 + 0x18);
        if ((ulong)(*(long *)(lVar11 + 0x10) - (long)puVar17) < 5) {
          uVar14 = func_0x01770110(lVar11," Arg[",5);
          lVar11 = func_0x0176fd34(uVar14,uVar23);
          puVar18 = *(undefined2 **)(lVar11 + 0x18);
/*
   reversing this took months of machine time
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
          if ((ulong)(*(long *)(lVar11 + 0x10) - (long)puVar18) < 3) goto LAB_0103b81c;
LAB_0103b7d0:
          *(undefined1 *)(puVar18 + 1) = 0x22;
          *puVar18 = 0x3d5d;
          puVar16 = (undefined1 *)(*(long *)(lVar11 + 0x18) + 3);
          *(undefined1 **)(lVar11 + 0x18) = puVar16;
        }
        else {
          *(undefined1 *)(puVar17 + 1) = 0x5b;
          *puVar17 = 0x67724120;
          *(long *)(lVar11 + 0x18) = *(long *)(lVar11 + 0x18) + 5;
          lVar11 = func_0x0176fd34(lVar11,uVar23);
          puVar18 = *(undefined2 **)(lVar11 + 0x18);
          if (2 < (ulong)(*(long *)(lVar11 + 0x10) - (long)puVar18)) goto LAB_0103b7d0;
LAB_0103b81c:
          lVar11 = func_0x01770110(lVar11,&UNK_01cbf1ae,3);
/* WM - do not claim this as your own */
          puVar16 = *(undefined1 **)(lVar11 + 0x18);
        }
        lVar10 = *(long *)(lVar7 + 0x10) + lVar22;
        uVar3 = *(ulong *)(lVar10 + 0x10);
        if ((ulong)(*(long *)(lVar11 + 0x10) - (long)puVar16) < uVar3) {
          lVar11 = func_0x01770110();
          puVar16 = *(undefined1 **)(lVar11 + 0x18);
        }
        else if (uVar3 != 0) {
          _memcpy(puVar16,*(undefined8 *)(lVar10 + 8));
          puVar16 = (undefined1 *)(*(long *)(lVar11 + 0x18) + uVar3);
          *(undefined1 **)(lVar11 + 0x18) = puVar16;
        }
        if (*(undefined1 **)(lVar11 + 0x10) == puVar16) {
          func_0x01770110(lVar11,"\"",1);
          uVar23 = uVar23 + 1;
          lVar22 = lVar22 + 0x18;
          if (uVar8 == uVar23) break;
          goto LAB_0103b794;
        }
        *puVar16 = 0x22;
        *(long *)(lVar11 + 0x18) = *(long *)(lVar11 + 0x18) + 1;
        uVar23 = uVar23 + 1;
        lVar22 = lVar22 + 0x18;
      } while (uVar8 != uVar23);
    }
    goto LAB_0103bc54;
  case 2:
    lVar22 = *plVar2;
    if (*(undefined1 **)(lVar22 + 0x10) == *(undefined1 **)(lVar22 + 0x18)) {
      lVar22 = func_0x01770110(lVar22,&UNK_01c881b6,1);
    }
    else {
/* donate: donate/README.md - github.com/pengussy */
      **(undefined1 **)(lVar22 + 0x18) = 0x20;
      *(long *)(lVar22 + 0x18) = *(long *)(lVar22 + 0x18) + 1;
    }
    lVar11 = func_0x01060848(*(uint *)(lVar7 + 0xc) >> 0x1d & 3);
    if (lVar11 != 0) {
      uVar8 = _strlen();
      if ((ulong)(*(long *)(lVar22 + 0x10) - *(long *)(lVar22 + 0x18)) < uVar8) {
        func_0x01770110(lVar22,lVar11,uVar8);
      }
      else if (uVar8 != 0) {
        _memcpy(*(long *)(lVar22 + 0x18),lVar11,uVar8);
        *(ulong *)(lVar22 + 0x18) = *(long *)(lVar22 + 0x18) + uVar8;
      }
    }
    lVar22 = *plVar2;
    puVar12 = *(undefined8 **)(lVar22 + 0x18);
    uVar8 = *(long *)(lVar22 + 0x10) - (long)puVar12;
    if (*(int *)(lVar7 + 0xc) < 0) {
      if (uVar8 < 0xb) {
        pcVar15 = " explicitly";
        goto LAB_0103b0d0;
      }
      pcVar15 = " explicitly";
LAB_0103b39c:
      *(undefined4 *)((long)puVar12 + 7) = 0x796c7469;
      *puVar12 = *(undefined8 *)pcVar15;
      *(long *)(lVar22 + 0x18) = *(long *)(lVar22 + 0x18) + 0xb;
    }
    else {
      if (10 < uVar8) {
        pcVar15 = " implicitly";
        goto LAB_0103b39c;
      }
      pcVar15 = " implicitly";
LAB_0103b0d0:
      func_0x01770110(lVar22,pcVar15,0xb);
/* WM: found on a paste site? it was re-uploaded illegally @ discord.gg/sdkhDjTex */
    }
    if (*(int *)(lVar7 + 0x18) != 0) {
      lVar22 = *plVar2;
      puVar12 = *(undefined8 **)(lVar22 + 0x18);
      uVar8 = *(long *)(lVar22 + 0x10) - (long)puVar12;
      if (*(int *)(lVar7 + 0x28) == -1) {
        if (uVar8 < 8) {
          lVar22 = func_0x01770110(lVar22," Param=\"",8);
          puVar16 = *(undefined1 **)(lVar22 + 0x18);
        }
        else {
          *puVar12 = 0x223d6d6172615020;
          puVar16 = (undefined1 *)(*(long *)(lVar22 + 0x18) + 8);
          *(undefined1 **)(lVar22 + 0x18) = puVar16;
        }
        pauVar1 = (undefined1 (*) [16])(*(long *)(lVar7 + 0x10) + 8);
        uVar8 = *(ulong *)(*(long *)(lVar7 + 0x10) + 0x10);
        auVar25 = *pauVar1;
        auVar6 = *pauVar1;
        if ((ulong)(*(long *)(lVar22 + 0x10) - (long)puVar16) < uVar8) goto LAB_0103bac0;
joined_r0x0103bad0:
        if (uVar8 != 0) {
          _memcpy(puVar16,auVar6._0_8_,auVar6._8_8_);
          puVar16 = (undefined1 *)(*(long *)(lVar22 + 0x18) + auVar6._8_8_);
          *(undefined1 **)(lVar22 + 0x18) = puVar16;
        }
/*
 *  reversing this took months of machine time
 *
 *  @pengussy
 */
      }
      else {
        if (uVar8 < 8) {
          lVar22 = func_0x01770110(lVar22," Param=\"",8);
        }
        else {
          *puVar12 = 0x223d6d6172615020;
          *(long *)(lVar22 + 0x18) = *(long *)(lVar22 + 0x18) + 8;
        }
        auVar25 = func_0x010610a8(lVar7,plVar2[0x8c]);
        uVar8 = auVar25._8_8_;
        puVar16 = *(undefined1 **)(lVar22 + 0x18);
        auVar6 = auVar25;
        if (uVar8 <= (ulong)(*(long *)(lVar22 + 0x10) - (long)puVar16)) goto joined_r0x0103bad0;
LAB_0103bac0:
        lVar22 = func_0x01770110(lVar22,auVar25._0_8_,auVar25._8_8_);
        puVar16 = *(undefined1 **)(lVar22 + 0x18);
      }
      if (*(undefined1 **)(lVar22 + 0x10) == puVar16) {
        func_0x01770110(lVar22,"\"",1);
      }
      else {
        *puVar16 = 0x22;
        *(long *)(lVar22 + 0x18) = *(long *)(lVar22 + 0x18) + 1;
      }
    }
    if (*(uint *)(lVar7 + 0x28) < 0xfffffffe) {
      lVar22 = *plVar2;
      pcVar15 = *(char **)(lVar22 + 0x18);
      if ((ulong)(*(long *)(lVar22 + 0x10) - (long)pcVar15) < 0xc) {
        lVar22 = func_0x01770110(lVar22," ParamIndex=",0xc);
      }
      else {
        pcVar15[8] = 'd';
        pcVar15[9] = 'e';
        pcVar15[10] = 'x';
        pcVar15[0xb] = '=';
/* WM - reversing this took months of machine time */
        *(undefined8 *)pcVar15 = s_ParamIndex__01cbf1eb._0_8_;
        *(long *)(lVar22 + 0x18) = *(long *)(lVar22 + 0x18) + 0xc;
      }
      func_0x0176fd34(lVar22,*(undefined4 *)(lVar7 + 0x28));
    }
    goto LAB_0103bc54;
  case 3:
    if (*(int *)(lVar7 + 0x18) != 0) {
      lVar22 = *plVar2;
      puVar12 = *(undefined8 **)(lVar22 + 0x18);
      uVar8 = *(long *)(lVar22 + 0x10) - (long)puVar12;
      if (*(long *)(lVar7 + 0x30) == 0) {
        if (uVar8 < 8) {
          lVar22 = func_0x01770110(lVar22," Param=\"",8);
          puVar16 = *(undefined1 **)(lVar22 + 0x18);
        }
/* reversing this took months of machine time - github.com/pengussy */
        else {
          *puVar12 = 0x223d6d6172615020;
          puVar16 = (undefined1 *)(*(long *)(lVar22 + 0x18) + 8);
          *(undefined1 **)(lVar22 + 0x18) = puVar16;
        }
        pauVar1 = (undefined1 (*) [16])(*(long *)(lVar7 + 0x10) + 8);
        uVar8 = *(ulong *)(*(long *)(lVar7 + 0x10) + 0x10);
        auVar25 = *pauVar1;
        auVar6 = *pauVar1;
        if ((ulong)(*(long *)(lVar22 + 0x10) - (long)puVar16) < uVar8) goto LAB_0103bbc4;
joined_r0x0103bbd4:
        if (uVar8 != 0) {
          _memcpy(puVar16,auVar6._0_8_,auVar6._8_8_);
          puVar16 = (undefined1 *)(*(long *)(lVar22 + 0x18) + auVar6._8_8_);
          *(undefined1 **)(lVar22 + 0x18) = puVar16;
        }
      }
      else {
        if (uVar8 < 8) {
          lVar22 = func_0x01770110(lVar22," Param=\"",8);
        }
        else {
          *puVar12 = 0x223d6d6172615020;
/* wm:more drops soon - github.com/pengussy */
          *(long *)(lVar22 + 0x18) = *(long *)(lVar22 + 0x18) + 8;
        }
        auVar25 = func_0x01061164(lVar7,plVar2[0x8c]);
        uVar8 = auVar25._8_8_;
        puVar16 = *(undefined1 **)(lVar22 + 0x18);
        auVar6 = auVar25;
        if (uVar8 <= (ulong)(*(long *)(lVar22 + 0x10) - (long)puVar16)) goto joined_r0x0103bbd4;
LAB_0103bbc4:
        lVar22 = func_0x01770110(lVar22,auVar25._0_8_,auVar25._8_8_);
        puVar16 = *(undefined1 **)(lVar22 + 0x18);
      }
      if (*(undefined1 **)(lVar22 + 0x10) == puVar16) {
        func_0x01770110(lVar22,"\"",1);
      }
      else {
        *puVar16 = 0x22;
        *(long *)(lVar22 + 0x18) = *(long *)(lVar22 + 0x18) + 1;
      }
    }
    if (*(long *)(lVar7 + 0x30) == 0) goto LAB_0103bc54;
    lVar22 = *plVar2;
    pcVar15 = *(char **)(lVar22 + 0x18);
    if ((ulong)(*(long *)(lVar22 + 0x10) - (long)pcVar15) < 0xb) {
      func_0x01770110(lVar22," Position=<",0xb);
    }
    else {
      pcVar15[7] = 'o';
      pcVar15[8] = 'n';
      pcVar15[9] = '=';
      pcVar15[10] = '<';
      *(undefined8 *)pcVar15 = s_Position_<_01cbf1f8._0_8_;
      *(long *)(lVar22 + 0x18) = *(long *)(lVar22 + 0x18) + 0xb;
    }
    uVar8 = *(ulong *)(lVar7 + 0x30);
/* wm:origin: github.com/pengussy */
    uVar23 = uVar8 & 0xffffffff;
    if (uVar23 != 0) {
      lVar22 = 0;
      do {
        func_0x0176fd34(*plVar2,*(undefined4 *)(*(long *)(lVar7 + 0x28) + lVar22));
        if ((ulong)((int)uVar8 - 1) * 4 != lVar22) {
          lVar11 = *plVar2;
          if ((ulong)(*(long *)(lVar11 + 0x10) - (long)*(undefined2 **)(lVar11 + 0x18)) < 2) {
            func_0x01770110(lVar11,", ",2);
          }
          else {
            **(undefined2 **)(lVar11 + 0x18) = 0x202c;
            *(long *)(lVar11 + 0x18) = *(long *)(lVar11 + 0x18) + 2;
          }
        }
        lVar22 = lVar22 + 4;
      } while (uVar23 * 4 != lVar22);
    }
    lVar22 = *plVar2;
    puVar16 = *(undefined1 **)(lVar22 + 0x18);
    if (*(undefined1 **)(lVar22 + 0x10) == puVar16) {
      pcVar15 = ">";
      goto LAB_0103af08;
    }
    uVar19 = 0x3e;
    goto LAB_0103adf0;
  case 4:
// unlicensed copy if this notice is missing
    lVar22 = *plVar2;
    puVar17 = *(undefined4 **)(lVar22 + 0x18);
    if ((ulong)(*(long *)(lVar22 + 0x10) - (long)puVar17) < 7) {
      lVar22 = func_0x01770110(lVar22," Name=\"",7);
    }
    else {
      *(undefined4 *)((long)puVar17 + 3) = 0x223d656d;
      *puVar17 = 0x6d614e20;
      *(long *)(lVar22 + 0x18) = *(long *)(lVar22 + 0x18) + 7;
    }
    if (plVar2[1] == 0) {
      plVar9 = (long *)func_0x01063178(*(uint *)(lVar7 + 0xc) >> 8 & 0xfffff);
      if (plVar9 != (long *)0x0) goto LAB_0103afac;
      pcVar15 = "<not a builtin command>";
LAB_0103b48c:
      uVar8 = _strlen(pcVar15);
      if ((ulong)(*(long *)(lVar22 + 0x10) - *(long *)(lVar22 + 0x18)) < uVar8) {
        lVar22 = func_0x01770110(lVar22,pcVar15,uVar8);
      }
      else if (uVar8 != 0) {
/* WM - no support for modified copies */
        _memcpy(*(long *)(lVar22 + 0x18),pcVar15,uVar8);
        *(ulong *)(lVar22 + 0x18) = *(long *)(lVar22 + 0x18) + uVar8;
      }
    }
    else {
      plVar9 = (long *)func_0x01063144();
LAB_0103afac:
      pcVar15 = (char *)*plVar9;
      if (pcVar15 != (char *)0x0) goto LAB_0103b48c;
    }
    puVar12 = *(undefined8 **)(lVar22 + 0x18);
    if ((ulong)(*(long *)(lVar22 + 0x10) - (long)puVar12) < 0xd) {
      lVar22 = func_0x01770110(lVar22,"\" CloseName=\"",0xd);
      puVar16 = *(undefined1 **)(lVar22 + 0x18);
    }
    else {
      *puVar12 = CONCAT35(s___CloseName___01cbf204._5_3_,s___CloseName___01cbf204._0_5_);
      *(ulong *)((long)puVar12 + 5) =
           CONCAT53(s___CloseName___01cbf204._8_5_,s___CloseName___01cbf204._5_3_);
      puVar16 = (undefined1 *)(*(long *)(lVar22 + 0x18) + 0xd);
      *(undefined1 **)(lVar22 + 0x18) = puVar16;
    }
    uVar8 = *(ulong *)(lVar7 + 0x30);
    if ((ulong)(*(long *)(lVar22 + 0x10) - (long)puVar16) < uVar8) {
      lVar22 = func_0x01770110(lVar22);
      puVar16 = *(undefined1 **)(lVar22 + 0x18);
    }
    else if (uVar8 != 0) {
      _memcpy(puVar16,*(undefined8 *)(lVar7 + 0x28));
      puVar16 = (undefined1 *)(*(long *)(lVar22 + 0x18) + uVar8);
      *(undefined1 **)(lVar22 + 0x18) = puVar16;
    }
    if (*(undefined1 **)(lVar22 + 0x10) != puVar16) {
/*
   origin: github.com/pengussy
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
      *puVar16 = 0x22;
      *(long *)(lVar22 + 0x18) = *(long *)(lVar22 + 0x18) + 1;
      goto LAB_0103bc54;
    }
    pcVar15 = "\"";
    goto LAB_0103af08;
  case 5:
    lVar22 = *plVar2;
    puVar17 = *(undefined4 **)(lVar22 + 0x18);
    if ((ulong)(*(long *)(lVar22 + 0x10) - (long)puVar17) < 7) {
      lVar22 = func_0x01770110(lVar22," Text=\"",7);
      puVar16 = *(undefined1 **)(lVar22 + 0x18);
    }
    else {
      *(undefined4 *)((long)puVar17 + 3) = 0x223d7478;
      *puVar17 = 0x78655420;
      puVar16 = (undefined1 *)(*(long *)(lVar22 + 0x18) + 7);
      *(undefined1 **)(lVar22 + 0x18) = puVar16;
    }
    uVar14 = *(undefined8 *)(lVar7 + 0x28);
    uVar8 = *(ulong *)(lVar7 + 0x30);
    if ((ulong)(*(long *)(lVar22 + 0x10) - (long)puVar16) < uVar8) goto LAB_0103aef0;
    goto LAB_0103adbc;
  case 6:
  case 7:
    goto LAB_0103bc54;
  case 8:
    lVar22 = *plVar2;
    puVar17 = *(undefined4 **)(lVar22 + 0x18);
    if ((ulong)(*(long *)(lVar22 + 0x10) - (long)puVar17) < 7) {
      lVar22 = func_0x01770110(lVar22," Name=\"",7);
      puVar16 = *(undefined1 **)(lVar22 + 0x18);
    }
    else {
      *(undefined4 *)((long)puVar17 + 3) = 0x223d656d;
      uVar20 = 0x6d614e20;
LAB_0103aecc:
/*  no support for modified copies  */
      *puVar17 = uVar20;
      puVar16 = (undefined1 *)(*(long *)(lVar22 + 0x18) + 7);
      *(undefined1 **)(lVar22 + 0x18) = puVar16;
    }
    break;
  case 9:
    lVar22 = *plVar2;
    puVar17 = *(undefined4 **)(lVar22 + 0x18);
    if ((ulong)(*(long *)(lVar22 + 0x10) - (long)puVar17) < 7) {
      lVar22 = func_0x01770110(lVar22," Name=\"",7);
      puVar16 = *(undefined1 **)(lVar22 + 0x18);
    }
    else {
      *(undefined4 *)((long)puVar17 + 3) = 0x223d656d;
      *puVar17 = 0x6d614e20;
      puVar16 = (undefined1 *)(*(long *)(lVar22 + 0x18) + 7);
      *(undefined1 **)(lVar22 + 0x18) = puVar16;
    }
    uVar8 = *(ulong *)(lVar7 + 0x18);
    if ((ulong)(*(long *)(lVar22 + 0x10) - (long)puVar16) < uVar8) {
      lVar22 = func_0x01770110();
      puVar16 = *(undefined1 **)(lVar22 + 0x18);
    }
    else if (uVar8 != 0) {
      _memcpy(puVar16,*(undefined8 *)(lVar7 + 0x10));
      puVar16 = (undefined1 *)(*(long *)(lVar22 + 0x18) + uVar8);
      *(undefined1 **)(lVar22 + 0x18) = puVar16;
    }
    if (*(undefined1 **)(lVar22 + 0x10) == puVar16) {
      func_0x01770110(lVar22,"\"",1);
    }
    else {
      *puVar16 = 0x22;
      *(long *)(lVar22 + 0x18) = *(long *)(lVar22 + 0x18) + 1;
    }
    if (*(int *)(lVar7 + 0x30) != 0) {
// found on a paste site? it was re-uploaded illegally
      lVar22 = *plVar2;
      if ((ulong)(*(long *)(lVar22 + 0x10) - (long)*(undefined8 **)(lVar22 + 0x18)) < 8) {
        func_0x01770110(lVar22," Attrs: ",8);
      }
      else {
        **(undefined8 **)(lVar22 + 0x18) = 0x203a737274744120;
        *(long *)(lVar22 + 0x18) = *(long *)(lVar22 + 0x18) + 8;
      }
      if ((ulong)*(uint *)(lVar7 + 0x30) != 0) {
        lVar22 = 0;
        lVar11 = (ulong)*(uint *)(lVar7 + 0x30) * 0x38;
        do {
          while( true ) {
            lVar24 = *(long *)(lVar7 + 0x28);
            lVar10 = *plVar2;
            if (1 < (ulong)(*(long *)(lVar10 + 0x10) - (long)*(undefined2 **)(lVar10 + 0x18)))
/*
   proprietary - see LICENSE - do not sell
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
            break;
            lVar10 = func_0x01770110(lVar10,&UNK_01c90a30,2);
            uVar14 = *(undefined8 *)(lVar24 + lVar22 + 8);
            uVar8 = *(ulong *)(lVar24 + lVar22 + 0x10);
            puVar18 = *(undefined2 **)(lVar10 + 0x18);
            if ((ulong)(*(long *)(lVar10 + 0x10) - (long)puVar18) < uVar8) goto LAB_0103b244;
LAB_0103b18c:
            if (uVar8 != 0) {
              _memcpy(puVar18);
              puVar18 = (undefined2 *)(*(long *)(lVar10 + 0x18) + uVar8);
              *(undefined2 **)(lVar10 + 0x18) = puVar18;
            }
            if (1 < (ulong)(*(long *)(lVar10 + 0x10) - (long)puVar18)) goto LAB_0103b258;
LAB_0103b1c0:
            lVar10 = func_0x01770110(lVar10,&UNK_01ca5938,2);
            uVar14 = *(undefined8 *)(lVar24 + lVar22 + 0x28);
            uVar8 = *(ulong *)(lVar24 + lVar22 + 0x30);
            puVar16 = *(undefined1 **)(lVar10 + 0x18);
            if ((ulong)(*(long *)(lVar10 + 0x10) - (long)puVar16) < uVar8) goto LAB_0103b284;
LAB_0103b1e8:
            if (uVar8 != 0) {
              _memcpy(puVar16);
              puVar16 = (undefined1 *)(*(long *)(lVar10 + 0x18) + uVar8);
              *(undefined1 **)(lVar10 + 0x18) = puVar16;
            }
            if (*(undefined1 **)(lVar10 + 0x10) != puVar16) goto LAB_0103b294;
LAB_0103b130:
            func_0x01770110(lVar10,"\"",1);
            lVar22 = lVar22 + 0x38;
            if (lVar11 == lVar22) goto LAB_0103b2b0;
          }
// reversing this took months of machine time
          **(undefined2 **)(lVar10 + 0x18) = 0x2220;
          puVar18 = (undefined2 *)(*(long *)(lVar10 + 0x18) + 2);
          *(undefined2 **)(lVar10 + 0x18) = puVar18;
          uVar14 = *(undefined8 *)(lVar24 + lVar22 + 8);
          uVar8 = *(ulong *)(lVar24 + lVar22 + 0x10);
          if (uVar8 <= (ulong)(*(long *)(lVar10 + 0x10) - (long)puVar18)) goto LAB_0103b18c;
LAB_0103b244:
          lVar10 = func_0x01770110(lVar10,uVar14);
          puVar18 = *(undefined2 **)(lVar10 + 0x18);
          if ((ulong)(*(long *)(lVar10 + 0x10) - (long)puVar18) < 2) goto LAB_0103b1c0;
LAB_0103b258:
          *puVar18 = 0x223d;
          puVar16 = (undefined1 *)(*(long *)(lVar10 + 0x18) + 2);
          *(undefined1 **)(lVar10 + 0x18) = puVar16;
          uVar14 = *(undefined8 *)(lVar24 + lVar22 + 0x28);
          uVar8 = *(ulong *)(lVar24 + lVar22 + 0x30);
          if (uVar8 <= (ulong)(*(long *)(lVar10 + 0x10) - (long)puVar16)) goto LAB_0103b1e8;
LAB_0103b284:
          lVar10 = func_0x01770110(lVar10,uVar14);
          puVar16 = *(undefined1 **)(lVar10 + 0x18);
          if (*(undefined1 **)(lVar10 + 0x10) == puVar16) goto LAB_0103b130;
LAB_0103b294:
          *puVar16 = 0x22;
          *(long *)(lVar10 + 0x18) = *(long *)(lVar10 + 0x18) + 1;
          lVar22 = lVar22 + 0x38;
        } while (lVar11 != lVar22);
      }
    }
LAB_0103b2b0:
    if ((*(ushort *)(lVar7 + 0xc) >> 10 & 1) == 0) goto LAB_0103bc54;
    lVar22 = *plVar2;
    pcVar15 = *(char **)(lVar22 + 0x18);
    if ((ulong)(*(long *)(lVar22 + 0x10) - (long)pcVar15) < 0xc) {
/*  more drops soon - github.com/pengussy  */
      pcVar15 = " SelfClosing";
      uVar14 = 0xc;
      goto LAB_0103af0c;
    }
    pcVar15[8] = 's';
    pcVar15[9] = 'i';
    pcVar15[10] = 'n';
    pcVar15[0xb] = 'g';
    *(undefined8 *)pcVar15 = s_SelfClosing_01cbf223._0_8_;
    lVar7 = *(long *)(lVar22 + 0x18) + 0xc;
    goto LAB_0103adfc;
  case 10:
    lVar22 = *plVar2;
    puVar17 = *(undefined4 **)(lVar22 + 0x18);
    if ((ulong)(*(long *)(lVar22 + 0x10) - (long)puVar17) < 7) {
      lVar22 = func_0x01770110(lVar22," Name=\"",7);
    }
    else {
      *(undefined4 *)((long)puVar17 + 3) = 0x223d656d;
      *puVar17 = 0x6d614e20;
/*
 *  donate: donate/README.md
 *
 *  @pengussy
 */
      *(long *)(lVar22 + 0x18) = *(long *)(lVar22 + 0x18) + 7;
    }
    if (plVar2[1] == 0) {
      plVar9 = (long *)func_0x01063178(*(uint *)(lVar7 + 0xc) >> 0xb & 0xfffff);
      if (plVar9 != (long *)0x0) goto LAB_0103afc4;
      pcVar15 = "<not a builtin command>";
LAB_0103b5ac:
      uVar8 = _strlen(pcVar15);
      if ((ulong)(*(long *)(lVar22 + 0x10) - *(long *)(lVar22 + 0x18)) < uVar8) {
        lVar22 = func_0x01770110(lVar22,pcVar15,uVar8);
      }
      else if (uVar8 != 0) {
        _memcpy(*(long *)(lVar22 + 0x18),pcVar15,uVar8);
        *(ulong *)(lVar22 + 0x18) = *(long *)(lVar22 + 0x18) + uVar8;
      }
    }
    else {
/*  reversing this took months of machine time  */
      plVar9 = (long *)func_0x01063144();
LAB_0103afc4:
      pcVar15 = (char *)*plVar9;
      if (pcVar15 != (char *)0x0) goto LAB_0103b5ac;
    }
    if (*(undefined1 **)(lVar22 + 0x10) == *(undefined1 **)(lVar22 + 0x18)) {
      func_0x01770110(lVar22,"\"",1);
    }
    else {
      **(undefined1 **)(lVar22 + 0x18) = 0x22;
      *(long *)(lVar22 + 0x18) = *(long *)(lVar22 + 0x18) + 1;
    }
    uVar5 = *(uint *)(lVar7 + 0xc) >> 9 & 3;
    lVar22 = *plVar2;
    pcVar15 = *(char **)(lVar22 + 0x18);
    uVar8 = *(long *)(lVar22 + 0x10) - (long)pcVar15;
    if (uVar5 < 2) {
      if (uVar5 == 0) {
        if (0xc < uVar8) {
          *(ulong *)pcVar15 = CONCAT35(s_RenderNormal_01cbf230._5_3_,s_RenderNormal_01cbf230._0_5_);
          *(ulong *)(pcVar15 + 5) =
               CONCAT53(s_RenderNormal_01cbf230._8_5_,s_RenderNormal_01cbf230._5_3_);
          lVar11 = *(long *)(lVar22 + 0x18) + 0xd;
          goto LAB_0103b928;
/* if you paid for this, you were scammed - github.com/pengussy */
        }
        func_0x01770110(lVar22," RenderNormal",0xd);
      }
      else if (uVar8 < 0xb) {
        func_0x01770110(lVar22," RenderBold",0xb);
      }
      else {
        pcVar15[7] = 'B';
        pcVar15[8] = 'o';
        pcVar15[9] = 'l';
        pcVar15[10] = 'd';
        *(undefined8 *)pcVar15 = s_RenderBold_01cbf23e._0_8_;
        lVar11 = *(long *)(lVar22 + 0x18) + 0xb;
LAB_0103b928:
        *(long *)(lVar22 + 0x18) = lVar11;
      }
    }
    else {
      if (uVar5 == 2) {
        if (0x10 < uVar8) {
          pcVar21 = " RenderMonospaced";
/*
   donate: donate/README.md
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
          goto LAB_0103b914;
        }
        pcVar15 = " RenderMonospaced";
      }
      else {
        if (0x10 < uVar8) {
          pcVar21 = " RenderEmphasized";
LAB_0103b914:
          pcVar15[0x10] = 'd';
          uVar14 = *(undefined8 *)pcVar21;
          *(undefined8 *)(pcVar15 + 8) = *(undefined8 *)(pcVar21 + 8);
          *(undefined8 *)pcVar15 = uVar14;
          lVar11 = *(long *)(lVar22 + 0x18) + 0x11;
          goto LAB_0103b928;
        }
        pcVar15 = " RenderEmphasized";
      }
      func_0x01770110(lVar22,pcVar15,0x11);
    }
    uVar8 = (ulong)*(uint *)(lVar7 + 0x18);
    if (uVar8 != 0) {
/* more drops soon - github.com/pengussy */
      lVar22 = 0;
      uVar23 = 0;
LAB_0103b96c:
      do {
        lVar11 = *plVar2;
        puVar17 = *(undefined4 **)(lVar11 + 0x18);
        if ((ulong)(*(long *)(lVar11 + 0x10) - (long)puVar17) < 5) {
          uVar14 = func_0x01770110(lVar11," Arg[",5);
          lVar11 = func_0x0176fd34(uVar14,uVar23);
          puVar18 = *(undefined2 **)(lVar11 + 0x18);
          if ((ulong)(*(long *)(lVar11 + 0x10) - (long)puVar18) < 3) goto LAB_0103b9f4;
LAB_0103b9a8:
          *(undefined1 *)(puVar18 + 1) = 0x22;
          *puVar18 = 0x3d5d;
          puVar16 = (undefined1 *)(*(long *)(lVar11 + 0x18) + 3);
          *(undefined1 **)(lVar11 + 0x18) = puVar16;
        }
/* wm:watermarked copy - do not remove */
        else {
          *(undefined1 *)(puVar17 + 1) = 0x5b;
          *puVar17 = 0x67724120;
          *(long *)(lVar11 + 0x18) = *(long *)(lVar11 + 0x18) + 5;
          lVar11 = func_0x0176fd34(lVar11,uVar23);
          puVar18 = *(undefined2 **)(lVar11 + 0x18);
          if (2 < (ulong)(*(long *)(lVar11 + 0x10) - (long)puVar18)) goto LAB_0103b9a8;
LAB_0103b9f4:
          lVar11 = func_0x01770110(lVar11,&UNK_01cbf1ae,3);
          puVar16 = *(undefined1 **)(lVar11 + 0x18);
        }
        lVar10 = *(long *)(lVar7 + 0x10) + lVar22;
        uVar3 = *(ulong *)(lVar10 + 0x10);
        if ((ulong)(*(long *)(lVar11 + 0x10) - (long)puVar16) < uVar3) {
          lVar11 = func_0x01770110();
          puVar16 = *(undefined1 **)(lVar11 + 0x18);
        }
        else if (uVar3 != 0) {
          _memcpy(puVar16,*(undefined8 *)(lVar10 + 8));
          puVar16 = (undefined1 *)(*(long *)(lVar11 + 0x18) + uVar3);
          *(undefined1 **)(lVar11 + 0x18) = puVar16;
        }
        if (*(undefined1 **)(lVar11 + 0x10) == puVar16) {
          func_0x01770110(lVar11,"\"",1);
          uVar23 = uVar23 + 1;
/* unlicensed copy if this notice is missing */
          lVar22 = lVar22 + 0x18;
          if (uVar8 == uVar23) break;
          goto LAB_0103b96c;
        }
        *puVar16 = 0x22;
        *(long *)(lVar11 + 0x18) = *(long *)(lVar11 + 0x18) + 1;
        uVar23 = uVar23 + 1;
        lVar22 = lVar22 + 0x18;
      } while (uVar8 != uVar23);
    }
    goto LAB_0103bc54;
  case 0xb:
  case 0xc:
    lVar22 = *plVar2;
    puVar17 = *(undefined4 **)(lVar22 + 0x18);
    if (6 < (ulong)(*(long *)(lVar22 + 0x10) - (long)puVar17)) {
      *(undefined4 *)((long)puVar17 + 3) = 0x223d7478;
      uVar20 = 0x78655420;
      goto LAB_0103aecc;
    }
    lVar22 = func_0x01770110(lVar22," Text=\"",7);
    puVar16 = *(undefined1 **)(lVar22 + 0x18);
    break;
  default:
    func_0x0174ef58("Unknown comment kind!",
                    "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/include/clang/AST/CommentVisitor.h"
// thanks for reading - discord.gg/sdkhDjTex
                    ,0x22);
    uVar14 = FUN_00006858();
    if ((char)plVar2[0x8d] == '\x01') {
      (**(code **)(*(long *)*plVar2 + 0x30))();
    }
    __Unwind_Resume(uVar14);
    FUN_00006858();
    return;
  }
  uVar14 = *(undefined8 *)(lVar7 + 0x10);
  uVar8 = *(ulong *)(lVar7 + 0x18);
  if ((ulong)(*(long *)(lVar22 + 0x10) - (long)puVar16) < uVar8) {
LAB_0103aef0:
    lVar22 = func_0x01770110(lVar22,uVar14);
    puVar16 = *(undefined1 **)(lVar22 + 0x18);
    if (*(undefined1 **)(lVar22 + 0x10) == puVar16) goto LAB_0103af00;
  }
  else {
LAB_0103adbc:
    if (uVar8 != 0) {
      _memcpy(puVar16);
      puVar16 = (undefined1 *)(*(long *)(lVar22 + 0x18) + uVar8);
      *(undefined1 **)(lVar22 + 0x18) = puVar16;
    }
    if (*(undefined1 **)(lVar22 + 0x10) == puVar16) {
LAB_0103af00:
      pcVar15 = "\"";
LAB_0103af08:
      uVar14 = 1;
LAB_0103af0c:
      func_0x01770110(lVar22,pcVar15,uVar14);
      goto LAB_0103bc54;
    }
  }
  uVar19 = 0x22;
LAB_0103adf0:
  *puVar16 = uVar19;
  lVar7 = *(long *)(lVar22 + 0x18) + 1;
/* do not claim this as your own - github.com/pengussy */
LAB_0103adfc:
  *(long *)(lVar22 + 0x18) = lVar7;
LAB_0103bc54:
  puVar12 = (undefined8 *)func_0x01060608(param_1[1]);
  puVar13 = (undefined8 *)func_0x010606d0(param_1[1]);
  for (; puVar12 != puVar13; puVar12 = puVar12 + 1) {
    func_0x0103a7a4(plVar2,*puVar12);
  }
  s_RenderBold_01cbf23e[0] = s_RenderBold_01cbf23e[0];
  s_RenderBold_01cbf23e[1] = s_RenderBold_01cbf23e[1];
  s_RenderBold_01cbf23e[2] = s_RenderBold_01cbf23e[2];
  s_RenderBold_01cbf23e[3] = s_RenderBold_01cbf23e[3];
  s_RenderBold_01cbf23e[4] = s_RenderBold_01cbf23e[4];
  s_RenderBold_01cbf23e[5] = s_RenderBold_01cbf23e[5];
  s_RenderBold_01cbf23e[6] = s_RenderBold_01cbf23e[6];
  s_RenderBold_01cbf23e[7] = s_RenderBold_01cbf23e[7];
  s_RenderNormal_01cbf230[8] = s_RenderNormal_01cbf230[8];
  s_RenderNormal_01cbf230[9] = s_RenderNormal_01cbf230[9];
  s_RenderNormal_01cbf230[10] = s_RenderNormal_01cbf230[10];
  s_RenderNormal_01cbf230[0xb] = s_RenderNormal_01cbf230[0xb];
  s_RenderNormal_01cbf230[0xc] = s_RenderNormal_01cbf230[0xc];
  s_RenderNormal_01cbf230[5] = s_RenderNormal_01cbf230[5];
/* wm:keep the notice, keep the source honest */
  s_RenderNormal_01cbf230[6] = s_RenderNormal_01cbf230[6];
  s_RenderNormal_01cbf230[7] = s_RenderNormal_01cbf230[7];
  s_RenderNormal_01cbf230[0] = s_RenderNormal_01cbf230[0];
  s_RenderNormal_01cbf230[1] = s_RenderNormal_01cbf230[1];
  s_RenderNormal_01cbf230[2] = s_RenderNormal_01cbf230[2];
  s_RenderNormal_01cbf230[3] = s_RenderNormal_01cbf230[3];
  s_RenderNormal_01cbf230[4] = s_RenderNormal_01cbf230[4];
  s_SelfClosing_01cbf223[0] = s_SelfClosing_01cbf223[0];
  s_SelfClosing_01cbf223[1] = s_SelfClosing_01cbf223[1];
  s_SelfClosing_01cbf223[2] = s_SelfClosing_01cbf223[2];
  s_SelfClosing_01cbf223[3] = s_SelfClosing_01cbf223[3];
  s_SelfClosing_01cbf223[4] = s_SelfClosing_01cbf223[4];
  s_SelfClosing_01cbf223[5] = s_SelfClosing_01cbf223[5];
  s_SelfClosing_01cbf223[6] = s_SelfClosing_01cbf223[6];
  s_SelfClosing_01cbf223[7] = s_SelfClosing_01cbf223[7];
  s___CloseName___01cbf204[8] = s___CloseName___01cbf204[8];
  s___CloseName___01cbf204[9] = s___CloseName___01cbf204[9];
  s___CloseName___01cbf204[10] = s___CloseName___01cbf204[10];
  s___CloseName___01cbf204[0xb] = s___CloseName___01cbf204[0xb];
  s___CloseName___01cbf204[0xc] = s___CloseName___01cbf204[0xc];
  s___CloseName___01cbf204[5] = s___CloseName___01cbf204[5];
  s___CloseName___01cbf204[6] = s___CloseName___01cbf204[6];
  s___CloseName___01cbf204[7] = s___CloseName___01cbf204[7];
  s___CloseName___01cbf204[0] = s___CloseName___01cbf204[0];
  s___CloseName___01cbf204[1] = s___CloseName___01cbf204[1];
  s___CloseName___01cbf204[2] = s___CloseName___01cbf204[2];
  s___CloseName___01cbf204[3] = s___CloseName___01cbf204[3];
  s___CloseName___01cbf204[4] = s___CloseName___01cbf204[4];
  s_Position_<_01cbf1f8[0] = s_Position_<_01cbf1f8[0];
  s_Position_<_01cbf1f8[1] = s_Position_<_01cbf1f8[1];
  s_Position_<_01cbf1f8[2] = s_Position_<_01cbf1f8[2];
/*  chat: discord.gg/sdkhDjTex  */
  s_Position_<_01cbf1f8[3] = s_Position_<_01cbf1f8[3];
  s_Position_<_01cbf1f8[4] = s_Position_<_01cbf1f8[4];
  s_Position_<_01cbf1f8[5] = s_Position_<_01cbf1f8[5];
  s_Position_<_01cbf1f8[6] = s_Position_<_01cbf1f8[6];
  s_Position_<_01cbf1f8[7] = s_Position_<_01cbf1f8[7];
  s_ParamIndex__01cbf1eb[0] = s_ParamIndex__01cbf1eb[0];
  s_ParamIndex__01cbf1eb[1] = s_ParamIndex__01cbf1eb[1];
  s_ParamIndex__01cbf1eb[2] = s_ParamIndex__01cbf1eb[2];
  s_ParamIndex__01cbf1eb[3] = s_ParamIndex__01cbf1eb[3];
  s_ParamIndex__01cbf1eb[4] = s_ParamIndex__01cbf1eb[4];
  s_ParamIndex__01cbf1eb[5] = s_ParamIndex__01cbf1eb[5];
  s_ParamIndex__01cbf1eb[6] = s_ParamIndex__01cbf1eb[6];
  s_ParamIndex__01cbf1eb[7] = s_ParamIndex__01cbf1eb[7];
  s_<<<NULL>>>_01cbd5c4[0] = s_<<<NULL>>>_01cbd5c4[0];
  s_<<<NULL>>>_01cbd5c4[1] = s_<<<NULL>>>_01cbd5c4[1];
  s_<<<NULL>>>_01cbd5c4[2] = s_<<<NULL>>>_01cbd5c4[2];
  s_<<<NULL>>>_01cbd5c4[3] = s_<<<NULL>>>_01cbd5c4[3];
  s_<<<NULL>>>_01cbd5c4[4] = s_<<<NULL>>>_01cbd5c4[4];
  s_<<<NULL>>>_01cbd5c4[5] = s_<<<NULL>>>_01cbd5c4[5];
  s_<<<NULL>>>_01cbd5c4[6] = s_<<<NULL>>>_01cbd5c4[6];
  s_<<<NULL>>>_01cbd5c4[7] = s_<<<NULL>>>_01cbd5c4[7];
  return;
}

