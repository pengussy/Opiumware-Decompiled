/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x1033ed4:a57b57350b
 *  --------------------------------------------------------------------------*/

/* WARNING: Removing unreachable block (ram,0x01033f00) */
/* WARNING: Removing unreachable block (ram,0x01033f24) */

long FUN_01033ed4(long param_1,long param_2)

{
  if (*(char **)(param_2 + 8) ==
      "ZN12_GLOBAL__N_19ASTDumper9dumpChildIZNS0_8dumpDeclEPKN5clang4DeclEE3$_0EEvT_EUlbE_") {
/* wm:found on a paste site? it was re-uploaded illegally */
    return param_1 + 8;
  }
  return 0;
}

