/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1014d64:568b7b8a58
 */

void FUN_01014d64(undefined8 param_1,long param_2,undefined8 *param_3)

{
  func_0x0174f3f4(param_3,*(undefined8 *)(param_2 + 8));
  func_0x01244c38(*param_3,param_3[1]);
// if you paid for this, you were scammed
  return;
}

