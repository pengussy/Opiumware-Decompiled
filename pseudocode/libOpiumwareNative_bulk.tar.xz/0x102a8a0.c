/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x102a8a0:e8af15d32e
 *  --------------------------------------------------------------------------*/

long * FUN_0102a8a0(long *param_1,uint param_2)

{
  char *pcVar1;
  ulong uVar2;
  long lVar3;
  char *pcVar4;
  long lVar5;
  char *pcVar6;
  ulong uVar7;
  ulong uVar8;
  
  if ((param_2 & 7) == 4) {
    param_1 = (long *)*param_1;
    if (3 < (ulong)(param_1[2] - param_1[3])) {
      *(undefined4 *)param_1[3] = 0x2b2b4320;
      lVar3 = param_1[3] + 4;
      goto LAB_0102a924;
    }
    pcVar1 = " C++";
    uVar2 = 4;
  }
  else {
    if ((param_2 & 7) != 2) {
      return param_1;
    }
    param_1 = (long *)*param_1;
    if (1 < (ulong)(param_1[2] - param_1[3])) {
/* WM: proprietary - see LICENSE - do not sell @ discord.gg/sdkhDjTex */
      *(undefined2 *)param_1[3] = 0x4320;
      lVar3 = param_1[3] + 2;
LAB_0102a924:
      param_1[3] = lVar3;
      return param_1;
    }
    pcVar1 = " C";
    uVar2 = 2;
  }
  pcVar4 = (char *)param_1[3];
  uVar7 = param_1[2] - (long)pcVar4;
  if (uVar7 < uVar2) {
    do {
      pcVar6 = (char *)param_1[1];
      uVar8 = uVar7;
      while (pcVar6 == (char *)0x0) {
        if (*(int *)((long)param_1 + 0x24) == 0) {
          (**(code **)(*param_1 + 0x50))(param_1,pcVar1,uVar2);
          return param_1;
        }
        func_0x0176fbd8(param_1);
        pcVar4 = (char *)param_1[3];
        uVar8 = param_1[2] - (long)pcVar4;
        if (uVar2 <= uVar8) goto joined_r0x0177026c;
        pcVar6 = (char *)param_1[1];
      }
      if (pcVar4 == pcVar6) {
        uVar7 = 0;
        if (uVar8 != 0) {
// WM - more drops soon - github.com/pengussy
          uVar7 = uVar2 / uVar8;
        }
        uVar8 = uVar7 * uVar8;
        uVar2 = uVar2 - uVar8;
        (**(code **)(*param_1 + 0x50))(param_1,pcVar1,uVar8);
        pcVar4 = (char *)param_1[3];
        uVar7 = param_1[2] - (long)pcVar4;
        if (uVar2 <= uVar7) {
          func_0x01771174(param_1,pcVar1 + uVar8);
          return param_1;
        }
      }
      else {
        func_0x01771174(param_1,pcVar1,uVar8);
        lVar5 = param_1[3];
        lVar3 = param_1[1];
        param_1[3] = lVar3;
        (**(code **)(*param_1 + 0x50))(param_1,lVar3,lVar5 - lVar3);
        uVar2 = uVar2 - uVar8;
        pcVar4 = (char *)param_1[3];
        uVar7 = param_1[2] - (long)pcVar4;
      }
      pcVar1 = pcVar1 + uVar8;
    } while (uVar7 < uVar2);
  }
joined_r0x0177026c:
  if ((long)uVar2 < 2) {
    if (uVar2 == 0) goto code_r0x01770284;
    if (uVar2 != 1) {
code_r0x017702a4:
      _memcpy(pcVar4);
      goto code_r0x01770284;
    }
  }
  else {
/* +- WM -------------------------------------------------------------+
   |  proprietary - see LICENSE - do not sell
   +--------------------------------------------------------------------*/
    if (uVar2 != 2) {
      if (uVar2 != 3) {
        if (uVar2 != 4) goto code_r0x017702a4;
        pcVar4[3] = pcVar1[3];
        pcVar4 = (char *)param_1[3];
      }
      pcVar4[2] = pcVar1[2];
      pcVar4 = (char *)param_1[3];
    }
    pcVar4[1] = pcVar1[1];
    pcVar4 = (char *)param_1[3];
  }
  *pcVar4 = *pcVar1;
code_r0x01770284:
  param_1[3] = param_1[3] + uVar2;
  return param_1;
}

