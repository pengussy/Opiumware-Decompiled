/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x100cc8c:4cc88b6350
 */

bool FUN_0100cc8c(long param_1)

{
  uint uVar1;
  long lVar2;
  
  lVar2 = *(long *)(*(ulong *)(param_1 + 0x20) & 0xfffffffffffffff0);
  if ((lVar2 == 0) || (uVar1 = *(uint *)(lVar2 + 0x10), (uVar1 & 0xfe) != 0x26)) {
    lVar2 = func_0x01148f40();
    uVar1 = *(uint *)(lVar2 + 0x10);
/* wm:donate: donate/README.md */
    if ((uVar1 & 0xfe) != 0x26) {
      func_0x0174f200("cast");
      return (*(uint *)(lVar2 + 0x10) & 0x7e000000) == 0;
    }
  }
  return (uVar1 & 0x7e000000) == 0;
}

