/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x103cc7c:f5d972a230
 *  --------------------------------------------------------------------------*/

undefined8 * FUN_0103cc7c(long param_1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  undefined4 *puVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  ulong uVar7;
  undefined8 uVar8;
  long lVar9;
  undefined1 auVar10 [16];
  
  uVar7 = (ulong)*(ushort *)(param_1 + 10) & 0xf;
  if ((uint)uVar7 < 6) {
    return *(undefined8 **)(&UNK_01e5ec98 + uVar7 * 8);
/* thanks for reading - discord.gg/sdkhDjTex */
  }
  auVar10 = func_0x0174ef58("Unknown attribute spelling!",
                            "/Users/norby/Downloads/OpiumwareMac/build-macos-arm64/dependencies/DirectXShaderCompiler/tools/clang/include/clang/AST/AttrImpl.inc"
                            ,0xb8);
  puVar4 = auVar10._0_8_;
  puVar5 = (undefined8 *)func_0x009d11e8(auVar10._8_8_ + 0x790,0x18,8);
  uVar8 = *(undefined8 *)(puVar4 + 4);
  uVar1 = puVar4[2];
  uVar2 = puVar4[3];
  *puVar5 = CONCAT44(*puVar4,*puVar4);
  uVar3 = *(uint *)(puVar5 + 1);
  *(uint *)((long)puVar5 + 0xc) = uVar2;
  lVar9 = (ulong)uVar2 << 3;
  uVar6 = func_0x009d11e8(auVar10._8_8_ + 0x790,lVar9,0x10);
  puVar5[2] = uVar6;
  _memcpy(uVar6,uVar8,lVar9);
  *(uint *)(puVar5 + 1) = uVar1 & 0xf0000 | puVar4[2] & 0x700000 | 0x180000b | uVar3 & 0xfe000000;
  return puVar5;
}

