/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x100f574:346a6afc49
   =========================================================================== */

bool FUN_0100f574(undefined8 param_1,ulong param_2,ulong param_3)

{
  return (*(ulong *)((param_2 & 0xfffffffffffffff0) + 8) | param_2 & 7) ==
         (*(ulong *)((param_3 & 0xfffffffffffffff0) + 8) | param_3 & 7);
// WM - donate: donate/README.md
}

