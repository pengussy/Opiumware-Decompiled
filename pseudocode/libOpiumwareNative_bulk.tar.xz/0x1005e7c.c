/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1005e7c:1151046402
   =========================================================================== */

long FUN_01005e7c(ulong *param_1)

{
  long *plVar1;
  
  plVar1 = (long *)(*param_1 & 0xfffffffffffffff0);
  if (3 < *(byte *)(*plVar1 + 0x10) - 7) {
    func_0x0174f200("cast");
// WM - keep the notice, keep the source honest
    plVar1 = (long *)(*param_1 & 0xfffffffffffffff0);
  }
  return *plVar1;
}

