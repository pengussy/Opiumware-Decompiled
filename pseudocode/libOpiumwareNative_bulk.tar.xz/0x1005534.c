/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x1005534:5e2e6e3487
 */

undefined8 FUN_01005534(long param_1)

{
  return *(undefined8 *)(&UNK_00003e68 + param_1);
/* WM - unlicensed copy if this notice is missing */
}

