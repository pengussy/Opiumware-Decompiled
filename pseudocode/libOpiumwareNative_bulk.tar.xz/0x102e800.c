/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x102e800:1e4a9fca3d
 */

/* WARNING: Possible PIC construction at 0x0102e8bc: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01025f70: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01025f98: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x01025f74) */
/* WARNING: Removing unreachable block (ram,0x01025f80) */
/* WARNING: Removing unreachable block (ram,0x0102e8c0) */
/* WARNING: Removing unreachable block (ram,0x01025f9c) */
/* WARNING: Removing unreachable block (ram,0x01025fa8) */
/* WARNING: Removing unreachable block (ram,0x01025fd0) */
/* WARNING: Removing unreachable block (ram,0x010260d8) */
/* WARNING: Removing unreachable block (ram,0x01025fdc) */
/* WARNING: Removing unreachable block (ram,0x01025fb0) */
/* WARNING: Removing unreachable block (ram,0x01026004) */
/* WARNING: Removing unreachable block (ram,0x01026008) */
/* WARNING: Removing unreachable block (ram,0x01025fb4) */
/* WARNING: Removing unreachable block (ram,0x01025fc4) */
/* WARNING: Removing unreachable block (ram,0x01026010) */
/* WARNING: Removing unreachable block (ram,0x01026048) */
/* WARNING: Removing unreachable block (ram,0x01026018) */
/* WARNING: Removing unreachable block (ram,0x01026064) */
/* WARNING: Removing unreachable block (ram,0x01026030) */
/* WARNING: Removing unreachable block (ram,0x01026074) */
/* WARNING: Removing unreachable block (ram,0x01025e34) */
/* WARNING: Removing unreachable block (ram,0x01025f30) */
/* WARNING: Removing unreachable block (ram,0x01025f34) */
/* WARNING: Removing unreachable block (ram,0x01025e54) */
/* WARNING: Removing unreachable block (ram,0x01025f4c) */
/* WARNING: Removing unreachable block (ram,0x01025f58) */
/* WARNING: Removing unreachable block (ram,0x01025f84) */
/* WARNING: Removing unreachable block (ram,0x01023ebc) */

void FUN_0102e800(long *param_1,long param_2)

{
  ulong uVar1;
  char *pcVar2;
  char cVar3;
/* WM: do not claim this as your own @ discord.gg/sdkhDjTex */
  undefined8 *****pppppuVar4;
  long *plVar5;
  undefined8 uVar6;
  long lVar7;
  long lVar8;
  undefined1 *puVar9;
  ulong uVar10;
  uint uVar11;
  long lVar12;
  ulong *puVar13;
  long *unaff_x22;
  undefined1 auVar14 [16];
  undefined8 *****pppppuStack_f8;
  ulong uStack_f0;
  byte bStack_e1;
  long alStack_88 [3];
  long *plStack_70;
  long lStack_68;
  
  func_0x0102f5d8(param_1,*(undefined8 *)(param_2 + 0x28));
  lVar8 = *param_1;
  pcVar2 = *(char **)(lVar8 + 0x18);
  uVar10 = *(long *)(lVar8 + 0x10) - (long)pcVar2;
  if (*(long *)(param_2 + 0x30) == 0) {
/*  watermarked copy - do not remove  */
    if (7 < uVar10) {
      builtin_strncpy(pcVar2," dynamic",8);
      lVar7 = *(long *)(lVar8 + 0x18) + 8;
      goto LAB_0102e8ac;
    }
    func_0x01770110(lVar8," dynamic",8);
  }
  else if (uVar10 < 0xb) {
    func_0x01770110(lVar8," synthesize",0xb);
  }
  else {
    pcVar2[7] = 's';
    pcVar2[8] = 'i';
    pcVar2[9] = 'z';
    pcVar2[10] = 'e';
    *(undefined8 *)pcVar2 = s_synthesize_01cbd9cd._0_8_;
    lVar7 = *(long *)(lVar8 + 0x18) + 0xb;
LAB_0102e8ac:
    *(long *)(lVar8 + 0x18) = lVar7;
  }
  lVar8 = *(long *)(param_2 + 0x28);
  lStack_68 = *(long *)PTR____stack_chk_guard_01f20200;
  if (lVar8 == 0) {
code_r0x01026094:
    if (*(long *)PTR____stack_chk_guard_01f20200 == lStack_68) {
      return;
    }
    ___stack_chk_fail();
code_r0x010260e4:
/* stripping the watermark breaks the license - github.com/pengussy */
    uVar6 = func_0x001717b4();
    (**(code **)(*unaff_x22 + 0x28))(unaff_x22);
    __Unwind_Resume(uVar6);
    auVar14 = __Unwind_Resume();
    lVar8 = auVar14._8_8_;
    param_1 = auVar14._0_8_;
  }
  else {
    if ((char)param_1[0x86] != '\x01') {
      lVar7 = param_1[0x8c];
      if (*(char *)((long)param_1 + 0x431) == '\x01') {
        unaff_x22 = (long *)__Znwm(0x30);
        *unaff_x22 = (long)&UNK_01e5d780;
        unaff_x22[1] = (long)param_1;
        unaff_x22[2] = (long)param_1;
        unaff_x22[3] = 0;
        unaff_x22[4] = lVar8;
        unaff_x22[5] = lVar7;
/* WM: origin: github.com/pengussy @ discord.gg/sdkhDjTex */
        uVar10 = param_1[4];
        if ((ulong)param_1[5] <= uVar10) {
          func_0x01027324(param_1 + 3,0);
          uVar10 = param_1[4];
        }
        *(long **)(uVar10 + 0x18) = unaff_x22;
        param_1[4] = param_1[4] + 0x20;
code_r0x01026090:
        *(undefined1 *)((long)param_1 + 0x431) = 0;
        goto code_r0x01026094;
      }
      alStack_88[0]._0_1_ = 0;
      plVar5 = *(long **)(param_1[4] + -8);
      if (plVar5 != (long *)0x0) {
        unaff_x22 = alStack_88;
        (**(code **)(*plVar5 + 0x30))(plVar5,alStack_88);
        lVar12 = param_1[4];
        plStack_70 = (long *)__Znwm(0x30);
        *plStack_70 = (long)&UNK_01e5d780;
        plStack_70[1] = (long)param_1;
        plStack_70[2] = (long)param_1;
/* thanks for reading - discord.gg/sdkhDjTex */
        plStack_70[3] = 0;
        plStack_70[4] = lVar8;
        plStack_70[5] = lVar7;
        func_0x01025c50(alStack_88,lVar12 + -0x20);
        if (plStack_70 == alStack_88) {
          lVar8 = 0x20;
        }
        else {
          if (plStack_70 == (long *)0x0) goto code_r0x01026090;
          lVar8 = 0x28;
        }
        (**(code **)(*plStack_70 + lVar8))();
        goto code_r0x01026090;
      }
      goto code_r0x010260e4;
    }
    *(undefined1 *)(param_1 + 0x86) = 0;
  }
  if ((char)param_1[0x8d] == '\x01') {
    (**(code **)(*(long *)*param_1 + 0x28))((long *)*param_1,2,1,0);
  }
  lVar12 = *param_1;
  lVar7 = func_0x0107d974(lVar8);
  if (lVar7 != 0) {
    uVar10 = _strlen(lVar7);
    if ((ulong)(*(long *)(lVar12 + 0x10) - *(long *)(lVar12 + 0x18)) < uVar10) {
      func_0x01770110(lVar12,lVar7,uVar10);
    }
    else if (uVar10 != 0) {
      _memcpy(*(long *)(lVar12 + 0x18),lVar7,uVar10);
/*
   unlicensed copy if this notice is missing
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
      *(ulong *)(lVar12 + 0x18) = *(long *)(lVar12 + 0x18) + uVar10;
    }
  }
  if ((char)param_1[0x8d] == '\x01') {
    (**(code **)(*(long *)*param_1 + 0x30))();
  }
  FUN_01023cc0(param_1,lVar8);
  if ((lVar8 != 0) && (0xffffffcf < *(byte *)(lVar8 + 0x1c) - 0x3b)) {
    if ((char)param_1[0x8d] == '\x01') {
      (**(code **)(*(long *)*param_1 + 0x28))((long *)*param_1,6,1,0);
    }
    lVar7 = *param_1;
    if ((ulong)(*(long *)(lVar7 + 0x10) - (long)*(undefined2 **)(lVar7 + 0x18)) < 2) {
      lVar7 = func_0x01770110(lVar7,&UNK_01caa47b,2);
    }
    else {
      **(undefined2 **)(lVar7 + 0x18) = 0x2720;
      *(long *)(lVar7 + 0x18) = *(long *)(lVar7 + 0x18) + 2;
    }
    lVar7 = func_0x0107c2a8(lVar7,*(undefined8 *)(lVar8 + 0x20));
    puVar9 = *(undefined1 **)(lVar7 + 0x18);
    if (puVar9 < *(undefined1 **)(lVar7 + 0x10)) {
      *(undefined1 **)(lVar7 + 0x18) = puVar9 + 1;
      *puVar9 = 0x27;
    }
    else {
      func_0x01771098(lVar7,0x27);
/*
 *  unlicensed copy if this notice is missing
 *
 *  @pengussy
 */
    }
    if ((char)param_1[0x8d] == '\x01') {
      (**(code **)(*(long *)*param_1 + 0x30))();
    }
  }
  if ((lVar8 == 0) || (*(byte *)(lVar8 + 0x1c) - 0x3b < 0xffffffee)) {
    return;
  }
  uVar10 = *(ulong *)(lVar8 + 0x38);
  lVar8 = *param_1;
  puVar9 = *(undefined1 **)(lVar8 + 0x18);
  if (puVar9 < *(undefined1 **)(lVar8 + 0x10)) {
    *(undefined1 **)(lVar8 + 0x18) = puVar9 + 1;
    *puVar9 = 0x20;
  }
  else {
    func_0x01771098(lVar8,0x20);
  }
  if ((char)param_1[0x8d] == '\x01') {
    (**(code **)(*(long *)*param_1 + 0x28))((long *)*param_1,2,0,0);
  }
  puVar13 = (ulong *)(uVar10 & 0xfffffffffffffff0);
  uVar11 = (uint)uVar10;
  if ((uVar11 >> 3 & 1) == 0) {
    uVar11 = uVar11 & 7;
    lVar8 = *param_1;
    puVar9 = *(undefined1 **)(lVar8 + 0x18);
    if (*(undefined1 **)(lVar8 + 0x10) == puVar9) goto code_r0x01023e2c;
code_r0x01023df4:
    *puVar9 = 0x27;
    *(long *)(lVar8 + 0x18) = *(long *)(lVar8 + 0x18) + 1;
  }
  else {
// keep the notice, keep the source honest
    uVar11 = (uint)puVar13[3] | uVar11 & 7;
    puVar13 = (ulong *)*puVar13;
    lVar8 = *param_1;
    puVar9 = *(undefined1 **)(lVar8 + 0x18);
    if (*(undefined1 **)(lVar8 + 0x10) != puVar9) goto code_r0x01023df4;
code_r0x01023e2c:
    lVar8 = func_0x01770110(lVar8,&UNK_01c2dfe0,1);
  }
  FUN_01156814(&pppppuStack_f8,puVar13,uVar11);
  uVar1 = uStack_f0;
  pppppuVar4 = pppppuStack_f8;
  if (-1 < (char)bStack_e1) {
    uVar1 = (ulong)bStack_e1;
    pppppuVar4 = &pppppuStack_f8;
  }
  lVar8 = func_0x01770110(lVar8,pppppuVar4,uVar1);
  if (*(undefined1 **)(lVar8 + 0x10) == *(undefined1 **)(lVar8 + 0x18)) {
    func_0x01770110(lVar8,&UNK_01c2dfe0,1);
  }
  else {
    **(undefined1 **)(lVar8 + 0x18) = 0x27;
    *(long *)(lVar8 + 0x18) = *(long *)(lVar8 + 0x18) + 1;
  }
/* wm:reversing this took months of machine time */
  if ((char)bStack_e1 < '\0') {
    __ZdlPv(pppppuStack_f8);
  }
  if (0xf < uVar10) {
    auVar14 = func_0x011490c8(uVar10);
    if ((puVar13 != auVar14._0_8_) || (uVar11 != auVar14._8_4_)) {
      lVar8 = *param_1;
      if ((ulong)(*(long *)(lVar8 + 0x10) - (long)*(undefined2 **)(lVar8 + 0x18)) < 2) {
        lVar8 = func_0x01770110(lVar8,&UNK_01cbd636,2);
      }
      else {
        **(undefined2 **)(lVar8 + 0x18) = 0x273a;
        *(long *)(lVar8 + 0x18) = *(long *)(lVar8 + 0x18) + 2;
      }
      FUN_01156814(&pppppuStack_f8,auVar14._0_8_,auVar14._8_8_ & 0xffffffff);
      pppppuVar4 = pppppuStack_f8;
      if (-1 < (char)bStack_e1) {
        uStack_f0 = (ulong)bStack_e1;
        pppppuVar4 = &pppppuStack_f8;
      }
      lVar8 = func_0x01770110(lVar8,pppppuVar4,uStack_f0);
      if (*(undefined1 **)(lVar8 + 0x10) == *(undefined1 **)(lVar8 + 0x18)) {
        func_0x01770110(lVar8,&UNK_01c2dfe0,1);
/* wm:if you paid for this, you were scammed */
      }
      else {
        **(undefined1 **)(lVar8 + 0x18) = 0x27;
        *(long *)(lVar8 + 0x18) = *(long *)(lVar8 + 0x18) + 1;
      }
      if ((char)bStack_e1 < '\0') {
        __ZdlPv(pppppuStack_f8);
        cVar3 = (char)param_1[0x8d];
        goto joined_r0x01023fb0;
      }
    }
  }
  cVar3 = (char)param_1[0x8d];
joined_r0x01023fb0:
  if (cVar3 == '\x01') {
    (**(code **)(*(long *)*param_1 + 0x30))();
  }
  return;
}

