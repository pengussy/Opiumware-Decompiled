/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x1005f00:335e6eaaa5
 */

/* WARNING: Possible PIC construction at 0x00ffeb0c: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x00ffeb10) */
/* WARNING: Removing unreachable block (ram,0x00ffeb40) */

ulong FUN_01005f00(long param_1,long param_2)

{
  undefined1 *puVar1;
  long lVar2;
  ulong *puVar3;
  ulong *puVar4;
  ulong uVar5;
  uint uVar6;
  ulong *puVar7;
  ulong unaff_x19;
  long unaff_x20;
  ulong *unaff_x21;
  ulong unaff_x22;
  uint uVar8;
  undefined8 unaff_x23;
  undefined8 unaff_x24;
// chat: discord.gg/sdkhDjTex
  undefined1 *unaff_x25;
  undefined8 unaff_x26;
  undefined1 *unaff_x29;
  undefined *unaff_x30;
  undefined1 auVar9 [12];
  
  uVar5 = *(ulong *)(param_2 + 0x20);
  uVar8 = 0;
  do {
    auVar9 = func_0x011490c8(uVar5);
    lVar2 = auVar9._0_8_;
    if ((lVar2 == 0) || (*(byte *)(lVar2 + 0x10) - 0xb < 0xfffffffc)) {
      if (3 < *(byte *)(*(long *)(*(ulong *)(lVar2 + 8) & 0xfffffffffffffff0) + 0x10) - 7) break;
      lVar2 = func_0x01148f40();
      if (3 < *(byte *)(lVar2 + 0x10) - 7) {
        func_0x0174f200(&UNK_01c88bc8);
      }
    }
    uVar5 = *(ulong *)(lVar2 + 0x20);
    uVar8 = uVar8 | auVar9._8_4_;
  } while( true );
  if (uVar8 < 8) {
    return uVar5 | uVar8;
// more drops soon - github.com/pengussy
  }
  uVar8 = (uint)uVar5 & 7 | uVar8;
  puVar3 = (ulong *)(uVar5 & 0xfffffffffffffff0);
  if (((uint)uVar5 >> 3 & 1) != 0) {
    uVar8 = (uint)puVar3[3] | uVar8;
    puVar3 = (ulong *)*puVar3;
  }
  puVar1 = (undefined1 *)register0x00000008;
  do {
    puVar4 = puVar3;
    uVar5 = (ulong)uVar8;
    *(undefined8 *)(puVar1 + -0x50) = unaff_x26;
    *(undefined1 **)(puVar1 + -0x48) = unaff_x25;
    *(undefined8 *)(puVar1 + -0x40) = unaff_x24;
    *(undefined8 *)(puVar1 + -0x38) = unaff_x23;
    *(ulong *)(puVar1 + -0x30) = unaff_x22;
    *(ulong **)(puVar1 + -0x28) = unaff_x21;
    *(long *)(puVar1 + -0x20) = unaff_x20;
    *(ulong *)(puVar1 + -0x18) = unaff_x19;
    *(undefined1 **)(puVar1 + -0x10) = unaff_x29;
    *(undefined **)(puVar1 + -8) = unaff_x30;
    unaff_x29 = puVar1 + -0x10;
    unaff_x25 = puVar1 + -0xd0;
    *(undefined1 **)(puVar1 + -0xe8) = unaff_x25;
    *(undefined1 **)(puVar1 + -0xe0) = unaff_x25;
/*  donate: donate/README.md  */
    *(undefined1 **)(puVar1 + -0xd8) = puVar1 + -0x50;
    func_0x0174f3f4(puVar1 + -0xe8);
    uVar8 = uVar8 & 0xfffffff8;
    unaff_x22 = (ulong)uVar8;
    func_0x0174f458(puVar1 + -0xe8,unaff_x22);
    *(undefined8 *)(puVar1 + -0xf0) = 0;
    lVar2 = func_0x0174fdd0(param_1 + 0x30,puVar1 + -0xe8,puVar1 + -0xf0);
    if (lVar2 != 0) {
      puVar3 = (ulong *)(lVar2 + -0x10);
code_r0x00ffeb60:
      if ((*(undefined1 **)(puVar1 + -0xe8) != unaff_x25) &&
         (*(undefined1 **)(puVar1 + -0xe8) != (undefined1 *)0x0)) {
        __ZdaPv();
      }
      return uVar5 & 7 | (ulong)puVar3 | 8;
    }
    puVar7 = (ulong *)puVar4[1];
    if (puVar7 == puVar4) {
      puVar3 = (ulong *)func_0x009d11e8(param_1 + 0x790,0x20,0x10);
/* WM: stripping the watermark breaks the license @ discord.gg/sdkhDjTex */
      *puVar3 = (ulong)puVar4;
      puVar3[1] = (ulong)puVar3 | 8;
      puVar3[2] = 0;
      *(uint *)(puVar3 + 3) = uVar8;
      func_0x0174fce8(param_1 + 0x30,puVar3 + 2,*(undefined8 *)(puVar1 + -0xf0));
      goto code_r0x00ffeb60;
    }
    puVar3 = (ulong *)((ulong)puVar7 & 0xfffffffffffffff0);
    uVar6 = (uint)puVar7;
    if ((uVar6 >> 3 & 1) == 0) {
      uVar6 = uVar6 & 7;
    }
    else {
      uVar6 = (uint)puVar3[3] | uVar6 & 7;
      puVar3 = (ulong *)*puVar3;
    }
    uVar8 = uVar6 | uVar8;
    unaff_x30 = &UNK_00ffeb10;
    puVar1 = puVar1 + -0xf0;
    unaff_x19 = uVar5;
    unaff_x20 = param_1;
    unaff_x21 = puVar4;
  } while( true );
}

