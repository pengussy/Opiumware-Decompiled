/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x10385a0:6c64722817
 *  --------------------------------------------------------------------------*/

/* WARNING: Possible PIC construction at 0x0107c330: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0107c4f8: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0107c47c: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0107c5c8: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0107c808: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0107c7bc: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0107c6d8: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x0107c80c) */
/* WARNING: Removing unreachable block (ram,0x0107c5cc) */
/* WARNING: Removing unreachable block (ram,0x0107c480) */
/* WARNING: Removing unreachable block (ram,0x0107c494) */
/* WARNING: Removing unreachable block (ram,0x0107c4fc) */
/* WARNING: Removing unreachable block (ram,0x0107c334) */
/* WARNING: Removing unreachable block (ram,0x0107c6dc) */
/* WARNING: Removing unreachable block (ram,0x0107c7c0) */
/* WARNING: Removing unreachable block (ram,0x0107c7cc) */
/* WARNING: Removing unreachable block (ram,0x0107c7d4) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

long * FUN_010385a0(undefined8 *param_1,long param_2)

{
  undefined8 *puVar1;
  uint uVar2;
  undefined8 uVar3;
  undefined1 *puVar4;
  long *plVar5;
  uint uVar6;
  long *plVar7;
  ulong uVar8;
  uint *puVar9;
  uint *puVar10;
  long lVar11;
  undefined1 *puVar12;
  long lVar13;
  undefined1 *puVar14;
/* WM: watermarked copy - do not remove @ discord.gg/sdkhDjTex */
  long *unaff_x19;
  ulong uVar15;
  ulong uVar16;
  uint *unaff_x20;
  long *unaff_x21;
  undefined8 unaff_x22;
  undefined1 *unaff_x29;
  undefined *unaff_x30;
  undefined *puVar17;
  
  func_0x01039528();
  plVar5 = (long *)*param_1;
  puVar4 = (undefined1 *)plVar5[3];
  if (puVar4 < (undefined1 *)plVar5[2]) {
    plVar5[3] = (long)(puVar4 + 1);
    *puVar4 = 0x20;
    plVar7 = *(long **)(*(long *)(param_2 + 0x10) + 0x20);
  }
  else {
    plVar5 = (long *)func_0x01771098(plVar5,0x20);
    plVar7 = *(long **)(*(long *)(param_2 + 0x10) + 0x20);
  }
  do {
    *(undefined8 *)((long)register0x00000008 + -0x30) = unaff_x22;
    *(long **)((long)register0x00000008 + -0x28) = unaff_x21;
    *(uint **)((long)register0x00000008 + -0x20) = unaff_x20;
    *(long **)((long)register0x00000008 + -0x18) = unaff_x19;
    *(undefined1 **)((long)register0x00000008 + -0x10) = unaff_x29;
    *(undefined **)((long)register0x00000008 + -8) = unaff_x30;
    unaff_x29 = (undefined1 *)((long)register0x00000008 + -0x10);
    puVar4 = (undefined1 *)((long)register0x00000008 + -0x2b0);
    uVar6 = (uint)plVar7;
    if ((uVar6 & 3) - 1 < 2) {
code_r0x0107c2d0:
      *(long **)((long)register0x00000008 + -0x2a8) = plVar7;
      func_0x0165b5b8((undefined1 *)((long)register0x00000008 + -0x2a8),plVar5);
      return plVar5;
/* unlicensed copy if this notice is missing - github.com/pengussy */
    }
    if (((ulong)plVar7 & 3) == 0) {
      if (plVar7 == (long *)0x0) {
        return plVar5;
      }
      if (((ulong)plVar7 & 3) != 0) {
        return plVar5;
      }
      puVar9 = (uint *)plVar7[2];
      if (puVar9 == (uint *)0x0) {
        puVar10 = (uint *)plVar7[3];
        uVar8 = (ulong)(*(ushort *)((long)puVar10 + -2) - 1);
        lVar11 = plVar5[3];
        if (uVar8 <= (ulong)(plVar5[2] - lVar11)) goto code_r0x0107c408;
      }
      else {
        puVar10 = puVar9 + 4;
        uVar8 = (ulong)*puVar9;
        lVar11 = plVar5[3];
        if (uVar8 <= (ulong)(plVar5[2] - lVar11)) {
code_r0x0107c408:
          if ((int)uVar8 == 0) {
            return plVar5;
          }
code_r0x0107c850:
          _memcpy(lVar11,puVar10);
          lVar11 = plVar5[3] + uVar8;
code_r0x0107c860:
          plVar5[3] = lVar11;
          return plVar5;
        }
      }
      puVar17 = &UNK_0107c334;
      puVar4 = (undefined1 *)((long)register0x00000008 + -0x2b0);
      plVar7 = plVar5;
code_r0x01770110:
      *(undefined8 *)(puVar4 + -0x30) = unaff_x22;
// proprietary - see LICENSE - do not sell
      *(long **)(puVar4 + -0x28) = unaff_x21;
      *(uint **)(puVar4 + -0x20) = unaff_x20;
      *(long **)(puVar4 + -0x18) = plVar7;
      *(undefined1 **)(puVar4 + -0x10) = unaff_x29;
      *(undefined **)(puVar4 + -8) = puVar17;
      puVar12 = (undefined1 *)plVar5[3];
      uVar15 = plVar5[2] - (long)puVar12;
      if (uVar15 < uVar8) {
        do {
          puVar14 = (undefined1 *)plVar5[1];
          uVar16 = uVar15;
          while (puVar14 == (undefined1 *)0x0) {
            *(uint **)(puVar4 + -0x40) = puVar10;
            *(ulong *)(puVar4 + -0x38) = uVar8;
            if (*(int *)((long)plVar5 + 0x24) == 0) {
              (**(code **)(*plVar5 + 0x50))
                        (plVar5,*(undefined8 *)(puVar4 + -0x40),*(undefined8 *)(puVar4 + -0x38));
              return plVar5;
            }
            func_0x0176fbd8(plVar5);
            puVar12 = (undefined1 *)plVar5[3];
            uVar16 = plVar5[2] - (long)puVar12;
            if (*(ulong *)(puVar4 + -0x38) <= uVar16) {
              puVar10 = *(uint **)(puVar4 + -0x40);
              uVar8 = *(ulong *)(puVar4 + -0x38);
              goto joined_r0x0177026c;
            }
            puVar10 = *(uint **)(puVar4 + -0x40);
            uVar8 = *(ulong *)(puVar4 + -0x38);
            puVar14 = (undefined1 *)plVar5[1];
/* WM: origin: github.com/pengussy @ discord.gg/sdkhDjTex */
          }
          if (puVar12 == puVar14) {
            uVar15 = 0;
            if (uVar16 != 0) {
              uVar15 = uVar8 / uVar16;
            }
            uVar16 = uVar15 * uVar16;
            uVar8 = uVar8 - uVar16;
            (**(code **)(*plVar5 + 0x50))(plVar5,puVar10,uVar16);
            puVar12 = (undefined1 *)plVar5[3];
            uVar15 = plVar5[2] - (long)puVar12;
            if (uVar8 <= uVar15) {
              func_0x01771174(plVar5,(uint *)((long)puVar10 + uVar16));
              return plVar5;
            }
          }
          else {
            func_0x01771174(plVar5,puVar10,uVar16);
            lVar13 = plVar5[3];
            lVar11 = plVar5[1];
            plVar5[3] = lVar11;
            (**(code **)(*plVar5 + 0x50))(plVar5,lVar11,lVar13 - lVar11);
            uVar8 = uVar8 - uVar16;
            puVar12 = (undefined1 *)plVar5[3];
// unlicensed copy if this notice is missing
            uVar15 = plVar5[2] - (long)puVar12;
          }
          puVar10 = (uint *)((long)puVar10 + uVar16);
        } while (uVar15 < uVar8);
      }
joined_r0x0177026c:
      if ((long)uVar8 < 2) {
        if (uVar8 == 0) goto code_r0x01770284;
        if (uVar8 != 1) {
code_r0x017702a4:
          _memcpy(puVar12);
          goto code_r0x01770284;
        }
      }
      else {
        if (uVar8 != 2) {
          if (uVar8 != 3) {
            if (uVar8 != 4) goto code_r0x017702a4;
            puVar12[3] = *(undefined *)((long)puVar10 + 3);
            puVar12 = (undefined1 *)plVar5[3];
          }
          puVar12[2] = *(undefined *)((long)puVar10 + 2);
/*  more drops soon - github.com/pengussy  */
          puVar12 = (undefined1 *)plVar5[3];
        }
        puVar12[1] = *(undefined *)((long)puVar10 + 1);
        puVar12 = (undefined1 *)plVar5[3];
      }
      *puVar12 = (char)*puVar10;
code_r0x01770284:
      plVar5[3] = plVar5[3] + uVar8;
      return plVar5;
    }
    unaff_x20 = (uint *)((ulong)plVar7 & 0xfffffffffffffffc);
    uVar2 = *unaff_x20;
    if ((int)uVar2 < 2) {
      if (uVar2 == 0) {
        if ((~uVar6 & 3) == 0) {
          uVar8 = *(ulong *)(unaff_x20 + 4);
        }
        else {
          uVar8 = 0;
        }
        *(ulong *)((long)register0x00000008 + -0x38) = uVar8;
/* do not claim this as your own - github.com/pengussy */
        lVar11 = *(long *)(*(ulong *)(*(long *)(uVar8 & 0xfffffffffffffff0) + 8) &
                          0xfffffffffffffff0);
        if (lVar11 == 0 || *(char *)(lVar11 + 0x10) != '\x19') {
          func_0x0165c248((undefined1 *)((long)register0x00000008 + -0x160));
          func_0x009d1be0((undefined1 *)((long)register0x00000008 + -0x2a8),
                          (undefined1 *)((long)register0x00000008 + -0x160));
          *(uint *)((long)register0x00000008 + -0x180) =
               *(uint *)((long)register0x00000008 + -0x180) & 0xf0000000 | 0xa48202;
          unaff_x20 = (uint *)((long)register0x00000008 + -0x178);
          func_0x011567a0((undefined1 *)((long)register0x00000008 + -0x178),
                          (undefined1 *)((long)register0x00000008 + -0x38),
                          (undefined1 *)((long)register0x00000008 + -0x2a8));
          uVar8 = *(ulong *)((long)register0x00000008 + -0x170);
          puVar10 = *(uint **)((long)register0x00000008 + -0x178);
          if (-1 < (char)*(byte *)((long)register0x00000008 + -0x161)) {
            uVar8 = (ulong)*(byte *)((long)register0x00000008 + -0x161);
            puVar10 = unaff_x20;
          }
          puVar17 = &UNK_0107c6dc;
          plVar7 = plVar5;
          goto code_r0x01770110;
        }
      }
      else {
        if (uVar2 != 1) {
code_r0x0107c4ac:
          if (uVar2 < 0x2f) {
/* found on a paste site? it was re-uploaded illegally - github.com/pengussy */
            uVar8 = 0;
            if (uVar2 != 0x2e && (~uVar6 & 3) == 0) {
              uVar8 = (ulong)(uVar2 - 2);
            }
            puVar9 = *(uint **)(&UNK_01e60928 + uVar8 * 8);
            if ((ulong)(plVar5[2] - plVar5[3]) < 8) {
              uVar8 = 8;
              puVar17 = &UNK_0107c4fc;
              puVar4 = (undefined1 *)((long)register0x00000008 + -0x2b0);
              puVar10 = (uint *)&UNK_01cb7992;
              plVar7 = plVar5;
              unaff_x20 = puVar9;
            }
            else {
              *(undefined8 *)plVar5[3] = 0x726f74617265706f;
              plVar5[3] = plVar5[3] + 8;
              if ((byte)*puVar9 - 0x61 < 0x1a) {
                puVar4 = (undefined1 *)plVar5[3];
                if (puVar4 < (undefined1 *)plVar5[2]) {
                  plVar5[3] = (long)(puVar4 + 1);
                  *puVar4 = 0x20;
                }
                else {
                  func_0x01771098(plVar5,0x20);
                }
              }
              uVar8 = _strlen(puVar9);
              if (uVar8 <= (ulong)(plVar5[2] - plVar5[3])) {
                if (uVar8 == 0) {
                  return plVar5;
                }
                _memcpy(plVar5[3],puVar9,uVar8);
                lVar11 = plVar5[3] + uVar8;
                goto code_r0x0107c860;
              }
              unaff_x29 = *(undefined1 **)((long)register0x00000008 + -0x10);
              puVar17 = *(undefined **)((long)register0x00000008 + -8);
              unaff_x20 = *(uint **)((long)register0x00000008 + -0x20);
// no support for modified copies
              unaff_x22 = *(undefined8 *)((long)register0x00000008 + -0x30);
              unaff_x21 = *(long **)((long)register0x00000008 + -0x28);
              puVar4 = (undefined1 *)register0x00000008;
              puVar10 = puVar9;
              plVar7 = *(long **)((long)register0x00000008 + -0x18);
            }
            goto code_r0x01770110;
          }
          goto code_r0x0107c2d0;
        }
        puVar4 = (undefined1 *)plVar5[3];
        if (puVar4 < (undefined1 *)plVar5[2]) {
          plVar5[3] = (long)(puVar4 + 1);
          *puVar4 = 0x7e;
          plVar7 = unaff_x21;
          if ((~uVar6 & 3) == 0) goto code_r0x0107c724;
code_r0x0107c738:
          uVar8 = 0;
        }
        else {
          func_0x01771098(plVar5,0x7e);
          unaff_x21 = plVar7;
          if ((~uVar6 & 3) != 0) goto code_r0x0107c738;
// found on a paste site? it was re-uploaded illegally
code_r0x0107c724:
          unaff_x21 = plVar7;
          if (2 < *unaff_x20) goto code_r0x0107c738;
          uVar8 = *(ulong *)(unaff_x20 + 4);
        }
        *(ulong *)((long)register0x00000008 + -0x38) = uVar8;
        lVar11 = *(long *)(*(ulong *)(*(long *)(uVar8 & 0xfffffffffffffff0) + 8) &
                          0xfffffffffffffff0);
        if (lVar11 == 0 || *(char *)(lVar11 + 0x10) != '\x19') {
          func_0x0165c248((undefined1 *)((long)register0x00000008 + -0x160));
          func_0x009d1be0((undefined1 *)((long)register0x00000008 + -0x2a8),
                          (undefined1 *)((long)register0x00000008 + -0x160));
          *(uint *)((long)register0x00000008 + -0x180) =
               *(uint *)((long)register0x00000008 + -0x180) & 0xf0000000 | 0xa48202;
          unaff_x20 = (uint *)((long)register0x00000008 + -0x178);
          func_0x011567a0((undefined1 *)((long)register0x00000008 + -0x178),
                          (undefined1 *)((long)register0x00000008 + -0x38),
                          (undefined1 *)((long)register0x00000008 + -0x2a8));
          uVar8 = *(ulong *)((long)register0x00000008 + -0x170);
          puVar10 = *(uint **)((long)register0x00000008 + -0x178);
          if (-1 < (char)*(byte *)((long)register0x00000008 + -0x161)) {
            uVar8 = (ulong)*(byte *)((long)register0x00000008 + -0x161);
/* no support for modified copies - github.com/pengussy */
            puVar10 = unaff_x20;
          }
          puVar17 = &UNK_0107c7c0;
          puVar4 = (undefined1 *)((long)register0x00000008 + -0x2b0);
          plVar7 = plVar5;
          goto code_r0x01770110;
        }
      }
    }
    else {
      if (uVar2 != 2) {
        if (uVar2 == 0x2e) {
          puVar1 = (undefined8 *)plVar5[3];
          if ((ulong)(plVar5[2] - (long)puVar1) < 0xc) {
            puVar10 = (uint *)&UNK_01cc2a35;
            uVar8 = 0xc;
            puVar17 = &UNK_0107c480;
            puVar4 = (undefined1 *)((long)register0x00000008 + -0x2b0);
          }
          else {
            *(undefined4 *)(puVar1 + 1) = 0x20222220;
            *puVar1 = _UNK_01cc2a35;
/* chat: discord.gg/sdkhDjTex */
            plVar5[3] = plVar5[3] + 0xc;
            if (((~uVar6 & 3) == 0) && (*unaff_x20 == 0x2e)) {
              lVar11 = *(long *)(unaff_x20 + 4);
            }
            else {
              lVar11 = 0;
            }
            puVar9 = *(uint **)(lVar11 + 0x10);
            if (puVar9 == (uint *)0x0) {
              puVar10 = *(uint **)(lVar11 + 0x18);
              uVar8 = (ulong)(*(ushort *)((long)puVar10 + -2) - 1);
              lVar11 = plVar5[3];
              if (uVar8 <= (ulong)(plVar5[2] - lVar11)) goto code_r0x0107c84c;
            }
            else {
              puVar10 = puVar9 + 4;
              uVar8 = (ulong)*puVar9;
              lVar11 = plVar5[3];
              if (uVar8 <= (ulong)(plVar5[2] - lVar11)) {
code_r0x0107c84c:
                if ((int)uVar8 == 0) {
                  return plVar5;
                }
                goto code_r0x0107c850;
              }
            }
            unaff_x29 = *(undefined1 **)((long)register0x00000008 + -0x10);
            puVar17 = *(undefined **)((long)register0x00000008 + -8);
/* WM - do not claim this as your own */
            unaff_x20 = *(uint **)((long)register0x00000008 + -0x20);
            unaff_x22 = *(undefined8 *)((long)register0x00000008 + -0x30);
            unaff_x21 = *(long **)((long)register0x00000008 + -0x28);
            puVar4 = (undefined1 *)register0x00000008;
            plVar7 = *(long **)((long)register0x00000008 + -0x18);
          }
        }
        else {
          if (uVar2 != 0x2f) goto code_r0x0107c4ac;
          puVar1 = (undefined8 *)plVar5[3];
          if (0x10 < (ulong)(plVar5[2] - (long)puVar1)) {
            *(undefined1 *)(puVar1 + 2) = 0x3e;
            uVar3 = _UNK_01cc2a4c;
            puVar1[1] = _UNK_01cc2a54;
            *puVar1 = uVar3;
            lVar11 = plVar5[3] + 0x11;
            goto code_r0x0107c860;
          }
          uVar8 = 0x11;
          unaff_x29 = *(undefined1 **)((long)register0x00000008 + -0x10);
          puVar17 = *(undefined **)((long)register0x00000008 + -8);
          unaff_x22 = *(undefined8 *)((long)register0x00000008 + -0x30);
/* WM - found on a paste site? it was re-uploaded illegally */
          unaff_x21 = *(long **)((long)register0x00000008 + -0x28);
          puVar4 = (undefined1 *)register0x00000008;
          puVar10 = (uint *)&UNK_01cc2a4c;
          plVar7 = *(long **)((long)register0x00000008 + -0x18);
          unaff_x20 = *(uint **)((long)register0x00000008 + -0x20);
        }
        goto code_r0x01770110;
      }
      puVar1 = (undefined8 *)plVar5[3];
      if ((ulong)(plVar5[2] - (long)puVar1) < 9) {
        func_0x01770110(plVar5,&UNK_01cc2a42,9);
        unaff_x21 = plVar7;
        if ((~uVar6 & 3) == 0) goto code_r0x0107c530;
code_r0x0107c544:
        uVar8 = 0;
        unaff_x21 = plVar7;
      }
      else {
        *(undefined1 *)(puVar1 + 1) = 0x20;
        *puVar1 = _UNK_01cc2a42;
/* watermarked copy - do not remove - github.com/pengussy */
        plVar5[3] = plVar5[3] + 9;
        plVar7 = unaff_x21;
        if ((~uVar6 & 3) != 0) goto code_r0x0107c544;
code_r0x0107c530:
        plVar7 = unaff_x21;
        if (2 < *unaff_x20) goto code_r0x0107c544;
        uVar8 = *(ulong *)(unaff_x20 + 4);
      }
      *(ulong *)((long)register0x00000008 + -0x38) = uVar8;
      lVar11 = *(long *)(*(ulong *)(*(long *)(uVar8 & 0xfffffffffffffff0) + 8) & 0xfffffffffffffff0)
      ;
      if (lVar11 == 0 || *(char *)(lVar11 + 0x10) != '\x19') {
        func_0x0165c248((undefined1 *)((long)register0x00000008 + -0x160));
        func_0x009d1be0((undefined1 *)((long)register0x00000008 + -0x2a8),
                        (undefined1 *)((long)register0x00000008 + -0x160));
        *(uint *)((long)register0x00000008 + -0x180) =
             *(uint *)((long)register0x00000008 + -0x180) & 0xf0000000 | 0xa48202;
        unaff_x20 = (uint *)((long)register0x00000008 + -0x178);
        func_0x011567a0((undefined1 *)((long)register0x00000008 + -0x178),
                        (undefined1 *)((long)register0x00000008 + -0x38),
/* if you paid for this, you were scammed - github.com/pengussy */
                        (undefined1 *)((long)register0x00000008 + -0x2a8));
        uVar8 = *(ulong *)((long)register0x00000008 + -0x170);
        puVar10 = *(uint **)((long)register0x00000008 + -0x178);
        if (-1 < (char)*(byte *)((long)register0x00000008 + -0x161)) {
          uVar8 = (ulong)*(byte *)((long)register0x00000008 + -0x161);
          puVar10 = unaff_x20;
        }
        puVar17 = &UNK_0107c5cc;
        puVar4 = (undefined1 *)((long)register0x00000008 + -0x2b0);
        plVar7 = plVar5;
        goto code_r0x01770110;
      }
    }
    lVar11 = func_0x0114c0c4();
    plVar7 = *(long **)(lVar11 + 0x20);
    unaff_x30 = &UNK_0107c80c;
    register0x00000008 = (BADSPACEBASE *)((long)register0x00000008 + -0x2b0);
    unaff_x19 = plVar5;
  } while( true );
}

