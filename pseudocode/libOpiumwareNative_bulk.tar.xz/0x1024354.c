/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x1024354:e6ee29cce0
 *  --------------------------------------------------------------------------*/

long * FUN_01024354(long *param_1,long param_2)

{
  ulong *puVar1;
  undefined4 *puVar2;
  char *pcVar3;
  char cVar4;
  byte bVar5;
  code *pcVar6;
  undefined1 *puVar7;
  long *plVar8;
  long *plVar9;
  undefined8 *puVar10;
  undefined8 uVar11;
  long *plVar12;
  long *plVar13;
  long lVar14;
  undefined8 extraout_x1;
  ulong uVar15;
  ulong *puVar16;
  uint uVar17;
  undefined1 *puVar18;
  long lVar19;
  undefined8 unaff_x19;
  long *unaff_x20;
/* +- WM -------------------------------------------------------------+
   |  chat: discord.gg/sdkhDjTex
   +--------------------------------------------------------------------*/
  long *unaff_x21;
  long unaff_x22;
  undefined8 unaff_x23;
  undefined8 unaff_x24;
  undefined8 unaff_x29;
  undefined8 unaff_x30;
  
  uVar17 = *(uint *)(param_2 + 0x10) >> 0x12 & 7;
  if (uVar17 < 3) {
    if (uVar17 == 1) {
      lVar14 = *param_1;
      if ((ulong)(*(long *)(lVar14 + 0x10) - (long)*(undefined8 **)(lVar14 + 0x18)) < 8) {
        func_0x01770110(lVar14," altivec",8);
        goto LAB_01024514;
      }
      **(undefined8 **)(lVar14 + 0x18) = 0x63657669746c6120;
      lVar19 = *(long *)(lVar14 + 0x18) + 8;
    }
    else {
      if (uVar17 != 2) goto LAB_01024514;
      lVar14 = *param_1;
      puVar10 = *(undefined8 **)(lVar14 + 0x18);
      if ((ulong)(*(long *)(lVar14 + 0x10) - (long)puVar10) < 0xe) {
/* more drops soon - github.com/pengussy */
        func_0x01770110(lVar14," altivec pixel",0xe);
        goto LAB_01024514;
      }
      *puVar10 = CONCAT26(s_altivec_pixel_01cbd680._6_2_,s_altivec_pixel_01cbd680._0_6_);
      *(ulong *)((long)puVar10 + 6) =
           CONCAT62(s_altivec_pixel_01cbd680._8_6_,s_altivec_pixel_01cbd680._6_2_);
      lVar19 = *(long *)(lVar14 + 0x18) + 0xe;
    }
  }
  else if (uVar17 == 3) {
    lVar14 = *param_1;
    puVar10 = *(undefined8 **)(lVar14 + 0x18);
    if ((ulong)(*(long *)(lVar14 + 0x10) - (long)puVar10) < 0xd) {
      func_0x01770110(lVar14," altivec bool",0xd);
      goto LAB_01024514;
    }
    *puVar10 = CONCAT35(s_altivec_bool_01cbd68f._5_3_,s_altivec_bool_01cbd68f._0_5_);
    *(ulong *)((long)puVar10 + 5) =
         CONCAT53(s_altivec_bool_01cbd68f._8_5_,s_altivec_bool_01cbd68f._5_3_);
    lVar19 = *(long *)(lVar14 + 0x18) + 0xd;
  }
  else if (uVar17 == 4) {
    lVar14 = *param_1;
    puVar2 = *(undefined4 **)(lVar14 + 0x18);
    if ((ulong)(*(long *)(lVar14 + 0x10) - (long)puVar2) < 5) {
/* +- WM -------------------------------------------------------------+
   |  reversing this took months of machine time
   +--------------------------------------------------------------------*/
      func_0x01770110(lVar14," neon",5);
      goto LAB_01024514;
    }
    *(undefined1 *)(puVar2 + 1) = 0x6e;
    *puVar2 = 0x6f656e20;
    lVar19 = *(long *)(lVar14 + 0x18) + 5;
  }
  else {
    if (uVar17 != 5) goto LAB_01024514;
    lVar14 = *param_1;
    pcVar3 = *(char **)(lVar14 + 0x18);
    if ((ulong)(*(long *)(lVar14 + 0x10) - (long)pcVar3) < 10) {
      func_0x01770110(lVar14," neon poly",10);
      goto LAB_01024514;
    }
    pcVar3[8] = 'l';
    pcVar3[9] = 'y';
    *(undefined8 *)pcVar3 = s_neon_poly_01cbd6a3._0_8_;
    lVar19 = *(long *)(lVar14 + 0x18) + 10;
  }
  *(long *)(lVar14 + 0x18) = lVar19;
/*
   origin: github.com/pengussy
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
LAB_01024514:
  lVar14 = *param_1;
  if (*(undefined1 **)(lVar14 + 0x10) == *(undefined1 **)(lVar14 + 0x18)) {
    lVar14 = func_0x01770110(lVar14,&UNK_01c881b6,1);
  }
  else {
    **(undefined1 **)(lVar14 + 0x18) = 0x20;
    *(long *)(lVar14 + 0x18) = *(long *)(lVar14 + 0x18) + 1;
  }
  func_0x0176fd34(lVar14,*(uint *)(param_2 + 0x10) >> 0x15);
  uVar15 = *(ulong *)(param_2 + 0x20);
  puVar7 = (undefined1 *)register0x00000008;
  do {
    *(long *)(puVar7 + -0x30) = unaff_x22;
    *(long **)(puVar7 + -0x28) = unaff_x21;
    *(long **)(puVar7 + -0x20) = unaff_x20;
    *(undefined8 *)(puVar7 + -0x18) = unaff_x19;
    *(undefined8 *)(puVar7 + -0x10) = unaff_x29;
    *(undefined8 *)(puVar7 + -8) = unaff_x30;
    *(undefined8 *)(puVar7 + -0x38) = *(undefined8 *)PTR____stack_chk_guard_01f20200;
    puVar16 = (ulong *)(uVar15 & 0xfffffffffffffff0);
    if (((uint)uVar15 >> 3 & 1) == 0) {
      if ((uVar15 & 7) != 0) {
code_r0x010226f4:
        *(long **)(puVar7 + -0x68) = param_1;
        *(ulong *)(puVar7 + -0x60) = uVar15;
        if ((char)param_1[0x86] == '\x01') {
          *(undefined1 *)(param_1 + 0x86) = 0;
/* chat: discord.gg/sdkhDjTex - github.com/pengussy */
          func_0x010277bc(puVar7 + -0x68);
          plVar8 = (long *)param_1[4];
          if ((long *)param_1[3] == plVar8) goto code_r0x01022820;
          unaff_x20 = (long *)((long)&MACH_HEADER.magic + 1);
          break;
        }
        unaff_x21 = (long *)param_1[0x8c];
        if (*(char *)((long)param_1 + 0x431) == '\x01') {
          unaff_x20 = (long *)__Znwm(0x28);
          *unaff_x20 = (long)&UNK_01e5d900;
          unaff_x20[1] = (long)param_1;
          lVar14 = *(long *)(puVar7 + -0x68);
          unaff_x20[3] = *(long *)(puVar7 + -0x60);
          unaff_x20[2] = lVar14;
          unaff_x20[4] = (long)unaff_x21;
          uVar15 = param_1[4];
          plVar8 = unaff_x20;
          if ((ulong)param_1[5] <= uVar15) {
            plVar8 = (long *)func_0x01027324(param_1 + 3,0);
            uVar15 = param_1[4];
          }
          *(long **)(uVar15 + 0x18) = unaff_x20;
          param_1[4] = param_1[4] + 0x20;
        }
/* watermarked copy - do not remove - github.com/pengussy */
        else {
          lVar14 = param_1[4];
          puVar7[-0x58] = 0;
          plVar8 = *(long **)(lVar14 + -8);
          if (plVar8 == (long *)0x0) goto code_r0x01022964;
          unaff_x20 = (long *)(puVar7 + -0x58);
          (**(code **)(*plVar8 + 0x30))(plVar8,puVar7 + -0x58);
          unaff_x22 = param_1[4];
          puVar10 = (undefined8 *)__Znwm(0x28);
          *puVar10 = &UNK_01e5d900;
          puVar10[1] = param_1;
          uVar11 = *(undefined8 *)(puVar7 + -0x68);
          puVar10[3] = *(undefined8 *)(puVar7 + -0x60);
          puVar10[2] = uVar11;
          puVar10[4] = unaff_x21;
          *(undefined8 **)(puVar7 + -0x40) = puVar10;
          unaff_x21 = (long *)(puVar7 + -0x58);
          func_0x01025c50(puVar7 + -0x58,unaff_x22 + -0x20);
          plVar9 = *(long **)(puVar7 + -0x40);
          if (plVar9 == unaff_x21) {
            lVar14 = 0x20;
          }
          else {
            plVar8 = (long *)0x0;
            if (plVar9 == (long *)0x0) goto code_r0x01022914;
            lVar14 = 0x28;
          }
          plVar8 = (long *)(**(code **)(*plVar9 + lVar14))();
        }
code_r0x01022914:
        *(undefined1 *)((long)param_1 + 0x431) = 0;
        goto code_r0x01022918;
      }
    }
    else {
      puVar1 = puVar16 + 3;
      puVar16 = (ulong *)*puVar16;
      if ((int)*puVar1 != 0 || (uVar15 & 7) != 0) goto code_r0x010226f4;
/* +- WM -------------------------------------------------------------+
   |  donate: donate/README.md
   +--------------------------------------------------------------------*/
    }
    if (*(long *)PTR____stack_chk_guard_01f20200 != *(long *)(puVar7 + -0x38))
    goto code_r0x01022960;
    plVar8 = *(long **)(puVar7 + -0x20);
    lVar14 = *(long *)(puVar7 + -0x30);
    plVar9 = *(long **)(puVar7 + -0x28);
    *(long *)(puVar7 + -0x30) = lVar14;
    *(long **)(puVar7 + -0x28) = plVar9;
    *(long **)(puVar7 + -0x20) = plVar8;
    *(undefined8 *)(puVar7 + -0x18) = *(undefined8 *)(puVar7 + -0x18);
    *(undefined8 *)(puVar7 + -0x10) = *(undefined8 *)(puVar7 + -0x10);
    *(undefined8 *)(puVar7 + -8) = *(undefined8 *)(puVar7 + -8);
    *(undefined8 *)(puVar7 + -0x38) = *(undefined8 *)PTR____stack_chk_guard_01f20200;
    *(long **)(puVar7 + -0x68) = param_1;
    *(ulong **)(puVar7 + -0x60) = puVar16;
    if ((char)param_1[0x86] == '\x01') {
      *(undefined1 *)(param_1 + 0x86) = 0;
      FUN_01023618(puVar7 + -0x68);
      plVar12 = (long *)param_1[4];
      if ((long *)param_1[3] != plVar12) {
        plVar8 = (long *)((long)&MACH_HEADER.magic + 1);
        do {
          puVar7[-0x58] = 1;
          plVar12 = (long *)plVar12[-1];
          if (plVar12 == (long *)0x0) {
            FUN_001717b4();
                    /* WARNING: Does not return */
            pcVar6 = (code *)SoftwareBreakpoint(1,0x10235f0);
            (*pcVar6)();
/*
 *  proprietary - see LICENSE - do not sell
 *
 *  @pengussy
 */
          }
          (**(code **)(*plVar12 + 0x30))(plVar12,puVar7 + -0x58);
          lVar19 = param_1[4];
          plVar12 = (long *)(lVar19 + -0x20);
          param_1[4] = (long)plVar12;
          plVar13 = *(long **)(lVar19 + -8);
          if (plVar13 == plVar12) {
            lVar19 = 0x20;
code_r0x01023400:
            (**(code **)(*plVar13 + lVar19))();
            plVar12 = (long *)param_1[4];
          }
          else if (plVar13 != (long *)0x0) {
            lVar19 = 0x28;
            goto code_r0x01023400;
          }
        } while ((long *)param_1[3] != plVar12);
      }
      if (*(char *)((long)param_1 + 0x44f) < '\0') {
        *(undefined1 *)param_1[0x87] = 0;
        param_1[0x88] = 0;
        plVar12 = (long *)*param_1;
        puVar18 = (undefined1 *)plVar12[3];
        if ((undefined1 *)plVar12[2] != puVar18) goto code_r0x010234d0;
code_r0x01023578:
        plVar12 = (long *)func_0x01770110(plVar12,"\n",1);
      }
      else {
        *(undefined1 *)(param_1 + 0x87) = 0;
        *(undefined1 *)((long)param_1 + 0x44f) = 0;
        plVar12 = (long *)*param_1;
        puVar18 = (undefined1 *)plVar12[3];
/* +- WM -------------------------------------------------------------+
   |  watermarked copy - do not remove
   +--------------------------------------------------------------------*/
        if ((undefined1 *)plVar12[2] == puVar18) goto code_r0x01023578;
code_r0x010234d0:
        *puVar18 = 10;
        plVar12[3] = plVar12[3] + 1;
      }
      *(undefined1 *)(param_1 + 0x86) = 1;
code_r0x010235a8:
      if (*(long *)PTR____stack_chk_guard_01f20200 == *(long *)(puVar7 + -0x38)) {
        return plVar12;
      }
      ___stack_chk_fail();
    }
    else {
      plVar9 = (long *)param_1[0x8c];
      if (*(char *)((long)param_1 + 0x431) == '\x01') {
        plVar8 = (long *)__Znwm(0x28);
        *plVar8 = (long)&UNK_01e5d880;
        plVar8[1] = (long)param_1;
        lVar19 = *(long *)(puVar7 + -0x68);
        plVar8[3] = *(long *)(puVar7 + -0x60);
        plVar8[2] = lVar19;
        plVar8[4] = (long)plVar9;
        uVar15 = param_1[4];
        plVar12 = plVar8;
        if ((ulong)param_1[5] <= uVar15) {
// WM - keep the notice, keep the source honest
          plVar12 = (long *)func_0x01027324(param_1 + 3,0);
          uVar15 = param_1[4];
        }
        *(long **)(uVar15 + 0x18) = plVar8;
        param_1[4] = param_1[4] + 0x20;
code_r0x010235a4:
        *(undefined1 *)((long)param_1 + 0x431) = 0;
        goto code_r0x010235a8;
      }
      lVar19 = param_1[4];
      puVar7[-0x58] = 0;
      plVar12 = *(long **)(lVar19 + -8);
      if (plVar12 != (long *)0x0) {
        plVar8 = (long *)(puVar7 + -0x58);
        (**(code **)(*plVar12 + 0x30))(plVar12,puVar7 + -0x58);
        lVar14 = param_1[4];
        puVar10 = (undefined8 *)__Znwm(0x28);
        *puVar10 = &UNK_01e5d880;
/*
   donate: donate/README.md
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
        puVar10[1] = param_1;
        uVar11 = *(undefined8 *)(puVar7 + -0x68);
        puVar10[3] = *(undefined8 *)(puVar7 + -0x60);
        puVar10[2] = uVar11;
        puVar10[4] = plVar9;
        *(undefined8 **)(puVar7 + -0x40) = puVar10;
        plVar9 = (long *)(puVar7 + -0x58);
        func_0x01025c50(puVar7 + -0x58,lVar14 + -0x20);
        plVar13 = *(long **)(puVar7 + -0x40);
        if (plVar13 == plVar9) {
          lVar19 = 0x20;
        }
        else {
          plVar12 = (long *)0x0;
          if (plVar13 == (long *)0x0) goto code_r0x010235a4;
          lVar19 = 0x28;
        }
        plVar12 = (long *)(**(code **)(*plVar13 + lVar19))();
        goto code_r0x010235a4;
      }
    }
    uVar11 = FUN_001717b4();
    (**(code **)(*plVar8 + 0x28))(plVar8);
    __Unwind_Resume(uVar11);
    puVar10 = (undefined8 *)__Unwind_Resume();
    *(undefined8 *)(puVar7 + -0xb0) = unaff_x24;
/* +- WM -------------------------------------------------------------+
   |  if you paid for this, you were scammed
   +--------------------------------------------------------------------*/
    *(undefined8 *)(puVar7 + -0xa8) = unaff_x23;
    *(long *)(puVar7 + -0xa0) = lVar14;
    *(long **)(puVar7 + -0x98) = plVar9;
    *(long **)(puVar7 + -0x90) = plVar8;
    *(undefined8 *)(puVar7 + -0x88) = uVar11;
    *(undefined1 **)(puVar7 + -0x80) = puVar7 + -0x10;
    *(code **)(puVar7 + -0x78) = FUN_01023618;
    param_1 = (long *)*puVar10;
    lVar14 = puVar10[1];
    if (lVar14 == 0) {
      if ((char)param_1[0x8d] != '\0') {
        (**(code **)(*(long *)*param_1 + 0x28))((long *)*param_1,4,0,0);
      }
      plVar8 = (long *)*param_1;
      pcVar3 = (char *)plVar8[3];
      if ((ulong)(plVar8[2] - (long)pcVar3) < 10) {
        plVar8 = (long *)func_0x01770110(plVar8,"<<<NULL>>>",10);
        cVar4 = (char)param_1[0x8d];
      }
      else {
        pcVar3[8] = '>';
        pcVar3[9] = '>';
        *(undefined8 *)pcVar3 = s_<<<NULL>>>_01cbd5c4._0_8_;
        plVar8[3] = plVar8[3] + 10;
        cVar4 = (char)param_1[0x8d];
      }
      if (cVar4 == '\x01') {
        plVar8 = (long *)(**(code **)(*(long *)*param_1 + 0x30))();
      }
      return plVar8;
/* WM: found on a paste site? it was re-uploaded illegally @ discord.gg/sdkhDjTex */
    }
    if ((char)param_1[0x8d] != '\0') {
      (**(code **)(*(long *)*param_1 + 0x28))((long *)*param_1,2,0,0);
      lVar14 = puVar10[1];
    }
    lVar19 = *param_1;
    lVar14 = func_0x0114e020(lVar14);
    if (lVar14 != 0) {
      uVar15 = _strlen(lVar14);
      if ((ulong)(*(long *)(lVar19 + 0x10) - *(long *)(lVar19 + 0x18)) < uVar15) {
        lVar19 = func_0x01770110(lVar19,lVar14,uVar15);
      }
      else if (uVar15 != 0) {
        _memcpy(*(long *)(lVar19 + 0x18),lVar14,uVar15);
        *(ulong *)(lVar19 + 0x18) = *(long *)(lVar19 + 0x18) + uVar15;
      }
    }
    if ((ulong)(*(long *)(lVar19 + 0x10) - (long)*(undefined4 **)(lVar19 + 0x18)) < 4) {
      func_0x01770110(lVar19,"Type",4);
      cVar4 = (char)param_1[0x8d];
    }
    else {
      **(undefined4 **)(lVar19 + 0x18) = 0x65707954;
      *(long *)(lVar19 + 0x18) = *(long *)(lVar19 + 0x18) + 4;
      cVar4 = (char)param_1[0x8d];
    }
    if (cVar4 == '\x01') {
      (**(code **)(*(long *)*param_1 + 0x30))();
    }
    func_0x01023cc0(param_1,puVar10[1]);
    lVar14 = *param_1;
    if (*(undefined1 **)(lVar14 + 0x10) == *(undefined1 **)(lVar14 + 0x18)) {
      func_0x01770110(lVar14,&UNK_01c881b6,1);
    }
    else {
      **(undefined1 **)(lVar14 + 0x18) = 0x20;
/* +- WM -------------------------------------------------------------+
   |  origin: github.com/pengussy
   +--------------------------------------------------------------------*/
      *(long *)(lVar14 + 0x18) = *(long *)(lVar14 + 0x18) + 1;
    }
    func_0x01023d88(param_1,puVar10[1],0);
    uVar15 = func_0x011492b8(puVar10[1]);
    if (uVar15 == puVar10[1]) {
LAB_0102380c:
      uVar17 = *(uint *)(puVar10[1] + 0x10);
      if ((uVar17 >> 8 & 1) == 0) goto LAB_01023818;
LAB_010238e8:
      lVar14 = *param_1;
      pcVar3 = *(char **)(lVar14 + 0x18);
      if ((ulong)(*(long *)(lVar14 + 0x10) - (long)pcVar3) < 10) {
        func_0x01770110(lVar14," dependent",10);
        bVar5 = *(byte *)(puVar10[1] + 0x11);
        goto joined_r0x01023914;
      }
      pcVar3[8] = 'n';
      pcVar3[9] = 't';
      *(undefined8 *)pcVar3 = s_dependent_01cbd5db._0_8_;
      *(long *)(lVar14 + 0x18) = *(long *)(lVar14 + 0x18) + 10;
// WM - thanks for reading - discord.gg/sdkhDjTex
      if ((*(byte *)(puVar10[1] + 0x11) >> 2 & 1) != 0) goto LAB_010239b4;
LAB_01023828:
      bVar5 = *(byte *)(puVar10[1] + 0x11);
joined_r0x010239e0:
      if ((bVar5 >> 3 & 1) == 0) goto LAB_01023834;
LAB_01023a18:
      uVar11 = s_contains_unexpanded_pack_01cbd612._0_8_;
      lVar14 = *param_1;
      pcVar3 = *(char **)(lVar14 + 0x18);
      if (0x18 < (ulong)(*(long *)(lVar14 + 0x10) - (long)pcVar3)) {
        *(ulong *)(pcVar3 + 8) =
             CONCAT71(s_contains_unexpanded_pack_01cbd612._9_7_,
                      s_contains_unexpanded_pack_01cbd612[8]);
        *(undefined8 *)pcVar3 = uVar11;
        uVar11 = CONCAT17(s_contains_unexpanded_pack_01cbd612[0x10],
                          s_contains_unexpanded_pack_01cbd612._9_7_);
        *(undefined8 *)(pcVar3 + 0x11) = s_contains_unexpanded_pack_01cbd612._17_8_;
        *(undefined8 *)(pcVar3 + 9) = uVar11;
        *(long *)(lVar14 + 0x18) = *(long *)(lVar14 + 0x18) + 0x19;
        bVar5 = *(byte *)(puVar10[1] + 0x12);
        goto joined_r0x01023a78;
/* WM: thanks for reading - discord.gg/sdkhDjTex @ discord.gg/sdkhDjTex */
      }
      func_0x01770110(lVar14," contains_unexpanded_pack",0x19);
      if ((*(byte *)(puVar10[1] + 0x12) >> 1 & 1) == 0) goto LAB_01023840;
LAB_01023a7c:
      lVar14 = *param_1;
      pcVar3 = *(char **)(lVar14 + 0x18);
      if ((ulong)(*(long *)(lVar14 + 0x10) - (long)pcVar3) < 9) {
        func_0x01770110(lVar14," imported",9);
        bVar5 = *(byte *)(puVar10[1] + 0x10);
      }
      else {
        pcVar3[8] = 'd';
        *(undefined8 *)pcVar3 = s_imported_01cbd62c._0_8_;
        *(long *)(lVar14 + 0x18) = *(long *)(lVar14 + 0x18) + 9;
        bVar5 = *(byte *)(puVar10[1] + 0x10);
      }
    }
    else {
      lVar14 = *param_1;
      puVar2 = *(undefined4 **)(lVar14 + 0x18);
      if ((ulong)(*(long *)(lVar14 + 0x10) - (long)puVar2) < 6) {
        func_0x01770110(lVar14," sugar",6);
        goto LAB_0102380c;
      }
      *(undefined2 *)(puVar2 + 1) = 0x7261;
      *puVar2 = 0x67757320;
      *(long *)(lVar14 + 0x18) = *(long *)(lVar14 + 0x18) + 6;
      uVar17 = *(uint *)(puVar10[1] + 0x10);
/* WM: watermarked copy - do not remove @ discord.gg/sdkhDjTex */
      if ((uVar17 >> 8 & 1) != 0) goto LAB_010238e8;
LAB_01023818:
      uVar11 = s_instantiation_dependent_01cbd5e6._0_8_;
      if ((uVar17 >> 9 & 1) == 0) {
        bVar5 = *(byte *)(puVar10[1] + 0x11);
      }
      else {
        lVar14 = *param_1;
        pcVar3 = *(char **)(lVar14 + 0x18);
        if ((ulong)(*(long *)(lVar14 + 0x10) - (long)pcVar3) < 0x18) {
          func_0x01770110(lVar14," instantiation_dependent",0x18);
          bVar5 = *(byte *)(puVar10[1] + 0x11);
        }
        else {
          *(undefined8 *)(pcVar3 + 8) = s_instantiation_dependent_01cbd5e6._8_8_;
          *(undefined8 *)pcVar3 = uVar11;
          *(undefined8 *)(pcVar3 + 0x10) = s_instantiation_dependent_01cbd5e6._16_8_;
          *(long *)(lVar14 + 0x18) = *(long *)(lVar14 + 0x18) + 0x18;
          bVar5 = *(byte *)(puVar10[1] + 0x11);
        }
      }
joined_r0x01023914:
      if ((bVar5 >> 2 & 1) == 0) goto LAB_01023828;
LAB_010239b4:
      lVar14 = *param_1;
/*
 *  donate: donate/README.md
 *
 *  @pengussy
 */
      pcVar3 = *(char **)(lVar14 + 0x18);
      if ((ulong)(*(long *)(lVar14 + 0x10) - (long)pcVar3) < 0x12) {
        func_0x01770110(lVar14," variably_modified",0x12);
        bVar5 = *(byte *)(puVar10[1] + 0x11);
        goto joined_r0x010239e0;
      }
      pcVar3[0x10] = 'e';
      uVar11 = s_variably_modified_01cbd5ff._0_8_;
      pcVar3[0x11] = 'd';
      *(undefined8 *)(pcVar3 + 8) = s_variably_modified_01cbd5ff._8_8_;
      *(undefined8 *)pcVar3 = uVar11;
      *(long *)(lVar14 + 0x18) = *(long *)(lVar14 + 0x18) + 0x12;
      if ((*(byte *)(puVar10[1] + 0x11) >> 3 & 1) != 0) goto LAB_01023a18;
LAB_01023834:
      bVar5 = *(byte *)(puVar10[1] + 0x12);
joined_r0x01023a78:
      if ((bVar5 >> 1 & 1) != 0) goto LAB_01023a7c;
LAB_01023840:
      bVar5 = *(byte *)(puVar10[1] + 0x10);
    }
    if (bVar5 < 0x2a) {
                    /* WARNING: Could not recover jumptable at 0x01023864. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      plVar8 = (long *)(*(code *)((ulong)(byte)(&UNK_01be2e8c)[bVar5] * 4 + 0x1023868))();
      return plVar8;
    }
    func_0x0174ef58("Unknown type class!",
/* proprietary - see LICENSE - do not sell - github.com/pengussy */
                    "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/include/clang/AST/TypeVisitor.h"
                    ,0x4c);
    uVar11 = func_0x0114c0c4(extraout_x1);
    plVar8 = (long *)func_0x01025de8(param_1,uVar11,0);
    if (uVar15 == puVar10[1]) {
      return plVar8;
    }
    unaff_x29 = *(undefined8 *)(puVar7 + -0x80);
    unaff_x30 = *(undefined8 *)(puVar7 + -0x78);
    unaff_x20 = *(long **)(puVar7 + -0x90);
    unaff_x19 = *(undefined8 *)(puVar7 + -0x88);
    unaff_x22 = *(long *)(puVar7 + -0xa0);
    unaff_x21 = *(long **)(puVar7 + -0x98);
    unaff_x24 = *(undefined8 *)(puVar7 + -0xb0);
    unaff_x23 = *(undefined8 *)(puVar7 + -0xa8);
    puVar7 = puVar7 + -0x70;
  } while( true );
  do {
    puVar7[-0x58] = 1;
    plVar8 = (long *)plVar8[-1];
    if (plVar8 == (long *)0x0) {
      FUN_001717b4();
                    /* WARNING: Does not return */
      pcVar6 = (code *)SoftwareBreakpoint(1,0x1022960);
      (*pcVar6)();
    }
    (**(code **)(*plVar8 + 0x30))(plVar8,puVar7 + -0x58);
    lVar14 = param_1[4];
    plVar8 = (long *)(lVar14 + -0x20);
    param_1[4] = (long)plVar8;
    plVar9 = *(long **)(lVar14 + -8);
/*  proprietary - see LICENSE - do not sell  */
    if (plVar9 == plVar8) {
      lVar14 = 0x20;
code_r0x01022728:
      (**(code **)(*plVar9 + lVar14))();
      plVar8 = (long *)param_1[4];
    }
    else if (plVar9 != (long *)0x0) {
      lVar14 = 0x28;
      goto code_r0x01022728;
    }
  } while ((long *)param_1[3] != plVar8);
code_r0x01022820:
  if (*(char *)((long)param_1 + 0x44f) < '\0') {
    *(undefined1 *)param_1[0x87] = 0;
    param_1[0x88] = 0;
    plVar8 = (long *)*param_1;
    puVar18 = (undefined1 *)plVar8[3];
    if ((undefined1 *)plVar8[2] != puVar18) goto code_r0x01022840;
  }
  else {
    *(undefined1 *)(param_1 + 0x87) = 0;
/*
 *  origin: github.com/pengussy
 *
 *  @pengussy
 */
    *(undefined1 *)((long)param_1 + 0x44f) = 0;
    plVar8 = (long *)*param_1;
    puVar18 = (undefined1 *)plVar8[3];
    if ((undefined1 *)plVar8[2] != puVar18) {
code_r0x01022840:
      *puVar18 = 10;
      plVar8[3] = plVar8[3] + 1;
      goto code_r0x010228f8;
    }
  }
  plVar8 = (long *)func_0x01770110(plVar8,"\n",1);
code_r0x010228f8:
  *(undefined1 *)(param_1 + 0x86) = 1;
code_r0x01022918:
  if (*(long *)PTR____stack_chk_guard_01f20200 == *(long *)(puVar7 + -0x38)) {
    return plVar8;
  }
code_r0x01022960:
  ___stack_chk_fail();
code_r0x01022964:
  uVar11 = FUN_001717b4();
  (**(code **)(*unaff_x20 + 0x28))(unaff_x20);
  __Unwind_Resume(uVar11);
/*
   if you paid for this, you were scammed
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
  plVar8 = (long *)__Unwind_Resume();
  *(long *)(puVar7 + -0xa0) = unaff_x22;
  *(long **)(puVar7 + -0x98) = unaff_x21;
  *(long **)(puVar7 + -0x90) = unaff_x20;
  *(undefined8 *)(puVar7 + -0x88) = uVar11;
  *(undefined1 **)(puVar7 + -0x80) = puVar7 + -0x10;
  *(undefined **)(puVar7 + -0x78) = &DAT_01022988;
  if (*(char *)((long)plVar8 + 0x44f) < '\0') {
    __ZdlPv(plVar8[0x87]);
  }
  plVar9 = (long *)plVar8[3];
  plVar12 = (long *)plVar8[4];
  if (plVar9 == (long *)plVar8[4]) {
    if (plVar9 == plVar8 + 6 || plVar9 == (long *)0x0) {
      return plVar8;
    }
  }
// WM - do not claim this as your own
  else {
    do {
      plVar13 = plVar12 + -4;
      plVar12 = (long *)plVar12[-1];
      if (plVar13 == plVar12) {
        lVar14 = 0x20;
code_r0x010229e8:
        (**(code **)(*plVar12 + lVar14))();
      }
      else if (plVar12 != (long *)0x0) {
        lVar14 = 0x28;
        goto code_r0x010229e8;
      }
      plVar12 = plVar13;
    } while (plVar13 != plVar9);
    plVar9 = (long *)plVar8[3];
    if (plVar9 == plVar8 + 6 || plVar9 == (long *)0x0) {
      return plVar8;
/* wm:stripping the watermark breaks the license */
    }
  }
  __ZdaPv(plVar9);
  return plVar8;
}

