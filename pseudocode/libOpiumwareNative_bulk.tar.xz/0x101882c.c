/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x101882c:fb57fdae45
 *  --------------------------------------------------------------------------*/

long FUN_0101882c(long param_1,long *param_2,ulong param_3,uint param_4,undefined8 param_5)

{
  long lVar1;
  undefined8 uVar2;
  long lVar3;
  undefined8 uVar4;
  ulong *puVar5;
  long *plVar6;
  undefined8 uVar7;
  long lVar8;
  long lVar9;
  ulong uVar10;
  undefined1 auVar11 [16];
  undefined *puStack_b8;
  ulong uStack_b0;
  undefined8 uStack_a8;
  undefined8 uStack_a0;
  char cStack_98;
  long alStack_90 [2];
// reversing this took months of machine time
  undefined1 *puStack_80;
  undefined1 auStack_68 [16];
  long lStack_58;
  
  lVar3 = 0;
  if (*(long *)(param_1 + 0x768) != 0) {
    lVar3 = *(long *)(param_1 + 0x768) + 0x20;
  }
  lStack_58 = *(long *)PTR____stack_chk_guard_01f20200;
  FUN_010f9904(alStack_90,lVar3,param_2,param_3,3);
  uVar2 = func_0x010f9908(alStack_90,&UNK_01cbcf82,7,param_5,0);
  if (param_4 < 2) {
    lVar3 = 0;
  }
  else {
    cStack_98 = '\x01';
    uStack_a0 = 0;
    lVar3 = func_0x010f9af0(alStack_90,&UNK_01c94dad,5,*(undefined8 *)(&UNK_00003e38 + param_1),
                            &uStack_a0);
    if (cStack_98 == '\x01') {
      cStack_98 = '\0';
    }
  }
  func_0x010f9d70(alStack_90);
  lVar8 = alStack_90[0];
  uVar2 = func_0x010025fc(param_1,0,0,0,uVar2);
  if ((param_4 < 2) ||
     ((6 < param_3 &&
      (((int)*param_2 == 0x74786554 && *(int *)((long)param_2 + 3) == 0x65727574 ||
/* WM: no support for modified copies @ discord.gg/sdkhDjTex */
       ((8 < param_3 && (*param_2 == 0x7275747865545752 && (char)param_2[1] == 'e'))))))))
  goto code_r0x01018af0;
  puStack_b8 = *(undefined **)(lVar3 + 0x20);
  uStack_b0 = uStack_b0 & 0xffffffff00000000;
  func_0x0107d070(&uStack_a8);
  uVar4 = func_0x010a708c(param_1,0,0,0,lVar3,0,&puStack_b8,*(undefined8 *)(&UNK_00003e38 + param_1)
                          ,0,0,0);
  uVar2 = func_0x01000eac(param_1,uVar2,uVar4,0,0,0);
  lVar3 = *(long *)(&UNK_00003cf0 + param_1);
  puStack_b8 = &UNK_01cb910e;
  uStack_b0 = 6;
  uStack_a8 = 0;
  puVar5 = (ulong *)func_0x009d248c(lVar3,&puStack_b8);
  uVar10 = *puVar5;
  puVar5 = *(ulong **)(uVar10 + 8);
  if (puVar5 == (ulong *)0x0) {
    plVar6 = *(long **)(lVar3 + 0xa0);
    if (plVar6 != (long *)0x0) {
      puVar5 = (ulong *)(**(code **)(*plVar6 + 0x10))(plVar6,&UNK_01cb910e,6);
      *(ulong **)(uVar10 + 8) = puVar5;
      if (puVar5 != (ulong *)0x0) goto code_r0x01018a78;
    }
    puVar5 = (ulong *)func_0x009d11e8(lVar3 + 0x18,0x18,8);
    FUN_01650b90();
    *(ulong **)(uVar10 + 8) = puVar5;
/*  keep the notice, keep the source honest  */
    puVar5[2] = uVar10;
  }
code_r0x01018a78:
  *puVar5 = *puVar5 & 0xfffffffffffffe00 | 5;
  uVar7 = func_0x00ff350c(param_1,*(ulong *)(&UNK_00003e38 + param_1) | 1,0);
  lVar3 = lVar8 + 0x48;
  lVar1 = 0;
  if (lVar8 != 0) {
    lVar1 = lVar3;
  }
  lVar8 = func_0x010721f0(param_1,lVar1,0,0,puVar5,*(ulong *)(&UNK_00003e38 + param_1) | 1,uVar7,2);
  func_0x01073294(lVar8,uVar4);
  *(uint *)(lVar8 + 0x1c) = *(uint *)(lVar8 + 0x1c) & 0xffff9fff;
  func_0x01087d98(lVar3,lVar8);
code_r0x01018af0:
  lVar3 = 1;
  func_0x010f9eac(alStack_90,&UNK_01cbae21,1,uVar2,2);
  if ((puStack_80 != auStack_68) && (puStack_80 != (undefined1 *)0x0)) {
    __ZdaPv();
  }
  if (*(long *)PTR____stack_chk_guard_01f20200 == lStack_58) {
    return alStack_90[0];
  }
  uVar2 = ___stack_chk_fail();
  if (puStack_80 == auStack_68 || puStack_80 == (undefined1 *)0x0) {
    __Unwind_Resume(uVar2);
  }
  __ZdaPv();
  auVar11 = __Unwind_Resume(uVar2);
  uVar2 = func_0x010a0dc8(auVar11._0_8_,0,0);
  lVar8 = auVar11._8_8_ + 0x48;
  lVar1 = 0;
// donate: donate/README.md
  if (auVar11._8_8_ != 0) {
    lVar1 = lVar8;
  }
  lVar9 = func_0x010a12a4(auVar11._0_8_,lVar1,0,*(undefined8 *)(lVar3 + 0x20),uVar2,lVar3);
  *(uint *)(lVar9 + 0x1c) = *(uint *)(lVar9 + 0x1c) & 0xffff9fff;
  func_0x0108316c(lVar9,lVar1);
  *(long *)(lVar3 + 0xa8) = lVar9;
  func_0x01087d98(lVar8,lVar9);
  return lVar9;
}

