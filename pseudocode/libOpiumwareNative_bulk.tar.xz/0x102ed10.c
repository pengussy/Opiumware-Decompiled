/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x102ed10:173a0b1475
 */

/* WARNING: Removing unreachable block (ram,0x0102ed3c) */
/* WARNING: Removing unreachable block (ram,0x0102ed60) */

long FUN_0102ed10(long param_1,long param_2)

{
  if (*(char **)(param_2 + 8) ==
      "ZN12_GLOBAL__N_19ASTDumper9dumpChildIZNS0_14VisitBlockDeclEPKN5clang9BlockDeclEE3$_0EEvT_EUlbE_"
/* no support for modified copies - github.com/pengussy */
     ) {
    return param_1 + 8;
  }
  return 0;
}

