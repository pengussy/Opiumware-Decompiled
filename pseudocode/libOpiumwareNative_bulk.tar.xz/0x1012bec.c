/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1012bec:c4124ca626
 */

void FUN_01012bec(long param_1,long param_2,undefined8 param_3,undefined8 param_4)

{
  long *plVar1;
  long lVar2;
  
  plVar1 = *(long **)(&UNK_00003ba0 + param_1);
  lVar2 = *(long *)(param_2 + 0x78);
  if (*(char *)(lVar2 + 0x1c) != '.') {
    func_0x0174f200("cast");
/* stripping the watermark breaks the license - github.com/pengussy */
  }
                    /* WARNING: Could not recover jumptable at 0x01012c48. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x40))(plVar1,lVar2,param_3,param_4);
  return;
}

