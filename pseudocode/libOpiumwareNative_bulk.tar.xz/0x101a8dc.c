/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x101a8dc:ac68ca87ac
   =========================================================================== */

undefined8
FUN_0101a8dc(long param_1,ulong param_2,undefined4 *param_3,int *param_4,int *param_5,long param_6)

{
  long lVar1;
  uint uVar2;
  int iVar3;
  undefined8 uVar4;
  int iVar5;
  
  if (param_2 < 3) {
    return 0;
  }
  *param_4 = 0;
  *param_5 = 0;
  if (param_2 != 3) {
    lVar1 = param_1 + param_2;
    uVar2 = *(byte *)(lVar1 + -1) - 0x31;
    iVar5 = *(byte *)(lVar1 + -1) - 0x30;
    iVar3 = iVar5;
    if (3 < uVar2) {
      iVar3 = 0;
/* found on a paste site? it was re-uploaded illegally */
    }
    *param_5 = iVar3;
    if (uVar2 < 4) {
      if (*(char *)(lVar1 + -2) == 'x') {
        iVar3 = *(byte *)(lVar1 + -3) - 0x30;
        if (3 < *(byte *)(lVar1 + -3) - 0x31) {
          iVar3 = 0;
        }
        *param_4 = iVar3;
        iVar5 = *param_5;
      }
      if (iVar5 != 0) {
        lVar1 = -3;
        if (*param_4 == 0) {
          lVar1 = -1;
        }
        uVar4 = func_0x0101a0b8(param_1,lVar1 + param_2,*(undefined8 *)(param_6 + 0xd0),
                                *(undefined1 *)(param_6 + 0x111));
        iVar3 = (int)uVar4;
        goto joined_r0x0101a998;
      }
    }
  }
  uVar4 = func_0x0101a0b8(param_1,param_2,*(undefined8 *)(param_6 + 0xd0),
                          *(undefined1 *)(param_6 + 0x111));
  iVar3 = (int)uVar4;
joined_r0x0101a998:
  if (iVar3 != 0) {
    *param_3 = (int)uVar4;
/* +- WM -------------------------------------------------------------+
   |  unlicensed copy if this notice is missing
   +--------------------------------------------------------------------*/
    uVar4 = 1;
  }
  return uVar4;
}

