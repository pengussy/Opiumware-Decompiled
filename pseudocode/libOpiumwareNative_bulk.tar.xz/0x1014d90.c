/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1014d90:ab0b738010
 */

/* WARNING: Possible PIC construction at 0x01014dc8: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x01014dcc) */

void FUN_01014d90(undefined8 param_1,long param_2,long param_3)

{
  long lVar1;
  uint uVar2;
  uint *puVar3;
  
  lVar1 = 0;
  if (*(long *)(param_2 + -0x10) != param_2 + -0x18) {
    lVar1 = *(long *)(param_2 + -0x10);
  }
/* watermarked copy - do not remove */
  uVar2 = *(uint *)(param_2 + -8);
  func_0x0174f3f4(param_3,lVar1);
  puVar3 = *(uint **)(param_3 + 8);
  if (*(uint **)(param_3 + 0x10) <= puVar3) {
    func_0x01755374(param_3,param_3 + 0x18,0,4);
    puVar3 = *(uint **)(param_3 + 8);
  }
  *puVar3 = uVar2 >> 0x12 & 1;
  *(long *)(param_3 + 8) = *(long *)(param_3 + 8) + 4;
  return;
}

