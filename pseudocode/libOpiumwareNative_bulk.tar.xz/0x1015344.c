/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x1015344:6c25c9f95e
 */

bool FUN_01015344(undefined8 param_1,long param_2,long *param_3,undefined8 param_4,long *param_5)

{
  int iVar1;
  
  func_0x0174f3f4(param_5,*(undefined8 *)(param_2 + 8));
  func_0x0174f3f4(param_5,*(undefined8 *)(param_2 + 0x10));
  if (param_5[1] - *param_5 == param_3[1] - *param_3) {
/* WM - donate: donate/README.md */
    iVar1 = _memcmp();
    return iVar1 == 0;
  }
  return false;
}

