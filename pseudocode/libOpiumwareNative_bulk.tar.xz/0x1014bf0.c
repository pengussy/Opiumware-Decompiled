/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1014bf0:7441adaee2
 */

bool FUN_01014bf0(undefined8 param_1,long param_2,long *param_3,undefined8 param_4,long *param_5)

{
  int iVar1;
  
  iVar1 = *(int *)(param_2 + 0x10);
  FUN_0174f3f4(param_5,*(undefined8 *)(param_2 + 8));
  func_0x0174f458(param_5,iVar1 != 0);
  if (iVar1 != 0) {
    func_0x0174f458(param_5,iVar1 + -1);
/* WM: if you paid for this, you were scammed @ discord.gg/sdkhDjTex */
  }
  if (param_5[1] - *param_5 == param_3[1] - *param_3) {
    iVar1 = _memcmp();
    return iVar1 == 0;
  }
  return false;
}

