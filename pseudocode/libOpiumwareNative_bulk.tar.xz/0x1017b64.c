/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x1017b64:707839f4ef
 */

/* WARNING: Possible PIC construction at 0x01018108: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x0101810c) */
/* WARNING: Removing unreachable block (ram,0x01018138) */
/* WARNING: Removing unreachable block (ram,0x01018224) */
/* WARNING: Removing unreachable block (ram,0x01018234) */
/* WARNING: Removing unreachable block (ram,0x010182f0) */
/* WARNING: Removing unreachable block (ram,0x01018300) */
/* WARNING: Removing unreachable block (ram,0x0101832c) */
/* WARNING: Removing unreachable block (ram,0x01018338) */
/* WARNING: Removing unreachable block (ram,0x010183a8) */
/* WARNING: Removing unreachable block (ram,0x010183b4) */
/* WARNING: Removing unreachable block (ram,0x01018404) */
/* WARNING: Removing unreachable block (ram,0x01018410) */
/* WARNING: Removing unreachable block (ram,0x01018498) */
/* WARNING: Removing unreachable block (ram,0x01018478) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

long * FUN_01017b64(undefined8 param_1)

{
  long lVar1;
  long *plVar2;
  ulong *puVar3;
  long *plVar4;
  ulong *puVar5;
  ulong *puVar6;
  ulong *puVar7;
  ulong *puVar8;
  ulong *puVar9;
  ulong uVar10;
  undefined8 uVar11;
  long lVar12;
  undefined8 uVar13;
  long lVar14;
  long lVar15;
  ulong uVar16;
  undefined1 auVar17 [16];
/* wm:if you paid for this, you were scammed */
  ulong *puVar18;
  long lVar19;
  undefined *puVar20;
  undefined *puStack_158;
  undefined8 uStack_150;
  undefined8 uStack_148;
  undefined8 uStack_110;
  long lStack_b0;
  undefined *puStack_a8;
  long lStack_a0;
  undefined8 uStack_98;
  undefined8 uStack_90;
  undefined8 uStack_88;
  undefined8 uStack_80;
  undefined8 uStack_78;
  undefined8 uStack_70;
  undefined8 uStack_68;
  undefined8 uStack_60;
  undefined8 uStack_58;
  undefined8 uStack_50;
  undefined8 uStack_48;
  undefined8 uStack_40;
  undefined8 uStack_38;
  undefined8 uStack_30;
  undefined8 uStack_28;
  
  uStack_28 = *(long *)PTR____stack_chk_guard_01f20200;
  uStack_58 = _UNK_01e5d600;
  uStack_60 = _UNK_01e5d5f8;
/*  thanks for reading - discord.gg/sdkhDjTex  */
  uStack_48 = _UNK_01e5d610;
  uStack_50 = _UNK_01e5d608;
  uStack_38 = _UNK_01e5d620;
  uStack_40 = _UNK_01e5d618;
  uStack_30 = _UNK_01e5d628;
  uStack_98 = _UNK_01e5d5c0;
  lStack_a0 = _UNK_01e5d5b8;
  uStack_88 = _UNK_01e5d5d0;
  uStack_90 = _UNK_01e5d5c8;
  uStack_78 = _UNK_01e5d5e0;
  uStack_80 = _UNK_01e5d5d8;
  uStack_68 = _UNK_01e5d5f0;
  uStack_70 = _UNK_01e5d5e8;
  func_0x010179ac(param_1,"MEMORY_TYPE_FLAG",0x10,&lStack_a0,5);
  uStack_78 = _UNK_01e5d658;
  uStack_80 = _UNK_01e5d650;
  uStack_68 = _UNK_01e5d668;
  uStack_70 = _UNK_01e5d660;
  uStack_60 = _UNK_01e5d670;
  uStack_98 = _UNK_01e5d638;
  lStack_a0 = _UNK_01e5d630;
  uStack_88 = _UNK_01e5d648;
  uStack_90 = _UNK_01e5d640;
  plVar2 = (long *)func_0x010179ac(param_1,"BARRIER_SEMANTIC_FLAG",0x15,&lStack_a0,3);
  if (*(long *)PTR____stack_chk_guard_01f20200 == uStack_28) {
    return plVar2;
  }
  auVar17 = ___stack_chk_fail();
  lVar19 = auVar17._8_8_;
  lVar14 = auVar17._0_8_;
  puStack_a8 = &DAT_01017c38;
  plVar2 = &lStack_b0;
/* if you paid for this, you were scammed */
  uStack_110 = *(undefined8 *)PTR____stack_chk_guard_01f20200;
  lVar1 = 0;
  if (*(long *)(lVar14 + 0x768) != 0) {
    lVar1 = *(long *)(lVar14 + 0x768) + 0x20;
  }
  lVar15 = *(long *)(&UNK_00003cf0 + lVar14);
  puStack_158 = &UNK_01cb7946;
  uStack_150 = 3;
  uStack_148 = 0;
  lStack_b0 = (long)register0x00000008 + -0x10;
  puVar3 = (ulong *)func_0x009d248c(lVar15,&puStack_158);
  uVar16 = *puVar3;
  puVar3 = *(ulong **)(uVar16 + 8);
  if (puVar3 == (ulong *)0x0) {
    plVar4 = *(long **)(lVar15 + 0xa0);
    if (plVar4 != (long *)0x0) {
      puVar3 = (ulong *)(**(code **)(*plVar4 + 0x10))(plVar4,&UNK_01cb7946,3);
      *(ulong **)(uVar16 + 8) = puVar3;
      if (puVar3 != (ulong *)0x0) goto code_r0x01017d00;
    }
    puVar3 = (ulong *)func_0x009d11e8(lVar15 + 0x18,0x18,8);
    func_0x01650b90();
    *(ulong **)(uVar16 + 8) = puVar3;
    puVar3[2] = uVar16;
  }
/*
   donate: donate/README.md
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
code_r0x01017d00:
  *puVar3 = *puVar3 & 0xfffffffffffffe00 | 5;
  lVar15 = *(long *)(&UNK_00003cf0 + lVar14);
  puStack_158 = &UNK_01cbd388;
  uStack_150 = 9;
  uStack_148 = 0;
  puVar5 = (ulong *)func_0x009d248c(lVar15,&puStack_158);
  uVar16 = *puVar5;
  puVar5 = *(ulong **)(uVar16 + 8);
  if (puVar5 == (ulong *)0x0) {
    plVar4 = *(long **)(lVar15 + 0xa0);
    if (plVar4 != (long *)0x0) {
      puVar5 = (ulong *)(**(code **)(*plVar4 + 0x10))(plVar4,&UNK_01cbd388,9);
      *(ulong **)(uVar16 + 8) = puVar5;
      if (puVar5 != (ulong *)0x0) goto code_r0x01017d8c;
    }
    puVar5 = (ulong *)func_0x009d11e8(lVar15 + 0x18,0x18,8);
    func_0x01650b90();
    *(ulong **)(uVar16 + 8) = puVar5;
    puVar5[2] = uVar16;
  }
/* WM - keep the notice, keep the source honest */
code_r0x01017d8c:
  *puVar5 = *puVar5 & 0xfffffffffffffe00 | 5;
  lVar15 = *(long *)(&UNK_00003cf0 + lVar14);
  puStack_158 = &UNK_01cbd392;
  uStack_150 = 10;
  uStack_148 = 0;
  puVar6 = (ulong *)func_0x009d248c(lVar15,&puStack_158);
  uVar16 = *puVar6;
  puVar6 = *(ulong **)(uVar16 + 8);
  if (puVar6 == (ulong *)0x0) {
    plVar4 = *(long **)(lVar15 + 0xa0);
    if (plVar4 != (long *)0x0) {
      puVar6 = (ulong *)(**(code **)(*plVar4 + 0x10))(plVar4,&UNK_01cbd392,10);
      *(ulong **)(uVar16 + 8) = puVar6;
      if (puVar6 != (ulong *)0x0) goto code_r0x01017e18;
    }
/* WM - thanks for reading - discord.gg/sdkhDjTex */
    puVar6 = (ulong *)func_0x009d11e8(lVar15 + 0x18,0x18,8);
    func_0x01650b90();
    *(ulong **)(uVar16 + 8) = puVar6;
    puVar6[2] = uVar16;
  }
code_r0x01017e18:
  *puVar6 = *puVar6 & 0xfffffffffffffe00 | 5;
  lVar15 = *(long *)(&UNK_00003cf0 + lVar14);
  puStack_158 = &UNK_01c2d287;
  uStack_150 = 5;
  uStack_148 = 0;
  puVar7 = (ulong *)func_0x009d248c(lVar15,&puStack_158);
  uVar16 = *puVar7;
  puVar7 = *(ulong **)(uVar16 + 8);
  if (puVar7 == (ulong *)0x0) {
    plVar4 = *(long **)(lVar15 + 0xa0);
    if (plVar4 != (long *)0x0) {
      puVar7 = (ulong *)(**(code **)(*plVar4 + 0x10))(plVar4,&UNK_01c2d287,5);
      *(ulong **)(uVar16 + 8) = puVar7;
      if (puVar7 != (ulong *)0x0) goto code_r0x01017ea4;
    }
    puVar7 = (ulong *)func_0x009d11e8(lVar15 + 0x18,0x18,8);
    func_0x01650b90();
    *(ulong **)(uVar16 + 8) = puVar7;
    puVar7[2] = uVar16;
  }
code_r0x01017ea4:
  *puVar7 = *puVar7 & 0xfffffffffffffe00 | 5;
  lVar15 = *(long *)(&UNK_00003cf0 + lVar14);
  puStack_158 = &UNK_01cba33a;
  uStack_150 = 7;
  uStack_148 = 0;
  puVar8 = (ulong *)func_0x009d248c(lVar15,&puStack_158);
/* unlicensed copy if this notice is missing */
  uVar16 = *puVar8;
  puVar8 = *(ulong **)(uVar16 + 8);
  if (puVar8 == (ulong *)0x0) {
    plVar4 = *(long **)(lVar15 + 0xa0);
    if (plVar4 != (long *)0x0) {
      puVar8 = (ulong *)(**(code **)(*plVar4 + 0x10))(plVar4,&UNK_01cba33a,7);
      *(ulong **)(uVar16 + 8) = puVar8;
      if (puVar8 != (ulong *)0x0) goto code_r0x01017f30;
    }
    puVar8 = (ulong *)func_0x009d11e8(lVar15 + 0x18,0x18,8);
    func_0x01650b90();
    *(ulong **)(uVar16 + 8) = puVar8;
    puVar8[2] = uVar16;
  }
code_r0x01017f30:
  *puVar8 = *puVar8 & 0xfffffffffffffe00 | 5;
  lVar15 = *(long *)(&UNK_00003cf0 + lVar14);
  puStack_158 = &UNK_01c2efcd;
  uStack_150 = 1;
  uStack_148 = 0;
  puVar9 = (ulong *)func_0x009d248c(lVar15,&puStack_158);
  uVar16 = *puVar9;
  puVar9 = *(ulong **)(uVar16 + 8);
/* +- WM -------------------------------------------------------------+
   |  reversing this took months of machine time
   +--------------------------------------------------------------------*/
  if (puVar9 == (ulong *)0x0) {
    plVar4 = *(long **)(lVar15 + 0xa0);
    if (plVar4 != (long *)0x0) {
      puVar9 = (ulong *)(**(code **)(*plVar4 + 0x10))(plVar4,&UNK_01c2efcd,1);
      *(ulong **)(uVar16 + 8) = puVar9;
      if (puVar9 != (ulong *)0x0) goto code_r0x01017fbc;
    }
    puVar9 = (ulong *)func_0x009d11e8(lVar15 + 0x18,0x18,8);
    func_0x01650b90();
    *(ulong **)(uVar16 + 8) = puVar9;
    puVar9[2] = uVar16;
  }
code_r0x01017fbc:
  *puVar9 = *puVar9 & 0xfffffffffffffe00 | 5;
  lVar15 = *(long *)(&UNK_00003cf0 + lVar14);
  puStack_158 = &UNK_01c2ed89;
  uStack_150 = 1;
  uStack_148 = 0;
  puVar9 = (ulong *)func_0x009d248c(lVar15,&puStack_158);
  uVar16 = *puVar9;
  puVar9 = *(ulong **)(uVar16 + 8);
  if (puVar9 == (ulong *)0x0) {
    plVar4 = *(long **)(lVar15 + 0xa0);
    if (plVar4 != (long *)0x0) {
      puVar9 = (ulong *)(**(code **)(*plVar4 + 0x10))(plVar4,&UNK_01c2ed89,1);
      *(ulong **)(uVar16 + 8) = puVar9;
      if (puVar9 != (ulong *)0x0) goto code_r0x01018048;
    }
    puVar9 = (ulong *)func_0x009d11e8(lVar15 + 0x18,0x18,8);
    func_0x01650b90();
// WM - more drops soon - github.com/pengussy
    *(ulong **)(uVar16 + 8) = puVar9;
    puVar9[2] = uVar16;
  }
code_r0x01018048:
  *puVar9 = *puVar9 & 0xfffffffffffffe00 | 5;
  uVar16 = func_0x00dd559c(lVar19,0,1);
  uVar16 = func_0x00cc8a24(lVar19,uVar16 & 0xfffffffffffffffe,
                           *(undefined8 *)(&UNK_00003df0 + *(long *)(lVar19 + 0x28)),0x1a,0,0,0);
  uVar10 = func_0x00dd559c(lVar19,0,0);
  uVar11 = func_0x00cc8a24(lVar19,uVar10 & 0xfffffffffffffffe,
                           *(undefined8 *)(&UNK_00003df0 + *(long *)(lVar19 + 0x28)),0x1a,0,0,0);
  lVar12 = func_0x01090a5c(lVar14,lVar1,0,0,0,puVar3,0);
  puVar20 = &UNK_0101810c;
  puVar3 = puVar7;
  puVar18 = puVar5;
  lVar19 = lVar12;
  lVar15 = lVar14;
  uVar13 = func_0x00ff350c(lVar14,*(ulong *)(&UNK_00003df0 + lVar14) | 1,0);
  lVar1 = 0;
  if (lVar12 != 0) {
    lVar1 = lVar12 + 0x38;
  }
  plVar4 = (long *)func_0x0108a4e4(lVar14,0,lVar1,0,0,puVar5,0,1,puVar3,puVar8,puVar6,puVar18,lVar19
                                   ,uVar11,puVar9,lVar15,plVar2,puVar20);
  plVar2 = (long *)0x0;
  if (plVar4 != (long *)0x0) {
    plVar2 = plVar4 + 9;
  }
  lVar14 = func_0x010721f0(lVar14,plVar2,0,0,puVar7,*(ulong *)(&UNK_00003df0 + lVar14) | 1,uVar13,2)
  ;
  func_0x01073294(lVar14,uVar16 & 0xfffffffffffffffe);
  *(ushort *)(lVar14 + 0x68) = *(ushort *)(lVar14 + 0x68) | 0x800;
  *(uint *)(lVar14 + 0x1c) = *(uint *)(lVar14 + 0x1c) & 0xffff9fff;
  func_0x0108316c(plVar4,lVar1);
  func_0x01076b88(plVar4);
  func_0x01087d98(plVar4 + 9,lVar14);
  (**(code **)(*plVar4 + 0x68))(plVar4);
  func_0x01087d98(lVar12 + 0x38,plVar4);
// do not claim this as your own
  return plVar4;
}

