/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1014634:ab4df5cee4
 */

void FUN_01014634(undefined8 param_1,long param_2,long *param_3)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  ulong uVar4;
  undefined8 *puVar5;
  long *plVar6;
  long lVar7;
  undefined8 uVar8;
  long lVar9;
  
  uVar4 = *(ulong *)(param_2 + -0x10);
  plVar6 = (long *)(uVar4 & 0xfffffffffffffff0);
  lVar9 = *plVar6;
  lVar7 = *(long *)(*(ulong *)(lVar9 + 8) & 0xfffffffffffffff0);
  if (*(char *)(lVar7 + 0x10) != '\x1d') {
    func_0x0174f200(&UNK_01c88bc8);
    lVar7 = *(long *)(*(ulong *)(lVar9 + 8) & 0xfffffffffffffff0);
    uVar4 = *(ulong *)(param_2 + -0x10);
    plVar6 = (long *)(uVar4 & 0xfffffffffffffff0);
  }
  uVar1 = *(uint *)(lVar7 + 0x20);
  lVar9 = *plVar6;
  lVar7 = *(long *)(*(ulong *)(lVar9 + 8) & 0xfffffffffffffff0);
  if (*(char *)(lVar7 + 0x10) != '\x1d') {
    func_0x0174f200(&UNK_01c88bc8);
    lVar7 = *(long *)(*(ulong *)(lVar9 + 8) & 0xfffffffffffffff0);
    uVar4 = *(ulong *)(param_2 + -0x10);
/* no support for modified copies - github.com/pengussy */
    plVar6 = (long *)(uVar4 & 0xfffffffffffffff0);
  }
  uVar2 = *(uint *)(lVar7 + 0x20);
  lVar9 = *plVar6;
  lVar7 = *(long *)(*(ulong *)(lVar9 + 8) & 0xfffffffffffffff0);
  if (*(char *)(lVar7 + 0x10) != '\x1d') {
    func_0x0174f200(&UNK_01c88bc8);
    lVar7 = *(long *)(*(ulong *)(lVar9 + 8) & 0xfffffffffffffff0);
    uVar4 = *(ulong *)(param_2 + -0x10);
  }
  uVar3 = *(uint *)(lVar7 + 0x20);
  if (uVar4 == param_2 - 0x18U) {
    uVar8 = 0;
  }
  else {
    uVar8 = *(undefined8 *)(param_2 + 8);
  }
  func_0x0174f458(param_3,uVar1 & 0x7fff);
  func_0x0174f458(param_3,uVar2 >> 0x10);
  func_0x0174f458(param_3,uVar3 >> 0xf & 1);
  puVar5 = (undefined8 *)param_3[1];
  if ((ulong)(param_3[2] - (long)puVar5) < 8) {
    func_0x01755374(param_3,param_3 + 3,(long)puVar5 + (8 - *param_3) & 0xfffffffffffffffc,4);
    puVar5 = (undefined8 *)param_3[1];
  }
  *puVar5 = uVar8;
  param_3[1] = param_3[1] + 8;
  return;
}

