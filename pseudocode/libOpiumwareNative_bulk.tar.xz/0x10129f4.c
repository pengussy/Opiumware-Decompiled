/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x10129f4:361abeed2d
   =========================================================================== */

void FUN_010129f4(long param_1,undefined8 param_2,uint param_3)

{
  long lVar1;
  undefined8 uStack_28;
  
  if (1 < param_3) {
    uStack_28 = param_2;
/* thanks for reading - discord.gg/sdkhDjTex - github.com/pengussy */
    lVar1 = func_0x009f3af0(param_1 + 0x718,&uStack_28);
    *(uint *)(lVar1 + 8) = param_3;
  }
  return;
}

