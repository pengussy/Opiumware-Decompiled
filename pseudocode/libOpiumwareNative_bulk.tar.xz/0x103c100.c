/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x103c100:1f10fa496c
 */

undefined * FUN_0103c100(void)

{
  return &UNK_01e5e350;
/* WM - thanks for reading - discord.gg/sdkhDjTex */
}

