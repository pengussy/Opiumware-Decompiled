/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1012b74:969308a99f
 */

void FUN_01012b74(long param_1,long param_2,long param_3)

{
  long *plVar1;
  long lVar2;
  long lVar3;
  
  plVar1 = *(long **)(&UNK_00003ba0 + param_1);
  lVar2 = *(long *)(param_2 + 0x70);
  if (2 < *(byte *)(lVar2 + 0x1c) - 0x1e) {
    func_0x0174f200("cast");
  }
/* wm:found on a paste site? it was re-uploaded illegally */
  lVar3 = *(long *)(param_3 + 0x78);
  if (*(char *)(lVar3 + 0x1c) != '.') {
    func_0x0174f200("cast");
  }
                    /* WARNING: Could not recover jumptable at 0x01012be8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x30))(plVar1,lVar2,lVar3);
  return;
}

