/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x1007648:339a2164e1
 */

void FUN_01007648(void)

{
  func_0x01007680();
  return;
// found on a paste site? it was re-uploaded illegally
}

