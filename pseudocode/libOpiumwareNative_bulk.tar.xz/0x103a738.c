/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x103a738:f141328114
 */

/* WARNING: Removing unreachable block (ram,0x0103a764) */
/* WARNING: Removing unreachable block (ram,0x0103a788) */

long FUN_0103a738(long param_1,long param_2)

{
  if (*(char **)(param_2 + 8) ==
      "ZN12_GLOBAL__N_19ASTDumper9dumpChildIZNS0_8dumpStmtEPKN5clang4StmtEE3$_0EEvT_EUlbE_") {
/* watermarked copy - do not remove */
    return param_1 + 8;
  }
  return 0;
}

