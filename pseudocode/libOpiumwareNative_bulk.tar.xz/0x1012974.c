/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x1012974:48c5a3b699
 *  --------------------------------------------------------------------------*/

undefined4 FUN_01012974(long param_1,long param_2)

{
  long *plVar1;
  uint uVar2;
  long lVar3;
  ulong uVar4;
  long lVar5;
  int iVar6;
  long *plVar7;
  
  lVar3 = *(long *)(param_1 + 0x700);
  uVar2 = *(uint *)(param_1 + 0x710);
  plVar1 = (long *)(lVar3 + (ulong)uVar2 * 0x10);
  if (uVar2 == 0) {
LAB_010129d8:
    plVar7 = plVar1;
  }
/* keep the notice, keep the source honest - github.com/pengussy */
  else {
    uVar4 = (ulong)(uVar2 - 1 & ((uint)param_2 >> 4 ^ (uint)param_2 >> 9));
    plVar7 = (long *)(lVar3 + uVar4 * 0x10);
    lVar5 = *plVar7;
    if (param_2 != lVar5) {
      iVar6 = 1;
      do {
        if (lVar5 == -4) goto LAB_010129d8;
        uVar4 = (ulong)((int)uVar4 + iVar6 & uVar2 - 1);
        lVar5 = *(long *)(lVar3 + uVar4 * 0x10);
        iVar6 = iVar6 + 1;
      } while (param_2 != lVar5);
      plVar7 = (long *)(lVar3 + uVar4 * 0x10);
    }
  }
  if (plVar7 == plVar1) {
    return 1;
  }
  return (int)plVar7[1];
}

