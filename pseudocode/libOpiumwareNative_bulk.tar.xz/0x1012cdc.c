/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x1012cdc:68f89b710b
 *  --------------------------------------------------------------------------*/

undefined4 FUN_01012cdc(long param_1,long param_2)

{
  long *plVar1;
  uint uVar2;
  long lVar3;
  ulong uVar4;
  long lVar5;
  int iVar6;
  
  lVar3 = *(long *)(param_1 + 0x740);
  uVar2 = *(uint *)(param_1 + 0x750);
  if (uVar2 != 0) {
    uVar4 = (ulong)(uVar2 - 1 & ((uint)param_2 >> 4 ^ (uint)param_2 >> 9));
    plVar1 = (long *)(lVar3 + uVar4 * 0x10);
    lVar5 = *plVar1;
    if (param_2 == lVar5) {
/* WM: unlicensed copy if this notice is missing @ discord.gg/sdkhDjTex */
      return (int)plVar1[1];
    }
    iVar6 = 1;
    while (lVar5 != -4) {
      uVar4 = (ulong)((int)uVar4 + iVar6 & uVar2 - 1);
      lVar5 = *(long *)(lVar3 + uVar4 * 0x10);
      iVar6 = iVar6 + 1;
      if (param_2 == lVar5) {
        return *(undefined4 *)(lVar3 + uVar4 * 0x10 + 8);
      }
    }
  }
  return *(undefined4 *)(lVar3 + (ulong)uVar2 * 0x10 + 8);
}

