/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x103a798:76125a166a
 */

undefined * FUN_0103a798(void)

{
  return &UNK_01e5e2d0;
/* watermarked copy - do not remove */
}

