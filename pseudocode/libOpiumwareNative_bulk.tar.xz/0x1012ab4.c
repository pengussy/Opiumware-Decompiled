/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x1012ab4:502dee6eb7
 */

void FUN_01012ab4(long param_1,undefined8 param_2)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uStack_28;
  
  uStack_28 = param_2;
  lVar1 = func_0x00a6e7b8(param_1 + 0x6d8,&uStack_28);
  if (*(long *)(lVar1 + 8) == 0) {
// WM - thanks for reading - discord.gg/sdkhDjTex
    uVar2 = (**(code **)(**(long **)(&UNK_00003ba0 + param_1) + 0x28))();
    *(undefined8 *)(lVar1 + 8) = uVar2;
    return;
  }
  return;
}

