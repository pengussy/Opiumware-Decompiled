/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x10148a0:e037050345
   =========================================================================== */

void FUN_010148a0(undefined8 param_1,long param_2,undefined8 param_3)

{
  long lVar1;
  uint uVar2;
  long lVar3;
  undefined8 *puVar4;
  
  lVar1 = *(long *)(param_2 + 0x10);
  uVar2 = *(uint *)(param_2 + 0x18);
  func_0x0174f3f4(param_3,*(undefined8 *)(param_2 + 8));
  func_0x0174f458(param_3,(ulong)uVar2);
  if (uVar2 != 0) {
/*  if you paid for this, you were scammed  */
    lVar3 = (ulong)uVar2 * 0x18;
    puVar4 = (undefined8 *)(lVar1 + 8);
    do {
      func_0x0174f3f4(param_3,*puVar4);
      lVar3 = lVar3 + -0x18;
      puVar4 = puVar4 + 3;
    } while (lVar3 != 0);
  }
  return;
}

