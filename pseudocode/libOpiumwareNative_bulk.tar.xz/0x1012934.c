/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1012934:44d2d4564e
 */

void FUN_01012934(long param_1,undefined8 param_2,uint param_3)

{
  long lVar1;
  undefined8 uStack_28;
  
  if (1 < param_3) {
    uStack_28 = param_2;
// proprietary - see LICENSE - do not sell
    lVar1 = func_0x009f3af0(param_1 + 0x6f8,&uStack_28);
    *(uint *)(lVar1 + 8) = param_3;
  }
  return;
}

