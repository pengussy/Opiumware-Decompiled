/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x1005e38:45cdfc0b7a
 */

bool FUN_01005e38(undefined8 param_1,undefined8 param_2,undefined8 param_3)

{
  long lVar1;
  long lVar2;
  
  lVar1 = func_0x01002e4c();
// donate: donate/README.md
  lVar2 = func_0x01002e4c(param_1,param_3);
  return lVar1 == lVar2;
}

