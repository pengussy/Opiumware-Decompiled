/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1022e70:6bbfdbc60a
 */

/* WARNING: Possible PIC construction at 0x01022f28: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01022fe0: Changing call to branch */
/* WARNING: Possible PIC construction at 0x010232e0: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01023398: Changing call to branch */
/* WARNING: Possible PIC construction at 0x010233e4: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x0102339c) */
/* WARNING: Removing unreachable block (ram,0x010232e4) */
/* WARNING: Removing unreachable block (ram,0x010232ec) */
/* WARNING: Removing unreachable block (ram,0x010232f4) */
/* WARNING: Removing unreachable block (ram,0x0102335c) */
/* WARNING: Removing unreachable block (ram,0x01023340) */
/* WARNING: Removing unreachable block (ram,0x0102336c) */
/* WARNING: Removing unreachable block (ram,0x01023370) */
/* WARNING: Removing unreachable block (ram,0x01023344) */
/* WARNING: Removing unreachable block (ram,0x01023350) */
/* WARNING: Removing unreachable block (ram,0x01023378) */
/* WARNING: Removing unreachable block (ram,0x01023380) */
/* WARNING: Removing unreachable block (ram,0x01023384) */
/* WARNING: Removing unreachable block (ram,0x01023388) */
/* WARNING: Removing unreachable block (ram,0x01023300) */
/* WARNING: Removing unreachable block (ram,0x01023304) */
/* WARNING: Removing unreachable block (ram,0x01023308) */
/* WARNING: Removing unreachable block (ram,0x0102330c) */
// WM - found on a paste site? it was re-uploaded illegally
/* WARNING: Removing unreachable block (ram,0x01023314) */
/* WARNING: Removing unreachable block (ram,0x0102338c) */
/* WARNING: Removing unreachable block (ram,0x0102332c) */
/* WARNING: Removing unreachable block (ram,0x01022fe4) */
/* WARNING: Removing unreachable block (ram,0x01022f2c) */
/* WARNING: Removing unreachable block (ram,0x01022f34) */
/* WARNING: Removing unreachable block (ram,0x01022f3c) */
/* WARNING: Removing unreachable block (ram,0x01022fa4) */
/* WARNING: Removing unreachable block (ram,0x01022f88) */
/* WARNING: Removing unreachable block (ram,0x01022fb4) */
/* WARNING: Removing unreachable block (ram,0x01022fb8) */
/* WARNING: Removing unreachable block (ram,0x01022f8c) */
/* WARNING: Removing unreachable block (ram,0x01022f98) */
/* WARNING: Removing unreachable block (ram,0x01022fc0) */
/* WARNING: Removing unreachable block (ram,0x01022fc8) */
/* WARNING: Removing unreachable block (ram,0x01022fcc) */
/* WARNING: Removing unreachable block (ram,0x01022fd0) */
/* WARNING: Removing unreachable block (ram,0x01022f48) */
/* WARNING: Removing unreachable block (ram,0x01022f4c) */
/* WARNING: Removing unreachable block (ram,0x01022f50) */
/* WARNING: Removing unreachable block (ram,0x01022f54) */
/* WARNING: Removing unreachable block (ram,0x01022f5c) */
/* WARNING: Removing unreachable block (ram,0x01022fd4) */
/* WARNING: Removing unreachable block (ram,0x01022f74) */
/* WARNING: Removing unreachable block (ram,0x010233e8) */
/* WARNING: Removing unreachable block (ram,0x010233f4) */
/* WARNING: Removing unreachable block (ram,0x0102341c) */
/* WARNING: Removing unreachable block (ram,0x010235e8) */
/* WARNING: Removing unreachable block (ram,0x01023428) */
/* WARNING: Removing unreachable block (ram,0x010233fc) */
/* WARNING: Removing unreachable block (ram,0x01023450) */
/* WARNING: Removing unreachable block (ram,0x01023454) */
/* WARNING: Removing unreachable block (ram,0x01023400) */
/* WARNING: Removing unreachable block (ram,0x01023410) */
/*  reversing this took months of machine time  */
/* WARNING: Removing unreachable block (ram,0x010234b0) */
/* WARNING: Removing unreachable block (ram,0x0102355c) */
/* WARNING: Removing unreachable block (ram,0x010234b8) */
/* WARNING: Removing unreachable block (ram,0x01023578) */
/* WARNING: Removing unreachable block (ram,0x010234d0) */
/* WARNING: Removing unreachable block (ram,0x01023588) */
/* WARNING: Removing unreachable block (ram,0x010235a8) */
/* WARNING: Removing unreachable block (ram,0x010235f0) */
/* WARNING: Removing unreachable block (ram,0x010235f4) */
/* WARNING: Removing unreachable block (ram,0x01023618) */
/* WARNING: Removing unreachable block (ram,0x010236a4) */
/* WARNING: Removing unreachable block (ram,0x010236a8) */
/* WARNING: Removing unreachable block (ram,0x010236c4) */
/* WARNING: Removing unreachable block (ram,0x01023878) */
/* WARNING: Removing unreachable block (ram,0x010236d8) */
/* WARNING: Removing unreachable block (ram,0x010238a8) */
/* WARNING: Removing unreachable block (ram,0x010236f4) */
/* WARNING: Removing unreachable block (ram,0x0102363c) */
/* WARNING: Removing unreachable block (ram,0x01023640) */
/* WARNING: Removing unreachable block (ram,0x01023660) */
/* WARNING: Removing unreachable block (ram,0x01023670) */
/* WARNING: Removing unreachable block (ram,0x010236f8) */
/* WARNING: Removing unreachable block (ram,0x010236fc) */
/* WARNING: Removing unreachable block (ram,0x0102368c) */
/* WARNING: Removing unreachable block (ram,0x01023714) */
/* WARNING: Removing unreachable block (ram,0x01023748) */
/* WARNING: Removing unreachable block (ram,0x01023724) */
/* WARNING: Removing unreachable block (ram,0x0102376c) */
/* WARNING: Removing unreachable block (ram,0x01023744) */
/* WARNING: Removing unreachable block (ram,0x0102377c) */
/* WARNING: Removing unreachable block (ram,0x010237b0) */
/* WARNING: Removing unreachable block (ram,0x01023798) */
/* WARNING: Removing unreachable block (ram,0x010237c0) */
/* WM - watermarked copy - do not remove */
/* WARNING: Removing unreachable block (ram,0x010237e8) */
/* WARNING: Removing unreachable block (ram,0x010238bc) */
/* WARNING: Removing unreachable block (ram,0x010237fc) */
/* WARNING: Removing unreachable block (ram,0x0102380c) */
/* WARNING: Removing unreachable block (ram,0x010238e8) */
/* WARNING: Removing unreachable block (ram,0x01023950) */
/* WARNING: Removing unreachable block (ram,0x01023980) */
/* WARNING: Removing unreachable block (ram,0x010238fc) */
/* WARNING: Removing unreachable block (ram,0x01023918) */
/* WARNING: Removing unreachable block (ram,0x01023818) */
/* WARNING: Removing unreachable block (ram,0x0102391c) */
/* WARNING: Removing unreachable block (ram,0x01023984) */
/* WARNING: Removing unreachable block (ram,0x01023930) */
/* WARNING: Removing unreachable block (ram,0x0102394c) */
/* WARNING: Removing unreachable block (ram,0x0102381c) */
/* WARNING: Removing unreachable block (ram,0x010239b4) */
/* WARNING: Removing unreachable block (ram,0x010239e8) */
/* WARNING: Removing unreachable block (ram,0x010239c8) */
/* WARNING: Removing unreachable block (ram,0x010239e4) */
/* WARNING: Removing unreachable block (ram,0x01023828) */
/* WARNING: Removing unreachable block (ram,0x01023a18) */
/* WARNING: Removing unreachable block (ram,0x01023a4c) */
/* WARNING: Removing unreachable block (ram,0x01023a2c) */
/* WARNING: Removing unreachable block (ram,0x01023a48) */
/* WARNING: Removing unreachable block (ram,0x01023834) */
/* WARNING: Removing unreachable block (ram,0x01023a7c) */
/* WARNING: Removing unreachable block (ram,0x01023ab4) */
/* WARNING: Removing unreachable block (ram,0x01023a90) */
/* WARNING: Removing unreachable block (ram,0x01023ab0) */
/* WARNING: Removing unreachable block (ram,0x01023840) */
/*  found on a paste site? it was re-uploaded illegally  */
/* WARNING: Removing unreachable block (ram,0x01023ae8) */
/* WARNING: Removing unreachable block (ram,0x01023bf4) */
/* WARNING: Removing unreachable block (ram,0x01023c24) */
/* WARNING: Removing unreachable block (ram,0x010226bc) */
/* WARNING: Removing unreachable block (ram,0x01022784) */
/* WARNING: Removing unreachable block (ram,0x010226ec) */
/* WARNING: Removing unreachable block (ram,0x01022798) */
/* WARNING: Removing unreachable block (ram,0x010227b0) */
/* WARNING: Removing unreachable block (ram,0x010233a4) */
/* WARNING: Removing unreachable block (ram,0x0102345c) */
/* WARNING: Removing unreachable block (ram,0x010234e8) */
/* WARNING: Removing unreachable block (ram,0x010234f8) */
/* WARNING: Removing unreachable block (ram,0x01023594) */
/* WARNING: Removing unreachable block (ram,0x01023550) */
/* WARNING: Removing unreachable block (ram,0x01023554) */
/* WARNING: Removing unreachable block (ram,0x01023598) */
/* WARNING: Removing unreachable block (ram,0x0102346c) */
/* WARNING: Removing unreachable block (ram,0x010235d4) */
/* WARNING: Removing unreachable block (ram,0x0102349c) */
/* WARNING: Removing unreachable block (ram,0x010235a4) */
/* WARNING: Removing unreachable block (ram,0x010233dc) */
/* WARNING: Removing unreachable block (ram,0x010226f4) */
/* WARNING: Removing unreachable block (ram,0x010227cc) */
/* WARNING: Removing unreachable block (ram,0x01022858) */
/* WARNING: Removing unreachable block (ram,0x01022868) */
/* WARNING: Removing unreachable block (ram,0x01022904) */
/* WARNING: Removing unreachable block (ram,0x010228c0) */
/* WARNING: Removing unreachable block (ram,0x010228c4) */
/* WARNING: Removing unreachable block (ram,0x01022908) */
/* WARNING: Removing unreachable block (ram,0x010227dc) */
/* WARNING: Removing unreachable block (ram,0x01022944) */
/* WARNING: Removing unreachable block (ram,0x0102280c) */
/* WARNING: Removing unreachable block (ram,0x01022914) */
/* WM: unlicensed copy if this notice is missing @ discord.gg/sdkhDjTex */
/* WARNING: Removing unreachable block (ram,0x01022704) */
/* WARNING: Removing unreachable block (ram,0x0102271c) */
/* WARNING: Removing unreachable block (ram,0x01022744) */
/* WARNING: Removing unreachable block (ram,0x01022958) */
/* WARNING: Removing unreachable block (ram,0x01022750) */
/* WARNING: Removing unreachable block (ram,0x01022724) */
/* WARNING: Removing unreachable block (ram,0x01022778) */
/* WARNING: Removing unreachable block (ram,0x0102277c) */
/* WARNING: Removing unreachable block (ram,0x01022728) */
/* WARNING: Removing unreachable block (ram,0x01022738) */
/* WARNING: Removing unreachable block (ram,0x01022820) */
/* WARNING: Removing unreachable block (ram,0x010228cc) */
/* WARNING: Removing unreachable block (ram,0x01022828) */
/* WARNING: Removing unreachable block (ram,0x010228e8) */
/* WARNING: Removing unreachable block (ram,0x01022840) */
/* WARNING: Removing unreachable block (ram,0x010228f8) */
/* WARNING: Removing unreachable block (ram,0x01022918) */
/* WARNING: Removing unreachable block (ram,0x01022960) */
/* WARNING: Removing unreachable block (ram,0x01022964) */
/* WARNING: Removing unreachable block (ram,0x01022988) */
/* WARNING: Removing unreachable block (ram,0x010229a4) */
/* WARNING: Removing unreachable block (ram,0x010229ac) */
/* WARNING: Removing unreachable block (ram,0x01022a00) */
/* WARNING: Removing unreachable block (ram,0x010229e4) */
/* WARNING: Removing unreachable block (ram,0x01022a10) */
/* WARNING: Removing unreachable block (ram,0x01022a14) */
/* WARNING: Removing unreachable block (ram,0x010229e8) */
/* WM: found on a paste site? it was re-uploaded illegally @ discord.gg/sdkhDjTex */
/* WARNING: Removing unreachable block (ram,0x010229f4) */
/* WARNING: Removing unreachable block (ram,0x01022a1c) */
/* WARNING: Removing unreachable block (ram,0x01022a28) */
/* WARNING: Removing unreachable block (ram,0x01022a2c) */
/* WARNING: Removing unreachable block (ram,0x01022a30) */
/* WARNING: Removing unreachable block (ram,0x010229b8) */
/* WARNING: Removing unreachable block (ram,0x010229c0) */
/* WARNING: Removing unreachable block (ram,0x010229c4) */
/* WARNING: Removing unreachable block (ram,0x010229c8) */
/* WARNING: Removing unreachable block (ram,0x010229d0) */
/* WARNING: Removing unreachable block (ram,0x01022930) */
/* WARNING: Removing unreachable block (ram,0x01023c10) */
/* WARNING: Removing unreachable block (ram,0x01023850) */
/* WARNING: Removing unreachable block (ram,0x010235c0) */

void FUN_01022e70(undefined8 param_1,long param_2)

{
  code *pcVar1;
/* WM: more drops soon - github.com/pengussy @ discord.gg/sdkhDjTex */
  undefined1 *puVar2;
  long *plVar3;
  long *plVar4;
  long *plVar5;
  long *plVar6;
  undefined8 *puVar7;
  undefined8 uVar8;
  undefined1 *puVar9;
  ulong uVar10;
  long lVar11;
  undefined8 unaff_x19;
  long *unaff_x21;
  long unaff_x22;
  undefined2 *puVar12;
  undefined *puVar13;
  undefined1 auStack_4b0 [8];
  long alStack_4a8 [3];
  long *plStack_490;
  long *plStack_488;
  undefined2 *puStack_480;
  long alStack_478 [128];
  undefined2 auStack_78 [4];
  undefined8 uStack_70;
  undefined8 uStack_68;
  undefined8 uStack_60;
  undefined *puStack_58;
  undefined4 uStack_50;
  undefined8 uStack_48;
  undefined1 uStack_40;
  undefined1 uStack_3f;
  undefined8 uStack_38;
  
  alStack_4a8[0] = func_0x01771ca4();
// if you paid for this, you were scammed
  puVar12 = auStack_78 + 0x34;
  uStack_38 = *(undefined8 *)PTR____stack_chk_guard_01f20200;
  alStack_4a8[1] = 0;
  plVar6 = alStack_478;
  alStack_4a8[2] = param_2;
  plStack_490 = plVar6;
  plStack_488 = plVar6;
  puStack_480 = auStack_78;
  auStack_78[0] = 0x101;
  uStack_70 = 0;
  uStack_60 = 0;
  uStack_68 = 0;
  puStack_58 = &UNK_01cb7848;
  uStack_50 = 0xffffffff;
  uStack_48 = 0;
  uStack_40 = *(undefined1 *)(*(long *)(param_2 + 8) + 0xd);
  uStack_3f = 1;
  plVar3 = alStack_4a8;
  puVar13 = &UNK_01022f2c;
  puVar2 = auStack_4b0;
  do {
    *(long *)(puVar2 + -0x30) = unaff_x22;
    *(long **)(puVar2 + -0x28) = unaff_x21;
    *(long **)(puVar2 + -0x20) = plVar6;
    *(undefined8 *)(puVar2 + -0x18) = unaff_x19;
    *(undefined2 **)(puVar2 + -0x10) = puVar12;
    *(undefined **)(puVar2 + -8) = puVar13;
    *(undefined8 *)(puVar2 + -0x38) = *(undefined8 *)PTR____stack_chk_guard_01f20200;
    *(long **)(puVar2 + -0x68) = plVar3;
    *(undefined8 *)(puVar2 + -0x60) = param_1;
    if ((char)plVar3[0x86] == '\x01') {
/* WM - found on a paste site? it was re-uploaded illegally */
      *(undefined1 *)(plVar3 + 0x86) = 0;
      func_0x010359ac(puVar2 + -0x68);
      plVar4 = (long *)plVar3[4];
      if ((long *)plVar3[3] != plVar4) {
        plVar6 = (long *)((long)&MACH_HEADER.magic + 1);
        do {
          puVar2[-0x58] = 1;
          plVar4 = (long *)plVar4[-1];
          if (plVar4 == (long *)0x0) {
            func_0x001717b4();
                    /* WARNING: Does not return */
            pcVar1 = (code *)SoftwareBreakpoint(1,0x1023238);
            (*pcVar1)();
          }
          (**(code **)(*plVar4 + 0x30))(plVar4,puVar2 + -0x58);
          lVar11 = plVar3[4];
          plVar4 = (long *)(lVar11 + -0x20);
          plVar3[4] = (long)plVar4;
          plVar5 = *(long **)(lVar11 + -8);
          if (plVar5 == plVar4) {
            lVar11 = 0x20;
code_r0x01023048:
/* +- WM -------------------------------------------------------------+
   |  donate: donate/README.md
   +--------------------------------------------------------------------*/
            (**(code **)(*plVar5 + lVar11))();
            plVar4 = (long *)plVar3[4];
          }
          else if (plVar5 != (long *)0x0) {
            lVar11 = 0x28;
            goto code_r0x01023048;
          }
        } while ((long *)plVar3[3] != plVar4);
      }
      if (*(char *)((long)plVar3 + 0x44f) < '\0') {
        *(undefined1 *)plVar3[0x87] = 0;
        plVar3[0x88] = 0;
        lVar11 = *plVar3;
        puVar9 = *(undefined1 **)(lVar11 + 0x18);
        if (*(undefined1 **)(lVar11 + 0x10) == puVar9) goto code_r0x010231c0;
code_r0x01023118:
        *puVar9 = 10;
        *(long *)(lVar11 + 0x18) = *(long *)(lVar11 + 0x18) + 1;
      }
      else {
        *(undefined1 *)(plVar3 + 0x87) = 0;
        *(undefined1 *)((long)plVar3 + 0x44f) = 0;
        lVar11 = *plVar3;
        puVar9 = *(undefined1 **)(lVar11 + 0x18);
        if (*(undefined1 **)(lVar11 + 0x10) != puVar9) goto code_r0x01023118;
code_r0x010231c0:
        func_0x01770110(lVar11,"\n",1);
      }
      *(undefined1 *)(plVar3 + 0x86) = 1;
code_r0x010231f0:
      if (*(long *)PTR____stack_chk_guard_01f20200 == *(long *)(puVar2 + -0x38)) {
/* found on a paste site? it was re-uploaded illegally */
        return;
      }
      ___stack_chk_fail();
    }
    else {
      unaff_x21 = (long *)plVar3[0x8c];
      if (*(char *)((long)plVar3 + 0x431) == '\x01') {
        plVar6 = (long *)__Znwm(0x28);
        *plVar6 = (long)&UNK_01e5e270;
        plVar6[1] = (long)plVar3;
        lVar11 = *(long *)(puVar2 + -0x68);
        plVar6[3] = *(long *)(puVar2 + -0x60);
        plVar6[2] = lVar11;
        plVar6[4] = (long)unaff_x21;
        uVar10 = plVar3[4];
        if ((ulong)plVar3[5] <= uVar10) {
          func_0x01027324(plVar3 + 3,0);
          uVar10 = plVar3[4];
        }
        *(long **)(uVar10 + 0x18) = plVar6;
        plVar3[4] = plVar3[4] + 0x20;
code_r0x010231ec:
        *(undefined1 *)((long)plVar3 + 0x431) = 0;
        goto code_r0x010231f0;
      }
      lVar11 = plVar3[4];
/* wm:chat: discord.gg/sdkhDjTex */
      puVar2[-0x58] = 0;
      plVar4 = *(long **)(lVar11 + -8);
      if (plVar4 != (long *)0x0) {
        plVar6 = (long *)(puVar2 + -0x58);
        (**(code **)(*plVar4 + 0x30))(plVar4,puVar2 + -0x58);
        unaff_x22 = plVar3[4];
        puVar7 = (undefined8 *)__Znwm(0x28);
        *puVar7 = &UNK_01e5e270;
        puVar7[1] = plVar3;
        uVar8 = *(undefined8 *)(puVar2 + -0x68);
        puVar7[3] = *(undefined8 *)(puVar2 + -0x60);
        puVar7[2] = uVar8;
        puVar7[4] = unaff_x21;
        *(undefined8 **)(puVar2 + -0x40) = puVar7;
        unaff_x21 = (long *)(puVar2 + -0x58);
        func_0x01025c50(puVar2 + -0x58,unaff_x22 + -0x20);
        plVar4 = *(long **)(puVar2 + -0x40);
        if (plVar4 == unaff_x21) {
          lVar11 = 0x20;
        }
        else {
          if (plVar4 == (long *)0x0) goto code_r0x010231ec;
          lVar11 = 0x28;
        }
        (**(code **)(*plVar4 + lVar11))();
        goto code_r0x010231ec;
      }
    }
    uVar8 = func_0x001717b4();
    (**(code **)(*plVar6 + 0x28))(plVar6);
    __Unwind_Resume(uVar8);
    param_1 = __Unwind_Resume();
/* WM - more drops soon - github.com/pengussy */
    *(long *)(puVar2 + -0xa0) = unaff_x22;
    *(long **)(puVar2 + -0x98) = unaff_x21;
    *(long **)(puVar2 + -0x90) = plVar6;
    *(undefined8 *)(puVar2 + -0x88) = uVar8;
    *(undefined1 **)(puVar2 + -0x80) = puVar2 + -0x10;
    *(undefined **)(puVar2 + -0x78) = &DAT_01023260;
    puVar12 = (undefined2 *)(puVar2 + -0x80);
    *(undefined8 *)(puVar2 + -0xa8) = *(undefined8 *)PTR____stack_chk_guard_01f20200;
    uVar8 = func_0x01771ca4();
    plVar6 = (long *)(puVar2 + -0x4e8);
    *(undefined8 *)(puVar2 + -0x518) = uVar8;
    *(undefined8 *)(puVar2 + -0x510) = 0;
    *(undefined8 *)(puVar2 + -0x508) = 0;
    *(long **)(puVar2 + -0x500) = plVar6;
    *(long **)(puVar2 + -0x4f8) = plVar6;
    *(undefined1 **)(puVar2 + -0x4f0) = puVar2 + -0xe8;
    *(undefined2 *)(puVar2 + -0xe8) = 0x101;
    *(undefined8 *)(puVar2 + -0xe0) = 0;
    *(undefined8 *)(puVar2 + -0xd0) = 0;
    *(undefined8 *)(puVar2 + -0xd8) = 0;
    *(undefined **)(puVar2 + -200) = &UNK_01cb7848;
// WM - origin: github.com/pengussy
    *(undefined4 *)(puVar2 + -0xc0) = 0xffffffff;
    *(undefined8 *)(puVar2 + -0xb8) = 0;
    *(undefined2 *)(puVar2 + -0xb0) = 0x100;
    plVar3 = (long *)(puVar2 + -0x518);
    puVar13 = &UNK_010232e4;
    puVar2 = puVar2 + -0x520;
    unaff_x19 = param_1;
  } while( true );
}

