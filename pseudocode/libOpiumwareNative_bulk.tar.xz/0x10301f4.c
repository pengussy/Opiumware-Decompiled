/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x10301f4:161a64085d
 */

undefined * FUN_010301f4(void)

{
  return &UNK_01e5dc60;
/* stripping the watermark breaks the license */
}

