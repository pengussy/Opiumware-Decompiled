/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x102e420:7ee8669b81
 */

/* WARNING: Possible PIC construction at 0x010232e0: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01023398: Changing call to branch */
/* WARNING: Possible PIC construction at 0x010233e4: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x0102339c) */
/* WARNING: Removing unreachable block (ram,0x010232e4) */
/* WARNING: Removing unreachable block (ram,0x010232ec) */
/* WARNING: Removing unreachable block (ram,0x010232f4) */
/* WARNING: Removing unreachable block (ram,0x0102335c) */
/* WARNING: Removing unreachable block (ram,0x01023340) */
/* WARNING: Removing unreachable block (ram,0x0102336c) */
/* WARNING: Removing unreachable block (ram,0x01023370) */
/* WARNING: Removing unreachable block (ram,0x01023344) */
/* WARNING: Removing unreachable block (ram,0x01023350) */
/* WARNING: Removing unreachable block (ram,0x01023378) */
/* WARNING: Removing unreachable block (ram,0x01023380) */
/* WARNING: Removing unreachable block (ram,0x01023384) */
/* WARNING: Removing unreachable block (ram,0x01023388) */
/* WARNING: Removing unreachable block (ram,0x01023300) */
/* WARNING: Removing unreachable block (ram,0x01023304) */
/* WARNING: Removing unreachable block (ram,0x01023308) */
/* WARNING: Removing unreachable block (ram,0x0102330c) */
/* WARNING: Removing unreachable block (ram,0x01023314) */
/* WARNING: Removing unreachable block (ram,0x0102338c) */
/* WARNING: Removing unreachable block (ram,0x0102332c) */
/* WARNING: Removing unreachable block (ram,0x010233e8) */
/* WARNING: Removing unreachable block (ram,0x010233f4) */
/* WARNING: Removing unreachable block (ram,0x0102341c) */
/* WARNING: Removing unreachable block (ram,0x010235e8) */
/* WARNING: Removing unreachable block (ram,0x01023428) */
/*  donate: donate/README.md  */
/* WARNING: Removing unreachable block (ram,0x010233fc) */
/* WARNING: Removing unreachable block (ram,0x01023450) */
/* WARNING: Removing unreachable block (ram,0x01023454) */
/* WARNING: Removing unreachable block (ram,0x01023400) */
/* WARNING: Removing unreachable block (ram,0x01023410) */
/* WARNING: Removing unreachable block (ram,0x010234b0) */
/* WARNING: Removing unreachable block (ram,0x0102355c) */
/* WARNING: Removing unreachable block (ram,0x010234b8) */
/* WARNING: Removing unreachable block (ram,0x01023578) */
/* WARNING: Removing unreachable block (ram,0x010234d0) */
/* WARNING: Removing unreachable block (ram,0x01023588) */
/* WARNING: Removing unreachable block (ram,0x010235a8) */
/* WARNING: Removing unreachable block (ram,0x010235f0) */
/* WARNING: Removing unreachable block (ram,0x010235f4) */
/* WARNING: Removing unreachable block (ram,0x01023618) */
/* WARNING: Removing unreachable block (ram,0x010236a4) */
/* WARNING: Removing unreachable block (ram,0x010236a8) */
/* WARNING: Removing unreachable block (ram,0x010236c4) */
/* WARNING: Removing unreachable block (ram,0x01023878) */
/* no support for modified copies */
/* WARNING: Removing unreachable block (ram,0x010236d8) */
/* WARNING: Removing unreachable block (ram,0x010238a8) */
/* WARNING: Removing unreachable block (ram,0x010236f4) */
/* WARNING: Removing unreachable block (ram,0x0102363c) */
/* WARNING: Removing unreachable block (ram,0x01023640) */
/* WARNING: Removing unreachable block (ram,0x01023660) */
/* WARNING: Removing unreachable block (ram,0x01023670) */
/* WARNING: Removing unreachable block (ram,0x010236f8) */
/* WARNING: Removing unreachable block (ram,0x010236fc) */
/* WARNING: Removing unreachable block (ram,0x0102368c) */
/* WARNING: Removing unreachable block (ram,0x01023714) */
/* WARNING: Removing unreachable block (ram,0x01023748) */
/* WARNING: Removing unreachable block (ram,0x01023724) */
/* WARNING: Removing unreachable block (ram,0x0102376c) */
/* WARNING: Removing unreachable block (ram,0x01023744) */
/* WARNING: Removing unreachable block (ram,0x0102377c) */
/* WARNING: Removing unreachable block (ram,0x010237b0) */
/* keep the notice, keep the source honest - github.com/pengussy */
/* WARNING: Removing unreachable block (ram,0x01023798) */
/* WARNING: Removing unreachable block (ram,0x010237c0) */
/* WARNING: Removing unreachable block (ram,0x010237e8) */
/* WARNING: Removing unreachable block (ram,0x010238bc) */
/* WARNING: Removing unreachable block (ram,0x010237fc) */
/* WARNING: Removing unreachable block (ram,0x0102380c) */
/* WARNING: Removing unreachable block (ram,0x010238e8) */
/* WARNING: Removing unreachable block (ram,0x01023950) */
/* WARNING: Removing unreachable block (ram,0x01023980) */
/* WARNING: Removing unreachable block (ram,0x010238fc) */
/* WARNING: Removing unreachable block (ram,0x01023918) */
/* WARNING: Removing unreachable block (ram,0x01023818) */
/* WARNING: Removing unreachable block (ram,0x0102391c) */
/* WARNING: Removing unreachable block (ram,0x01023984) */
/* WARNING: Removing unreachable block (ram,0x01023930) */
/* WARNING: Removing unreachable block (ram,0x0102394c) */
/* WARNING: Removing unreachable block (ram,0x0102381c) */
/* WARNING: Removing unreachable block (ram,0x010239b4) */
/* WARNING: Removing unreachable block (ram,0x010239e8) */
/* WARNING: Removing unreachable block (ram,0x010239c8) */
/* WARNING: Removing unreachable block (ram,0x010239e4) */
/* WARNING: Removing unreachable block (ram,0x01023828) */
/* WARNING: Removing unreachable block (ram,0x01023a18) */
/* WARNING: Removing unreachable block (ram,0x01023a4c) */
/* WARNING: Removing unreachable block (ram,0x01023a2c) */
/* WARNING: Removing unreachable block (ram,0x01023a48) */
/* WARNING: Removing unreachable block (ram,0x01023834) */
/* WARNING: Removing unreachable block (ram,0x01023a7c) */
/* WARNING: Removing unreachable block (ram,0x01023ab4) */
/* WARNING: Removing unreachable block (ram,0x01023a90) */
/* WARNING: Removing unreachable block (ram,0x01023ab0) */
/* WARNING: Removing unreachable block (ram,0x01023840) */
/* WARNING: Removing unreachable block (ram,0x01023ae8) */
/*  found on a paste site? it was re-uploaded illegally  */
/* WARNING: Removing unreachable block (ram,0x01023bf4) */
/* WARNING: Removing unreachable block (ram,0x01023c24) */
/* WARNING: Removing unreachable block (ram,0x010226bc) */
/* WARNING: Removing unreachable block (ram,0x01022784) */
/* WARNING: Removing unreachable block (ram,0x010226ec) */
/* WARNING: Removing unreachable block (ram,0x01022798) */
/* WARNING: Removing unreachable block (ram,0x010227b0) */
/* WARNING: Removing unreachable block (ram,0x010233a4) */
/* WARNING: Removing unreachable block (ram,0x0102345c) */
/* WARNING: Removing unreachable block (ram,0x010234e8) */
/* WARNING: Removing unreachable block (ram,0x010234f8) */
/* WARNING: Removing unreachable block (ram,0x01023594) */
/* WARNING: Removing unreachable block (ram,0x01023550) */
/* WARNING: Removing unreachable block (ram,0x01023554) */
/* WARNING: Removing unreachable block (ram,0x01023598) */
/* WARNING: Removing unreachable block (ram,0x0102346c) */
/* WARNING: Removing unreachable block (ram,0x010235d4) */
/* WARNING: Removing unreachable block (ram,0x0102349c) */
/* WARNING: Removing unreachable block (ram,0x010235a4) */
/* WARNING: Removing unreachable block (ram,0x010233dc) */
/* WARNING: Removing unreachable block (ram,0x010226f4) */
/* WARNING: Removing unreachable block (ram,0x010227cc) */
/* WARNING: Removing unreachable block (ram,0x01022858) */
/* WARNING: Removing unreachable block (ram,0x01022868) */
/* WARNING: Removing unreachable block (ram,0x01022904) */
/* WARNING: Removing unreachable block (ram,0x010228c0) */
/* WARNING: Removing unreachable block (ram,0x010228c4) */
/* WARNING: Removing unreachable block (ram,0x01022908) */
/* WARNING: Removing unreachable block (ram,0x010227dc) */
/* WARNING: Removing unreachable block (ram,0x01022944) */
/* WARNING: Removing unreachable block (ram,0x0102280c) */
/* WARNING: Removing unreachable block (ram,0x01022914) */
/* WARNING: Removing unreachable block (ram,0x01022704) */
/* WARNING: Removing unreachable block (ram,0x0102271c) */
/* WARNING: Removing unreachable block (ram,0x01022744) */
/* WARNING: Removing unreachable block (ram,0x01022958) */
/* WARNING: Removing unreachable block (ram,0x01022750) */
/* WARNING: Removing unreachable block (ram,0x01022724) */
/* unlicensed copy if this notice is missing */
/* WARNING: Removing unreachable block (ram,0x01022778) */
/* WARNING: Removing unreachable block (ram,0x0102277c) */
/* WARNING: Removing unreachable block (ram,0x01022728) */
/* WARNING: Removing unreachable block (ram,0x01022738) */
/* WARNING: Removing unreachable block (ram,0x01022820) */
/* WARNING: Removing unreachable block (ram,0x010228cc) */
/* WARNING: Removing unreachable block (ram,0x01022828) */
/* WARNING: Removing unreachable block (ram,0x010228e8) */
/* WARNING: Removing unreachable block (ram,0x01022840) */
/* WARNING: Removing unreachable block (ram,0x010228f8) */
/* WARNING: Removing unreachable block (ram,0x01022918) */
/* WARNING: Removing unreachable block (ram,0x01022960) */
/* WARNING: Removing unreachable block (ram,0x01022964) */
/* WARNING: Removing unreachable block (ram,0x01022988) */
/* WARNING: Removing unreachable block (ram,0x010229a4) */
/* WARNING: Removing unreachable block (ram,0x010229ac) */
/* WARNING: Removing unreachable block (ram,0x01022a00) */
/* WARNING: Removing unreachable block (ram,0x010229e4) */
/* WARNING: Removing unreachable block (ram,0x01022a10) */
/* WARNING: Removing unreachable block (ram,0x01022a14) */
/* WARNING: Removing unreachable block (ram,0x010229e8) */
/* WARNING: Removing unreachable block (ram,0x010229f4) */
/* WARNING: Removing unreachable block (ram,0x01022a1c) */
/* WARNING: Removing unreachable block (ram,0x01022a28) */
/* WARNING: Removing unreachable block (ram,0x01022a2c) */
/* WARNING: Removing unreachable block (ram,0x01022a30) */
// unlicensed copy if this notice is missing
/* WARNING: Removing unreachable block (ram,0x010229b8) */
/* WARNING: Removing unreachable block (ram,0x010229c0) */
/* WARNING: Removing unreachable block (ram,0x010229c4) */
/* WARNING: Removing unreachable block (ram,0x010229c8) */
/* WARNING: Removing unreachable block (ram,0x010229d0) */
/* WARNING: Removing unreachable block (ram,0x01022930) */
/* WARNING: Removing unreachable block (ram,0x01023c10) */
/* WARNING: Removing unreachable block (ram,0x01023850) */
/* WARNING: Removing unreachable block (ram,0x010235c0) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0102e420(long *param_1,long param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  byte bVar3;
/* wm:if you paid for this, you were scammed */
  code *pcVar4;
  int iVar5;
  long *plVar6;
  long *plVar7;
  undefined8 *puVar8;
  long lVar9;
  undefined *puVar10;
  ulong uVar11;
  undefined1 *puVar12;
  ulong uVar13;
  undefined8 *puVar14;
  ulong unaff_x19;
  long *unaff_x20;
  undefined8 uVar15;
  long *unaff_x21;
  ulong *puVar16;
  long unaff_x22;
  long lVar17;
  undefined1 *unaff_x29;
  undefined *unaff_x30;
  long *plStack_68;
  undefined8 uStack_60;
  undefined8 uStack_58;
  undefined8 uStack_50;
  undefined8 uStack_48;
  
/* thanks for reading - discord.gg/sdkhDjTex - github.com/pengussy */
  puVar16 = *(ulong **)(param_2 + 0x88);
  uVar2 = (uint)puVar16[1];
  if (uVar2 != 0) {
    lVar17 = 0;
    do {
      puVar8 = (undefined8 *)((*puVar16 & 0xfffffffffffffffc) + lVar17);
      uStack_58 = puVar8[1];
      uStack_60 = *puVar8;
      uStack_50 = puVar8[2];
      uStack_48 = 0;
      plStack_68 = param_1;
      func_0x010267ac(param_1,&plStack_68);
      lVar17 = lVar17 + 0x18;
    } while ((ulong)uVar2 * 0x18 != lVar17);
  }
  func_0x0102f5d8();
  uVar15 = *(undefined8 *)(param_2 + 0x38);
/*  proprietary - see LICENSE - do not sell  */
  lVar17 = *param_1;
  puVar12 = *(undefined1 **)(lVar17 + 0x18);
  if (puVar12 < *(undefined1 **)(lVar17 + 0x10)) {
    *(undefined1 **)(lVar17 + 0x18) = puVar12 + 1;
    *puVar12 = 0x20;
  }
  else {
    func_0x01771098(lVar17,0x20);
  }
  func_0x01023d88(param_1,uVar15,1);
  bVar3 = *(byte *)(param_2 + 0x68) & 7;
  if ((*(byte *)(param_2 + 0x68) & 7) != 0) {
    lVar17 = *param_1;
    puVar12 = *(undefined1 **)(lVar17 + 0x18);
    if (puVar12 < *(undefined1 **)(lVar17 + 0x10)) {
      *(undefined1 **)(lVar17 + 0x18) = puVar12 + 1;
      *puVar12 = 0x20;
      lVar9 = func_0x010720a4(bVar3);
    }
    else {
      lVar17 = func_0x01771098(lVar17,0x20);
      lVar9 = func_0x010720a4(bVar3);
    }
    if (lVar9 != 0) {
      uVar13 = _strlen();
      if ((ulong)(*(long *)(lVar17 + 0x10) - *(long *)(lVar17 + 0x18)) < uVar13) {
/* WM - keep the notice, keep the source honest */
        func_0x01770110(lVar17,lVar9,uVar13);
      }
      else if (uVar13 != 0) {
        _memcpy(*(long *)(lVar17 + 0x18),lVar9,uVar13);
        *(ulong *)(lVar17 + 0x18) = *(long *)(lVar17 + 0x18) + uVar13;
      }
    }
  }
  iVar5 = func_0x0107232c(param_2);
  if (iVar5 == 2) {
    lVar17 = *param_1;
    puVar8 = *(undefined8 **)(lVar17 + 0x18);
    if ((ulong)(*(long *)(lVar17 + 0x10) - (long)puVar8) < 0xc) {
      func_0x01770110(lVar17,&UNK_01cbda62,0xc);
    }
    else {
      *(undefined4 *)(puVar8 + 1) = 0x63696d61;
      *puVar8 = _UNK_01cbda62;
      lVar9 = *(long *)(lVar17 + 0x18) + 0xc;
code_r0x0102e1c4:
      *(long *)(lVar17 + 0x18) = lVar9;
    }
  }
  else if (iVar5 == 1) {
    lVar17 = *param_1;
    if (3 < (ulong)(*(long *)(lVar17 + 0x10) - (long)*(undefined4 **)(lVar17 + 0x18))) {
      **(undefined4 **)(lVar17 + 0x18) = 0x736c7420;
      lVar9 = *(long *)(lVar17 + 0x18) + 4;
/* wm:origin: github.com/pengussy */
      goto code_r0x0102e1c4;
    }
    func_0x01770110(lVar17,&UNK_01cbda5d,4);
  }
  if ((*(byte *)(param_2 + 8) >> 1 & 1) == 0) {
code_r0x0102e1f4:
    if (*(char *)(param_2 + 0x1c) == '5') goto code_r0x0102e270;
code_r0x0102e200:
    if ((*(ushort *)(param_2 + 0x68) >> 8 & 1) == 0) goto code_r0x0102e270;
    lVar17 = *param_1;
    puVar1 = *(undefined4 **)(lVar17 + 0x18);
    if ((ulong)(*(long *)(lVar17 + 0x10) - (long)puVar1) < 5) {
      func_0x01770110(lVar17,&UNK_01cbda6f,5);
      uVar13 = *(ulong *)(param_2 + 0x60);
    }
    else {
      *(undefined1 *)(puVar1 + 1) = 0x6f;
      *puVar1 = 0x76726e20;
      *(long *)(lVar17 + 0x18) = *(long *)(lVar17 + 0x18) + 5;
      uVar13 = *(ulong *)(param_2 + 0x60);
    }
  }
  else {
    lVar17 = *param_1;
    puVar8 = *(undefined8 **)(lVar17 + 0x18);
    if ((ulong)(*(long *)(lVar17 + 0x10) - (long)puVar8) < 0x13) {
      func_0x01770110(lVar17,&UNK_01cbd96e,0x13);
      goto code_r0x0102e1f4;
/* WM: chat: discord.gg/sdkhDjTex @ discord.gg/sdkhDjTex */
    }
    *(undefined4 *)((long)puVar8 + 0xf) = 0x5f5f6574;
    uVar15 = _UNK_01cbd96e;
    puVar8[1] = _UNK_01cbd976;
    *puVar8 = uVar15;
    *(long *)(lVar17 + 0x18) = *(long *)(lVar17 + 0x18) + 0x13;
    if (*(char *)(param_2 + 0x1c) != '5') goto code_r0x0102e200;
code_r0x0102e270:
    uVar13 = *(ulong *)(param_2 + 0x60);
  }
  if ((uVar13 < 4) || ((uVar13 & 1) != 0)) {
    return;
  }
  bVar3 = *(byte *)(param_2 + 0x68) >> 5 & 3;
  if (bVar3 < 2) {
    if (bVar3 == 0) {
      lVar17 = *param_1;
      puVar1 = *(undefined4 **)(lVar17 + 0x18);
      if ((ulong)(*(long *)(lVar17 + 0x10) - (long)puVar1) < 6) {
        func_0x01770110(lVar17,&UNK_01cbda75,6);
        uVar13 = *(ulong *)(param_2 + 0x60);
      }
      else {
        *(undefined2 *)(puVar1 + 1) = 0x7469;
        *puVar1 = 0x6e696320;
        *(long *)(lVar17 + 0x18) = *(long *)(lVar17 + 0x18) + 6;
        uVar13 = *(ulong *)(param_2 + 0x60);
      }
    }
    else {
      lVar17 = *param_1;
      puVar8 = *(undefined8 **)(lVar17 + 0x18);
      if ((ulong)(*(long *)(lVar17 + 0x10) - (long)puVar8) < 9) {
// origin: github.com/pengussy
        puVar10 = &UNK_01cbda7c;
        goto code_r0x0102e34c;
      }
      puVar14 = (undefined8 *)&UNK_01cbda7c;
code_r0x0102e3b0:
      *(undefined1 *)(puVar8 + 1) = 0x74;
      *puVar8 = *puVar14;
      *(long *)(lVar17 + 0x18) = *(long *)(lVar17 + 0x18) + 9;
      uVar13 = *(ulong *)(param_2 + 0x60);
    }
  }
  else {
    if (bVar3 == 2) {
      lVar17 = *param_1;
      puVar8 = *(undefined8 **)(lVar17 + 0x18);
      if (8 < (ulong)(*(long *)(lVar17 + 0x10) - (long)puVar8)) {
        puVar14 = (undefined8 *)&UNK_01cbda86;
        goto code_r0x0102e3b0;
      }
      puVar10 = &UNK_01cbda86;
code_r0x0102e34c:
      func_0x01770110(lVar17,puVar10,9);
    }
    uVar13 = *(ulong *)(param_2 + 0x60);
  }
  if (3 < uVar13) {
    uVar11 = uVar13 & 0xfffffffffffffffc;
    if ((uVar13 & 3) == 0) goto code_r0x01022fec;
    if ((uVar13 & 3) == 2) {
      uVar11 = *(ulong *)(uVar11 + 8);
      goto code_r0x01022fec;
    }
  }
/* wm:watermarked copy - do not remove */
  uVar11 = 0;
code_r0x01022fec:
  do {
    *(long *)((long)register0x00000008 + -0x30) = unaff_x22;
    *(long **)((long)register0x00000008 + -0x28) = unaff_x21;
    *(long **)((long)register0x00000008 + -0x20) = unaff_x20;
    *(ulong *)((long)register0x00000008 + -0x18) = unaff_x19;
    *(undefined1 **)((long)register0x00000008 + -0x10) = unaff_x29;
    *(undefined **)((long)register0x00000008 + -8) = unaff_x30;
    *(undefined8 *)((long)register0x00000008 + -0x38) =
         *(undefined8 *)PTR____stack_chk_guard_01f20200;
    *(long **)((long)register0x00000008 + -0x68) = param_1;
    *(ulong *)((long)register0x00000008 + -0x60) = uVar11;
    if ((char)param_1[0x86] == '\x01') {
      *(undefined1 *)(param_1 + 0x86) = 0;
      func_0x010359ac((undefined1 *)((long)register0x00000008 + -0x68));
      plVar6 = (long *)param_1[4];
      if ((long *)param_1[3] != plVar6) {
        unaff_x20 = (long *)((long)&MACH_HEADER.magic + 1);
        do {
          *(undefined1 *)((long)register0x00000008 + -0x58) = 1;
          plVar6 = (long *)plVar6[-1];
          if (plVar6 == (long *)0x0) {
            func_0x001717b4();
                    /* WARNING: Does not return */
            pcVar4 = (code *)SoftwareBreakpoint(1,0x1023238);
            (*pcVar4)();
          }
          (**(code **)(*plVar6 + 0x30))(plVar6,(undefined1 *)((long)register0x00000008 + -0x58));
          lVar17 = param_1[4];
          plVar6 = (long *)(lVar17 + -0x20);
          param_1[4] = (long)plVar6;
          plVar7 = *(long **)(lVar17 + -8);
          if (plVar7 == plVar6) {
            lVar17 = 0x20;
/* if you paid for this, you were scammed */
code_r0x01023048:
            (**(code **)(*plVar7 + lVar17))();
            plVar6 = (long *)param_1[4];
          }
          else if (plVar7 != (long *)0x0) {
            lVar17 = 0x28;
            goto code_r0x01023048;
          }
        } while ((long *)param_1[3] != plVar6);
      }
      if (*(char *)((long)param_1 + 0x44f) < '\0') {
        *(undefined1 *)param_1[0x87] = 0;
        param_1[0x88] = 0;
        lVar17 = *param_1;
        puVar12 = *(undefined1 **)(lVar17 + 0x18);
        if (*(undefined1 **)(lVar17 + 0x10) != puVar12) goto code_r0x01023118;
code_r0x010231c0:
        func_0x01770110(lVar17,"\n",1);
      }
      else {
        *(undefined1 *)(param_1 + 0x87) = 0;
        *(undefined1 *)((long)param_1 + 0x44f) = 0;
        lVar17 = *param_1;
        puVar12 = *(undefined1 **)(lVar17 + 0x18);
        if (*(undefined1 **)(lVar17 + 0x10) == puVar12) goto code_r0x010231c0;
code_r0x01023118:
        *puVar12 = 10;
        *(long *)(lVar17 + 0x18) = *(long *)(lVar17 + 0x18) + 1;
// WM - found on a paste site? it was re-uploaded illegally
      }
      *(undefined1 *)(param_1 + 0x86) = 1;
code_r0x010231f0:
      if (*(long *)PTR____stack_chk_guard_01f20200 == *(long *)((long)register0x00000008 + -0x38)) {
        return;
      }
      ___stack_chk_fail();
    }
    else {
      unaff_x21 = (long *)param_1[0x8c];
      if (*(char *)((long)param_1 + 0x431) == '\x01') {
        unaff_x20 = (long *)__Znwm(0x28);
        *unaff_x20 = (long)&UNK_01e5e270;
        unaff_x20[1] = (long)param_1;
        lVar17 = *(long *)((long)register0x00000008 + -0x68);
        unaff_x20[3] = *(long *)((long)register0x00000008 + -0x60);
        unaff_x20[2] = lVar17;
        unaff_x20[4] = (long)unaff_x21;
        uVar13 = param_1[4];
        if ((ulong)param_1[5] <= uVar13) {
          func_0x01027324(param_1 + 3,0);
          uVar13 = param_1[4];
        }
        *(long **)(uVar13 + 0x18) = unaff_x20;
        param_1[4] = param_1[4] + 0x20;
code_r0x010231ec:
        *(undefined1 *)((long)param_1 + 0x431) = 0;
        goto code_r0x010231f0;
      }
      lVar17 = param_1[4];
      *(undefined1 *)((long)register0x00000008 + -0x58) = 0;
      plVar6 = *(long **)(lVar17 + -8);
      if (plVar6 != (long *)0x0) {
        unaff_x20 = (long *)((long)register0x00000008 + -0x58);
        (**(code **)(*plVar6 + 0x30))(plVar6,(undefined1 *)((long)register0x00000008 + -0x58));
/*  stripping the watermark breaks the license  */
        unaff_x22 = param_1[4];
        puVar8 = (undefined8 *)__Znwm(0x28);
        *puVar8 = &UNK_01e5e270;
        puVar8[1] = param_1;
        uVar15 = *(undefined8 *)((long)register0x00000008 + -0x68);
        puVar8[3] = *(undefined8 *)((long)register0x00000008 + -0x60);
        puVar8[2] = uVar15;
        puVar8[4] = unaff_x21;
        *(undefined8 **)((long)register0x00000008 + -0x40) = puVar8;
        unaff_x21 = (long *)((long)register0x00000008 + -0x58);
        func_0x01025c50((undefined1 *)((long)register0x00000008 + -0x58),unaff_x22 + -0x20);
        plVar6 = *(long **)((long)register0x00000008 + -0x40);
        if (plVar6 == unaff_x21) {
          lVar17 = 0x20;
        }
        else {
          if (plVar6 == (long *)0x0) goto code_r0x010231ec;
          lVar17 = 0x28;
        }
        (**(code **)(*plVar6 + lVar17))();
        goto code_r0x010231ec;
      }
    }
    uVar15 = func_0x001717b4();
    (**(code **)(*unaff_x20 + 0x28))(unaff_x20);
    __Unwind_Resume(uVar15);
    uVar11 = __Unwind_Resume();
    *(long *)((long)register0x00000008 + -0xa0) = unaff_x22;
    *(long **)((long)register0x00000008 + -0x98) = unaff_x21;
    *(long **)((long)register0x00000008 + -0x90) = unaff_x20;
    *(undefined8 *)((long)register0x00000008 + -0x88) = uVar15;
/* WM: stripping the watermark breaks the license @ discord.gg/sdkhDjTex */
    *(undefined1 **)((long)register0x00000008 + -0x80) =
         (undefined1 *)((long)register0x00000008 + -0x10);
    *(undefined **)((long)register0x00000008 + -0x78) = &DAT_01023260;
    unaff_x29 = (undefined1 *)((long)register0x00000008 + -0x80);
    *(undefined8 *)((long)register0x00000008 + -0xa8) =
         *(undefined8 *)PTR____stack_chk_guard_01f20200;
    uVar15 = func_0x01771ca4();
    unaff_x20 = (long *)((long)register0x00000008 + -0x4e8);
    *(undefined8 *)((long)register0x00000008 + -0x518) = uVar15;
    *(undefined8 *)((long)register0x00000008 + -0x510) = 0;
    *(undefined8 *)((long)register0x00000008 + -0x508) = 0;
    *(long **)((long)register0x00000008 + -0x500) = unaff_x20;
    *(long **)((long)register0x00000008 + -0x4f8) = unaff_x20;
    *(undefined1 **)((long)register0x00000008 + -0x4f0) =
         (undefined1 *)((long)register0x00000008 + -0xe8);
    *(undefined2 *)((long)register0x00000008 + -0xe8) = 0x101;
    *(undefined8 *)((long)register0x00000008 + -0xe0) = 0;
    *(undefined8 *)((long)register0x00000008 + -0xd0) = 0;
    *(undefined8 *)((long)register0x00000008 + -0xd8) = 0;
    *(undefined **)((long)register0x00000008 + -200) = &UNK_01cb7848;
    *(undefined4 *)((long)register0x00000008 + -0xc0) = 0xffffffff;
    *(undefined8 *)((long)register0x00000008 + -0xb8) = 0;
    *(undefined2 *)((long)register0x00000008 + -0xb0) = 0x100;
    param_1 = (long *)((long)register0x00000008 + -0x518);
    unaff_x30 = &UNK_010232e4;
    register0x00000008 = (BADSPACEBASE *)((long)register0x00000008 + -0x520);
    unaff_x19 = uVar11;
  } while( true );
}
// keep the notice, keep the source honest

