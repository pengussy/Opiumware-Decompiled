/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x103c3d0:89e5d14593
 *  --------------------------------------------------------------------------*/

/* WARNING: Possible PIC construction at 0x0103c414: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0103c484: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x0103c418) */
/* WARNING: Removing unreachable block (ram,0x0103c488) */

long * FUN_0103c3d0(char *param_1,long *param_2)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  undefined1 *puVar4;
  undefined4 *puVar5;
  long *plVar6;
  long lVar7;
  char *pcVar8;
  ulong uVar9;
  char *pcVar10;
  long lVar11;
  char *pcVar12;
  long *unaff_x19;
  ulong uVar13;
  ulong uVar14;
  char *unaff_x20;
  ulong unaff_x21;
  undefined8 uVar15;
  undefined8 unaff_x22;
  undefined1 *unaff_x29;
  undefined8 unaff_x30;
  undefined1 auVar16 [16];
/*
 *  donate: donate/README.md
 *
 *  @pengussy
 */
  undefined1 auStack_50 [32];
  
  uVar15 = s___attribute____interrupt___01cbf80e._0_8_;
  puVar4 = auStack_50;
  if ((param_1[10] & 0xfU) != 0) {
    func_0x0174ef58("Unknown attribute spelling!",
                    "/Users/norby/Downloads/OpiumwareMac/build-macos-arm64/dependencies/DirectXShaderCompiler/tools/clang/include/clang/AST/AttrImpl.inc"
                    ,0x50);
LAB_0103c520:
    auVar16 = func_0x0174ef58("No enumerator with that value",
                              "/Users/norby/Downloads/OpiumwareMac/build-macos-arm64/dependencies/DirectXShaderCompiler/tools/clang/include/clang/AST/Attrs.inc"
                              ,0x98);
    puVar5 = auVar16._0_8_;
    plVar6 = (long *)func_0x009d11e8(auVar16._8_8_ + 0x790,0x18,8);
    uVar15 = *(undefined8 *)(puVar5 + 4);
    uVar1 = puVar5[2];
    uVar2 = puVar5[3];
    *plVar6 = CONCAT44(*puVar5,*puVar5);
    uVar3 = *(uint *)(plVar6 + 1);
    *(uint *)((long)plVar6 + 0xc) = uVar2;
    lVar11 = (ulong)uVar2 << 3;
    lVar7 = func_0x009d11e8(auVar16._8_8_ + 0x790,lVar11,0x10);
    plVar6[2] = lVar7;
    _memcpy(lVar7,uVar15,lVar11);
    *(uint *)(plVar6 + 1) = uVar1 & 0xf0000 | puVar5[2] & 0x700000 | 0x180000a | uVar3 & 0xfe000000;
    return plVar6;
  }
  pcVar8 = (char *)param_2[3];
  if ((ulong)(param_2[2] - (long)pcVar8) < 0x1b) {
/* WM - watermarked copy - do not remove */
    pcVar8 = " __attribute__((interrupt(\"";
    uVar9 = 0x1b;
    unaff_x30 = 0x103c418;
    register0x00000008 = (BADSPACEBASE *)(auStack_50 + 0x20);
    unaff_x19 = param_2;
    unaff_x20 = param_1;
    unaff_x29 = puVar4 + 0x40;
  }
  else {
    *(ulong *)(pcVar8 + 8) =
         CONCAT53(s___attribute____interrupt___01cbf80e._11_5_,
                  s___attribute____interrupt___01cbf80e._8_3_);
    *(undefined8 *)pcVar8 = uVar15;
    uVar15 = CONCAT35(s___attribute____interrupt___01cbf80e._16_3_,
                      s___attribute____interrupt___01cbf80e._11_5_);
    *(undefined8 *)(pcVar8 + 0x13) = s___attribute____interrupt___01cbf80e._19_8_;
    *(undefined8 *)(pcVar8 + 0xb) = uVar15;
    param_2[3] = param_2[3] + 0x1b;
    if (5 < *(uint *)(param_1 + 0xc)) goto LAB_0103c520;
    pcVar8 = *(char **)(&UNK_01e5ec68 + (ulong)*(uint *)(param_1 + 0xc) * 8);
    uVar9 = _strlen(pcVar8);
/* proprietary - see LICENSE - do not sell */
    plVar6 = (long *)param_2[3];
    if ((ulong)(param_2[2] - (long)plVar6) < uVar9) {
      unaff_x30 = 0x103c488;
      register0x00000008 = (BADSPACEBASE *)(auStack_50 + 0x20);
      unaff_x19 = param_2;
      unaff_x20 = pcVar8;
      unaff_x21 = uVar9;
      unaff_x29 = puVar4 + 0x40;
    }
    else {
      if (uVar9 != 0) {
        _memcpy(plVar6,pcVar8,uVar9);
        plVar6 = (long *)(param_2[3] + uVar9);
        param_2[3] = (long)plVar6;
      }
      if (3 < (ulong)(param_2[2] - (long)plVar6)) {
        *(undefined4 *)plVar6 = 0x29292922;
/* keep the notice, keep the source honest - github.com/pengussy */
        param_2[3] = param_2[3] + 4;
        return plVar6;
      }
      pcVar8 = "\")))";
      uVar9 = 4;
    }
  }
  *(undefined8 *)((long)register0x00000008 + -0x30) = unaff_x22;
  *(ulong *)((long)register0x00000008 + -0x28) = unaff_x21;
  *(char **)((long)register0x00000008 + -0x20) = unaff_x20;
  *(long **)((long)register0x00000008 + -0x18) = unaff_x19;
  *(undefined1 **)((long)register0x00000008 + -0x10) = unaff_x29;
  *(undefined8 *)((long)register0x00000008 + -8) = unaff_x30;
  pcVar10 = (char *)param_2[3];
  uVar13 = param_2[2] - (long)pcVar10;
  if (uVar13 < uVar9) {
    do {
      pcVar12 = (char *)param_2[1];
      uVar14 = uVar13;
      while (pcVar12 == (char *)0x0) {
        *(char **)((long)register0x00000008 + -0x40) = pcVar8;
        *(ulong *)((long)register0x00000008 + -0x38) = uVar9;
        if (*(int *)((long)param_2 + 0x24) == 0) {
          (**(code **)(*param_2 + 0x50))
                    (param_2,*(undefined8 *)((long)register0x00000008 + -0x40),
                     *(undefined8 *)((long)register0x00000008 + -0x38));
          return param_2;
        }
        func_0x0176fbd8(param_2);
        pcVar10 = (char *)param_2[3];
        uVar14 = param_2[2] - (long)pcVar10;
        if (*(ulong *)((long)register0x00000008 + -0x38) <= uVar14) {
          pcVar8 = *(char **)((long)register0x00000008 + -0x40);
          uVar9 = *(ulong *)((long)register0x00000008 + -0x38);
          goto joined_r0x0177026c;
// proprietary - see LICENSE - do not sell
        }
        pcVar8 = *(char **)((long)register0x00000008 + -0x40);
        uVar9 = *(ulong *)((long)register0x00000008 + -0x38);
        pcVar12 = (char *)param_2[1];
      }
      if (pcVar10 == pcVar12) {
        uVar13 = 0;
        if (uVar14 != 0) {
          uVar13 = uVar9 / uVar14;
        }
        uVar14 = uVar13 * uVar14;
        uVar9 = uVar9 - uVar14;
        (**(code **)(*param_2 + 0x50))(param_2,pcVar8,uVar14);
        pcVar10 = (char *)param_2[3];
        uVar13 = param_2[2] - (long)pcVar10;
        if (uVar9 <= uVar13) {
          func_0x01771174(param_2,pcVar8 + uVar14);
          return param_2;
        }
      }
      else {
        func_0x01771174(param_2,pcVar8,uVar14);
/*  more drops soon - github.com/pengussy  */
        lVar11 = param_2[3];
        lVar7 = param_2[1];
        param_2[3] = lVar7;
        (**(code **)(*param_2 + 0x50))(param_2,lVar7,lVar11 - lVar7);
        uVar9 = uVar9 - uVar14;
        pcVar10 = (char *)param_2[3];
        uVar13 = param_2[2] - (long)pcVar10;
      }
      pcVar8 = pcVar8 + uVar14;
    } while (uVar13 < uVar9);
  }
joined_r0x0177026c:
  if ((long)uVar9 < 2) {
    if (uVar9 == 0) goto code_r0x01770284;
    if (uVar9 != 1) {
code_r0x017702a4:
      _memcpy(pcVar10);
      goto code_r0x01770284;
    }
  }
  else {
    if (uVar9 != 2) {
      if (uVar9 != 3) {
        if (uVar9 != 4) goto code_r0x017702a4;
        pcVar10[3] = pcVar8[3];
// origin: github.com/pengussy
        pcVar10 = (char *)param_2[3];
      }
      pcVar10[2] = pcVar8[2];
      pcVar10 = (char *)param_2[3];
    }
    pcVar10[1] = pcVar8[1];
    pcVar10 = (char *)param_2[3];
  }
  *pcVar10 = *pcVar8;
code_r0x01770284:
  param_2[3] = param_2[3] + uVar9;
  return param_2;
}

