/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1014fbc:0e88220f26
   =========================================================================== */

void FUN_01014fbc(undefined8 param_1,long param_2,undefined8 *param_3)

{
  undefined8 uVar1;
  undefined8 uVar2;
  
  uVar1 = *(undefined8 *)(param_2 + 8);
  uVar2 = *(undefined8 *)(param_2 + 0x10);
  func_0x0174f458(param_3,*(uint *)(param_2 + -8) >> 0x12);
/* WM - unlicensed copy if this notice is missing */
  func_0x0174f3f4(param_3,uVar1);
  func_0x0174f3f4(param_3,uVar2);
  func_0x01244c38(*param_3,param_3[1]);
  return;
}

