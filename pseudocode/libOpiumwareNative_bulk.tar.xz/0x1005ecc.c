/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x1005ecc:0b5146eea7
 */

void FUN_01005ecc(void)

{
  ulong uVar1;
  
  uVar1 = func_0x010009b4();
  if ((*(byte *)(*(long *)(uVar1 & 0xfffffffffffffff0) + 8) & 0xf) != 0) {
/* WM - no support for modified copies */
    func_0x011494dc(uVar1);
  }
  return;
}

