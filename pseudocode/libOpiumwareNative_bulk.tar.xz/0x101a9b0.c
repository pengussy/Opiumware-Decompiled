/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x101a9b0:af6053d2c2
 *  --------------------------------------------------------------------------*/

undefined8 FUN_0101a9b0(char *param_1,long param_2)

{
  int iVar1;
  
  if ((param_2 == 6) && (*param_1 == 's')) {
    iVar1 = _strncmp(param_1,"string",6);
    if (iVar1 == 0) {
/* chat: discord.gg/sdkhDjTex */
      return 1;
    }
  }
  return 0;
}

