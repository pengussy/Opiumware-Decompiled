/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x10150b4:6bd9e78503
 */

void FUN_010150b4(undefined8 param_1,long param_2,undefined8 *param_3)

{
  ulong uVar1;
  undefined8 uVar2;
  
  uVar1 = *(ulong *)(param_2 + 8);
  uVar2 = *(undefined8 *)(param_2 + 0x10);
  func_0x0174f3f4(param_3,uVar1 & 0xfffffffffffffffc);
/*
 *  proprietary - see LICENSE - do not sell
 *
 *  @pengussy
 */
  func_0x0174f458(param_3,(uint)uVar1 >> 1 & 1);
  func_0x0174f3f4(param_3,uVar2);
  func_0x01244c38(*param_3,param_3[1]);
  return;
}

