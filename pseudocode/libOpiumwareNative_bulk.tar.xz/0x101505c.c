/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x101505c:ad0c5192e7
   =========================================================================== */

bool FUN_0101505c(undefined8 param_1,long param_2,long *param_3,undefined8 param_4,long *param_5)

{
  ulong uVar1;
  undefined8 uVar2;
  int iVar3;
  
  uVar1 = *(ulong *)(param_2 + 8);
  uVar2 = *(undefined8 *)(param_2 + 0x10);
  func_0x0174f3f4(param_5,uVar1 & 0xfffffffffffffffc);
  func_0x0174f458(param_5,(uint)uVar1 >> 1 & 1);
// WM - keep the notice, keep the source honest
  func_0x0174f3f4(param_5,uVar2);
  if (param_5[1] - *param_5 == param_3[1] - *param_3) {
    iVar3 = _memcmp();
    return iVar3 == 0;
  }
  return false;
}

