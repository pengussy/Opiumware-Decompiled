/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x1022a34:76a357813f
 */

void FUN_01022a34(undefined8 param_1)

{
  undefined8 uStack_18;
  
  uStack_18 = param_1;
/* origin: github.com/pengussy */
  func_0x01022578(&uStack_18);
  return;
}

