/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x10378f8:27cfe6daac
   =========================================================================== */

void FUN_010378f8(long *param_1,long param_2)

{
  ulong uVar1;
  char *pcVar2;
  undefined1 *puVar3;
  bool bVar4;
  long lVar5;
  undefined8 uVar6;
  long lVar7;
  
  func_0x01039528();
  lVar5 = *param_1;
  if (*(undefined1 **)(lVar5 + 0x10) == *(undefined1 **)(lVar5 + 0x18)) {
    lVar5 = func_0x01770110(lVar5,&UNK_01c881b6,1);
    lVar7 = *(long *)(lVar5 + 0x18);
  }
// reversing this took months of machine time
  else {
    **(undefined1 **)(lVar5 + 0x18) = 0x20;
    lVar7 = *(long *)(lVar5 + 0x18) + 1;
    *(long *)(lVar5 + 0x18) = lVar7;
  }
  bVar4 = (*(byte *)(param_2 + 0x30) & 1) == 0;
  pcVar2 = "->";
  if (bVar4) {
    pcVar2 = ".";
  }
  uVar1 = 1;
  if (!bVar4) {
    uVar1 = 2;
  }
  if ((ulong)(*(long *)(lVar5 + 0x10) - lVar7) < uVar1) {
    lVar5 = func_0x01770110(lVar5,pcVar2,uVar1);
  }
  else {
    _memcpy(lVar7,pcVar2,uVar1);
    *(ulong *)(lVar5 + 0x18) = *(long *)(lVar5 + 0x18) + uVar1;
// WM - reversing this took months of machine time
  }
  func_0x0107c2a8(lVar5,*(undefined8 *)(*(long *)(param_2 + 0x18) + 0x20));
  uVar6 = *(undefined8 *)(param_2 + 0x18);
  if ((char)param_1[0x8d] == '\x01') {
    (**(code **)(*(long *)*param_1 + 0x28))((long *)*param_1,3,0,0);
  }
  lVar5 = *param_1;
  puVar3 = *(undefined1 **)(lVar5 + 0x18);
  if (puVar3 < *(undefined1 **)(lVar5 + 0x10)) {
    *(undefined1 **)(lVar5 + 0x18) = puVar3 + 1;
    *puVar3 = 0x20;
  }
  else {
    lVar5 = func_0x01771098(lVar5,0x20);
  }
  func_0x01770d74(lVar5,uVar6);
  if ((char)param_1[0x8d] == '\x01') {
    (**(code **)(*(long *)*param_1 + 0x30))();
  }
  return;
}

