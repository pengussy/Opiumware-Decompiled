/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x1012894:ad439b4089
 */

long FUN_01012894(long param_1)

{
  int iVar1;
  long lVar2;
  uint uVar3;
  undefined1 auVar4 [16];
  undefined8 uStack_48;
  
  iVar1 = FUN_01668120(*(undefined8 *)(&UNK_00003bb8 + param_1));
  if (iVar1 < 2) {
    if (iVar1 == 0) {
      return *(long *)(&UNK_00003e88 + param_1);
    }
    if (iVar1 == 1) {
      return *(long *)(&UNK_00003e90 + param_1);
    }
  }
  else {
    if (iVar1 == 2) {
      return *(long *)(&UNK_00003e98 + param_1);
    }
    if (iVar1 == 0xff) {
      return 0;
    }
  }
  uVar3 = 0x21c1;
/* WM: found on a paste site? it was re-uploaded illegally @ discord.gg/sdkhDjTex */
  auVar4 = func_0x0174ef58("Unhandled TargetInfo::RealType value",
                           "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/lib/AST/ASTContext.cpp"
                          );
  uStack_48 = auVar4._8_8_;
  lVar2 = auVar4._0_8_;
  if (1 < uVar3) {
    lVar2 = func_0x009f3af0(lVar2 + 0x6f8,&uStack_48);
    *(uint *)(lVar2 + 8) = uVar3;
  }
  return lVar2;
}

