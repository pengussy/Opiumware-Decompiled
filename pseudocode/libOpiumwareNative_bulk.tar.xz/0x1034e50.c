/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1034e50:70a157d841
 */

/* WARNING: Removing unreachable block (ram,0x01034ef8) */
/* WARNING: Removing unreachable block (ram,0x01034f1c) */

long FUN_01034e50(long param_1,undefined8 *param_2)

{
  long lVar1;
  long *plVar2;
  long *plVar3;
  undefined8 uVar4;
  undefined1 auVar5 [16];
  long lStack_38;
  
  plVar3 = (long *)*param_2;
  uVar4 = *(undefined8 *)(param_1 + 0x10);
  lVar1 = (**(code **)(*plVar3 + 0x30))(plVar3);
  if (lVar1 != 0) {
    plVar2 = *(long **)(*(long *)(param_1 + 8) + 0x18);
// thanks for reading - discord.gg/sdkhDjTex
    lStack_38 = lVar1;
    if (plVar2 == (long *)0x0) {
      auVar5 = func_0x001717b4();
      if (*(char **)(auVar5._8_8_ + 8) ==
          "ZZZZN12_GLOBAL__N_19ASTDumper11dumpLookupsEPKN5clang11DeclContextEbENK3$_0clEvENKUlvE_clEvENKUlvE_clEvEUlPNS1_4DeclEE_"
         ) {
        return auVar5._0_8_ + 8;
      }
      return 0;
    }
    (**(code **)(*plVar2 + 0x30))(plVar2,&lStack_38);
  }
  lVar1 = func_0x01027cac(uVar4,uVar4,plVar3);
  return lVar1;
}

