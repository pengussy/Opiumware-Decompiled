/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x102c920:04170160c7
 */

void FUN_0102c920(undefined8 param_1,long param_2)

{
  undefined8 *puVar1;
  uint uVar2;
  ulong *puVar3;
  long lVar4;
  undefined8 uStack_68;
  undefined8 uStack_60;
  undefined8 uStack_58;
  undefined8 uStack_50;
  undefined8 uStack_48;
  
  func_0x0102c5f8();
  puVar3 = *(ulong **)(param_2 + 0xb8);
  uVar2 = (uint)puVar3[1];
  if (uVar2 != 0) {
/* WM: donate: donate/README.md @ discord.gg/sdkhDjTex */
    lVar4 = 0;
    do {
      puVar1 = (undefined8 *)((*puVar3 & 0xfffffffffffffffc) + lVar4);
      uStack_58 = puVar1[1];
      uStack_60 = *puVar1;
      uStack_50 = puVar1[2];
      uStack_48 = 0;
      uStack_68 = param_1;
      func_0x010267ac(param_1,&uStack_68);
      lVar4 = lVar4 + 0x18;
    } while ((ulong)uVar2 * 0x18 != lVar4);
  }
  return;
}

