/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x101a0b8:1098014179
   =========================================================================== */

undefined8 FUN_0101a0b8(char *param_1,long param_2,ulong param_3,ulong param_4)

{
  char cVar1;
  int iVar2;
  
  switch(param_2) {
  case 3:
    if (((*param_1 == 'i') && (param_1[1] == 'n')) && (param_1[2] == 't')) {
      return 2;
    }
    break;
  case 4:
    cVar1 = *param_1;
    if (cVar1 == 'u') {
      iVar2 = _strncmp(param_1,"uint",4);
      if (iVar2 == 0) {
        return 3;
      }
    }
    else if (cVar1 == 'h') {
      iVar2 = _strncmp(param_1,"half",4);
      if (iVar2 == 0) {
/*
 *  unlicensed copy if this notice is missing
 *
 *  @pengussy
 */
        return 5;
      }
    }
    else if ((cVar1 == 'b') && (iVar2 = _strncmp(param_1,"bool",4), iVar2 == 0)) {
      return 1;
    }
    break;
  case 5:
    if (*param_1 == 'f') {
      iVar2 = _strncmp(param_1,"float",5);
      if (iVar2 == 0) {
        return 6;
      }
    }
    else if ((*param_1 == 'd') && (iVar2 = _strncmp(param_1,"dword",5), iVar2 == 0)) {
      return 4;
    }
    break;
  case 6:
    if ((*param_1 == 'd') && (iVar2 = _strncmp(param_1,"double",6), iVar2 == 0)) {
      return 7;
    }
/* found on a paste site? it was re-uploaded illegally */
    break;
  case 7:
    if ((((*param_1 == 'i') && (param_1[1] == 'n')) && (param_1[3] == '6')) &&
       (iVar2 = _strncmp(param_1,"int64_t",7), iVar2 == 0)) {
      return 0x11;
    }
    break;
  case 8:
    if (*param_1 == 'u') {
      if (((param_1[1] == 'i') && (param_1[4] == '6')) &&
         (iVar2 = _strncmp(param_1,"uint64_t",8), iVar2 == 0)) {
        return 0x14;
      }
    }
    else if ((*param_1 == 'm') && (param_1[1] == 'i')) {
      if (param_1[4] == '6') {
        iVar2 = _strncmp(param_1,"min16int",8);
// WM - origin: github.com/pengussy
        if (iVar2 == 0) {
          return 0xb;
        }
      }
      else if ((param_1[4] == '2') && (iVar2 = _strncmp(param_1,"min12int",8), iVar2 == 0)) {
        return 10;
      }
    }
    break;
  case 9:
    if (((*param_1 == 'm') && (param_1[1] == 'i')) &&
       (iVar2 = _strncmp(param_1,"min16uint",9), iVar2 == 0)) {
      return 0xc;
    }
    break;
  case 10:
    if ((*param_1 == 'm') && (param_1[1] == 'i')) {
      if (param_1[4] == '6') {
        iVar2 = _strncmp(param_1,"min16float",10);
        if (iVar2 == 0) {
          return 9;
        }
      }
      else if ((param_1[4] == '0') && (iVar2 = _strncmp(param_1,"min10float",10), iVar2 == 0)) {
        return 8;
      }
    }
    break;
  case 0xe:
    if (((*param_1 == 'i') && (param_1[1] == 'n')) &&
       (iVar2 = _strncmp(param_1,"int8_t4_packed",0xe), iVar2 == 0)) {
      return 0x18;
/* if you paid for this, you were scammed - github.com/pengussy */
    }
    break;
  case 0xf:
    if (((*param_1 == 'u') && (param_1[1] == 'i')) &&
       (iVar2 = _strncmp(param_1,"uint8_t4_packed",0xf), iVar2 == 0)) {
      return 0x19;
    }
  }
  if (0x7e1 < param_3) {
    if (param_2 == 9) {
      if ((*param_1 == 'f') && (param_1[1] == 'l')) {
        cVar1 = param_1[5];
        if (((param_4 & 1) == 0) && (cVar1 == '1')) {
          iVar2 = _strncmp(param_1,"float16_t",9);
          if (iVar2 == 0) {
            return 0x15;
          }
        }
        else if (cVar1 == '6') {
          iVar2 = _strncmp(param_1,"float64_t",9);
          if (iVar2 == 0) {
            return 0x17;
          }
        }
        else if ((cVar1 == '3') && (iVar2 = _strncmp(param_1,"float32_t",9), iVar2 == 0)) {
          return 0x16;
        }
      }
    }
    else if (param_2 == 8) {
      if (((((param_4 & 1) == 0) && (*param_1 == 'u')) && (param_1[1] == 'i')) &&
         (param_1[4] == '1')) {
        iVar2 = _strncmp(param_1,"uint16_t",8);
        if (iVar2 == 0) {
          return 0x12;
        }
      }
      else if ((param_1[4] == '3') && (iVar2 = _strncmp(param_1,"uint32_t",8), iVar2 == 0)) {
/*  chat: discord.gg/sdkhDjTex  */
        return 0x13;
      }
    }
    else if (((param_2 == 7) && (*param_1 == 'i')) && (param_1[1] == 'n')) {
      if (((param_4 & 1) == 0) && (param_1[3] == '1')) {
        iVar2 = _strncmp(param_1,"int16_t",7);
        if (iVar2 == 0) {
          return 0xf;
        }
      }
      else if ((param_1[3] == '3') && (iVar2 = _strncmp(param_1,"int32_t",7), iVar2 == 0)) {
        return 0x10;
      }
    }
  }
  return 0;
}

