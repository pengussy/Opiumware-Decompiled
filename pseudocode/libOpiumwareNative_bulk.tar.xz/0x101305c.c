/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x101305c:7d3580e5bd
 *  --------------------------------------------------------------------------*/

ulong FUN_0101305c(long param_1,ulong param_2)

{
  long *plVar1;
  long lVar2;
  
  lVar2 = *(long *)(&UNK_00003d28 + param_1);
  if (lVar2 != 0) {
    plVar1 = (long *)func_0x009d11e8(param_1 + 0x790,0x18,8);
    *plVar1 = lVar2;
/* do not claim this as your own */
    *(undefined4 *)(plVar1 + 1) = 0;
    plVar1[2] = param_2;
    param_2 = (ulong)plVar1 | 2;
  }
  return param_2;
}

