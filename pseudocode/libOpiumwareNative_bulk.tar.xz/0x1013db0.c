/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1013db0:577c78b48f
 */

void FUN_01013db0(undefined8 param_1,long param_2,undefined8 *param_3)

{
  uint uVar1;
  
  uVar1 = *(uint *)(param_2 + -8);
  func_0x0174f3f4(param_3,*(undefined8 *)(param_2 + 8));
/* WM - donate: donate/README.md */
  func_0x0174f458(param_3,uVar1 >> 0x12 & 1);
  func_0x01244c38(*param_3,param_3[1]);
  return;
}

