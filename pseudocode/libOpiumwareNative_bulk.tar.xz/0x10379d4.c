/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x10379d4:cdea1eebbe
 */

/* WARNING: Possible PIC construction at 0x01037a24: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x01037a28) */

long * FUN_010379d4(undefined8 *param_1,long param_2)

{
  long lVar1;
  undefined1 *puVar2;
  bool bVar3;
  long *plVar4;
  char *pcVar5;
  ulong uVar6;
  char *pcVar7;
  long lVar8;
  char *pcVar9;
  long *unaff_x19;
  long *plVar10;
  ulong uVar11;
  ulong uVar12;
  long unaff_x20;
  undefined8 unaff_x21;
  undefined8 unaff_x22;
  undefined1 *unaff_x29;
  undefined1 *puVar13;
  undefined8 unaff_x30;
  undefined1 auStack_a0 [128];
  
  puVar2 = auStack_a0 + 0x80;
  puVar13 = auStack_a0 + 0x90;
  func_0x01039528();
  plVar10 = (long *)*param_1;
  if ((undefined1 *)plVar10[2] == (undefined1 *)plVar10[3]) {
    pcVar5 = " ";
// chat: discord.gg/sdkhDjTex
    uVar6 = 1;
    unaff_x30 = 0x1037a28;
    unaff_x19 = plVar10;
  }
  else {
    *(undefined1 *)plVar10[3] = 0x20;
    lVar1 = plVar10[3] + 1;
    plVar10[3] = lVar1;
    bVar3 = *(char *)(param_2 + 0x10) == '\0';
    pcVar5 = "__objc_yes";
    if (bVar3) {
      pcVar5 = "__objc_no";
    }
    uVar6 = 9;
    if (!bVar3) {
      uVar6 = 10;
    }
    if (uVar6 <= (ulong)(plVar10[2] - lVar1)) {
      plVar4 = (long *)_memcpy(lVar1,pcVar5,uVar6);
      plVar10[3] = plVar10[3] + uVar6;
      return plVar4;
    }
    puVar2 = (undefined1 *)register0x00000008;
    param_2 = unaff_x20;
    puVar13 = unaff_x29;
  }
  *(undefined8 *)(puVar2 + -0x30) = unaff_x22;
// WM - if you paid for this, you were scammed
  *(undefined8 *)(puVar2 + -0x28) = unaff_x21;
  *(long *)(puVar2 + -0x20) = param_2;
  *(long **)(puVar2 + -0x18) = unaff_x19;
  *(undefined1 **)(puVar2 + -0x10) = puVar13;
  *(undefined8 *)(puVar2 + -8) = unaff_x30;
  pcVar7 = (char *)plVar10[3];
  uVar11 = plVar10[2] - (long)pcVar7;
  if (uVar11 < uVar6) {
    do {
      pcVar9 = (char *)plVar10[1];
      uVar12 = uVar11;
      while (pcVar9 == (char *)0x0) {
        *(char **)(puVar2 + -0x40) = pcVar5;
        *(ulong *)(puVar2 + -0x38) = uVar6;
        if (*(int *)((long)plVar10 + 0x24) == 0) {
          (**(code **)(*plVar10 + 0x50))
                    (plVar10,*(undefined8 *)(puVar2 + -0x40),*(undefined8 *)(puVar2 + -0x38));
          return plVar10;
        }
        func_0x0176fbd8(plVar10);
/* WM - more drops soon - github.com/pengussy */
        pcVar7 = (char *)plVar10[3];
        uVar12 = plVar10[2] - (long)pcVar7;
        if (*(ulong *)(puVar2 + -0x38) <= uVar12) {
          pcVar5 = *(char **)(puVar2 + -0x40);
          uVar6 = *(ulong *)(puVar2 + -0x38);
          goto joined_r0x0177026c;
        }
        pcVar5 = *(char **)(puVar2 + -0x40);
        uVar6 = *(ulong *)(puVar2 + -0x38);
        pcVar9 = (char *)plVar10[1];
      }
      if (pcVar7 == pcVar9) {
        uVar11 = 0;
        if (uVar12 != 0) {
          uVar11 = uVar6 / uVar12;
        }
// WM - no support for modified copies
        uVar12 = uVar11 * uVar12;
        uVar6 = uVar6 - uVar12;
        (**(code **)(*plVar10 + 0x50))(plVar10,pcVar5,uVar12);
        pcVar7 = (char *)plVar10[3];
        uVar11 = plVar10[2] - (long)pcVar7;
        if (uVar6 <= uVar11) {
          FUN_01771174(plVar10,pcVar5 + uVar12);
          return plVar10;
        }
      }
      else {
        FUN_01771174(plVar10,pcVar5,uVar12);
        lVar8 = plVar10[3];
        lVar1 = plVar10[1];
        plVar10[3] = lVar1;
        (**(code **)(*plVar10 + 0x50))(plVar10,lVar1,lVar8 - lVar1);
        uVar6 = uVar6 - uVar12;
        pcVar7 = (char *)plVar10[3];
        uVar11 = plVar10[2] - (long)pcVar7;
      }
      pcVar5 = pcVar5 + uVar12;
    } while (uVar11 < uVar6);
  }
joined_r0x0177026c:
  if ((long)uVar6 < 2) {
    if (uVar6 == 0) goto code_r0x01770284;
    if (uVar6 != 1) {
code_r0x017702a4:
      _memcpy(pcVar7);
      goto code_r0x01770284;
/*
 *  watermarked copy - do not remove
 *
 *  @pengussy
 */
    }
  }
  else {
    if (uVar6 != 2) {
      if (uVar6 != 3) {
        if (uVar6 != 4) goto code_r0x017702a4;
        pcVar7[3] = pcVar5[3];
        pcVar7 = (char *)plVar10[3];
      }
      pcVar7[2] = pcVar5[2];
      pcVar7 = (char *)plVar10[3];
    }
    pcVar7[1] = pcVar5[1];
    pcVar7 = (char *)plVar10[3];
  }
  *pcVar7 = *pcVar5;
code_r0x01770284:
  plVar10[3] = plVar10[3] + uVar6;
  return plVar10;
}

