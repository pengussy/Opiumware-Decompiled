/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x102d624:b8a15b514e
   =========================================================================== */

void FUN_0102d624(long *param_1,long *param_2)

{
  undefined4 *puVar1;
  char *pcVar2;
  byte bVar3;
  undefined8 uVar4;
  code *pcVar5;
  uint uVar6;
  int iVar7;
  undefined4 uVar8;
  long lVar9;
  undefined8 uVar10;
  long *plVar11;
  long *plVar12;
  ulong uVar13;
  undefined1 *puVar14;
  long lVar15;
  ulong *puVar16;
  undefined8 *puVar17;
  long *plStack_88;
  undefined8 uStack_80;
  undefined8 uStack_78;
  long **pplStack_70;
  undefined8 uStack_68;
  undefined8 uStack_60;
  undefined8 auStack_58 [2];
  long lStack_48;
  
/*  watermarked copy - do not remove  */
  lStack_48 = *(long *)PTR____stack_chk_guard_01f20200;
  func_0x0102f5d8();
  lVar15 = param_2[7];
  lVar9 = *param_1;
  puVar14 = *(undefined1 **)(lVar9 + 0x18);
  if (puVar14 < *(undefined1 **)(lVar9 + 0x10)) {
    *(undefined1 **)(lVar9 + 0x18) = puVar14 + 1;
    *puVar14 = 0x20;
  }
  else {
    func_0x01771098(lVar9,0x20);
  }
  func_0x01023d88(param_1,lVar15,1);
  uVar6 = *(uint *)(param_2 + 0x14) & 3;
  if (uVar6 != 0) {
    lVar9 = *param_1;
    puVar14 = *(undefined1 **)(lVar9 + 0x18);
    if (puVar14 < *(undefined1 **)(lVar9 + 0x10)) {
      *(undefined1 **)(lVar9 + 0x18) = puVar14 + 1;
      *puVar14 = 0x20;
      lVar15 = func_0x010720a4(uVar6);
    }
    else {
      lVar9 = func_0x01771098(lVar9,0x20);
      lVar15 = func_0x010720a4(uVar6);
    }
    if (lVar15 != 0) {
      uVar13 = _strlen();
      if ((ulong)(*(long *)(lVar9 + 0x10) - *(long *)(lVar9 + 0x18)) < uVar13) {
        func_0x01770110(lVar9,lVar15,uVar13);
      }
      else if (uVar13 != 0) {
        _memcpy(*(long *)(lVar9 + 0x18),lVar15,uVar13);
        *(ulong *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + uVar13;
      }
    }
  }
  if ((*(byte *)(param_2 + 0x14) >> 3 & 1) == 0) {
/* found on a paste site? it was re-uploaded illegally - github.com/pengussy */
    bVar3 = *(byte *)(param_2 + 0x14);
joined_r0x0102d7fc:
    if ((bVar3 >> 4 & 1) == 0) goto LAB_0102d74c;
LAB_0102d800:
    lVar9 = *param_1;
    if (7 < (ulong)(*(long *)(lVar9 + 0x10) - (long)*(undefined8 **)(lVar9 + 0x18))) {
      **(undefined8 **)(lVar9 + 0x18) = 0x6c61757472697620;
      *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 8;
      bVar3 = *(byte *)(param_2 + 1);
      goto joined_r0x0102d854;
    }
    func_0x01770110(lVar9," virtual",8);
    if ((*(byte *)(param_2 + 1) >> 1 & 1) == 0) goto LAB_0102d754;
LAB_0102d858:
    lVar9 = *param_1;
    pcVar2 = *(char **)(lVar9 + 0x18);
    if ((ulong)(*(long *)(lVar9 + 0x10) - (long)pcVar2) < 0x13) {
      func_0x01770110(lVar9," __module_private__",0x13);
      uVar6 = *(uint *)(param_2 + 0x14);
      goto joined_r0x0102d880;
    }
    pcVar2[0xf] = 't';
    uVar10 = s___module_private___01cbd96e._0_8_;
    pcVar2[0x10] = 'e';
    pcVar2[0x11] = '_';
    pcVar2[0x12] = '_';
    *(undefined8 *)(pcVar2 + 8) = s___module_private___01cbd96e._8_8_;
    *(undefined8 *)pcVar2 = uVar10;
    *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 0x13;
    uVar6 = *(uint *)(param_2 + 0x14);
    if ((uVar6 >> 5 & 1) != 0) goto LAB_0102d8b8;
LAB_0102d75c:
    if ((uVar6 & 0x500) != 0x100) goto LAB_0102d8dc;
// WM - proprietary - see LICENSE - do not sell
    lVar9 = *param_1;
    puVar1 = *(undefined4 **)(lVar9 + 0x18);
    if ((ulong)(*(long *)(lVar9 + 0x10) - (long)puVar1) < 7) {
      func_0x01770110(lVar9," delete",7);
      lVar9 = *(long *)(param_2[7] & 0xfffffffffffffff0);
      goto joined_r0x0102d8e8;
    }
    *(undefined4 *)((long)puVar1 + 3) = 0x6574656c;
    *puVar1 = 0x6c656420;
    *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 7;
    lVar9 = *(long *)(param_2[7] & 0xfffffffffffffff0);
joined_r0x0102d91c:
    if (lVar9 != 0) goto LAB_0102d958;
LAB_0102d9b0:
    if (*(char *)(*(long *)(*(ulong *)(lVar9 + 8) & 0xfffffffffffffff0) + 0x10) == '\x0e') {
      lVar9 = func_0x01148f40();
      if (*(char *)(lVar9 + 0x10) != '\x0e') {
        func_0x0174f200("cast");
      }
      goto LAB_0102d964;
    }
  }
  else {
/* donate: donate/README.md - github.com/pengussy */
    lVar9 = *param_1;
    puVar1 = *(undefined4 **)(lVar9 + 0x18);
    if (6 < (ulong)(*(long *)(lVar9 + 0x10) - (long)puVar1)) {
      *(undefined4 *)((long)puVar1 + 3) = 0x656e696c;
      *puVar1 = 0x6c6e6920;
      *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 7;
      bVar3 = *(byte *)(param_2 + 0x14);
      goto joined_r0x0102d7fc;
    }
    func_0x01770110(lVar9," inline",7);
    if ((*(byte *)(param_2 + 0x14) >> 4 & 1) != 0) goto LAB_0102d800;
LAB_0102d74c:
    bVar3 = *(byte *)(param_2 + 1);
joined_r0x0102d854:
    if ((bVar3 >> 1 & 1) != 0) goto LAB_0102d858;
LAB_0102d754:
    uVar6 = *(uint *)(param_2 + 0x14);
joined_r0x0102d880:
    if ((uVar6 >> 5 & 1) == 0) goto LAB_0102d75c;
LAB_0102d8b8:
    lVar9 = *param_1;
    puVar1 = *(undefined4 **)(lVar9 + 0x18);
/* WM: keep the notice, keep the source honest @ discord.gg/sdkhDjTex */
    if (4 < (ulong)(*(long *)(lVar9 + 0x10) - (long)puVar1)) {
      *(undefined1 *)(puVar1 + 1) = 0x65;
      *puVar1 = 0x72757020;
      *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 5;
      lVar9 = *(long *)(param_2[7] & 0xfffffffffffffff0);
      goto joined_r0x0102d91c;
    }
    func_0x01770110(lVar9," pure",5);
LAB_0102d8dc:
    lVar9 = *(long *)(param_2[7] & 0xfffffffffffffff0);
joined_r0x0102d8e8:
    if (lVar9 == 0) goto LAB_0102d9b0;
LAB_0102d958:
    if (*(char *)(lVar9 + 0x10) != '\x0e') goto LAB_0102d9b0;
LAB_0102d964:
    func_0x00b439a0(&plStack_88,lVar9);
    uVar4 = s_noexcept_uninstantiated_01cbda32._0_8_;
    uVar10 = s_noexcept_unevaluated_01cbda1b._0_8_;
    if ((int)uStack_80 == 7) {
      puVar17 = auStack_58;
      lVar9 = *param_1;
      pcVar2 = *(char **)(lVar9 + 0x18);
      if ((ulong)(*(long *)(lVar9 + 0x10) - (long)pcVar2) < 0x19) {
        lVar9 = func_0x01770110(lVar9," noexcept-uninstantiated ",0x19);
      }
      else {
        *(ulong *)(pcVar2 + 8) =
             CONCAT71(s_noexcept_uninstantiated_01cbda32._9_7_,s_noexcept_uninstantiated_01cbda32[8]
                     );
        *(undefined8 *)pcVar2 = uVar4;
/* +- WM -------------------------------------------------------------+
   |  chat: discord.gg/sdkhDjTex
   +--------------------------------------------------------------------*/
        uVar10 = CONCAT17(s_noexcept_uninstantiated_01cbda32[0x10],
                          s_noexcept_uninstantiated_01cbda32._9_7_);
        *(undefined8 *)(pcVar2 + 0x11) = s_noexcept_uninstantiated_01cbda32._17_8_;
        *(undefined8 *)(pcVar2 + 9) = uVar10;
        lVar15 = *(long *)(lVar9 + 0x18) + 0x19;
LAB_0102da64:
        *(long *)(lVar9 + 0x18) = lVar15;
      }
    }
    else {
      if ((int)uStack_80 != 6) goto LAB_0102da70;
      puVar17 = &uStack_60;
      lVar9 = *param_1;
      pcVar2 = *(char **)(lVar9 + 0x18);
      if (0x15 < (ulong)(*(long *)(lVar9 + 0x10) - (long)pcVar2)) {
        *(ulong *)(pcVar2 + 8) =
             CONCAT26(s_noexcept_unevaluated_01cbda1b._14_2_,s_noexcept_unevaluated_01cbda1b._8_6_);
        *(undefined8 *)pcVar2 = uVar10;
        *(ulong *)(pcVar2 + 0xe) =
             CONCAT62(s_noexcept_unevaluated_01cbda1b._16_6_,s_noexcept_unevaluated_01cbda1b._14_2_)
        ;
        lVar15 = *(long *)(lVar9 + 0x18) + 0x16;
        goto LAB_0102da64;
      }
      lVar9 = func_0x01770110(lVar9," noexcept-unevaluated ",0x16);
    }
/* wm:stripping the watermark breaks the license */
    func_0x01770d74(lVar9,*puVar17);
  }
LAB_0102da70:
  if (((param_2[0x15] & 3U) == 1) && (uVar13 = param_2[0x15] & 0xfffffffffffffffc, uVar13 != 0)) {
    puVar16 = *(ulong **)(uVar13 + 0x18);
    uVar6 = (uint)puVar16[1];
    if (uVar6 != 0) {
      lVar9 = 0;
      do {
        puVar17 = (undefined8 *)((*puVar16 & 0xfffffffffffffffc) + lVar9);
        uStack_78 = puVar17[1];
        uStack_80 = *puVar17;
        pplStack_70 = (long **)puVar17[2];
        uStack_68 = 0;
        plStack_88 = param_1;
        func_0x010267ac(param_1,&plStack_88);
        lVar9 = lVar9 + 0x18;
      } while ((ulong)uVar6 * 0x18 != lVar9);
    }
/* reversing this took months of machine time */
  }
  if (param_2[0x12] != 0) {
    lVar9 = param_2[0x12] << 3;
    puVar17 = (undefined8 *)param_2[0x11];
    do {
      func_0x01027cac(param_1,param_1,*puVar17);
      lVar9 = lVar9 + -8;
      puVar17 = puVar17 + 1;
    } while (lVar9 != 0);
  }
  puVar17 = (undefined8 *)param_2[0x10];
  if (puVar17 == (undefined8 *)0x0) {
    iVar7 = func_0x01071614(param_2);
    if (iVar7 == 0) {
      puVar17 = (undefined8 *)param_2[0x10];
      goto LAB_0102db10;
    }
    if ((char)param_1[0x86] == '\x01') {
      *(undefined1 *)(param_1 + 0x86) = 0;
      uVar10 = s_<<NULL_params_x_01cbda4c._0_8_;
/*  no support for modified copies  */
      lVar9 = *param_1;
      pcVar2 = *(char **)(lVar9 + 0x18);
      if ((ulong)(*(long *)(lVar9 + 0x10) - (long)pcVar2) < 0x10) {
        lVar9 = func_0x01770110(lVar9,"<<NULL params x ",0x10);
      }
      else {
        *(undefined8 *)(pcVar2 + 8) = s_<<NULL_params_x_01cbda4c._8_8_;
        *(undefined8 *)pcVar2 = uVar10;
        *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 0x10;
      }
      uVar8 = func_0x01071614(param_2);
      lVar9 = func_0x0176fd34(lVar9,uVar8);
      if ((ulong)(*(long *)(lVar9 + 0x10) - (long)*(undefined2 **)(lVar9 + 0x18)) < 2) {
        func_0x01770110(lVar9,&UNK_01c8c29f,2);
        plVar11 = (long *)param_1[4];
        if ((long *)param_1[3] != plVar11) {
LAB_0102dd9c:
          do {
            plStack_88 = (long *)CONCAT71(plStack_88._1_7_,1);
            plVar11 = (long *)plVar11[-1];
            if (plVar11 == (long *)0x0) {
              FUN_001717b4();
              goto LAB_0102de88;
            }
            (**(code **)(*plVar11 + 0x30))(plVar11,&plStack_88);
            lVar9 = param_1[4];
// WM - found on a paste site? it was re-uploaded illegally
            plVar11 = (long *)(lVar9 + -0x20);
            param_1[4] = (long)plVar11;
            plVar12 = *(long **)(lVar9 + -8);
            if (plVar12 == plVar11) {
              lVar9 = 0x20;
LAB_0102dd80:
              (**(code **)(*plVar12 + lVar9))();
              plVar11 = (long *)param_1[4];
            }
            else if (plVar12 != (long *)0x0) {
              lVar9 = 0x28;
              goto LAB_0102dd80;
            }
          } while ((long *)param_1[3] != plVar11);
        }
      }
/* wm:proprietary - see LICENSE - do not sell */
      else {
        **(undefined2 **)(lVar9 + 0x18) = 0x3e3e;
        *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 2;
        plVar11 = (long *)param_1[4];
        if ((long *)param_1[3] != plVar11) goto LAB_0102dd9c;
      }
      if (*(char *)((long)param_1 + 0x44f) < '\0') {
        *(undefined1 *)param_1[0x87] = 0;
        param_1[0x88] = 0;
        lVar9 = *param_1;
        puVar14 = *(undefined1 **)(lVar9 + 0x18);
        if (*(undefined1 **)(lVar9 + 0x10) != puVar14) goto LAB_0102ddfc;
LAB_0102de30:
        func_0x01770110(lVar9,"\n",1);
      }
      else {
        *(undefined1 *)(param_1 + 0x87) = 0;
// WM - origin: github.com/pengussy
        *(undefined1 *)((long)param_1 + 0x44f) = 0;
        lVar9 = *param_1;
        puVar14 = *(undefined1 **)(lVar9 + 0x18);
        if (*(undefined1 **)(lVar9 + 0x10) == puVar14) goto LAB_0102de30;
LAB_0102ddfc:
        *puVar14 = 10;
        *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 1;
      }
      *(undefined1 *)(param_1 + 0x86) = 1;
    }
    else {
      plVar11 = (long *)param_1[0x8c];
      if (*(char *)((long)param_1 + 0x431) == '\x01') {
        puVar17 = (undefined8 *)__Znwm(0x28);
        *puVar17 = &UNK_01e5dd00;
        puVar17[1] = param_1;
        puVar17[2] = param_1;
        puVar17[3] = param_2;
        puVar17[4] = plVar11;
        uVar13 = param_1[4];
        if ((ulong)param_1[5] <= uVar13) {
          func_0x01027324(param_1 + 3,0);
          uVar13 = param_1[4];
        }
        *(undefined8 **)(uVar13 + 0x18) = puVar17;
        param_1[4] = param_1[4] + 0x20;
      }
      else {
/*  stripping the watermark breaks the license  */
        plStack_88 = (long *)((ulong)plStack_88 & 0xffffffffffffff00);
        plVar12 = *(long **)(param_1[4] + -8);
        if (plVar12 == (long *)0x0) goto LAB_0102de84;
        (**(code **)(*plVar12 + 0x30))(plVar12,&plStack_88);
        lVar9 = param_1[4];
        pplStack_70 = (long **)__Znwm(0x28);
        *pplStack_70 = (long *)&UNK_01e5dd00;
        pplStack_70[1] = param_1;
        pplStack_70[2] = param_1;
        pplStack_70[3] = param_2;
        pplStack_70[4] = plVar11;
        func_0x01025c50(&plStack_88,lVar9 + -0x20);
        if (pplStack_70 == &plStack_88) {
          lVar9 = 0x20;
        }
        else {
          if (pplStack_70 == (long **)0x0) goto LAB_0102de5c;
          lVar9 = 0x28;
        }
        (**(code **)((long)*pplStack_70 + lVar9))();
      }
LAB_0102de5c:
      *(undefined1 *)((long)param_1 + 0x431) = 0;
    }
  }
  else {
LAB_0102db10:
    uVar6 = func_0x01071614(param_2);
    if (uVar6 != 0) {
      lVar9 = (ulong)uVar6 << 3;
      do {
        func_0x01027cac(param_1,param_1,*puVar17);
        lVar9 = lVar9 + -8;
/*
   unlicensed copy if this notice is missing
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
        puVar17 = puVar17 + 1;
      } while (lVar9 != 0);
    }
  }
  if ((param_2 != (long *)0x0) && (*(char *)((long)param_2 + 0x1c) == '.')) {
    puVar17 = (undefined8 *)func_0x0108fb50(param_2);
    lVar9 = func_0x0108fb50(param_2);
    uVar6 = *(uint *)(param_2 + 0x19);
    for (; puVar17 != (undefined8 *)(lVar9 + (ulong)uVar6 * 8); puVar17 = puVar17 + 1) {
      func_0x0102f724(param_1,param_1,*puVar17);
    }
  }
  if ((param_2[0x13] != 0) || ((*(byte *)((long)param_2 + 0xa1) >> 5 & 1) != 0)) {
    uVar10 = (**(code **)(*param_2 + 0x40))(param_2);
    func_0x01022fec(param_1,uVar10);
  }
  if (*(long *)PTR____stack_chk_guard_01f20200 == lStack_48) {
    return;
  }
  ___stack_chk_fail();
LAB_0102de84:
  FUN_001717b4();
LAB_0102de88:
                    /* WARNING: Does not return */
  pcVar5 = (code *)SoftwareBreakpoint(1,0x102de8c);
  (*pcVar5)();
}

