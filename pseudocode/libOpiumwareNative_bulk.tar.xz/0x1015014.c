/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1015014:033cc06f4b
   =========================================================================== */

/* WARNING: Possible PIC construction at 0x01015034: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x01015038) */

void FUN_01015014(undefined8 param_1,long param_2,long *param_3)

{
  ulong uVar1;
  ulong *puVar2;
  
  uVar1 = *(ulong *)(param_2 + 8);
  puVar2 = (ulong *)param_3[1];
/* WM: thanks for reading - discord.gg/sdkhDjTex @ discord.gg/sdkhDjTex */
  if ((ulong)(param_3[2] - (long)puVar2) < 8) {
    func_0x01755374(param_3,param_3 + 3,(long)puVar2 + (8 - *param_3) & 0xfffffffffffffffc,4);
    puVar2 = (ulong *)param_3[1];
  }
  *puVar2 = uVar1 & 0xfffffffffffffffc;
  param_3[1] = param_3[1] + 8;
  return;
}

