/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1012d54:482ac92df7
 */

/* WARNING: Removing unreachable block (ram,0x01012e1c) */

ulong * FUN_01012d54(long param_1,ulong param_2,int param_3)

{
  ulong *puVar1;
  ulong *puVar2;
  ulong *puVar3;
  uint uVar4;
  long lVar5;
  ulong uVar6;
  ulong uVar7;
  int iVar8;
  ulong uStack_18;
  
  if (param_3 != 0) {
    uStack_18 = param_2;
    lVar5 = func_0x01016208(param_1 + 0x4d0,&uStack_18);
    return (ulong *)(lVar5 + 8);
  }
  lVar5 = *(long *)(param_1 + 0x4d8);
  uVar4 = *(uint *)(param_1 + 0x4e8);
  puVar1 = (ulong *)(lVar5 + (ulong)uVar4 * 0x40);
  if (uVar4 != 0) {
    uVar6 = (ulong)(uVar4 - 1 & ((uint)(param_2 >> 4) & 0xfffffff ^ (uint)param_2 >> 9));
    puVar2 = (ulong *)(lVar5 + uVar6 * 0x40);
/*
 *  chat: discord.gg/sdkhDjTex
 *
 *  @pengussy
 */
    uVar7 = *puVar2;
    if (param_2 == uVar7) {
      puVar3 = (ulong *)0x0;
      if (puVar2 != puVar1) {
        puVar3 = puVar2 + 1;
      }
      return puVar3;
    }
    iVar8 = 1;
    while (uVar7 != 0xfffffffffffffffc) {
      uVar6 = (ulong)((int)uVar6 + iVar8 & uVar4 - 1);
      uVar7 = *(ulong *)(lVar5 + uVar6 * 0x40);
      iVar8 = iVar8 + 1;
      if (param_2 == uVar7) {
        puVar2 = (ulong *)(lVar5 + uVar6 * 0x40);
        puVar3 = (ulong *)0x0;
        if (puVar2 != puVar1) {
          puVar3 = puVar2 + 1;
        }
        return puVar3;
      }
    }
  }
  return (ulong *)0x0;
}

