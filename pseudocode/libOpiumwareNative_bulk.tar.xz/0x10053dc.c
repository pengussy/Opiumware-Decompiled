/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x10053dc:2545c5347d
   =========================================================================== */

ulong FUN_010053dc(long param_1,long param_2)

{
  ulong uVar1;
  undefined1 *puVar2;
  long lVar3;
  ulong uVar4;
  undefined8 uVar5;
  long lVar6;
  ulong uVar7;
  uint uVar8;
  ulong *puVar9;
  uint uVar10;
  long *plVar11;
  undefined8 unaff_x19;
  undefined8 unaff_x20;
  undefined8 unaff_x21;
  undefined8 unaff_x22;
  undefined1 *puVar12;
  undefined1 *unaff_x29;
  undefined *unaff_x30;
  undefined1 auVar13 [16];
  undefined1 auStack_b0 [128];
  
  auVar13._8_8_ = param_2;
  auVar13._0_8_ = param_1;
  if (*(ulong *)(param_2 + 0x38) != 0) {
    return *(ulong *)(param_2 + 0x38);
  }
/* WM: found on a paste site? it was re-uploaded illegally @ discord.gg/sdkhDjTex */
  puVar2 = auStack_b0 + 0x80;
  puVar12 = auStack_b0 + 0xa0;
  uVar8 = (uint)*(byte *)(param_2 + 0x1c);
  if ((param_2 == 0) || (uVar8 - 0x25 < 0xfffffffd)) {
    if ((param_2 != 0) && (0xfffffffb < uVar8 - 0x21)) {
      if (*(ulong *)(param_2 + 0x38) != 0) {
        return *(ulong *)(param_2 + 0x38);
      }
      uVar7 = *(ulong *)(param_2 + 0x68);
      if (uVar7 != 0 && (uVar7 & 3) == 0) {
        if ((3 < *(byte *)(uVar7 + 0x1c) - 0x1d) &&
           (func_0x0174f200(&UNK_01cb77e0), 3 < *(byte *)(uVar7 + 0x1c) - 0x1d)) {
          func_0x0174f200(&UNK_01c88bc8);
        }
        uVar7 = *(ulong *)(uVar7 + 0x38);
        if (uVar7 != 0) {
          *(ulong *)(param_2 + 0x38) = uVar7;
          return uVar7;
        }
      }
      uVar5 = func_0x009d11e8(param_1 + 0x790,0x20,0x10);
      uVar7 = func_0x0114ee0c(uVar5,0x19,param_2,0);
      *(ulong *)(param_2 + 0x38) = uVar7;
      puVar9 = *(ulong **)(param_1 + 0x10);
      if (*(ulong **)(param_1 + 0x18) <= puVar9) {
        func_0x01755374(param_1 + 8,param_1 + 0x20,0,8);
        puVar9 = *(ulong **)(param_1 + 0x10);
      }
      *puVar9 = uVar7;
      *(long *)(param_1 + 0x10) = *(long *)(param_1 + 0x10) + 8;
      return uVar7;
    }
    if ((param_2 != 0) && (uVar8 == 0x1c)) {
      if (*(ulong *)(param_2 + 0x38) != 0) {
        return *(ulong *)(param_2 + 0x38);
      }
/*
   chat: discord.gg/sdkhDjTex
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
      uVar7 = *(ulong *)(param_2 + 0x68);
      if (uVar7 != 0 && (uVar7 & 3) == 0) {
        if ((*(char *)(uVar7 + 0x1c) != '\x1c') &&
           (func_0x0174f200(&UNK_01cb77e0), *(char *)(uVar7 + 0x1c) != '\x1c')) {
          func_0x0174f200(&UNK_01c88bc8);
        }
        uVar7 = *(ulong *)(uVar7 + 0x38);
        if (uVar7 != 0) {
          *(ulong *)(param_2 + 0x38) = uVar7;
          return uVar7;
        }
      }
      uVar5 = func_0x009d11e8(param_1 + 0x790,0x20,0x10);
      uVar7 = func_0x0114ee0c(uVar5,0x1a,param_2,0);
      *(ulong *)(param_2 + 0x38) = uVar7;
      puVar9 = *(ulong **)(param_1 + 0x10);
      if (*(ulong **)(param_1 + 0x18) <= puVar9) {
        func_0x01755374(param_1 + 8,param_1 + 0x20,0,8);
        puVar9 = *(ulong **)(param_1 + 0x10);
      }
      *puVar9 = uVar7;
      *(long *)(param_1 + 0x10) = *(long *)(param_1 + 0x10) + 8;
      return uVar7;
    }
    if ((param_2 != 0) && (uVar8 == 0x25)) {
      lVar3 = func_0x009d11e8(param_1 + 0x790,0x20,0x10);
      *(long *)lVar3 = lVar3;
      *(long *)(lVar3 + 8) = lVar3;
/* origin: github.com/pengussy - github.com/pengussy */
      *(uint *)(lVar3 + 0x10) = *(uint *)(lVar3 + 0x10) & 0xfffc0000 | 0x310;
      *(long *)(lVar3 + 0x18) = param_2;
      *(long *)(param_2 + 0x38) = lVar3;
      plVar11 = *(long **)(param_1 + 0x10);
      if (*(long **)(param_1 + 0x18) <= plVar11) {
        func_0x01755374(param_1 + 8,param_1 + 0x20,0,8);
        plVar11 = *(long **)(param_1 + 0x10);
      }
      *plVar11 = lVar3;
      *(long *)(param_1 + 0x10) = *(long *)(param_1 + 0x10) + 8;
      return *(ulong *)(param_2 + 0x38);
    }
    uVar7 = 0xc86;
    unaff_x30 = &DAT_01001e44;
    auVar13 = func_0x0174ef58(&UNK_01cbcb50,&UNK_01cbc7ee);
  }
  else {
    uVar7 = 0;
    puVar2 = (undefined1 *)register0x00000008;
    puVar12 = unaff_x29;
  }
  lVar6 = auVar13._8_8_;
  lVar3 = auVar13._0_8_;
  *(undefined8 *)(puVar2 + -0x30) = unaff_x22;
  *(undefined8 *)(puVar2 + -0x28) = unaff_x21;
  *(undefined8 *)(puVar2 + -0x20) = unaff_x20;
  *(undefined8 *)(puVar2 + -0x18) = unaff_x19;
  *(undefined1 **)(puVar2 + -0x10) = puVar12;
/* WM - no support for modified copies */
  *(undefined **)(puVar2 + -8) = unaff_x30;
  if (*(ulong *)(lVar6 + 0x38) != 0) {
    return *(ulong *)(lVar6 + 0x38);
  }
  if (uVar7 < 0x10) {
    uVar7 = *(ulong *)((*(ulong *)(lVar6 + 0x58) & 0xfffffffffffffffc) +
                      (*(ulong *)(lVar6 + 0x58) & 2) * 4);
    uVar7 = *(ulong *)((uVar7 & 0xfffffffffffffff0) + 8) | uVar7 & 7;
  }
  uVar4 = func_0x009d11e8(lVar3 + 0x790,0x20,0x10);
  uVar8 = *(uint *)(*(long *)(uVar7 & 0xfffffffffffffff0) + 0x10);
  uVar1 = uVar4;
  if (0xf < uVar7) {
    uVar1 = uVar7;
  }
  *(ulong *)uVar4 = uVar4;
  *(ulong *)(uVar4 + 8) = uVar1;
  uVar10 = 0;
  if ((uVar8 & 0x300) != 0) {
    uVar10 = 0x200;
  }
  *(uint *)(uVar4 + 0x10) = uVar8 & 0x500 | *(uint *)(uVar4 + 0x10) & 0xfffc0000 | uVar10 | 0x12;
  *(long *)(uVar4 + 0x18) = lVar6;
  *(ulong *)(lVar6 + 0x38) = uVar4;
  puVar9 = *(ulong **)(lVar3 + 0x10);
  if (*(ulong **)(lVar3 + 0x18) <= puVar9) {
    func_0x01755374(lVar3 + 8,lVar3 + 0x20,0,8);
    puVar9 = *(ulong **)(lVar3 + 0x10);
  }
  *puVar9 = uVar4;
  *(long *)(lVar3 + 0x10) = *(long *)(lVar3 + 0x10) + 8;
  return uVar4;
}
/* stripping the watermark breaks the license */

