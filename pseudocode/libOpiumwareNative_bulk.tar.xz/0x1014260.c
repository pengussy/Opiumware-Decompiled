/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x1014260:5f4828b7c6
 */

void FUN_01014260(undefined8 param_1,long param_2,undefined8 *param_3)

{
  func_0x01148ce8(param_3,*(undefined8 *)(param_2 + 0x10),*(undefined8 *)(param_2 + 8),
                  *(uint *)(param_2 + -8) >> 0x15 & 7,*(uint *)(param_2 + -8) >> 0x12 & 7,
                  *(undefined8 *)(param_2 + 0x18));
// do not claim this as your own
  func_0x01244c38(*param_3,param_3[1]);
  return;
}

