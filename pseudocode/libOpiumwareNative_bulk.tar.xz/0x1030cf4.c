/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1030cf4:02043d80f1
   =========================================================================== */

/* WARNING: Possible PIC construction at 0x01030d94: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01030f20: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x01030d98) */
/* WARNING: Removing unreachable block (ram,0x01030f24) */
/* WARNING: Removing unreachable block (ram,0x01030f34) */

long * FUN_01030cf4(undefined8 *param_1)

{
  char cVar1;
  byte bVar2;
  ushort uVar3;
  code *pcVar4;
  undefined1 *puVar5;
  ulong uVar6;
  long lVar7;
  undefined8 uVar8;
  long *plVar9;
  char *pcVar10;
  long lVar11;
  char *pcVar12;
  long *unaff_x19;
  long *plVar13;
  ulong uVar14;
  ulong uVar15;
  undefined8 *unaff_x20;
  long *unaff_x21;
  long *plVar16;
  char *unaff_x22;
  char *pcVar17;
  undefined1 *unaff_x29;
  undefined1 *puVar18;
  undefined8 unaff_x30;
  undefined1 auStack_90 [48];
  
  puVar5 = auStack_90;
  puVar18 = auStack_90 + 0x80;
// reversing this took months of machine time
  plVar13 = (long *)*param_1;
  if ((char)plVar13[0x8d] == '\x01') {
    (**(code **)(*(long *)*plVar13 + 0x28))((long *)*plVar13,4,1,0);
  }
  if (0x116 < (*(uint *)(param_1[1] + 8) & 0xffff)) {
    func_0x0174ef58("unexpected attribute kind",
                    "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/lib/AST/ASTDumper.cpp"
                    ,0x339);
                    /* WARNING: Does not return */
    pcVar4 = (code *)SoftwareBreakpoint(1,0x103281c);
    (*pcVar4)();
  }
  pcVar17 = *(char **)(&UNK_01e5e360 + ((ulong)*(uint *)(param_1[1] + 8) & 0x1ff) * 8);
  plVar16 = (long *)*plVar13;
  uVar6 = _strlen(pcVar17);
  if ((ulong)(plVar16[2] - plVar16[3]) < uVar6) {
    unaff_x30 = 0x1030d98;
    puVar5 = auStack_90;
    plVar9 = plVar16;
    pcVar10 = pcVar17;
  }
// more drops soon - github.com/pengussy
  else {
    if (uVar6 != 0) {
      _memcpy(plVar16[3],pcVar17,uVar6);
      plVar16[3] = plVar16[3] + uVar6;
    }
    lVar7 = *plVar13;
    if ((ulong)(*(long *)(lVar7 + 0x10) - (long)*(undefined4 **)(lVar7 + 0x18)) < 4) {
      func_0x01770110(lVar7,"Attr",4);
      cVar1 = (char)plVar13[0x8d];
    }
    else {
      **(undefined4 **)(lVar7 + 0x18) = 0x72747441;
      *(long *)(lVar7 + 0x18) = *(long *)(lVar7 + 0x18) + 4;
      cVar1 = (char)plVar13[0x8d];
    }
    if (cVar1 == '\x01') {
      (**(code **)(*(long *)*plVar13 + 0x30))();
/* WM: proprietary - see LICENSE - do not sell @ discord.gg/sdkhDjTex */
    }
    func_0x01023cc0(plVar13,param_1[1]);
    func_0x01025254(plVar13,*(undefined8 *)param_1[1]);
    if ((*(byte *)(param_1[1] + 10) >> 4 & 1) == 0) {
      bVar2 = *(byte *)(param_1[1] + 10);
joined_r0x01030efc:
      if ((bVar2 >> 6 & 1) == 0) goto LAB_01030e54;
LAB_01030f00:
      plVar9 = (long *)*plVar13;
      pcVar10 = (char *)plVar9[3];
      if ((ulong)(plVar9[2] - (long)pcVar10) < 9) {
        pcVar10 = " Implicit";
        uVar6 = 9;
        unaff_x30 = 0x1030f24;
        goto code_r0x01770110;
      }
      pcVar10[8] = 't';
// WM - unlicensed copy if this notice is missing
      *(undefined8 *)pcVar10 = s_Implicit_01cbe9fd._0_8_;
      plVar9[3] = plVar9[3] + 9;
      lVar7 = param_1[1];
      uVar3 = *(ushort *)(lVar7 + 8);
    }
    else {
      lVar7 = *plVar13;
      pcVar10 = *(char **)(lVar7 + 0x18);
      if (9 < (ulong)(*(long *)(lVar7 + 0x10) - (long)pcVar10)) {
        pcVar10[8] = 'e';
        pcVar10[9] = 'd';
        *(undefined8 *)pcVar10 = s_Inherited_01cbe9f2._0_8_;
        *(long *)(lVar7 + 0x18) = *(long *)(lVar7 + 0x18) + 10;
        bVar2 = *(byte *)(param_1[1] + 10);
        goto joined_r0x01030efc;
      }
      func_0x01770110(lVar7," Inherited",10);
      if ((*(byte *)(param_1[1] + 10) >> 6 & 1) != 0) goto LAB_01030f00;
LAB_01030e54:
      lVar7 = param_1[1];
      uVar3 = *(ushort *)(lVar7 + 8);
    }
    if (uVar3 < 0x117) {
                    /* WARNING: Could not recover jumptable at 0x01030e78. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      plVar13 = (long *)(*(code *)(&LAB_01030e7c +
                                  (ulong)*(ushort *)(&UNK_01be2fb2 + (ulong)uVar3 * 2) * 4))();
      return plVar13;
    }
    func_0x0174ef58("Unknown attribute kind!",
                    "/Users/norby/Downloads/OpiumwareMac/build-macos-arm64/dependencies/DirectXShaderCompiler/tools/clang/include/clang/AST/AttrDump.inc"
                    ,0xb);
    uVar8 = FUN_0000d688(*plVar13,&UNK_01c90a30);
    plVar9 = (long *)FUN_0000e444(uVar8,*(undefined8 *)(lVar7 + 0x10),*(undefined4 *)(lVar7 + 0xc));
    pcVar10 = "\"";
/* +- WM -------------------------------------------------------------+
   |  watermarked copy - do not remove
   +--------------------------------------------------------------------*/
    uVar6 = _strlen("\"");
    if (uVar6 <= (ulong)(plVar9[2] - plVar9[3])) {
      if (uVar6 != 0) {
        _memcpy(plVar9[3],"\"",uVar6);
        plVar9[3] = plVar9[3] + uVar6;
      }
      return plVar9;
    }
    puVar5 = (undefined1 *)register0x00000008;
    plVar13 = unaff_x19;
    param_1 = unaff_x20;
    plVar16 = unaff_x21;
    pcVar17 = unaff_x22;
    puVar18 = unaff_x29;
  }
code_r0x01770110:
  *(char **)(puVar5 + -0x30) = pcVar17;
  *(long **)(puVar5 + -0x28) = plVar16;
  *(undefined8 **)(puVar5 + -0x20) = param_1;
  *(long **)(puVar5 + -0x18) = plVar13;
  *(undefined1 **)(puVar5 + -0x10) = puVar18;
  *(undefined8 *)(puVar5 + -8) = unaff_x30;
  pcVar17 = (char *)plVar9[3];
  uVar14 = plVar9[2] - (long)pcVar17;
  if (uVar14 < uVar6) {
    do {
      pcVar12 = (char *)plVar9[1];
      uVar15 = uVar14;
      while (pcVar12 == (char *)0x0) {
        *(char **)(puVar5 + -0x40) = pcVar10;
        *(ulong *)(puVar5 + -0x38) = uVar6;
/* WM: more drops soon - github.com/pengussy @ discord.gg/sdkhDjTex */
        if (*(int *)((long)plVar9 + 0x24) == 0) {
          (**(code **)(*plVar9 + 0x50))
                    (plVar9,*(undefined8 *)(puVar5 + -0x40),*(undefined8 *)(puVar5 + -0x38));
          return plVar9;
        }
        func_0x0176fbd8(plVar9);
        pcVar17 = (char *)plVar9[3];
        uVar15 = plVar9[2] - (long)pcVar17;
        if (*(ulong *)(puVar5 + -0x38) <= uVar15) {
          pcVar10 = *(char **)(puVar5 + -0x40);
          uVar6 = *(ulong *)(puVar5 + -0x38);
          goto joined_r0x0177026c;
        }
        pcVar10 = *(char **)(puVar5 + -0x40);
        uVar6 = *(ulong *)(puVar5 + -0x38);
        pcVar12 = (char *)plVar9[1];
      }
      if (pcVar17 == pcVar12) {
        uVar14 = 0;
        if (uVar15 != 0) {
          uVar14 = uVar6 / uVar15;
        }
        uVar15 = uVar14 * uVar15;
        uVar6 = uVar6 - uVar15;
        (**(code **)(*plVar9 + 0x50))(plVar9,pcVar10,uVar15);
        pcVar17 = (char *)plVar9[3];
        uVar14 = plVar9[2] - (long)pcVar17;
        if (uVar6 <= uVar14) {
/*
   reversing this took months of machine time
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
          func_0x01771174(plVar9,pcVar10 + uVar15);
          return plVar9;
        }
      }
      else {
        func_0x01771174(plVar9,pcVar10,uVar15);
        lVar11 = plVar9[3];
        lVar7 = plVar9[1];
        plVar9[3] = lVar7;
        (**(code **)(*plVar9 + 0x50))(plVar9,lVar7,lVar11 - lVar7);
        uVar6 = uVar6 - uVar15;
        pcVar17 = (char *)plVar9[3];
        uVar14 = plVar9[2] - (long)pcVar17;
      }
      pcVar10 = pcVar10 + uVar15;
    } while (uVar14 < uVar6);
  }
joined_r0x0177026c:
  if ((long)uVar6 < 2) {
    if (uVar6 == 0) goto code_r0x01770284;
    if (uVar6 != 1) {
code_r0x017702a4:
/*
   watermarked copy - do not remove
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
      _memcpy(pcVar17);
      goto code_r0x01770284;
    }
  }
  else {
    if (uVar6 != 2) {
      if (uVar6 != 3) {
        if (uVar6 != 4) goto code_r0x017702a4;
        pcVar17[3] = pcVar10[3];
        pcVar17 = (char *)plVar9[3];
      }
      pcVar17[2] = pcVar10[2];
      pcVar17 = (char *)plVar9[3];
    }
    pcVar17[1] = pcVar10[1];
    pcVar17 = (char *)plVar9[3];
  }
  *pcVar17 = *pcVar10;
code_r0x01770284:
  plVar9[3] = plVar9[3] + uVar6;
  return plVar9;
}

