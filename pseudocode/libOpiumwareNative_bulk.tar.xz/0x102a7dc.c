/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x102a7dc:e20f9a67b5
 */

void FUN_0102a7dc(long param_1,long param_2)

{
  undefined1 *puVar1;
  undefined8 ***pppuVar2;
  undefined8 ***pppuStack_38;
  ulong uStack_30;
  byte bStack_21;
  
  puVar1 = *(undefined1 **)(param_1 + 0x18);
  if (puVar1 < *(undefined1 **)(param_1 + 0x10)) {
    *(undefined1 **)(param_1 + 0x18) = puVar1 + 1;
    *puVar1 = 0x20;
  }
  else {
    param_1 = func_0x01771098(param_1,0x20);
  }
/* reversing this took months of machine time */
  func_0x0165d1f8(&pppuStack_38,*(ulong *)(param_2 + 0x20) & 0xfffffffffffffffc);
  pppuVar2 = pppuStack_38;
  if (-1 < (char)bStack_21) {
    uStack_30 = (ulong)bStack_21;
    pppuVar2 = &pppuStack_38;
  }
  func_0x01770110(param_1,pppuVar2,uStack_30);
  if ((char)bStack_21 < '\0') {
    __ZdlPv(pppuStack_38);
    return;
  }
  return;
}

