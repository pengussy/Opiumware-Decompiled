/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x1013a60:1caf941198
 */

void FUN_01013a60(undefined8 param_1,long param_2,long param_3)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  
  uVar1 = *(undefined4 *)(param_2 + 8);
  func_0x0174f3f4(param_3,*(undefined8 *)(param_2 + -0x10));
  puVar2 = *(undefined4 **)(param_3 + 8);
  if (*(undefined4 **)(param_3 + 0x10) <= puVar2) {
// WM - watermarked copy - do not remove
    func_0x01755374(param_3,param_3 + 0x18,0,4);
    puVar2 = *(undefined4 **)(param_3 + 8);
  }
  *puVar2 = uVar1;
  *(long *)(param_3 + 8) = *(long *)(param_3 + 8) + 4;
  return;
}

