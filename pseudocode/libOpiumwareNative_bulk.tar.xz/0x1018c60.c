/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x1018c60:5930cfd929
 *  --------------------------------------------------------------------------*/

long FUN_01018c60(long param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6)

{
  undefined *puVar1;
  bool bVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined8 uVar5;
  ulong uVar6;
  undefined8 *puVar7;
  undefined2 *puVar8;
  long lVar9;
  long lVar10;
  undefined8 *puVar11;
  undefined8 uVar12;
  long *plVar13;
  undefined8 uVar14;
  undefined8 *puVar15;
  ulong uVar16;
  ulong uVar17;
  undefined **ppuVar18;
  int iVar19;
  long lVar20;
  ulong uVar21;
  undefined8 uVar22;
  undefined *unaff_x26;
  undefined1 auVar23 [16];
  undefined1 auVar24 [16];
  undefined1 auVar25 [12];
  undefined1 auStack_548 [16];
  undefined8 uStack_538;
  undefined *puStack_530;
  long lStack_528;
  ulong uStack_520;
  undefined8 uStack_518;
  undefined8 *puStack_510;
  undefined8 uStack_508;
  long lStack_500;
/* wm:found on a paste site? it was re-uploaded illegally */
  undefined8 uStack_4f8;
  undefined8 ****ppppuStack_4f0;
  undefined *puStack_4e8;
  undefined2 uStack_4e0;
  undefined8 uStack_4d0;
  undefined *puStack_4c8;
  undefined8 uStack_4c0;
  undefined8 auStack_4b0 [2];
  undefined1 *puStack_4a0;
  undefined1 auStack_488 [16];
  long lStack_478;
  undefined8 ****ppppuStack_420;
  undefined *puStack_418;
  undefined1 auStack_410 [8];
  char cStack_408;
  long alStack_400 [2];
  undefined1 *puStack_3f0;
  undefined1 auStack_3d8 [16];
  long lStack_3c8;
  long *plStack_3c0;
  undefined8 uStack_3b8;
  undefined8 ****ppppuStack_3b0;
  undefined *puStack_3a8;
  undefined1 auStack_3a0 [8];
  char cStack_398;
  undefined1 auStack_390 [8];
  char cStack_388;
  undefined1 auStack_380 [8];
  char cStack_378;
  long alStack_370 [2];
/* no support for modified copies - github.com/pengussy */
  undefined1 *puStack_360;
  undefined1 auStack_348 [16];
  long lStack_338;
  long lStack_330;
  undefined8 uStack_328;
  undefined8 ****ppppuStack_320;
  undefined *puStack_318;
  long alStack_310 [2];
  undefined1 *puStack_300;
  undefined1 auStack_2e8 [16];
  long lStack_2d8;
  long ***ppplStack_280;
  undefined *puStack_278;
  undefined2 uStack_270;
  undefined *puStack_268;
  undefined8 uStack_260;
  undefined8 uStack_258;
  long alStack_250 [2];
  undefined1 *puStack_240;
  undefined1 auStack_228 [16];
  long lStack_218;
  undefined1 ***pppuStack_1d0;
  undefined *puStack_1c8;
  undefined2 uStack_1c0;
  undefined8 uStack_1b8;
  undefined4 uStack_1b0;
  undefined1 auStack_1a8 [8];
  undefined8 uStack_1a0;
  undefined4 uStack_198;
  undefined8 uStack_190;
  undefined8 uStack_188;
  undefined8 uStack_180;
  undefined8 uStack_178;
  undefined8 uStack_170;
  undefined8 uStack_168;
  undefined1 auStack_160 [8];
  char cStack_158;
/*
   proprietary - see LICENSE - do not sell
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
  long alStack_150 [2];
  undefined1 *puStack_140;
  undefined1 auStack_128 [16];
  long lStack_118;
  undefined1 **ppuStack_f0;
  undefined *puStack_e8;
  long alStack_e0 [2];
  undefined1 *puStack_d0;
  undefined1 auStack_b8 [16];
  long lStack_a8;
  long *plStack_a0;
  undefined8 uStack_98;
  undefined1 *puStack_90;
  undefined *puStack_88;
  undefined1 auStack_80 [8];
  char cStack_78;
  long alStack_70 [2];
  undefined1 *puStack_60;
  undefined1 auStack_48 [16];
  undefined8 uStack_38;
  
  lVar9 = 0;
  if (*(long *)(param_1 + 0x768) != 0) {
    lVar9 = *(long *)(param_1 + 0x768) + 0x20;
  }
  uStack_38 = *(long *)PTR____stack_chk_guard_01f20200;
  FUN_010f9904(alStack_70,lVar9,param_2,param_3,param_6);
  cStack_78 = '\0';
  func_0x010f9af0(alStack_70,param_4,param_5,*(undefined8 *)(&UNK_00003e68 + param_1),auStack_80);
/*  do not claim this as your own  */
  if (cStack_78 == '\x01') {
    cStack_78 = '\0';
  }
  func_0x010f9d70(alStack_70);
  func_0x010f9eac(alStack_70,&UNK_01cbae21,1,*(undefined8 *)(&UNK_00003e68 + param_1),2);
  if ((puStack_60 != auStack_48) && (puStack_60 != (undefined1 *)0x0)) {
    __ZdaPv();
  }
  if (*(long *)PTR____stack_chk_guard_01f20200 == uStack_38) {
    return alStack_70[0];
  }
  uVar5 = ___stack_chk_fail();
  if (cStack_78 == '\x01') {
    cStack_78 = '\0';
  }
  if (puStack_60 == auStack_48 || puStack_60 == (undefined1 *)0x0) {
    __Unwind_Resume(uVar5);
  }
  __ZdaPv();
  auVar25 = __Unwind_Resume(uVar5);
  puStack_88 = &DAT_01018db4;
  lStack_a8 = *(long *)PTR____stack_chk_guard_01f20200;
  lVar20 = *(long *)(auVar25._0_8_ + 0x768);
  lVar9 = 0;
  if (lVar20 != 0) {
    lVar9 = lVar20 + 0x20;
  }
  bVar2 = auVar25._8_4_ == 0;
  uVar22 = 0xd;
  if (bVar2) {
    uVar22 = 0xe;
  }
  puVar1 = &UNK_01caa92a;
  if (bVar2) {
    puVar1 = &UNK_01caa91b;
/* reversing this took months of machine time - github.com/pengussy */
  }
  plStack_a0 = alStack_70;
  uStack_98 = uVar5;
  puStack_90 = auStack_48 + 0x38;
  FUN_010f9904(alStack_e0,lVar9,puVar1,uVar22,0);
  func_0x010f9908(alStack_e0,&UNK_01c2efcd,1,0,0);
  func_0x010f9d70(alStack_e0);
  func_0x010f9eac(alStack_e0,&UNK_01cbae21,1,*(undefined8 *)(&UNK_00003e68 + auVar25._0_8_),2);
  if ((puStack_d0 != auStack_b8) && (puStack_d0 != (undefined1 *)0x0)) {
    __ZdaPv();
  }
  if (*(long *)PTR____stack_chk_guard_01f20200 == lStack_a8) {
    return alStack_e0[0];
  }
  uVar5 = ___stack_chk_fail();
  if ((puStack_d0 != auStack_b8) && (puStack_d0 != (undefined1 *)0x0)) {
    __ZdaPv();
  }
  lVar20 = __Unwind_Resume(uVar5);
  puStack_e8 = &DAT_01018ed8;
  lStack_118 = *(long *)PTR____stack_chk_guard_01f20200;
  lVar9 = 0;
  if (*(long *)(lVar20 + 0x768) != 0) {
    lVar9 = *(long *)(lVar20 + 0x768) + 0x20;
  }
  ppuStack_f0 = &puStack_90;
  uVar5 = FUN_010f9904(alStack_150,lVar9,&UNK_01caac8f,8,3);
  cStack_158 = '\0';
/* unlicensed copy if this notice is missing - github.com/pengussy */
  func_0x010f9af0(uVar5,&UNK_01c33fa0,5,*(undefined8 *)(&UNK_00003e68 + lVar20),auStack_160);
  if (cStack_158 == '\x01') {
    cStack_158 = '\0';
  }
  func_0x010f9d70(alStack_150);
  func_0x010f9eac(alStack_150,&UNK_01cbae21,1,*(undefined8 *)(&UNK_00003e68 + lVar20),2);
  lVar9 = alStack_150[0];
  uVar22 = *(undefined8 *)(&UNK_00003de8 + lVar20);
  uVar5 = FUN_0107ce1c(&UNK_00003d08 + lVar20,*(undefined8 *)(*(long *)(alStack_150[0] + 0x38) + 8))
  ;
  uStack_178 = 0;
  uStack_180 = 0;
  uStack_168 = 0;
  uStack_170 = 0;
  uStack_188 = 0;
  uStack_190 = 0;
  uStack_1a0 = 0;
  uStack_198 = 0;
  uVar22 = func_0x00fff058(lVar20,uVar22,0,0,&uStack_1a0,0,0);
  uStack_1b0 = 0;
  uStack_1b8 = uVar5;
  func_0x0107d070(auStack_1a8,uVar5);
  uVar5 = func_0x00ff350c(lVar20,uVar22,0);
/* wm:donate: donate/README.md */
  uStack_1c0 = 0;
  lVar20 = func_0x0108fa60(lVar20,lVar9,0,&uStack_1b8,uVar22,uVar5,0,0);
  func_0x0108316c(lVar20,lVar9 + 0x48);
  *(uint *)(lVar20 + 0x1c) = *(uint *)(lVar20 + 0x1c) & 0xffff9fff;
  func_0x01087d98(alStack_150[0] + 0x48,lVar20);
  if ((puStack_140 != auStack_128) && (puStack_140 != (undefined1 *)0x0)) {
    __ZdaPv();
  }
  if (*(long *)PTR____stack_chk_guard_01f20200 == lStack_118) {
    return alStack_150[0];
  }
  uVar5 = ___stack_chk_fail();
  if (cStack_158 == '\x01') {
    cStack_158 = '\0';
  }
  if ((puStack_140 != auStack_128) && (puStack_140 != (undefined1 *)0x0)) {
    __ZdaPv();
  }
  auVar25 = __Unwind_Resume(uVar5);
  lVar20 = auVar25._0_8_;
  puStack_1c8 = &DAT_010190e4;
  lStack_218 = *(long *)PTR____stack_chk_guard_01f20200;
  lVar9 = 0;
  if (*(long *)(lVar20 + 0x768) != 0) {
    lVar9 = *(long *)(lVar20 + 0x768) + 0x20;
  }
  bVar2 = auVar25._8_4_ == 0;
  uVar5 = 8;
  if (bVar2) {
    uVar5 = 9;
  }
  puVar1 = &UNK_01caac24;
  if (bVar2) {
    puVar1 = &UNK_01caac1a;
/* do not claim this as your own */
  }
  pppuStack_1d0 = &ppuStack_f0;
  FUN_010f9904(alStack_250,lVar9,puVar1,uVar5,0);
  func_0x010f9d70(alStack_250);
  func_0x010f9eac(alStack_250,&UNK_01cbae21,1,*(undefined8 *)(&UNK_00003e38 + lVar20),2);
  uStack_258 = *(undefined8 *)(&UNK_00003e68 + lVar20);
  uVar6 = func_0x01001f54(lVar20,alStack_250[0]);
  puStack_268 = &UNK_01c6ef69;
  uStack_260 = 5;
  FUN_0107cf78(&UNK_00003d08 + lVar20,0x2a);
  uStack_270 = 1;
  uVar21 = 0;
  ppuVar18 = &puStack_268;
  uVar16 = 1;
  iVar19 = 1;
  uVar5 = func_0x01016e84(lVar20,alStack_250[0],uVar6 | 1);
  puVar7 = (undefined8 *)func_0x009d11e8(lVar20 + 0x790,0x30,8);
  *puVar7 = 0;
  uVar3 = *(uint *)(puVar7 + 1);
  *(undefined4 *)((long)puVar7 + 0xc) = 2;
  puVar8 = (undefined2 *)func_0x009d11e8(lVar20 + 0x790,2,1);
  puVar7[2] = puVar8;
  *(undefined4 *)(puVar7 + 3) = 0;
  uVar22 = func_0x009d11e8(lVar20 + 0x790,0,1);
/* more drops soon - github.com/pengussy */
  puVar7[4] = uVar22;
  *(undefined4 *)(puVar7 + 5) = 8;
  *puVar8 = 0x706f;
  *(uint *)(puVar7 + 1) = (uVar3 & 0xfe000000 | 0x400042) + 0xe;
  func_0x00cc857c(uVar5,puVar7);
  uVar6 = 8;
  puVar7 = (undefined8 *)func_0x009d11e8(lVar20 + 0x790,0xc);
  *puVar7 = 0;
  *(uint *)(puVar7 + 1) = *(uint *)(puVar7 + 1) & 0xfe000000 | 0x400042;
  func_0x00cc857c(uVar5);
  if ((puStack_240 != auStack_228) && (puStack_240 != (undefined1 *)0x0)) {
    __ZdaPv();
  }
  if (*(long *)PTR____stack_chk_guard_01f20200 == lStack_218) {
    return alStack_250[0];
  }
  auVar25 = ___stack_chk_fail();
  uVar5 = auVar25._0_8_;
  if (((auVar25._8_4_ != 0) && (uVar5 = func_0x00006858(uVar5), puStack_240 != auStack_228)) &&
     (puStack_240 != (undefined1 *)0x0)) {
    __ZdaPv();
  }
  auVar23 = __Unwind_Resume(uVar5);
  lVar9 = auVar23._8_8_;
  lVar20 = auVar23._0_8_;
  puStack_278 = &DAT_01019340;
  lStack_2d8 = *(long *)PTR____stack_chk_guard_01f20200;
  uVar17 = uVar16;
  ppplStack_280 = (long ***)&pppuStack_1d0;
  uVar3 = func_0x00e915e0(lVar9);
/*  watermarked copy - do not remove  */
  if (uVar3 < 0xd) {
    uVar22 = *(undefined8 *)(&UNK_01e5d678 + (ulong)uVar3 * 8);
    uVar5 = _strlen(uVar22);
    lVar10 = 0;
    if (*(long *)(lVar20 + 0x768) != 0) {
      lVar10 = *(long *)(lVar20 + 0x768) + 0x20;
    }
    FUN_010f9904(alStack_310,lVar10,uVar22,uVar5,0);
    if ((int)uVar6 == 0) {
      unaff_x26 = (undefined *)0x0;
    }
    else {
      unaff_x26 = (undefined *)func_0x010f9908(alStack_310,&UNK_01cbd39d,10,0,0);
    }
    func_0x010f9d70(alStack_310);
    uVar17 = 0;
    func_0x010f9eac(alStack_310,&UNK_01cbae21,1,*(undefined8 *)(&UNK_00003e38 + lVar20));
    lVar10 = alStack_310[0];
    lVar9 = func_0x00e915e0(lVar9);
    puVar7 = (undefined8 *)func_0x009d11e8(lVar20 + 0x790,0x10,8);
    *puVar7 = 0;
    *(uint *)(puVar7 + 1) = *(uint *)(puVar7 + 1) & 0xfe000000 | 0x400062;
    *(int *)((long)puVar7 + 0xc) = (int)lVar9;
    func_0x00cc857c(lVar10);
    lVar10 = alStack_310[0];
    if ((int)uVar6 != 0) {
      uVar6 = *(ulong *)(unaff_x26 + 0x38);
      if (((uVar16 & 1) != 0) || ((int)ppuVar18 != 0)) {
        if ((uVar21 & 1) == 0) {
          func_0x0101adb0(lVar20,alStack_310[0],uVar6,1,0,ppuVar18);
/*
   origin: github.com/pengussy
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
        }
        uVar17 = 1;
        func_0x0101adb0(lVar20,lVar10,uVar6,1,1,ppuVar18);
      }
      lVar9 = lVar10;
      if ((int)ppuVar18 != 0) {
        if ((uVar21 & 1) == 0) {
          func_0x0101adb0(lVar20,lVar10,uVar6,0,0,1);
        }
        uVar17 = 1;
        func_0x0101adb0(lVar20,lVar10,uVar6,0,1,1);
      }
    }
    if (iVar19 == 0) {
      if (puStack_300 != auStack_2e8) goto code_r0x01019534;
    }
    else {
      alStack_310[0] = func_0x010fa000(alStack_310);
      if (puStack_300 != auStack_2e8) {
code_r0x01019534:
        if (puStack_300 != (undefined1 *)0x0) {
          __ZdaPv(puStack_300);
        }
      }
    }
    if (*(long *)PTR____stack_chk_guard_01f20200 == lStack_2d8) {
      return alStack_310[0];
    }
  }
  else {
    alStack_310[0] = func_0x0174ef58(&UNK_01cbaf7d,&UNK_01cb822e,0xfc5);
  }
  uVar5 = ___stack_chk_fail(alStack_310[0]);
  if ((puStack_300 != auStack_2e8) && (puStack_300 != (undefined1 *)0x0)) {
    __ZdaPv();
/* WM: chat: discord.gg/sdkhDjTex @ discord.gg/sdkhDjTex */
  }
  lVar10 = __Unwind_Resume(uVar5);
  puStack_318 = &DAT_010195e0;
  lStack_338 = *(long *)PTR____stack_chk_guard_01f20200;
  lStack_330 = lVar20;
  uStack_328 = uVar5;
  ppppuStack_320 = &ppplStack_280;
  FUN_010f9904(alStack_370);
  cStack_378 = '\0';
  func_0x010f9af0(alStack_370,&UNK_01cbd3a8,6,*(undefined8 *)(&UNK_00003e68 + lVar10),auStack_380);
  if (cStack_378 == '\x01') {
    cStack_378 = '\0';
  }
  if ((uVar17 & 1) == 0) {
    cStack_388 = '\0';
    func_0x010f9af0(alStack_370,&UNK_01c47081,4,*(undefined8 *)(&UNK_00003e68 + lVar10),auStack_390)
    ;
    if (cStack_388 == '\x01') {
      cStack_388 = '\0';
    }
    cStack_398 = '\0';
    func_0x010f9af0(alStack_370,&UNK_01cba4ef,9,*(undefined8 *)(&UNK_00003e68 + lVar10),auStack_3a0)
    ;
    if (cStack_398 == '\x01') {
      cStack_398 = '\0';
    }
  }
  func_0x010f9908(alStack_370,&UNK_01cbd3af,8,0,1);
  func_0x010f9d70(alStack_370);
  puVar7 = (undefined8 *)((long)&MACH_HEADER.magic + 2);
  func_0x010f9eac(alStack_370,&UNK_01cbae21,1,*(undefined8 *)(&UNK_00003e68 + lVar10));
  if ((puStack_360 != auStack_348) && (puStack_360 != (undefined1 *)0x0)) {
    __ZdaPv();
  }
  if (*(long *)PTR____stack_chk_guard_01f20200 == lStack_338) {
    return alStack_370[0];
/* WM: unlicensed copy if this notice is missing @ discord.gg/sdkhDjTex */
  }
  uVar5 = ___stack_chk_fail();
  if (cStack_398 == '\x01') {
    cStack_398 = '\0';
  }
  if ((puStack_360 != auStack_348) && (puStack_360 != (undefined1 *)0x0)) {
    __ZdaPv();
  }
  lVar20 = __Unwind_Resume(uVar5);
  puStack_3a8 = &DAT_010197ac;
  lStack_3c8 = *(long *)PTR____stack_chk_guard_01f20200;
  plStack_3c0 = alStack_370;
  uStack_3b8 = uVar5;
  ppppuStack_3b0 = &ppppuStack_320;
  FUN_010f9904(alStack_400);
  func_0x010f9908(alStack_400,&UNK_01c2efcd,1,0,0);
  cStack_408 = '\0';
  func_0x010f9af0(alStack_400,&UNK_01c953a8,1,*(undefined8 *)(&UNK_00003e68 + lVar20),auStack_410);
  if (cStack_408 == '\x01') {
    cStack_408 = '\0';
  }
  func_0x010f9d70(alStack_400);
  puVar15 = *(undefined8 **)(&UNK_00003e68 + lVar20);
  lVar20 = 1;
  func_0x010f9eac(alStack_400,&UNK_01cbae21,1,puVar15,2);
  uVar5 = func_0x002f78b4(alStack_400);
  *puVar7 = uVar5;
/*  thanks for reading - discord.gg/sdkhDjTex  */
  if ((puStack_3f0 != auStack_3d8) && (puStack_3f0 != (undefined1 *)0x0)) {
    __ZdaPv();
  }
  if (*(long *)PTR____stack_chk_guard_01f20200 == lStack_3c8) {
    return alStack_400[0];
  }
  uVar5 = ___stack_chk_fail();
  if (cStack_408 == '\x01') {
    cStack_408 = '\0';
  }
  if (puStack_3f0 == auStack_3d8 || puStack_3f0 == (undefined1 *)0x0) {
    __Unwind_Resume(uVar5);
  }
  __ZdaPv();
  auVar24 = __Unwind_Resume(uVar5);
  auVar23._8_8_ = uVar16;
  auVar23._0_8_ = puVar15;
  puVar11 = auVar24._8_8_;
  lVar10 = auVar24._0_8_;
  puStack_418 = &DAT_010198f8;
  lStack_478 = *(long *)PTR____stack_chk_guard_01f20200;
  puVar7 = puVar15;
  ppppuStack_420 = &ppppuStack_3b0;
  uVar3 = func_0x00e915e0(puVar11);
  if (uVar3 < 0xd) {
    uVar22 = *(undefined8 *)(&UNK_01e5d678 + (ulong)uVar3 * 8);
    uVar5 = _strlen(uVar22);
    lVar9 = 0;
    if (*(long *)(lVar10 + 0x768) != 0) {
      lVar9 = *(long *)(lVar10 + 0x768) + 0x20;
    }
    FUN_010f9904(auStack_4b0,lVar9,uVar22,uVar5,0);
    if ((int)puVar15 == 0) {
      uVar5 = 0;
    }
/* WM: proprietary - see LICENSE - do not sell @ discord.gg/sdkhDjTex */
    else {
      uVar5 = func_0x010f9908(auStack_4b0,&UNK_01cbd39d,10,0,0);
    }
    func_0x010f9d70(auStack_4b0);
    func_0x010f9eac(auStack_4b0,&UNK_01cbae21,1,*(undefined8 *)(&UNK_00003e38 + lVar10),2);
    uVar22 = auStack_4b0[0];
    uVar4 = func_0x00e915e0(puVar11);
    puVar7 = (undefined8 *)func_0x009d11e8(lVar10 + 0x790,0x10,8);
    unaff_x26 = &UNK_00400042;
    *puVar7 = 0;
    *(uint *)(puVar7 + 1) = *(uint *)(puVar7 + 1) & 0xfe000000 | 0x400062;
    *(undefined4 *)((long)puVar7 + 0xc) = uVar4;
    func_0x00cc857c(uVar22);
    if ((int)puVar15 == 0) {
      lVar9 = *(long *)(lVar20 + 0x38);
      if (lVar9 == 0) {
        lVar9 = func_0x01001d14(lVar10,lVar20);
      }
    }
    else {
      uStack_4c0 = func_0x010025fc(lVar10,0,0,0,uVar5);
      uVar5 = *(undefined8 *)(lVar20 + 0x38);
      puStack_4c8 = (undefined *)CONCAT44(puStack_4c8._4_4_,1);
      uVar21 = *(ulong *)(lVar20 + 0x98) & 0xfffffffffffffffc;
      if ((*(ulong *)(lVar20 + 0x98) & 2) != 0) {
        uVar21 = 0;
      }
/* stripping the watermark breaks the license - github.com/pengussy */
      uVar22 = func_0x01002e4c(lVar10,uVar21);
      lVar9 = func_0x01002a6c(lVar10,uVar22,&puStack_4c8,1,uVar5);
    }
    uStack_4d0 = *(undefined8 *)(&UNK_00003e68 + lVar10);
    puStack_4c8 = &UNK_01c6ef69;
    uStack_4c0 = 5;
    uVar5 = FUN_0107cf78(&UNK_00003d08 + lVar10,0x2a);
    uStack_4e0 = 0;
    puVar7 = &uStack_4d0;
    lVar20 = func_0x01016e84(lVar10,auStack_4b0[0],lVar9,puVar7,1,&puStack_4c8,1,uVar5);
    auVar23 = func_0x013fca18(0xc);
    puVar11 = (undefined8 *)func_0x009d11e8(lVar10 + 0x790,0x30,8);
    *puVar11 = 0;
    uVar3 = *(uint *)(puVar11 + 1);
    uVar6 = auVar23._8_8_ & 0xffffffff;
    *(int *)((long)puVar11 + 0xc) = auVar23._8_4_;
    lVar9 = func_0x009d11e8(lVar10 + 0x790,uVar6,1);
    puVar11[2] = lVar9;
    *(undefined4 *)(puVar11 + 3) = 0;
    uVar5 = func_0x009d11e8(lVar10 + 0x790,0,1);
    puVar11[4] = uVar5;
    *(undefined4 *)(puVar11 + 5) = 0xc;
    if (auVar23._8_8_ != 0) {
      _memcpy(lVar9,auVar23._0_8_,uVar6);
    }
    *(uint *)(puVar11 + 1) = (uVar3 & 0xfe000000 | 0x400042) + 0xe;
    func_0x00cc857c(lVar20,puVar11);
    uVar5 = 8;
/*
 *  donate: donate/README.md
 *
 *  @pengussy
 */
    puVar15 = (undefined8 *)func_0x009d11e8(lVar10 + 0x790,0xc,8);
    *puVar15 = 0;
    *(uint *)(puVar15 + 1) = *(uint *)(puVar15 + 1) & 0xfe000000 | 0x400042;
    func_0x00cc857c(lVar20);
    lVar10 = func_0x010fa000(auStack_4b0);
    if ((puStack_4a0 != auStack_488) && (puStack_4a0 != (undefined1 *)0x0)) {
      __ZdaPv(puStack_4a0);
    }
    if (*(long *)PTR____stack_chk_guard_01f20200 == lStack_478) {
      return lVar10;
    }
  }
  else {
    uVar5 = 0xfc5;
    lVar10 = func_0x0174ef58(&UNK_01cbaf7d,&UNK_01cb822e,0xfc5);
  }
  uVar22 = ___stack_chk_fail(lVar10);
  if ((puStack_4a0 != auStack_488) && (puStack_4a0 != (undefined1 *)0x0)) {
    __ZdaPv();
  }
  auStack_548 = __Unwind_Resume(uVar22);
  uVar14 = auStack_548._8_8_;
  uVar12 = auStack_548._0_8_;
  puStack_4e8 = &DAT_01019c9c;
  lVar10 = puVar7[0x79e];
  uStack_538 = 0;
  puStack_530 = unaff_x26;
  lStack_528 = lVar9;
  uStack_520 = uVar6;
  uStack_518 = auVar23._8_8_;
  puStack_510 = puVar11;
  uStack_508 = auVar23._0_8_;
  lStack_500 = lVar20;
  uStack_4f8 = uVar22;
/* wm:no support for modified copies */
  ppppuStack_4f0 = &ppppuStack_420;
  plVar13 = (long *)func_0x009d248c(lVar10,auStack_548);
  lVar20 = *plVar13;
  lVar9 = *(long *)(lVar20 + 8);
  if (lVar9 == 0) {
    plVar13 = *(long **)(lVar10 + 0xa0);
    if (plVar13 != (long *)0x0) {
      lVar9 = (**(code **)(*plVar13 + 0x10))(plVar13,uVar12,uVar14);
      *(long *)(lVar20 + 8) = lVar9;
      if (lVar9 != 0) goto code_r0x01019d34;
    }
    lVar9 = func_0x009d11e8(lVar10 + 0x18,0x18,8);
    lVar10 = FUN_01650b90();
    *(long *)(lVar20 + 8) = lVar10;
    *(long *)(lVar10 + 0x10) = lVar20;
  }
code_r0x01019d34:
  lVar20 = puVar7[0xed] + 0x20;
  lVar10 = 0;
/* WM - do not claim this as your own */
  if (puVar7[0xed] != 0) {
    lVar10 = lVar20;
  }
  uVar22 = func_0x00ff350c(puVar7,uVar5,0);
  lVar9 = func_0x010721f0(puVar7,lVar10,0,0,lVar9,uVar5,uVar22,1);
  *(uint *)(lVar9 + 0x1c) = *(uint *)(lVar9 + 0x1c) | 0x400;
  func_0x01087d98(lVar20,lVar9);
  return lVar9;
}

