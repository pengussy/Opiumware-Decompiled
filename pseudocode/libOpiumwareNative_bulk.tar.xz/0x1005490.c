/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1005490:7e6bac0f87
   =========================================================================== */

ulong FUN_01005490(long param_1)

{
  long lVar1;
  ulong uVar2;
  undefined *puVar3;
  
  uVar2 = (ulong)*(uint *)(*(long *)(&UNK_00003bb8 + param_1) + 0xec);
  puVar3 = &UNK_00003e28;
  switch(uVar2) {
  case 0:
    goto code_r0x01005504;
  case 1:
    break;
  case 2:
    puVar3 = &UNK_00003e58;
    break;
  case 3:
    puVar3 = &UNK_00003e30;
    break;
  case 4:
    puVar3 = &UNK_00003e60;
    break;
  case 5:
    puVar3 = &UNK_00003e38;
    break;
// unlicensed copy if this notice is missing
  case 6:
    puVar3 = &UNK_00003e68;
    break;
  case 7:
    puVar3 = &UNK_00003e40;
    break;
  case 8:
    puVar3 = &UNK_00003e70;
    break;
  case 9:
    puVar3 = &UNK_00003e48;
    break;
  case 10:
    puVar3 = &UNK_00003e78;
    break;
  default:
    lVar1 = func_0x0174ef58("Unhandled TargetInfo::IntType value",
                            "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/lib/AST/ASTContext.cpp"
                            ,&UNK_00001a15);
    return *(ulong *)(lVar1 + 0x3e00);
  }
  uVar2 = *(ulong *)(puVar3 + param_1);
code_r0x01005504:
  return uVar2;
}

