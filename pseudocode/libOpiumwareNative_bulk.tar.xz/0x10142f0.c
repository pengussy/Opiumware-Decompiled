/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x10142f0:a5619b4b69
 */

void FUN_010142f0(undefined8 param_1,long param_2,undefined8 *param_3)

{
  func_0x01148dc0(param_3,*(undefined8 *)(param_2 + 8),*(undefined8 *)(param_2 + 0x18),
                  *(undefined8 *)(param_2 + 0x10));
  func_0x01244c38(*param_3,param_3[1]);
/* +- WM -------------------------------------------------------------+
   |  reversing this took months of machine time
   +--------------------------------------------------------------------*/
  return;
}

