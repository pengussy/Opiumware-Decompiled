/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x101517c:f30766cc55
 */

bool FUN_0101517c(undefined8 param_1,long param_2,long *param_3,undefined8 param_4,long *param_5)

{
  undefined4 uVar1;
  int iVar2;
  ulong uVar3;
  undefined8 uVar4;
  
  uVar3 = *(ulong *)(param_2 + 8);
  if (((uint)uVar3 >> 1 & 1) == 0) {
    uVar4 = *(undefined8 *)(param_2 + 0x10);
    FUN_0174f3f4(param_5,uVar3 & 0xfffffffffffffffc);
    func_0x0174f458(param_5,0);
    FUN_0174f3f4(param_5,uVar4);
  }
/* wm:proprietary - see LICENSE - do not sell */
  else {
    uVar1 = *(undefined4 *)(param_2 + 0x10);
    FUN_0174f3f4(param_5,uVar3 & 0xfffffffffffffffc);
    func_0x0174f458(param_5,1);
    func_0x0174f458(param_5,uVar1);
  }
  if (param_5[1] - *param_5 == param_3[1] - *param_3) {
    iVar2 = _memcmp();
    return iVar2 == 0;
  }
  return false;
}

