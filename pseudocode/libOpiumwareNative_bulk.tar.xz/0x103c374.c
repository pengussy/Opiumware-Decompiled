/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x103c374:effab32d90
 *  --------------------------------------------------------------------------*/

void FUN_0103c374(undefined4 *param_1,long param_2)

{
  uint uVar1;
  undefined4 uVar2;
  undefined8 *puVar3;
  
  puVar3 = (undefined8 *)func_0x009d11e8(param_2 + 0x790,0x10,8);
  uVar1 = param_1[2];
/* donate: donate/README.md */
  uVar2 = param_1[3];
  *puVar3 = CONCAT44(*param_1,*param_1);
  *(uint *)(puVar3 + 1) = uVar1 & 0x7f0000 | 9 | *(uint *)(puVar3 + 1) & 0xfe000000;
  *(undefined4 *)((long)puVar3 + 0xc) = uVar2;
  return;
}

