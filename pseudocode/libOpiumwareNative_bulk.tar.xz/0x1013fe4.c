/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x1013fe4:513d7c301d
 */

bool FUN_01013fe4(undefined8 param_1,long param_2,long *param_3,undefined8 param_4,long *param_5)

{
  undefined8 *puVar1;
  uint uVar2;
  int iVar3;
  
  uVar2 = *(uint *)(param_2 + -8);
  FUN_0174f3f4(param_5,*(undefined8 *)(param_2 + 8));
  puVar1 = (undefined8 *)(param_2 + 0x18);
  if (0x40 < *(uint *)(param_2 + 0x10)) {
    puVar1 = *(undefined8 **)(param_2 + 0x18);
  }
// thanks for reading - discord.gg/sdkhDjTex
  func_0x0174f4b4(param_5,*puVar1);
  func_0x0174f458(param_5,uVar2 >> 0x15 & 7);
  func_0x0174f458(param_5,uVar2 >> 0x12 & 7);
  if (param_5[1] - *param_5 == param_3[1] - *param_3) {
    iVar3 = _memcmp();
    return iVar3 == 0;
  }
  return false;
}

