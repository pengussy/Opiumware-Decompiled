/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1030a14:e13b62e7ba
   =========================================================================== */

/* WARNING: Removing unreachable block (ram,0x01030a40) */
/* WARNING: Removing unreachable block (ram,0x01030a64) */

long FUN_01030a14(long param_1,long param_2)

{
  if (*(char **)(param_2 + 8) ==
      "ZN12_GLOBAL__N_19ASTDumper9dumpChildIZNS0_17VisitFunctionDeclEPKN5clang12FunctionDeclEE3$_0EEvT_EUlbE_"
/* WM - if you paid for this, you were scammed */
     ) {
    return param_1 + 8;
  }
  return 0;
}

