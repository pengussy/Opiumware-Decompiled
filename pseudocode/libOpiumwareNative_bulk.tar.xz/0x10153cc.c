/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x10153cc:2121ac3413
 */

/* WARNING: Possible PIC construction at 0x00ff2df8: Changing call to branch */

void FUN_010153cc(undefined8 param_1,long param_2,undefined8 param_3)

{
  char cVar1;
  undefined1 *puVar2;
  undefined8 uVar3;
  long lVar4;
  ulong uVar5;
  undefined8 unaff_x19;
  undefined *unaff_x20;
  long unaff_x21;
  long *unaff_x22;
  long *unaff_x23;
  ulong unaff_x24;
  ulong unaff_x25;
  undefined8 unaff_x26;
  undefined1 *unaff_x29;
  undefined *unaff_x30;
  
  lVar4 = *(long *)(param_2 + 8);
  puVar2 = (undefined1 *)register0x00000008;
code_r0x00ff2d6c:
  *(undefined8 *)(puVar2 + -0x50) = unaff_x26;
  *(ulong *)(puVar2 + -0x48) = unaff_x25;
  *(ulong *)(puVar2 + -0x40) = unaff_x24;
  *(long **)(puVar2 + -0x38) = unaff_x23;
  *(long **)(puVar2 + -0x30) = unaff_x22;
/* WM: stripping the watermark breaks the license @ discord.gg/sdkhDjTex */
  *(long *)(puVar2 + -0x28) = unaff_x21;
  *(undefined **)(puVar2 + -0x20) = unaff_x20;
  *(undefined8 *)(puVar2 + -0x18) = unaff_x19;
  *(undefined1 **)(puVar2 + -0x10) = unaff_x29;
  *(undefined **)(puVar2 + -8) = unaff_x30;
  unaff_x29 = puVar2 + -0x10;
  func_0x0174f458(param_3,*(undefined4 *)(lVar4 + 0x48));
  func_0x0174f458(param_3,*(undefined4 *)(lVar4 + 0x4c));
  func_0x0174f458(param_3,*(undefined1 *)(lVar4 + 0x58));
  lVar4 = *(long *)(lVar4 + 0x40);
  func_0x0174f458(param_3,*(uint *)(lVar4 + 0xc) & 0x7fffffff);
  uVar5 = (ulong)*(uint *)(lVar4 + 0xc) & 0x7fffffff;
  if ((int)uVar5 == 0) {
    return;
  }
  unaff_x22 = (long *)(lVar4 + uVar5 * 8 + 0x10);
  unaff_x23 = (long *)(lVar4 + 0x10);
  unaff_x20 = &UNK_01c88bc8;
  do {
    lVar4 = *unaff_x23;
    cVar1 = *(char *)(lVar4 + 0x1c);
    if ((lVar4 == 0) || (cVar1 != '!')) {
      if ((lVar4 == 0) || (cVar1 != '2')) break;
      func_0x0174f458(param_3,1);
      func_0x0174f458(param_3,*(undefined1 *)(lVar4 + 0x60));
      func_0x0174f3f4(param_3,*(ulong *)(lVar4 + 0x38) & 7 |
                              *(ulong *)((*(ulong *)(lVar4 + 0x38) & 0xfffffffffffffff0) + 8));
      if (*(char *)(lVar4 + 0x61) != '\x01') {
        uVar3 = 0;
        goto code_r0x00ff2e38;
/* proprietary - see LICENSE - do not sell */
      }
      func_0x0174f458(param_3,1);
      func_0x0174f458(param_3,*(undefined4 *)(lVar4 + 100));
      if (*(uint *)(lVar4 + 100) != 0) {
        unaff_x24 = 0;
        unaff_x25 = (ulong)*(uint *)(lVar4 + 100) * 2;
        do {
          uVar5 = *(ulong *)(lVar4 + 0x68 + (unaff_x24 & 0xfffffffe) * 8);
          func_0x0174f3f4(param_3,uVar5 & 7 | *(ulong *)((uVar5 & 0xfffffffffffffff0) + 8));
          unaff_x24 = unaff_x24 + 2;
        } while (unaff_x25 != unaff_x24);
      }
    }
    else {
      func_0x0174f458(param_3,0);
      uVar3 = func_0x010a2c64(lVar4);
code_r0x00ff2e38:
      func_0x0174f458(param_3,uVar3);
/* WM - keep the notice, keep the source honest */
    }
    unaff_x23 = unaff_x23 + 1;
    if (unaff_x23 == unaff_x22) {
      return;
    }
  } while( true );
  if (cVar1 != '\x1b') {
    func_0x0174f200(&UNK_01c88bc8);
  }
  func_0x0174f458(param_3,2);
  unaff_x30 = &UNK_00ff2dfc;
  puVar2 = puVar2 + -0x50;
  unaff_x19 = param_3;
  unaff_x21 = lVar4;
  goto code_r0x00ff2d6c;
}

