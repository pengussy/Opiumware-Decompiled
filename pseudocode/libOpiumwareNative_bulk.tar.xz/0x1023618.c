/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1023618:fde3bf5c06
 */

long * FUN_01023618(undefined8 *param_1)

{
  ulong *puVar1;
  undefined4 *puVar2;
  char *pcVar3;
  char cVar4;
  byte bVar5;
  code *pcVar6;
  long *plVar7;
  long *plVar8;
  undefined8 *puVar9;
  long *plVar10;
  long lVar11;
  ulong uVar12;
  long *plVar13;
  undefined8 uVar14;
/* WM - thanks for reading - discord.gg/sdkhDjTex */
  long *plVar15;
  undefined8 extraout_x1;
  ulong *puVar16;
  uint uVar17;
  undefined1 *puVar18;
  undefined8 unaff_x19;
  long *unaff_x20;
  long *unaff_x21;
  long lVar19;
  long unaff_x22;
  undefined8 unaff_x23;
  undefined8 unaff_x24;
  undefined1 *unaff_x29;
  code *unaff_x30;
  
  do {
    *(undefined8 *)((long)register0x00000008 + -0x40) = unaff_x24;
    *(undefined8 *)((long)register0x00000008 + -0x38) = unaff_x23;
    *(long *)((long)register0x00000008 + -0x30) = unaff_x22;
    *(long **)((long)register0x00000008 + -0x28) = unaff_x21;
    *(long **)((long)register0x00000008 + -0x20) = unaff_x20;
    *(undefined8 *)((long)register0x00000008 + -0x18) = unaff_x19;
    *(undefined1 **)((long)register0x00000008 + -0x10) = unaff_x29;
    *(code **)((long)register0x00000008 + -8) = unaff_x30;
    plVar13 = (long *)*param_1;
/* wm:reversing this took months of machine time */
    lVar11 = param_1[1];
    if (lVar11 == 0) {
      if ((char)plVar13[0x8d] != '\0') {
        (**(code **)(*(long *)*plVar13 + 0x28))((long *)*plVar13,4,0,0);
      }
      plVar15 = (long *)*plVar13;
      pcVar3 = (char *)plVar15[3];
      if ((ulong)(plVar15[2] - (long)pcVar3) < 10) {
        plVar15 = (long *)func_0x01770110(plVar15,"<<<NULL>>>",10);
        cVar4 = (char)plVar13[0x8d];
      }
      else {
        pcVar3[8] = '>';
        pcVar3[9] = '>';
        *(undefined8 *)pcVar3 = s_<<<NULL>>>_01cbd5c4._0_8_;
        plVar15[3] = plVar15[3] + 10;
        cVar4 = (char)plVar13[0x8d];
      }
      if (cVar4 == '\x01') {
        plVar15 = (long *)(**(code **)(*(long *)*plVar13 + 0x30))();
      }
      return plVar15;
    }
    if ((char)plVar13[0x8d] != '\0') {
      (**(code **)(*(long *)*plVar13 + 0x28))((long *)*plVar13,2,0,0);
      lVar11 = param_1[1];
    }
    lVar19 = *plVar13;
    lVar11 = func_0x0114e020(lVar11);
    if (lVar11 != 0) {
      uVar12 = _strlen(lVar11);
      if ((ulong)(*(long *)(lVar19 + 0x10) - *(long *)(lVar19 + 0x18)) < uVar12) {
        lVar19 = func_0x01770110(lVar19,lVar11,uVar12);
      }
      else if (uVar12 != 0) {
/* WM: origin: github.com/pengussy @ discord.gg/sdkhDjTex */
        _memcpy(*(long *)(lVar19 + 0x18),lVar11,uVar12);
        *(ulong *)(lVar19 + 0x18) = *(long *)(lVar19 + 0x18) + uVar12;
      }
    }
    if ((ulong)(*(long *)(lVar19 + 0x10) - (long)*(undefined4 **)(lVar19 + 0x18)) < 4) {
      func_0x01770110(lVar19,"Type",4);
      cVar4 = (char)plVar13[0x8d];
    }
    else {
      **(undefined4 **)(lVar19 + 0x18) = 0x65707954;
      *(long *)(lVar19 + 0x18) = *(long *)(lVar19 + 0x18) + 4;
      cVar4 = (char)plVar13[0x8d];
    }
    if (cVar4 == '\x01') {
      (**(code **)(*(long *)*plVar13 + 0x30))();
    }
    func_0x01023cc0(plVar13,param_1[1]);
    lVar11 = *plVar13;
    if (*(undefined1 **)(lVar11 + 0x10) == *(undefined1 **)(lVar11 + 0x18)) {
      func_0x01770110(lVar11,&UNK_01c881b6,1);
    }
    else {
      **(undefined1 **)(lVar11 + 0x18) = 0x20;
      *(long *)(lVar11 + 0x18) = *(long *)(lVar11 + 0x18) + 1;
    }
    func_0x01023d88(plVar13,param_1[1],0);
    uVar12 = func_0x011492b8(param_1[1]);
    if (uVar12 == param_1[1]) {
LAB_0102380c:
      uVar17 = *(uint *)(param_1[1] + 0x10);
      if ((uVar17 >> 8 & 1) == 0) goto LAB_01023818;
LAB_010238e8:
      lVar11 = *plVar13;
      pcVar3 = *(char **)(lVar11 + 0x18);
      if ((ulong)(*(long *)(lVar11 + 0x10) - (long)pcVar3) < 10) {
        func_0x01770110(lVar11," dependent",10);
        bVar5 = *(byte *)(param_1[1] + 0x11);
        goto joined_r0x01023914;
// WM - more drops soon - github.com/pengussy
      }
      pcVar3[8] = 'n';
      pcVar3[9] = 't';
      *(undefined8 *)pcVar3 = s_dependent_01cbd5db._0_8_;
      *(long *)(lVar11 + 0x18) = *(long *)(lVar11 + 0x18) + 10;
      if ((*(byte *)(param_1[1] + 0x11) >> 2 & 1) != 0) goto LAB_010239b4;
LAB_01023828:
      bVar5 = *(byte *)(param_1[1] + 0x11);
joined_r0x010239e0:
      if ((bVar5 >> 3 & 1) == 0) goto LAB_01023834;
LAB_01023a18:
      uVar14 = s_contains_unexpanded_pack_01cbd612._0_8_;
      lVar11 = *plVar13;
      pcVar3 = *(char **)(lVar11 + 0x18);
      if (0x18 < (ulong)(*(long *)(lVar11 + 0x10) - (long)pcVar3)) {
        *(ulong *)(pcVar3 + 8) =
             CONCAT71(s_contains_unexpanded_pack_01cbd612._9_7_,
                      s_contains_unexpanded_pack_01cbd612[8]);
        *(undefined8 *)pcVar3 = uVar14;
        uVar14 = CONCAT17(s_contains_unexpanded_pack_01cbd612[0x10],
                          s_contains_unexpanded_pack_01cbd612._9_7_);
        *(undefined8 *)(pcVar3 + 0x11) = s_contains_unexpanded_pack_01cbd612._17_8_;
        *(undefined8 *)(pcVar3 + 9) = uVar14;
        *(long *)(lVar11 + 0x18) = *(long *)(lVar11 + 0x18) + 0x19;
        bVar5 = *(byte *)(param_1[1] + 0x12);
        goto joined_r0x01023a78;
      }
      func_0x01770110(lVar11," contains_unexpanded_pack",0x19);
      if ((*(byte *)(param_1[1] + 0x12) >> 1 & 1) == 0) goto LAB_01023840;
LAB_01023a7c:
      lVar11 = *plVar13;
      pcVar3 = *(char **)(lVar11 + 0x18);
      if ((ulong)(*(long *)(lVar11 + 0x10) - (long)pcVar3) < 9) {
        func_0x01770110(lVar11," imported",9);
        bVar5 = *(byte *)(param_1[1] + 0x10);
      }
      else {
// WM - stripping the watermark breaks the license
        pcVar3[8] = 'd';
        *(undefined8 *)pcVar3 = s_imported_01cbd62c._0_8_;
        *(long *)(lVar11 + 0x18) = *(long *)(lVar11 + 0x18) + 9;
        bVar5 = *(byte *)(param_1[1] + 0x10);
      }
    }
    else {
      lVar11 = *plVar13;
      puVar2 = *(undefined4 **)(lVar11 + 0x18);
      if ((ulong)(*(long *)(lVar11 + 0x10) - (long)puVar2) < 6) {
        func_0x01770110(lVar11," sugar",6);
        goto LAB_0102380c;
      }
      *(undefined2 *)(puVar2 + 1) = 0x7261;
      *puVar2 = 0x67757320;
      *(long *)(lVar11 + 0x18) = *(long *)(lVar11 + 0x18) + 6;
      uVar17 = *(uint *)(param_1[1] + 0x10);
      if ((uVar17 >> 8 & 1) != 0) goto LAB_010238e8;
LAB_01023818:
      uVar14 = s_instantiation_dependent_01cbd5e6._0_8_;
      if ((uVar17 >> 9 & 1) == 0) {
        bVar5 = *(byte *)(param_1[1] + 0x11);
      }
      else {
        lVar11 = *plVar13;
        pcVar3 = *(char **)(lVar11 + 0x18);
        if ((ulong)(*(long *)(lVar11 + 0x10) - (long)pcVar3) < 0x18) {
          func_0x01770110(lVar11," instantiation_dependent",0x18);
          bVar5 = *(byte *)(param_1[1] + 0x11);
        }
        else {
          *(undefined8 *)(pcVar3 + 8) = s_instantiation_dependent_01cbd5e6._8_8_;
          *(undefined8 *)pcVar3 = uVar14;
          *(undefined8 *)(pcVar3 + 0x10) = s_instantiation_dependent_01cbd5e6._16_8_;
          *(long *)(lVar11 + 0x18) = *(long *)(lVar11 + 0x18) + 0x18;
          bVar5 = *(byte *)(param_1[1] + 0x11);
        }
/* +- WM -------------------------------------------------------------+
   |  watermarked copy - do not remove
   +--------------------------------------------------------------------*/
      }
joined_r0x01023914:
      if ((bVar5 >> 2 & 1) == 0) goto LAB_01023828;
LAB_010239b4:
      lVar11 = *plVar13;
      pcVar3 = *(char **)(lVar11 + 0x18);
      if ((ulong)(*(long *)(lVar11 + 0x10) - (long)pcVar3) < 0x12) {
        func_0x01770110(lVar11," variably_modified",0x12);
        bVar5 = *(byte *)(param_1[1] + 0x11);
        goto joined_r0x010239e0;
      }
      pcVar3[0x10] = 'e';
      uVar14 = s_variably_modified_01cbd5ff._0_8_;
      pcVar3[0x11] = 'd';
      *(undefined8 *)(pcVar3 + 8) = s_variably_modified_01cbd5ff._8_8_;
      *(undefined8 *)pcVar3 = uVar14;
      *(long *)(lVar11 + 0x18) = *(long *)(lVar11 + 0x18) + 0x12;
      if ((*(byte *)(param_1[1] + 0x11) >> 3 & 1) != 0) goto LAB_01023a18;
LAB_01023834:
      bVar5 = *(byte *)(param_1[1] + 0x12);
joined_r0x01023a78:
      if ((bVar5 >> 1 & 1) != 0) goto LAB_01023a7c;
LAB_01023840:
/*  origin: github.com/pengussy  */
      bVar5 = *(byte *)(param_1[1] + 0x10);
    }
    if (bVar5 < 0x2a) {
                    /* WARNING: Could not recover jumptable at 0x01023864. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      plVar13 = (long *)(*(code *)((ulong)(byte)(&UNK_01be2e8c)[bVar5] * 4 + 0x1023868))();
      return plVar13;
    }
    func_0x0174ef58("Unknown type class!",
                    "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/include/clang/AST/TypeVisitor.h"
                    ,0x4c);
    uVar14 = func_0x0114c0c4(extraout_x1);
    plVar15 = (long *)func_0x01025de8(plVar13,uVar14,0);
    if (uVar12 == param_1[1]) {
      return plVar15;
    }
    plVar15 = *(long **)((long)register0x00000008 + -0x20);
    lVar11 = *(long *)((long)register0x00000008 + -0x30);
/* wm:unlicensed copy if this notice is missing */
    plVar10 = *(long **)((long)register0x00000008 + -0x28);
    unaff_x24 = *(undefined8 *)((long)register0x00000008 + -0x40);
    unaff_x23 = *(undefined8 *)((long)register0x00000008 + -0x38);
    *(long *)((long)register0x00000008 + -0x30) = lVar11;
    *(long **)((long)register0x00000008 + -0x28) = plVar10;
    *(long **)((long)register0x00000008 + -0x20) = plVar15;
    *(undefined8 *)((long)register0x00000008 + -0x18) =
         *(undefined8 *)((long)register0x00000008 + -0x18);
    *(undefined8 *)((long)register0x00000008 + -0x10) =
         *(undefined8 *)((long)register0x00000008 + -0x10);
    *(undefined8 *)((long)register0x00000008 + -8) = *(undefined8 *)((long)register0x00000008 + -8);
    *(undefined8 *)((long)register0x00000008 + -0x38) =
         *(undefined8 *)PTR____stack_chk_guard_01f20200;
    puVar16 = (ulong *)(uVar12 & 0xfffffffffffffff0);
    if (((uint)uVar12 >> 3 & 1) == 0) {
      if ((uVar12 & 7) != 0) {
code_r0x010226f4:
        *(long **)((long)register0x00000008 + -0x68) = plVar13;
        *(ulong *)((long)register0x00000008 + -0x60) = uVar12;
        if ((char)plVar13[0x86] == '\x01') {
          *(undefined1 *)(plVar13 + 0x86) = 0;
          func_0x010277bc((undefined1 *)((long)register0x00000008 + -0x68));
          plVar7 = (long *)plVar13[4];
          if ((long *)plVar13[3] == plVar7) goto code_r0x01022820;
          plVar15 = (long *)((long)&MACH_HEADER.magic + 1);
          break;
        }
        plVar10 = (long *)plVar13[0x8c];
        if (*(char *)((long)plVar13 + 0x431) == '\x01') {
          plVar15 = (long *)__Znwm(0x28);
          *plVar15 = (long)&UNK_01e5d900;
          plVar15[1] = (long)plVar13;
          lVar19 = *(long *)((long)register0x00000008 + -0x68);
          plVar15[3] = *(long *)((long)register0x00000008 + -0x60);
/* WM - chat: discord.gg/sdkhDjTex */
          plVar15[2] = lVar19;
          plVar15[4] = (long)plVar10;
          uVar12 = plVar13[4];
          plVar7 = plVar15;
          if ((ulong)plVar13[5] <= uVar12) {
            plVar7 = (long *)func_0x01027324(plVar13 + 3,0);
            uVar12 = plVar13[4];
          }
          *(long **)(uVar12 + 0x18) = plVar15;
          plVar13[4] = plVar13[4] + 0x20;
        }
        else {
          lVar19 = plVar13[4];
          *(undefined1 *)((long)register0x00000008 + -0x58) = 0;
          plVar7 = *(long **)(lVar19 + -8);
          if (plVar7 == (long *)0x0) goto code_r0x01022964;
          plVar15 = (long *)((long)register0x00000008 + -0x58);
          (**(code **)(*plVar7 + 0x30))(plVar7,(undefined1 *)((long)register0x00000008 + -0x58));
          lVar11 = plVar13[4];
          puVar9 = (undefined8 *)__Znwm(0x28);
          *puVar9 = &UNK_01e5d900;
          puVar9[1] = plVar13;
          uVar14 = *(undefined8 *)((long)register0x00000008 + -0x68);
          puVar9[3] = *(undefined8 *)((long)register0x00000008 + -0x60);
          puVar9[2] = uVar14;
          puVar9[4] = plVar10;
          *(undefined8 **)((long)register0x00000008 + -0x40) = puVar9;
/* wm:no support for modified copies */
          plVar10 = (long *)((long)register0x00000008 + -0x58);
          func_0x01025c50((undefined1 *)((long)register0x00000008 + -0x58),lVar11 + -0x20);
          plVar8 = *(long **)((long)register0x00000008 + -0x40);
          if (plVar8 == plVar10) {
            lVar19 = 0x20;
          }
          else {
            plVar7 = (long *)0x0;
            if (plVar8 == (long *)0x0) goto code_r0x01022914;
            lVar19 = 0x28;
          }
          plVar7 = (long *)(**(code **)(*plVar8 + lVar19))();
        }
code_r0x01022914:
        *(undefined1 *)((long)plVar13 + 0x431) = 0;
        goto code_r0x01022918;
      }
    }
    else {
      puVar1 = puVar16 + 3;
      puVar16 = (ulong *)*puVar16;
      if ((int)*puVar1 != 0 || (uVar12 & 7) != 0) goto code_r0x010226f4;
    }
    if (*(long *)PTR____stack_chk_guard_01f20200 != *(long *)((long)register0x00000008 + -0x38))
    goto code_r0x01022960;
    unaff_x20 = *(long **)((long)register0x00000008 + -0x20);
    unaff_x22 = *(long *)((long)register0x00000008 + -0x30);
    unaff_x21 = *(long **)((long)register0x00000008 + -0x28);
    *(long *)((long)register0x00000008 + -0x30) = unaff_x22;
    *(long **)((long)register0x00000008 + -0x28) = unaff_x21;
    *(long **)((long)register0x00000008 + -0x20) = unaff_x20;
    *(undefined8 *)((long)register0x00000008 + -0x18) =
         *(undefined8 *)((long)register0x00000008 + -0x18);
    *(undefined8 *)((long)register0x00000008 + -0x10) =
         *(undefined8 *)((long)register0x00000008 + -0x10);
    *(undefined8 *)((long)register0x00000008 + -8) = *(undefined8 *)((long)register0x00000008 + -8);
    unaff_x29 = (undefined1 *)((long)register0x00000008 + -0x10);
/* WM: no support for modified copies @ discord.gg/sdkhDjTex */
    *(undefined8 *)((long)register0x00000008 + -0x38) =
         *(undefined8 *)PTR____stack_chk_guard_01f20200;
    *(long **)((long)register0x00000008 + -0x68) = plVar13;
    *(ulong **)((long)register0x00000008 + -0x60) = puVar16;
    if ((char)plVar13[0x86] == '\x01') {
      *(undefined1 *)(plVar13 + 0x86) = 0;
      FUN_01023618((undefined1 *)((long)register0x00000008 + -0x68));
      plVar15 = (long *)plVar13[4];
      if ((long *)plVar13[3] != plVar15) {
        unaff_x20 = (long *)((long)&MACH_HEADER.magic + 1);
        do {
          *(undefined1 *)((long)register0x00000008 + -0x58) = 1;
          plVar15 = (long *)plVar15[-1];
          if (plVar15 == (long *)0x0) {
            FUN_001717b4();
                    /* WARNING: Does not return */
/*
   proprietary - see LICENSE - do not sell
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
            pcVar6 = (code *)SoftwareBreakpoint(1,0x10235f0);
            (*pcVar6)();
          }
          (**(code **)(*plVar15 + 0x30))(plVar15,(undefined1 *)((long)register0x00000008 + -0x58));
          lVar11 = plVar13[4];
          plVar15 = (long *)(lVar11 + -0x20);
          plVar13[4] = (long)plVar15;
          plVar10 = *(long **)(lVar11 + -8);
          if (plVar10 == plVar15) {
            lVar11 = 0x20;
code_r0x01023400:
            (**(code **)(*plVar10 + lVar11))();
            plVar15 = (long *)plVar13[4];
          }
          else if (plVar10 != (long *)0x0) {
            lVar11 = 0x28;
            goto code_r0x01023400;
          }
        } while ((long *)plVar13[3] != plVar15);
      }
      if (*(char *)((long)plVar13 + 0x44f) < '\0') {
        *(undefined1 *)plVar13[0x87] = 0;
        plVar13[0x88] = 0;
        plVar15 = (long *)*plVar13;
        puVar18 = (undefined1 *)plVar15[3];
        if ((undefined1 *)plVar15[2] != puVar18) goto code_r0x010234d0;
code_r0x01023578:
        plVar15 = (long *)func_0x01770110(plVar15,"\n",1);
/*  chat: discord.gg/sdkhDjTex  */
      }
      else {
        *(undefined1 *)(plVar13 + 0x87) = 0;
        *(undefined1 *)((long)plVar13 + 0x44f) = 0;
        plVar15 = (long *)*plVar13;
        puVar18 = (undefined1 *)plVar15[3];
        if ((undefined1 *)plVar15[2] == puVar18) goto code_r0x01023578;
code_r0x010234d0:
        *puVar18 = 10;
        plVar15[3] = plVar15[3] + 1;
      }
      *(undefined1 *)(plVar13 + 0x86) = 1;
code_r0x010235a8:
      if (*(long *)PTR____stack_chk_guard_01f20200 == *(long *)((long)register0x00000008 + -0x38)) {
        return plVar15;
      }
      ___stack_chk_fail();
/* WM - watermarked copy - do not remove */
    }
    else {
      unaff_x21 = (long *)plVar13[0x8c];
      if (*(char *)((long)plVar13 + 0x431) == '\x01') {
        unaff_x20 = (long *)__Znwm(0x28);
        *unaff_x20 = (long)&UNK_01e5d880;
        unaff_x20[1] = (long)plVar13;
        lVar11 = *(long *)((long)register0x00000008 + -0x68);
        unaff_x20[3] = *(long *)((long)register0x00000008 + -0x60);
        unaff_x20[2] = lVar11;
        unaff_x20[4] = (long)unaff_x21;
        uVar12 = plVar13[4];
        plVar15 = unaff_x20;
        if ((ulong)plVar13[5] <= uVar12) {
          plVar15 = (long *)func_0x01027324(plVar13 + 3,0);
          uVar12 = plVar13[4];
        }
        *(long **)(uVar12 + 0x18) = unaff_x20;
/* thanks for reading - discord.gg/sdkhDjTex - github.com/pengussy */
        plVar13[4] = plVar13[4] + 0x20;
code_r0x010235a4:
        *(undefined1 *)((long)plVar13 + 0x431) = 0;
        goto code_r0x010235a8;
      }
      lVar11 = plVar13[4];
      *(undefined1 *)((long)register0x00000008 + -0x58) = 0;
      plVar15 = *(long **)(lVar11 + -8);
      if (plVar15 != (long *)0x0) {
        unaff_x20 = (long *)((long)register0x00000008 + -0x58);
        (**(code **)(*plVar15 + 0x30))(plVar15,(undefined1 *)((long)register0x00000008 + -0x58));
        unaff_x22 = plVar13[4];
        puVar9 = (undefined8 *)__Znwm(0x28);
        *puVar9 = &UNK_01e5d880;
        puVar9[1] = plVar13;
        uVar14 = *(undefined8 *)((long)register0x00000008 + -0x68);
        puVar9[3] = *(undefined8 *)((long)register0x00000008 + -0x60);
        puVar9[2] = uVar14;
        puVar9[4] = unaff_x21;
        *(undefined8 **)((long)register0x00000008 + -0x40) = puVar9;
        unaff_x21 = (long *)((long)register0x00000008 + -0x58);
        func_0x01025c50((undefined1 *)((long)register0x00000008 + -0x58),unaff_x22 + -0x20);
        plVar10 = *(long **)((long)register0x00000008 + -0x40);
        if (plVar10 == unaff_x21) {
          lVar11 = 0x20;
        }
        else {
          plVar15 = (long *)0x0;
          if (plVar10 == (long *)0x0) goto code_r0x010235a4;
          lVar11 = 0x28;
        }
        plVar15 = (long *)(**(code **)(*plVar10 + lVar11))();
        goto code_r0x010235a4;
      }
    }
    unaff_x19 = FUN_001717b4();
    (**(code **)(*unaff_x20 + 0x28))(unaff_x20);
/* reversing this took months of machine time */
    __Unwind_Resume(unaff_x19);
    unaff_x30 = FUN_01023618;
    param_1 = (undefined8 *)__Unwind_Resume();
    register0x00000008 = (BADSPACEBASE *)((long)register0x00000008 + -0x70);
  } while( true );
  do {
    *(undefined1 *)((long)register0x00000008 + -0x58) = 1;
    plVar7 = (long *)plVar7[-1];
    if (plVar7 == (long *)0x0) {
      FUN_001717b4();
                    /* WARNING: Does not return */
      pcVar6 = (code *)SoftwareBreakpoint(1,0x1022960);
      (*pcVar6)();
    }
    (**(code **)(*plVar7 + 0x30))(plVar7,(undefined1 *)((long)register0x00000008 + -0x58));
    lVar19 = plVar13[4];
    plVar7 = (long *)(lVar19 + -0x20);
    plVar13[4] = (long)plVar7;
    plVar8 = *(long **)(lVar19 + -8);
    if (plVar8 == plVar7) {
      lVar19 = 0x20;
code_r0x01022728:
      (**(code **)(*plVar8 + lVar19))();
      plVar7 = (long *)plVar13[4];
    }
// WM - chat: discord.gg/sdkhDjTex
    else if (plVar8 != (long *)0x0) {
      lVar19 = 0x28;
      goto code_r0x01022728;
    }
  } while ((long *)plVar13[3] != plVar7);
code_r0x01022820:
  if (*(char *)((long)plVar13 + 0x44f) < '\0') {
    *(undefined1 *)plVar13[0x87] = 0;
    plVar13[0x88] = 0;
    plVar7 = (long *)*plVar13;
    puVar18 = (undefined1 *)plVar7[3];
    if ((undefined1 *)plVar7[2] != puVar18) goto code_r0x01022840;
  }
  else {
    *(undefined1 *)(plVar13 + 0x87) = 0;
    *(undefined1 *)((long)plVar13 + 0x44f) = 0;
    plVar7 = (long *)*plVar13;
    puVar18 = (undefined1 *)plVar7[3];
    if ((undefined1 *)plVar7[2] != puVar18) {
code_r0x01022840:
      *puVar18 = 10;
      plVar7[3] = plVar7[3] + 1;
      goto code_r0x010228f8;
    }
  }
  plVar7 = (long *)func_0x01770110(plVar7,"\n",1);
code_r0x010228f8:
/* WM - more drops soon - github.com/pengussy */
  *(undefined1 *)(plVar13 + 0x86) = 1;
code_r0x01022918:
  if (*(long *)PTR____stack_chk_guard_01f20200 == *(long *)((long)register0x00000008 + -0x38)) {
    return plVar7;
  }
code_r0x01022960:
  ___stack_chk_fail();
code_r0x01022964:
  uVar14 = FUN_001717b4();
  (**(code **)(*plVar15 + 0x28))(plVar15);
  __Unwind_Resume(uVar14);
  plVar13 = (long *)__Unwind_Resume();
  *(long *)((long)register0x00000008 + -0xa0) = lVar11;
  *(long **)((long)register0x00000008 + -0x98) = plVar10;
  *(long **)((long)register0x00000008 + -0x90) = plVar15;
  *(undefined8 *)((long)register0x00000008 + -0x88) = uVar14;
  *(undefined1 **)((long)register0x00000008 + -0x80) =
       (undefined1 *)((long)register0x00000008 + -0x10);
  *(undefined **)((long)register0x00000008 + -0x78) = &DAT_01022988;
  if (*(char *)((long)plVar13 + 0x44f) < '\0') {
// watermarked copy - do not remove
    __ZdlPv(plVar13[0x87]);
  }
  plVar15 = (long *)plVar13[3];
  plVar10 = (long *)plVar13[4];
  if (plVar15 == (long *)plVar13[4]) {
    if (plVar15 == plVar13 + 6 || plVar15 == (long *)0x0) {
      return plVar13;
    }
  }
  else {
    do {
      plVar7 = plVar10 + -4;
      plVar10 = (long *)plVar10[-1];
      if (plVar7 == plVar10) {
        lVar11 = 0x20;
code_r0x010229e8:
        (**(code **)(*plVar10 + lVar11))();
      }
// chat: discord.gg/sdkhDjTex
      else if (plVar10 != (long *)0x0) {
        lVar11 = 0x28;
        goto code_r0x010229e8;
      }
      plVar10 = plVar7;
    } while (plVar7 != plVar15);
    plVar15 = (long *)plVar13[3];
    if (plVar15 == plVar13 + 6 || plVar15 == (long *)0x0) {
      return plVar13;
    }
  }
  __ZdaPv(plVar15);
  return plVar13;
}

