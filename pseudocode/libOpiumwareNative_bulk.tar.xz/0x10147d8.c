/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x10147d8:3e03a1efe6
   =========================================================================== */

/* WARNING: Possible PIC construction at 0x010147f8: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x010147fc) */

void FUN_010147d8(undefined8 param_1,long param_2,long *param_3)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  
  uVar1 = *(undefined8 *)(param_2 + 8);
  puVar2 = (undefined8 *)param_3[1];
/* +- WM -------------------------------------------------------------+
   |  reversing this took months of machine time
   +--------------------------------------------------------------------*/
  if ((ulong)(param_3[2] - (long)puVar2) < 8) {
    func_0x01755374(param_3,param_3 + 3,(long)puVar2 + (8 - *param_3) & 0xfffffffffffffffc,4);
    puVar2 = (undefined8 *)param_3[1];
  }
  *puVar2 = uVar1;
  param_3[1] = param_3[1] + 8;
  return;
}

