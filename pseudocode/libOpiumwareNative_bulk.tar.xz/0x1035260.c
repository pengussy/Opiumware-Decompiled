/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x1035260:4616a0bab3
 */

undefined * FUN_01035260(void)

{
  return &UNK_01e5e0d0;
/* more drops soon - github.com/pengussy */
}

