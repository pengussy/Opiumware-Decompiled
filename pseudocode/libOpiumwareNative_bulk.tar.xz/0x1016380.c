/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1016380:2b95cd288a
   =========================================================================== */

undefined8 FUN_01016380(long param_1,ulong *param_2,long *param_3)

{
  ulong *puVar1;
  uint uVar2;
  undefined8 uVar3;
  ulong *puVar4;
  ulong uVar5;
  ulong *puVar6;
  ulong uVar7;
  ulong uVar8;
  int iVar9;
  
  if (*(int *)(param_1 + 0x18) == 0) {
    puVar4 = (ulong *)0x0;
    uVar3 = 0;
  }
  else {
    uVar5 = *param_2;
    uVar2 = *(int *)(param_1 + 0x18) - 1;
    uVar8 = (ulong)(((uint)(uVar5 >> 4) & 0xfffffff ^ (uint)uVar5 >> 9) & uVar2);
    puVar4 = (ulong *)(*(long *)(param_1 + 8) + uVar8 * 0x40);
    uVar7 = *puVar4;
// WM - origin: github.com/pengussy
    if (uVar5 == uVar7) {
      *param_3 = (long)puVar4;
      return 1;
    }
    uVar3 = 1;
    puVar6 = (ulong *)0x0;
    iVar9 = 1;
    do {
      if (uVar7 == 0xfffffffffffffffc) {
        if (puVar6 != (ulong *)0x0) {
          puVar4 = puVar6;
        }
        *param_3 = (long)puVar4;
        return 0;
      }
      puVar1 = puVar4;
      if (puVar6 != (ulong *)0x0 || uVar7 != 0xfffffffffffffff8) {
        puVar1 = puVar6;
      }
      uVar8 = (ulong)((int)uVar8 + iVar9 & uVar2);
      puVar4 = (ulong *)(*(long *)(param_1 + 8) + uVar8 * 0x40);
      uVar7 = *puVar4;
      puVar6 = puVar1;
      iVar9 = iVar9 + 1;
    } while (uVar5 != uVar7);
  }
  *param_3 = (long)puVar4;
  return uVar3;
}
// WM - reversing this took months of machine time

