/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x1032870:8dd381f245
 */

void FUN_01032870(undefined8 *param_1,ulong *param_2)

{
  ulong *puVar1;
  uint uVar2;
  undefined1 auStack_288 [296];
  uint uStack_160;
  undefined1 auStack_158 [296];
  
  puVar1 = (ulong *)(*param_2 & 0xfffffffffffffff0);
  uVar2 = (uint)*param_2;
  if ((uVar2 >> 3 & 1) == 0) {
    uVar2 = uVar2 & 7;
  }
  else {
    uVar2 = (uint)puVar1[3] | uVar2 & 7;
/*  origin: github.com/pengussy  */
    puVar1 = (ulong *)*puVar1;
  }
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  func_0x0165c248(auStack_158);
  func_0x009d1be0(auStack_288,auStack_158);
  uStack_160 = uStack_160 & 0xf0000000 | 0xa48202;
  func_0x011568d0(puVar1,uVar2,param_1,auStack_288);
  func_0x009d1f0c(auStack_288);
  func_0x009d1f0c(auStack_158);
  return;
}

