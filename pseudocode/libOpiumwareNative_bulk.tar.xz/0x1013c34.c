/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1013c34:5e347bd7c6
 */

bool FUN_01013c34(undefined8 param_1,long param_2,long *param_3,undefined8 param_4,long *param_5)

{
  undefined8 uVar1;
  int iVar2;
  
  uVar1 = *(undefined8 *)(param_2 + 0x10);
  func_0x0174f3f4(param_5,*(undefined8 *)(param_2 + 8));
  func_0x0174f3f4(param_5,uVar1);
/*  more drops soon - github.com/pengussy  */
  if (param_5[1] - *param_5 == param_3[1] - *param_3) {
    iVar2 = _memcmp();
    return iVar2 == 0;
  }
  return false;
}

