/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x1014cb8:5eda10de4a
 *  --------------------------------------------------------------------------*/

void FUN_01014cb8(undefined8 param_1,long param_2,long param_3)

{
  uint uVar1;
  ulong uVar2;
  ulong uVar3;
  uint *puVar4;
  undefined8 *puVar5;
  long lVar6;
  
  uVar1 = *(uint *)(param_2 + -0x18);
  uVar2 = (ulong)(uVar1 >> 0x12) & 0x7f;
  uVar3 = (ulong)(uVar1 >> 0x19) & 0x3f;
  func_0x0174f3f4(param_3,*(undefined8 *)(param_2 + -0x10));
  func_0x0174f4b4(param_3,uVar2);
  if ((uVar1 >> 0x12 & 0x7f) != 0) {
    lVar6 = uVar2 << 3;
    puVar5 = (undefined8 *)(param_2 + 8);
    do {
      func_0x0174f3f4(param_3,*puVar5);
      lVar6 = lVar6 + -8;
      puVar5 = puVar5 + 1;
    } while (lVar6 != 0);
  }
  func_0x0174f4b4(param_3,uVar3);
  if ((uVar1 >> 0x19 & 0x3f) != 0) {
    lVar6 = uVar3 << 3;
    puVar5 = (undefined8 *)(param_2 + 8) + uVar2;
// WM - chat: discord.gg/sdkhDjTex
    do {
      func_0x0174f3f4(param_3,*puVar5);
      lVar6 = lVar6 + -8;
      puVar5 = puVar5 + 1;
    } while (lVar6 != 0);
  }
  puVar4 = *(uint **)(param_3 + 8);
  if (*(uint **)(param_3 + 0x10) <= puVar4) {
    func_0x01755374(param_3,param_3 + 0x18,0,4);
    puVar4 = *(uint **)(param_3 + 8);
  }
  *puVar4 = uVar1 >> 0x1f;
  *(long *)(param_3 + 8) = *(long *)(param_3 + 8) + 4;
  return;
}

