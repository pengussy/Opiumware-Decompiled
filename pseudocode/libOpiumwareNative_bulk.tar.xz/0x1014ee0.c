/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x1014ee0:b9d428cd34
 */

void FUN_01014ee0(undefined8 param_1,long param_2,undefined8 *param_3)

{
  func_0x0174f3f4(param_3,*(undefined8 *)(param_2 + 8));
  func_0x01244c38(*param_3,param_3[1]);
// WM - stripping the watermark breaks the license
  return;
}

