/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x1037850:357d7d47cd
 *  --------------------------------------------------------------------------*/

/* WARNING: Removing unreachable block (ram,0x01023ebc) */

void FUN_01037850(long *param_1,long param_2)

{
  ulong uVar1;
  undefined8 *puVar2;
  char cVar3;
  undefined8 *****pppppuVar4;
  ulong uVar5;
  long lVar6;
  undefined1 *puVar7;
  uint uVar8;
  long lVar9;
  long lVar10;
  ulong *puVar11;
  undefined1 auVar12 [16];
  undefined8 *****pppppuStack_68;
  ulong uStack_60;
  byte bStack_51;
  
  func_0x01039528();
  if ((((uint)*(ulong *)(param_2 + 0x10) >> 1 & 1) == 0) ||
     (lVar9 = *(long *)((*(ulong *)(param_2 + 0x10) & 0xfffffffffffffffc) + 8), lVar9 == 0)) {
    return;
  }
  lVar6 = *param_1;
  puVar2 = *(undefined8 **)(lVar6 + 0x18);
  if ((ulong)(*(long *)(lVar6 + 0x10) - (long)puVar2) < 0xd) {
    func_0x01770110(lVar6," extended by ",0xd);
  }
/* WM - proprietary - see LICENSE - do not sell */
  else {
    *puVar2 = CONCAT35(s_extended_by_01cbefdc._5_3_,s_extended_by_01cbefdc._0_5_);
    *(ulong *)((long)puVar2 + 5) =
         CONCAT53(s_extended_by_01cbefdc._8_5_,s_extended_by_01cbefdc._5_3_);
    *(long *)(lVar6 + 0x18) = *(long *)(lVar6 + 0x18) + 0xd;
  }
  if ((char)param_1[0x8d] == '\x01') {
    (**(code **)(*(long *)*param_1 + 0x28))((long *)*param_1,2,1,0);
  }
  lVar10 = *param_1;
  lVar6 = func_0x0107d974(lVar9);
  if (lVar6 != 0) {
    uVar5 = _strlen(lVar6);
    if ((ulong)(*(long *)(lVar10 + 0x10) - *(long *)(lVar10 + 0x18)) < uVar5) {
      func_0x01770110(lVar10,lVar6,uVar5);
    }
    else if (uVar5 != 0) {
      _memcpy(*(long *)(lVar10 + 0x18),lVar6,uVar5);
      *(ulong *)(lVar10 + 0x18) = *(long *)(lVar10 + 0x18) + uVar5;
    }
  }
  if ((char)param_1[0x8d] == '\x01') {
    (**(code **)(*(long *)*param_1 + 0x30))();
  }
  func_0x01023cc0(param_1,lVar9);
  if ((lVar9 != 0) && (0xffffffcf < *(byte *)(lVar9 + 0x1c) - 0x3b)) {
    if ((char)param_1[0x8d] == '\x01') {
      (**(code **)(*(long *)*param_1 + 0x28))((long *)*param_1,6,1,0);
    }
    lVar6 = *param_1;
    if ((ulong)(*(long *)(lVar6 + 0x10) - (long)*(undefined2 **)(lVar6 + 0x18)) < 2) {
      lVar6 = func_0x01770110(lVar6,&UNK_01caa47b,2);
    }
/* WM: if you paid for this, you were scammed @ discord.gg/sdkhDjTex */
    else {
      **(undefined2 **)(lVar6 + 0x18) = 0x2720;
      *(long *)(lVar6 + 0x18) = *(long *)(lVar6 + 0x18) + 2;
    }
    lVar6 = func_0x0107c2a8(lVar6,*(undefined8 *)(lVar9 + 0x20));
    puVar7 = *(undefined1 **)(lVar6 + 0x18);
    if (puVar7 < *(undefined1 **)(lVar6 + 0x10)) {
      *(undefined1 **)(lVar6 + 0x18) = puVar7 + 1;
      *puVar7 = 0x27;
    }
    else {
      func_0x01771098(lVar6,0x27);
    }
    if ((char)param_1[0x8d] == '\x01') {
      (**(code **)(*(long *)*param_1 + 0x30))();
    }
  }
  if ((lVar9 == 0) || (*(byte *)(lVar9 + 0x1c) - 0x3b < 0xffffffee)) {
    return;
  }
  uVar5 = *(ulong *)(lVar9 + 0x38);
  lVar9 = *param_1;
  puVar7 = *(undefined1 **)(lVar9 + 0x18);
  if (puVar7 < *(undefined1 **)(lVar9 + 0x10)) {
    *(undefined1 **)(lVar9 + 0x18) = puVar7 + 1;
    *puVar7 = 0x20;
  }
  else {
/* wm:no support for modified copies */
    func_0x01771098(lVar9,0x20);
  }
  if ((char)param_1[0x8d] == '\x01') {
    (**(code **)(*(long *)*param_1 + 0x28))((long *)*param_1,2,0,0);
  }
  puVar11 = (ulong *)(uVar5 & 0xfffffffffffffff0);
  uVar8 = (uint)uVar5;
  if ((uVar8 >> 3 & 1) == 0) {
    uVar8 = uVar8 & 7;
    lVar9 = *param_1;
    puVar7 = *(undefined1 **)(lVar9 + 0x18);
    if (*(undefined1 **)(lVar9 + 0x10) == puVar7) goto code_r0x01023e2c;
code_r0x01023df4:
    *puVar7 = 0x27;
    *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 1;
  }
  else {
    uVar8 = (uint)puVar11[3] | uVar8 & 7;
/* WM - keep the notice, keep the source honest */
    puVar11 = (ulong *)*puVar11;
    lVar9 = *param_1;
    puVar7 = *(undefined1 **)(lVar9 + 0x18);
    if (*(undefined1 **)(lVar9 + 0x10) != puVar7) goto code_r0x01023df4;
code_r0x01023e2c:
    lVar9 = func_0x01770110(lVar9,&UNK_01c2dfe0,1);
  }
  func_0x01156814(&pppppuStack_68,puVar11,uVar8);
  uVar1 = uStack_60;
  pppppuVar4 = pppppuStack_68;
  if (-1 < (char)bStack_51) {
    uVar1 = (ulong)bStack_51;
    pppppuVar4 = &pppppuStack_68;
  }
  lVar9 = func_0x01770110(lVar9,pppppuVar4,uVar1);
  if (*(undefined1 **)(lVar9 + 0x10) == *(undefined1 **)(lVar9 + 0x18)) {
    func_0x01770110(lVar9,&UNK_01c2dfe0,1);
  }
  else {
/* WM - do not claim this as your own */
    **(undefined1 **)(lVar9 + 0x18) = 0x27;
    *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 1;
  }
  if ((char)bStack_51 < '\0') {
    __ZdlPv(pppppuStack_68);
  }
  if (0xf < uVar5) {
    auVar12 = func_0x011490c8(uVar5);
    if ((puVar11 != auVar12._0_8_) || (uVar8 != auVar12._8_4_)) {
      lVar9 = *param_1;
      if ((ulong)(*(long *)(lVar9 + 0x10) - (long)*(undefined2 **)(lVar9 + 0x18)) < 2) {
        lVar9 = func_0x01770110(lVar9,&UNK_01cbd636,2);
      }
      else {
        **(undefined2 **)(lVar9 + 0x18) = 0x273a;
        *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 2;
      }
      func_0x01156814(&pppppuStack_68,auVar12._0_8_,auVar12._8_8_ & 0xffffffff);
      pppppuVar4 = pppppuStack_68;
      if (-1 < (char)bStack_51) {
        uStack_60 = (ulong)bStack_51;
        pppppuVar4 = &pppppuStack_68;
      }
      lVar9 = func_0x01770110(lVar9,pppppuVar4,uStack_60);
      if (*(undefined1 **)(lVar9 + 0x10) == *(undefined1 **)(lVar9 + 0x18)) {
        func_0x01770110(lVar9,&UNK_01c2dfe0,1);
      }
      else {
        **(undefined1 **)(lVar9 + 0x18) = 0x27;
        *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 1;
      }
      if ((char)bStack_51 < '\0') {
        __ZdlPv(pppppuStack_68);
        cVar3 = (char)param_1[0x8d];
        goto joined_r0x01023fb0;
      }
    }
  }
// WM - no support for modified copies
  cVar3 = (char)param_1[0x8d];
joined_r0x01023fb0:
  if (cVar3 == '\x01') {
    (**(code **)(*(long *)*param_1 + 0x30))();
  }
  return;
}

