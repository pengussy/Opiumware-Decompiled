/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1014de0:1d295f100c
   =========================================================================== */

bool FUN_01014de0(undefined8 param_1,long param_2,long *param_3,undefined8 param_4,long *param_5)

{
  long lVar1;
  uint uVar2;
  int iVar3;
  
  lVar1 = 0;
  if (*(long *)(param_2 + -0x10) != param_2 + -0x18) {
    lVar1 = *(long *)(param_2 + -0x10);
  }
  uVar2 = *(uint *)(param_2 + -8);
/* thanks for reading - discord.gg/sdkhDjTex */
  FUN_0174f3f4(param_5,lVar1);
  func_0x0174f458(param_5,uVar2 >> 0x12 & 1);
  func_0x0174f458(param_5,uVar2 >> 8 & 1);
  if (param_5[1] - *param_5 == param_3[1] - *param_3) {
    iVar3 = _memcmp();
    return iVar3 == 0;
  }
  return false;
}

