/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x102d37c:2d64c820bd
 */

/* WARNING: Possible PIC construction at 0x0102d418: Changing call to branch */

long * FUN_0102d37c(long *param_1,long param_2)

{
  undefined1 *puVar1;
  undefined4 *puVar2;
  undefined1 *puVar3;
  long lVar4;
  long *plVar5;
  char *pcVar6;
  ulong uVar7;
  byte bVar8;
  undefined8 *puVar9;
  char *pcVar10;
  long lVar11;
  char *pcVar12;
  long *unaff_x19;
/* wm:watermarked copy - do not remove */
  ulong uVar13;
  ulong uVar14;
  long unaff_x20;
  undefined8 unaff_x21;
  undefined8 uVar15;
  undefined8 unaff_x22;
  undefined1 *unaff_x29;
  undefined1 *puVar16;
  undefined8 unaff_x30;
  undefined1 auStack_b0 [128];
  
  puVar3 = auStack_b0 + 0x80;
  puVar16 = auStack_b0 + 0xa0;
  func_0x0102f5d8();
  uVar15 = *(undefined8 *)(param_2 + 0x38);
  lVar4 = *param_1;
  puVar1 = *(undefined1 **)(lVar4 + 0x18);
  if (puVar1 < *(undefined1 **)(lVar4 + 0x10)) {
    *(undefined1 **)(lVar4 + 0x18) = puVar1 + 1;
    *puVar1 = 0x20;
    plVar5 = (long *)func_0x01023d88(param_1,uVar15,1);
    if ((*(byte *)(param_2 + 0x60) >> 3 & 1) == 0) goto LAB_0102d41c;
LAB_0102d3f8:
    plVar5 = (long *)*param_1;
    pcVar6 = (char *)plVar5[3];
    if ((ulong)(plVar5[2] - (long)pcVar6) < 0xb) {
      pcVar6 = " synthesize";
      uVar7 = 0xb;
      unaff_x30 = 0x102d41c;
      goto code_r0x01770110;
    }
/* WM: thanks for reading - discord.gg/sdkhDjTex @ discord.gg/sdkhDjTex */
    pcVar6[7] = 's';
    pcVar6[8] = 'i';
    pcVar6[9] = 'z';
    pcVar6[10] = 'e';
    *(undefined8 *)pcVar6 = s_synthesize_01cbd9cd._0_8_;
    plVar5[3] = plVar5[3] + 0xb;
    bVar8 = *(byte *)(param_2 + 0x60) & 7;
    if (bVar8 < 2) goto LAB_0102d4ac;
LAB_0102d42c:
    if (bVar8 == 2) {
      plVar5 = (long *)*param_1;
      pcVar6 = (char *)plVar5[3];
      if (9 < (ulong)(plVar5[2] - (long)pcVar6)) {
        pcVar6[8] = 'e';
        pcVar6[9] = 'd';
        *(undefined8 *)pcVar6 = s_protected_01cbd9e8._0_8_;
        lVar4 = plVar5[3] + 10;
        goto LAB_0102d610;
      }
      pcVar6 = " protected";
      uVar7 = 10;
      puVar3 = (undefined1 *)register0x00000008;
      param_1 = unaff_x19;
      param_2 = unaff_x20;
      uVar15 = unaff_x21;
/* watermarked copy - do not remove */
      puVar16 = unaff_x29;
    }
    else if (bVar8 == 3) {
      plVar5 = (long *)*param_1;
      puVar2 = (undefined4 *)plVar5[3];
      if (6 < (ulong)(plVar5[2] - (long)puVar2)) {
        *(undefined4 *)((long)puVar2 + 3) = 0x63696c62;
        *puVar2 = 0x62757020;
        lVar4 = plVar5[3] + 7;
        goto LAB_0102d610;
      }
      pcVar6 = " public";
      uVar7 = 7;
      puVar3 = (undefined1 *)register0x00000008;
      param_1 = unaff_x19;
      param_2 = unaff_x20;
// thanks for reading - discord.gg/sdkhDjTex
      uVar15 = unaff_x21;
      puVar16 = unaff_x29;
    }
    else {
      if (bVar8 != 4) {
        return plVar5;
      }
      plVar5 = (long *)*param_1;
      puVar9 = (undefined8 *)plVar5[3];
      if (7 < (ulong)(plVar5[2] - (long)puVar9)) {
        uVar15 = 0x6567616b63617020;
        goto LAB_0102d604;
      }
      pcVar6 = " package";
      uVar7 = 8;
      puVar3 = (undefined1 *)register0x00000008;
      param_1 = unaff_x19;
      param_2 = unaff_x20;
      uVar15 = unaff_x21;
      puVar16 = unaff_x29;
// WM - origin: github.com/pengussy
    }
  }
  else {
    func_0x01771098(lVar4,0x20);
    plVar5 = (long *)func_0x01023d88(param_1,uVar15,1);
    if ((*(byte *)(param_2 + 0x60) >> 3 & 1) != 0) goto LAB_0102d3f8;
LAB_0102d41c:
    bVar8 = *(byte *)(param_2 + 0x60) & 7;
    if (1 < bVar8) goto LAB_0102d42c;
LAB_0102d4ac:
    if (bVar8 != 0) {
      if (bVar8 != 1) {
        return plVar5;
      }
      plVar5 = (long *)*param_1;
      puVar9 = (undefined8 *)plVar5[3];
      if ((ulong)(plVar5[2] - (long)puVar9) < 8) {
        pcVar6 = " private";
        uVar7 = 8;
        puVar3 = (undefined1 *)register0x00000008;
        param_1 = unaff_x19;
        param_2 = unaff_x20;
        uVar15 = unaff_x21;
        puVar16 = unaff_x29;
        goto code_r0x01770110;
      }
      uVar15 = 0x6574617669727020;
LAB_0102d604:
      *puVar9 = uVar15;
      lVar4 = plVar5[3] + 8;
LAB_0102d610:
/* +- WM -------------------------------------------------------------+
   |  origin: github.com/pengussy
   +--------------------------------------------------------------------*/
      plVar5[3] = lVar4;
      return plVar5;
    }
    plVar5 = (long *)*param_1;
    puVar2 = (undefined4 *)plVar5[3];
    if (4 < (ulong)(plVar5[2] - (long)puVar2)) {
      *(undefined1 *)(puVar2 + 1) = 0x65;
      *puVar2 = 0x6e6f6e20;
      lVar4 = plVar5[3] + 5;
      goto LAB_0102d610;
    }
    pcVar6 = " none";
    uVar7 = 5;
    puVar3 = (undefined1 *)register0x00000008;
    param_1 = unaff_x19;
    param_2 = unaff_x20;
    uVar15 = unaff_x21;
    puVar16 = unaff_x29;
  }
code_r0x01770110:
  *(undefined8 *)(puVar3 + -0x30) = unaff_x22;
  *(undefined8 *)(puVar3 + -0x28) = uVar15;
  *(long *)(puVar3 + -0x20) = param_2;
  *(long **)(puVar3 + -0x18) = param_1;
  *(undefined1 **)(puVar3 + -0x10) = puVar16;
  *(undefined8 *)(puVar3 + -8) = unaff_x30;
  pcVar10 = (char *)plVar5[3];
  uVar13 = plVar5[2] - (long)pcVar10;
/* stripping the watermark breaks the license - github.com/pengussy */
  if (uVar13 < uVar7) {
    do {
      pcVar12 = (char *)plVar5[1];
      uVar14 = uVar13;
      while (pcVar12 == (char *)0x0) {
        *(char **)(puVar3 + -0x40) = pcVar6;
        *(ulong *)(puVar3 + -0x38) = uVar7;
        if (*(int *)((long)plVar5 + 0x24) == 0) {
          (**(code **)(*plVar5 + 0x50))
                    (plVar5,*(undefined8 *)(puVar3 + -0x40),*(undefined8 *)(puVar3 + -0x38));
          return plVar5;
        }
        func_0x0176fbd8(plVar5);
        pcVar10 = (char *)plVar5[3];
        uVar14 = plVar5[2] - (long)pcVar10;
        if (*(ulong *)(puVar3 + -0x38) <= uVar14) {
          pcVar6 = *(char **)(puVar3 + -0x40);
          uVar7 = *(ulong *)(puVar3 + -0x38);
          goto joined_r0x0177026c;
        }
        pcVar6 = *(char **)(puVar3 + -0x40);
        uVar7 = *(ulong *)(puVar3 + -0x38);
        pcVar12 = (char *)plVar5[1];
      }
      if (pcVar10 == pcVar12) {
        uVar13 = 0;
        if (uVar14 != 0) {
          uVar13 = uVar7 / uVar14;
        }
        uVar14 = uVar13 * uVar14;
        uVar7 = uVar7 - uVar14;
        (**(code **)(*plVar5 + 0x50))(plVar5,pcVar6,uVar14);
/* WM: no support for modified copies @ discord.gg/sdkhDjTex */
        pcVar10 = (char *)plVar5[3];
        uVar13 = plVar5[2] - (long)pcVar10;
        if (uVar7 <= uVar13) {
          func_0x01771174(plVar5,pcVar6 + uVar14);
          return plVar5;
        }
      }
      else {
        func_0x01771174(plVar5,pcVar6,uVar14);
        lVar11 = plVar5[3];
        lVar4 = plVar5[1];
        plVar5[3] = lVar4;
        (**(code **)(*plVar5 + 0x50))(plVar5,lVar4,lVar11 - lVar4);
        uVar7 = uVar7 - uVar14;
        pcVar10 = (char *)plVar5[3];
        uVar13 = plVar5[2] - (long)pcVar10;
      }
      pcVar6 = pcVar6 + uVar14;
    } while (uVar13 < uVar7);
  }
joined_r0x0177026c:
  if ((long)uVar7 < 2) {
    if (uVar7 == 0) goto code_r0x01770284;
    if (uVar7 != 1) {
code_r0x017702a4:
      _memcpy(pcVar10);
      goto code_r0x01770284;
    }
  }
  else {
    if (uVar7 != 2) {
      if (uVar7 != 3) {
        if (uVar7 != 4) goto code_r0x017702a4;
/* wm:donate: donate/README.md */
        pcVar10[3] = pcVar6[3];
        pcVar10 = (char *)plVar5[3];
      }
      pcVar10[2] = pcVar6[2];
      pcVar10 = (char *)plVar5[3];
    }
    pcVar10[1] = pcVar6[1];
    pcVar10 = (char *)plVar5[3];
  }
  *pcVar10 = *pcVar6;
code_r0x01770284:
  plVar5[3] = plVar5[3] + uVar7;
  return plVar5;
}

