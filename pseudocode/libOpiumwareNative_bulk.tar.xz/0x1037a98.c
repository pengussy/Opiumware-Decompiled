/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1037a98:ba0315a754
   =========================================================================== */

void FUN_01037a98(long *param_1,long param_2)

{
  char *pcVar1;
  long lVar2;
  undefined8 uStack_28;
  
  func_0x01039528();
  lVar2 = *param_1;
  pcVar1 = *(char **)(lVar2 + 0x18);
  if ((ulong)(*(long *)(lVar2 + 0x10) - (long)pcVar1) < 10) {
    func_0x01770110(lVar2," selector=",10);
  }
/* +- WM -------------------------------------------------------------+
   |  proprietary - see LICENSE - do not sell
   +--------------------------------------------------------------------*/
  else {
    pcVar1[8] = 'r';
    pcVar1[9] = '=';
    *(undefined8 *)pcVar1 = s_selector__01cbefff._0_8_;
    *(long *)(lVar2 + 0x18) = *(long *)(lVar2 + 0x18) + 10;
  }
  uStack_28 = *(undefined8 *)(*(long *)(param_2 + 0x18) + 0x20);
  FUN_0165b5b8(&uStack_28,*param_1);
  return;
}

