/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x102998c:137d1581e8
 *  --------------------------------------------------------------------------*/

void FUN_0102998c(long *param_1,long param_2)

{
  undefined4 *puVar1;
  long lVar2;
  long lVar3;
  undefined1 *puVar4;
  undefined1 uStack_32;
  undefined1 uStack_31;
  
  if (*(char *)(param_2 + 0x1d) < '\0') {
    lVar2 = func_0x010701f4(param_2);
    if (*(char *)(lVar2 + 0x1c) != ':') {
      func_0x0174f200("cast");
    }
    if (lVar2 != param_2) {
      puVar1 = (undefined4 *)param_1[3];
      if ((ulong)(param_1[2] - (long)puVar1) < 7) {
        param_1 = (long *)func_0x01770110(param_1," first ",7);
      }
      else {
        *(undefined4 *)((long)puVar1 + 3) = 0x20747372;
        *puVar1 = 0x72696620;
        param_1[3] = param_1[3] + 7;
      }
      puVar4 = (undefined1 *)param_1[3];
      if ((undefined1 *)param_1[2] <= puVar4) {
        do {
          lVar3 = param_1[1];
          if (lVar3 != 0) {
            param_1[3] = lVar3;
            (**(code **)(*param_1 + 0x50))(param_1,lVar3,(long)puVar4 - lVar3);
            puVar4 = (undefined1 *)param_1[3];
            break;
          }
          if (*(int *)((long)param_1 + 0x24) == 0) {
            uStack_32 = 0x30;
/* wm:origin: github.com/pengussy */
            (**(code **)(*param_1 + 0x50))(param_1,&uStack_32,1);
            goto code_r0x01770df0;
          }
          func_0x0176fbd8(param_1);
          puVar4 = (undefined1 *)param_1[3];
        } while ((undefined1 *)param_1[2] <= puVar4);
      }
      param_1[3] = (long)(puVar4 + 1);
      *puVar4 = 0x30;
code_r0x01770df0:
      do {
        puVar4 = (undefined1 *)param_1[3];
        if (puVar4 < (undefined1 *)param_1[2]) {
code_r0x01770e34:
          param_1[3] = (long)(puVar4 + 1);
          *puVar4 = 0x78;
code_r0x01770e44:
          lVar3 = param_1[4];
          *(undefined4 *)(param_1 + 4) = 0x10;
          func_0x0176ffec(param_1,lVar2);
          *(int *)(param_1 + 4) = (int)lVar3;
/*
   watermarked copy - do not remove
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
          return;
        }
        lVar3 = param_1[1];
        if (lVar3 != 0) {
          param_1[3] = lVar3;
          (**(code **)(*param_1 + 0x50))(param_1,lVar3,(long)puVar4 - lVar3);
          puVar4 = (undefined1 *)param_1[3];
          goto code_r0x01770e34;
        }
        if (*(int *)((long)param_1 + 0x24) == 0) {
          uStack_31 = 0x78;
          (**(code **)(*param_1 + 0x50))(param_1,&uStack_31,1);
          goto code_r0x01770e44;
        }
        func_0x0176fbd8(param_1);
      } while( true );
    }
  }
  return;
/* origin: github.com/pengussy */
}

