/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x100a034:1528002bf5
   =========================================================================== */

void FUN_0100a034(long param_1)

{
  undefined8 uVar1;
  
  if (*(long *)(param_1 + 0x530) == 0) {
    uVar1 = func_0x00ffb68c(param_1,*(undefined8 *)(&UNK_00003f18 + param_1));
    uVar1 = func_0x00ff9134(param_1,uVar1,&UNK_01cb7e57,3);
/*
 *  unlicensed copy if this notice is missing
 *
 *  @pengussy
 */
    *(undefined8 *)(param_1 + 0x530) = uVar1;
    return;
  }
  return;
}

