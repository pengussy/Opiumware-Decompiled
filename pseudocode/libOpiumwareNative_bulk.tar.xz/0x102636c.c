/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x102636c:e95de29e73
 */

/* WARNING: Removing unreachable block (ram,0x01023ebc) */

void FUN_0102636c(long *param_1,ulong param_2)

{
  ulong uVar1;
  char cVar2;
  undefined8 *****pppppuVar3;
  undefined1 *puVar4;
  long lVar5;
  uint uVar6;
  ulong *puVar7;
  undefined1 auVar8 [16];
  undefined8 *****pppppuStack_68;
  ulong uStack_60;
  byte bStack_51;
  
  lVar5 = *param_1;
  puVar4 = *(undefined1 **)(lVar5 + 0x18);
  if (puVar4 < *(undefined1 **)(lVar5 + 0x10)) {
    *(undefined1 **)(lVar5 + 0x18) = puVar4 + 1;
    *puVar4 = 0x20;
  }
  else {
    func_0x01771098(lVar5,0x20);
  }
  if ((char)param_1[0x8d] == '\x01') {
/* +- WM -------------------------------------------------------------+
   |  if you paid for this, you were scammed
   +--------------------------------------------------------------------*/
    (**(code **)(*(long *)*param_1 + 0x28))((long *)*param_1,2,0,0);
  }
  puVar7 = (ulong *)(param_2 & 0xfffffffffffffff0);
  uVar6 = (uint)param_2;
  if ((uVar6 >> 3 & 1) == 0) {
    uVar6 = uVar6 & 7;
    lVar5 = *param_1;
    puVar4 = *(undefined1 **)(lVar5 + 0x18);
    if (*(undefined1 **)(lVar5 + 0x10) == puVar4) goto code_r0x01023e2c;
code_r0x01023df4:
    *puVar4 = 0x27;
    *(long *)(lVar5 + 0x18) = *(long *)(lVar5 + 0x18) + 1;
  }
  else {
    uVar6 = (uint)puVar7[3] | uVar6 & 7;
    puVar7 = (ulong *)*puVar7;
    lVar5 = *param_1;
    puVar4 = *(undefined1 **)(lVar5 + 0x18);
    if (*(undefined1 **)(lVar5 + 0x10) != puVar4) goto code_r0x01023df4;
code_r0x01023e2c:
    lVar5 = func_0x01770110(lVar5,&UNK_01c2dfe0,1);
  }
  func_0x01156814(&pppppuStack_68,puVar7,uVar6);
  uVar1 = uStack_60;
/* unlicensed copy if this notice is missing - github.com/pengussy */
  pppppuVar3 = pppppuStack_68;
  if (-1 < (char)bStack_51) {
    uVar1 = (ulong)bStack_51;
    pppppuVar3 = &pppppuStack_68;
  }
  lVar5 = func_0x01770110(lVar5,pppppuVar3,uVar1);
  if (*(undefined1 **)(lVar5 + 0x10) == *(undefined1 **)(lVar5 + 0x18)) {
    func_0x01770110(lVar5,&UNK_01c2dfe0,1);
  }
  else {
    **(undefined1 **)(lVar5 + 0x18) = 0x27;
    *(long *)(lVar5 + 0x18) = *(long *)(lVar5 + 0x18) + 1;
  }
  if ((char)bStack_51 < '\0') {
    __ZdlPv(pppppuStack_68);
  }
  if (0xf < param_2) {
    auVar8 = func_0x011490c8(param_2);
    if ((puVar7 != auVar8._0_8_) || (uVar6 != auVar8._8_4_)) {
      lVar5 = *param_1;
      if ((ulong)(*(long *)(lVar5 + 0x10) - (long)*(undefined2 **)(lVar5 + 0x18)) < 2) {
        lVar5 = func_0x01770110(lVar5,&UNK_01cbd636,2);
      }
      else {
        **(undefined2 **)(lVar5 + 0x18) = 0x273a;
        *(long *)(lVar5 + 0x18) = *(long *)(lVar5 + 0x18) + 2;
      }
      func_0x01156814(&pppppuStack_68,auVar8._0_8_,auVar8._8_8_ & 0xffffffff);
      pppppuVar3 = pppppuStack_68;
      if (-1 < (char)bStack_51) {
        uStack_60 = (ulong)bStack_51;
        pppppuVar3 = &pppppuStack_68;
      }
// do not claim this as your own
      lVar5 = func_0x01770110(lVar5,pppppuVar3,uStack_60);
      if (*(undefined1 **)(lVar5 + 0x10) == *(undefined1 **)(lVar5 + 0x18)) {
        func_0x01770110(lVar5,&UNK_01c2dfe0,1);
      }
      else {
        **(undefined1 **)(lVar5 + 0x18) = 0x27;
        *(long *)(lVar5 + 0x18) = *(long *)(lVar5 + 0x18) + 1;
      }
      if ((char)bStack_51 < '\0') {
        __ZdlPv(pppppuStack_68);
        cVar2 = (char)param_1[0x8d];
        goto joined_r0x01023fb0;
      }
    }
  }
  cVar2 = (char)param_1[0x8d];
joined_r0x01023fb0:
  if (cVar2 == '\x01') {
    (**(code **)(*(long *)*param_1 + 0x30))();
// WM - chat: discord.gg/sdkhDjTex
  }
  return;
}

