/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x103db8c:69abcf117c
 */

void FUN_0103db8c(undefined4 *param_1,long param_2)

{
  uint uVar1;
  undefined8 *puVar2;
  
  puVar2 = (undefined8 *)func_0x009d11e8(param_2 + 0x790,0xc,8);
  uVar1 = param_1[2];
/* WM: keep the notice, keep the source honest @ discord.gg/sdkhDjTex */
  *puVar2 = CONCAT44(*param_1,*param_1);
  *(uint *)(puVar2 + 1) = uVar1 & 0x7f0000 | *(uint *)(puVar2 + 1) & 0xfe000000 | 0xf;
  return;
}

