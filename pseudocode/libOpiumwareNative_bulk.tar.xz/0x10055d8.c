/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x10055d8:e96e7ef803
 */

/* WARNING: Possible PIC construction at 0x010056e8: Changing call to branch */
/* WARNING: Possible PIC construction at 0x010016ac: Changing call to branch */
/* WARNING: Possible PIC construction at 0x010058f8: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01001474: Changing call to branch */
/* WARNING: Possible PIC construction at 0x010007dc: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01001210: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x010007e0) */
/* WARNING: Removing unreachable block (ram,0x0100081c) */
/* WARNING: Removing unreachable block (ram,0x010007ec) */
/* WARNING: Removing unreachable block (ram,0x010007fc) */
/* WARNING: Removing unreachable block (ram,0x01000808) */
/* WARNING: Removing unreachable block (ram,0x01000820) */
/* WARNING: Removing unreachable block (ram,0x01001478) */
/* WARNING: Removing unreachable block (ram,0x010014b4) */
/* WARNING: Removing unreachable block (ram,0x01001484) */
/* WARNING: Removing unreachable block (ram,0x01001494) */
/* WARNING: Removing unreachable block (ram,0x010014a0) */
/* WARNING: Removing unreachable block (ram,0x010014b8) */
/* WARNING: Removing unreachable block (ram,0x010058fc) */
/* WARNING: Removing unreachable block (ram,0x01005924) */
/* WARNING: Removing unreachable block (ram,0x0100597c) */
/* WARNING: Removing unreachable block (ram,0x010059f8) */
/* WARNING: Removing unreachable block (ram,0x0100118c) */
/* found on a paste site? it was re-uploaded illegally - github.com/pengussy */
/* WARNING: Removing unreachable block (ram,0x010011d0) */
/* WARNING: Removing unreachable block (ram,0x010011e8) */
/* WARNING: Removing unreachable block (ram,0x01001218) */
/* WARNING: Removing unreachable block (ram,0x01001248) */
/* WARNING: Removing unreachable block (ram,0x01001258) */
/* WARNING: Removing unreachable block (ram,0x01001264) */
/* WARNING: Removing unreachable block (ram,0x010011f8) */
/* WARNING: Removing unreachable block (ram,0x010011e0) */
/* WARNING: Removing unreachable block (ram,0x01005984) */
/* WARNING: Removing unreachable block (ram,0x01005944) */
/* WARNING: Removing unreachable block (ram,0x010059cc) */
/* WARNING: Removing unreachable block (ram,0x01000600) */
/* WARNING: Removing unreachable block (ram,0x01000660) */
/* WARNING: Removing unreachable block (ram,0x01000644) */
/* WARNING: Removing unreachable block (ram,0x0100067c) */
/* WARNING: Removing unreachable block (ram,0x0100069c) */
/* WARNING: Removing unreachable block (ram,0x010006ac) */
/* WARNING: Removing unreachable block (ram,0x010006b0) */
/* WARNING: Removing unreachable block (ram,0x0100065c) */
/* WARNING: Removing unreachable block (ram,0x010006c4) */
/* WARNING: Removing unreachable block (ram,0x010006c8) */
/* WARNING: Removing unreachable block (ram,0x010006e0) */
/* WARNING: Removing unreachable block (ram,0x010006e8) */
/* WARNING: Removing unreachable block (ram,0x010006ec) */
/* WARNING: Removing unreachable block (ram,0x01000730) */
/* WARNING: Removing unreachable block (ram,0x01000784) */
/* WARNING: Removing unreachable block (ram,0x01000794) */
/* WARNING: Removing unreachable block (ram,0x010007a4) */
/* WARNING: Removing unreachable block (ram,0x010007bc) */
/* WARNING: Removing unreachable block (ram,0x010007b4) */
/* WARNING: Removing unreachable block (ram,0x010007cc) */
/* WARNING: Removing unreachable block (ram,0x0100079c) */
/* WARNING: Removing unreachable block (ram,0x01000830) */
/* WARNING: Removing unreachable block (ram,0x01000850) */
/* +- WM -------------------------------------------------------------+
   |  chat: discord.gg/sdkhDjTex
   +--------------------------------------------------------------------*/
/* WARNING: Removing unreachable block (ram,0x01000864) */
/* WARNING: Removing unreachable block (ram,0x010008b8) */
/* WARNING: Removing unreachable block (ram,0x010008ac) */
/* WARNING: Removing unreachable block (ram,0x010008c0) */
/* WARNING: Removing unreachable block (ram,0x0100093c) */
/* WARNING: Removing unreachable block (ram,0x010008dc) */
/* WARNING: Removing unreachable block (ram,0x01000770) */
/* WARNING: Removing unreachable block (ram,0x010008f8) */
/* WARNING: Removing unreachable block (ram,0x010008fc) */
/* WARNING: Removing unreachable block (ram,0x01000780) */
/* WARNING: Removing unreachable block (ram,0x01000900) */
/* WARNING: Removing unreachable block (ram,0x0100090c) */
/* WARNING: Removing unreachable block (ram,0x01000914) */
/* WARNING: Removing unreachable block (ram,0x01000918) */
/* WARNING: Removing unreachable block (ram,0x0100594c) */
/* WARNING: Removing unreachable block (ram,0x0100598c) */
/* WARNING: Removing unreachable block (ram,0x0100599c) */
/* WARNING: Removing unreachable block (ram,0x01000eac) */
/* WARNING: Removing unreachable block (ram,0x01000f04) */
/* WARNING: Removing unreachable block (ram,0x010010fc) */
/*
   unlicensed copy if this notice is missing
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
/* WARNING: Removing unreachable block (ram,0x01000f44) */
/* WARNING: Removing unreachable block (ram,0x01000ee4) */
/* WARNING: Removing unreachable block (ram,0x01000f58) */
/* WARNING: Removing unreachable block (ram,0x01000efc) */
/* WARNING: Removing unreachable block (ram,0x01000f68) */
/* WARNING: Removing unreachable block (ram,0x01000ff8) */
/* WARNING: Removing unreachable block (ram,0x01001134) */
/* WARNING: Removing unreachable block (ram,0x01001048) */
/* WARNING: Removing unreachable block (ram,0x01000fb0) */
/* WARNING: Removing unreachable block (ram,0x01001064) */
/* WARNING: Removing unreachable block (ram,0x01000fc0) */
/* WARNING: Removing unreachable block (ram,0x01000fd0) */
/* WARNING: Removing unreachable block (ram,0x01000fdc) */
/* WARNING: Removing unreachable block (ram,0x01001070) */
/* WARNING: Removing unreachable block (ram,0x01001118) */
/* WARNING: Removing unreachable block (ram,0x010010b0) */
/* WARNING: Removing unreachable block (ram,0x01000ff4) */
/* WARNING: Removing unreachable block (ram,0x010010c4) */
/* WARNING: Removing unreachable block (ram,0x010010d0) */
/* WARNING: Removing unreachable block (ram,0x010010d4) */
/* WARNING: Removing unreachable block (ram,0x010010d8) */
/* WARNING: Removing unreachable block (ram,0x01005954) */
/* WARNING: Removing unreachable block (ram,0x01001390) */
/* WARNING: Removing unreachable block (ram,0x0100141c) */
/* WARNING: Removing unreachable block (ram,0x01001428) */
/* WARNING: Removing unreachable block (ram,0x01001440) */
/* WARNING: Removing unreachable block (ram,0x01001458) */
/* WM: origin: github.com/pengussy @ discord.gg/sdkhDjTex */
/* WARNING: Removing unreachable block (ram,0x01001450) */
/* WARNING: Removing unreachable block (ram,0x01001468) */
/* WARNING: Removing unreachable block (ram,0x01001438) */
/* WARNING: Removing unreachable block (ram,0x010014c8) */
/* WARNING: Removing unreachable block (ram,0x010014e8) */
/* WARNING: Removing unreachable block (ram,0x010014fc) */
/* WARNING: Removing unreachable block (ram,0x0100158c) */
/* WARNING: Removing unreachable block (ram,0x01001548) */
/* WARNING: Removing unreachable block (ram,0x01001408) */
/* WARNING: Removing unreachable block (ram,0x01001564) */
/* WARNING: Removing unreachable block (ram,0x01001568) */
/* WARNING: Removing unreachable block (ram,0x01001418) */
/* WARNING: Removing unreachable block (ram,0x0100156c) */
/* WARNING: Removing unreachable block (ram,0x010016b0) */
/* WARNING: Removing unreachable block (ram,0x010056ec) */
/* WARNING: Removing unreachable block (ram,0x010015e0) */
/* WARNING: Removing unreachable block (ram,0x01001678) */
/* WARNING: Removing unreachable block (ram,0x01001694) */
/* WARNING: Removing unreachable block (ram,0x0100168c) */
/* WARNING: Removing unreachable block (ram,0x010016c4) */
/* WARNING: Removing unreachable block (ram,0x0100174c) */
/* WARNING: Removing unreachable block (ram,0x01001708) */
/* WARNING: Removing unreachable block (ram,0x01001664) */
/* WARNING: Removing unreachable block (ram,0x01001724) */
/* WARNING: Removing unreachable block (ram,0x01001728) */
/* WARNING: Removing unreachable block (ram,0x01001674) */
/* WM - proprietary - see LICENSE - do not sell */
/* WARNING: Removing unreachable block (ram,0x0100172c) */
/* WARNING: Removing unreachable block (ram,0x01001214) */
/* WARNING: Removing unreachable block (ram,0x01001278) */
/* WARNING: Removing unreachable block (ram,0x01001280) */
/* WARNING: Removing unreachable block (ram,0x0100129c) */
/* WARNING: Removing unreachable block (ram,0x010012b0) */
/* WARNING: Removing unreachable block (ram,0x01001354) */
/* WARNING: Removing unreachable block (ram,0x01001308) */
/* WARNING: Removing unreachable block (ram,0x01001374) */
/* WARNING: Removing unreachable block (ram,0x01001320) */

undefined8 FUN_010055d8(long param_1)

{
  undefined1 auVar1 [12];
  undefined1 *puVar2;
/*
 *  reversing this took months of machine time
 *
 *  @pengussy
 */
  long lVar3;
  uint uVar4;
  ulong *puVar5;
  undefined4 *puVar6;
  undefined *puVar7;
  ulong uVar8;
  long unaff_x19;
  undefined4 *unaff_x20;
  undefined8 unaff_x21;
  long *plVar9;
  long unaff_x22;
  undefined8 unaff_x23;
  undefined8 unaff_x24;
  ulong unaff_x25;
  undefined8 unaff_x26;
  undefined1 *unaff_x29;
  undefined *unaff_x30;
  undefined1 auVar10 [16];
  undefined1 auVar11 [16];
  undefined1 auStack_90 [128];
  
  auVar11._8_8_ = unaff_x24;
  auVar11._0_8_ = unaff_x21;
  puVar5 = (ulong *)(ulong)*(uint *)(*(long *)(&UNK_00003bb8 + param_1) + 0xf4);
  puVar7 = &UNK_00003e28;
  switch(puVar5) {
  case (ulong *)0x0:
    goto code_r0x0100564c;
  case (ulong *)0x1:
    break;
  case (ulong *)0x2:
    puVar7 = &UNK_00003e58;
    break;
  case (ulong *)0x3:
    puVar7 = &UNK_00003e30;
    break;
/* WM: do not claim this as your own @ discord.gg/sdkhDjTex */
  case (ulong *)0x4:
    puVar7 = &UNK_00003e60;
    break;
  case (ulong *)0x5:
    puVar7 = &UNK_00003e38;
    break;
  case (ulong *)0x6:
    puVar7 = &UNK_00003e68;
    break;
  case (ulong *)0x7:
    puVar7 = &UNK_00003e40;
    break;
  case (ulong *)0x8:
    puVar7 = &UNK_00003e70;
    break;
  case (ulong *)0x9:
    puVar7 = &UNK_00003e48;
    break;
  case (ulong *)0xa:
    puVar7 = &UNK_00003e78;
    break;
  default:
    unaff_x29 = auStack_90 + 0x80;
/* WM - stripping the watermark breaks the license */
    unaff_x30 = &LAB_01005670;
    auVar10 = func_0x0174ef58("Unhandled TargetInfo::IntType value",
                              "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/lib/AST/ASTContext.cpp"
                              ,&UNK_00001a15);
    puVar5 = auVar10._8_8_;
    param_1 = auVar10._0_8_;
    register0x00000008 = (BADSPACEBASE *)(auStack_90 + 0x80);
    goto code_r0x01005670;
  }
  puVar5 = *(ulong **)(puVar7 + param_1);
code_r0x0100564c:
code_r0x01005670:
  do {
    *(undefined4 **)((long)register0x00000008 + -0x20) = unaff_x20;
    *(long *)((long)register0x00000008 + -0x18) = unaff_x19;
    *(undefined1 **)((long)register0x00000008 + -0x10) = unaff_x29;
    *(undefined **)((long)register0x00000008 + -8) = unaff_x30;
    unaff_x29 = (undefined1 *)((long)register0x00000008 + -0x10);
    unaff_x20 = *(undefined4 **)((ulong)puVar5 & 0xfffffffffffffff0);
    if (unaff_x20 == (undefined4 *)0x0 || (unaff_x20[4] & 0xfe) != 0xc) {
      uVar4 = *(uint *)(*(long *)(*(ulong *)(unaff_x20 + 2) & 0xfffffffffffffff0) + 0x10);
      if ((uVar4 & 0xfe) != 0xc) {
        if ((uVar4 & 0xff) == 0x1a) {
          lVar3 = func_0x0114c0c4();
          uVar8 = *(ulong *)(lVar3 + 0x88);
          if (uVar8 < 4) {
            puVar5 = (ulong *)0x0;
          }
          else {
            puVar5 = (ulong *)(uVar8 & 0xfffffffffffffffc);
            if ((((uint)uVar8 >> 1 & 1) != 0) &&
               (puVar5 = *(ulong **)(*puVar5 & 0xfffffffffffffff0), (puVar5[1] & 0xf) != 0)) {
              puVar5 = (ulong *)func_0x011494dc();
            }
/* stripping the watermark breaks the license - github.com/pengussy */
          }
        }
        uVar4 = *(uint *)(*(long *)(*(ulong *)(*(long *)((ulong)puVar5 & 0xfffffffffffffff0) + 8) &
                                   0xfffffffffffffff0) + 0x10) >> 0x12 & 0xff;
        if (uVar4 < 0x14) {
          if (uVar4 - 0xf < 2) {
            return *(undefined8 *)(&UNK_00003e58 + param_1);
          }
          if (uVar4 == 0x12) {
            return *(undefined8 *)(&UNK_00003e60 + param_1);
          }
          if (uVar4 == 0x13) {
            return *(undefined8 *)(&UNK_00003e68 + param_1);
          }
        }
        else if (uVar4 < 0x16) {
          if (uVar4 == 0x14) {
            return *(undefined8 *)(&UNK_00003e70 + param_1);
          }
          if (uVar4 == 0x15) {
            return *(undefined8 *)(&UNK_00003e78 + param_1);
          }
        }
        else {
/*
 *  unlicensed copy if this notice is missing
 *
 *  @pengussy
 */
          if (uVar4 == 0x16) {
            return *(undefined8 *)(&UNK_00003e80 + param_1);
          }
          if (uVar4 == 0x19) {
            return *(undefined8 *)(&UNK_00003e68 + param_1);
          }
        }
        puVar6 = (undefined4 *)&UNK_00001f3f;
        puVar7 = &DAT_01005848;
        auVar10 = func_0x0174ef58(&UNK_01cbcd34,
                                  "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/lib/AST/ASTContext.cpp"
                                 );
        uVar8 = auVar10._8_8_;
        puVar2 = (undefined1 *)((long)register0x00000008 + -0x20);
        while( true ) {
          *(undefined8 *)(puVar2 + -0x50) = unaff_x26;
          *(ulong *)(puVar2 + -0x48) = unaff_x25;
          *(long *)(puVar2 + -0x40) = auVar11._8_8_;
          *(undefined8 *)(puVar2 + -0x38) = unaff_x23;
          *(long *)(puVar2 + -0x30) = unaff_x22;
          *(long *)(puVar2 + -0x28) = auVar11._0_8_;
          *(undefined4 **)(puVar2 + -0x20) = unaff_x20;
          *(long *)(puVar2 + -0x18) = param_1;
          *(undefined1 **)(puVar2 + -0x10) = unaff_x29;
          *(undefined **)(puVar2 + -8) = puVar7;
          unaff_x29 = puVar2 + -0x10;
          plVar9 = (long *)(uVar8 & 0xfffffffffffffff0);
          lVar3 = *plVar9;
          if ((*(byte *)(lVar3 + 8) & 0xf) == 0) {
            uVar4 = (uint)uVar8;
            if ((uVar4 >> 3 & 1) == 0) {
/*  keep the notice, keep the source honest  */
              auVar1._8_4_ = uVar4 & 7;
              auVar1._0_8_ = plVar9;
              auVar11._8_4_ = uVar4 & 7;
              auVar11._0_8_ = plVar9;
              auVar11._12_4_ = 0;
              unaff_x22 = func_0x01148f40(plVar9);
            }
            else {
              uVar4 = *(uint *)(plVar9 + 3) | uVar4 & 7;
              auVar1._8_4_ = uVar4;
              auVar1._0_8_ = lVar3;
              auVar11._8_4_ = uVar4;
              auVar11._0_8_ = lVar3;
              auVar11._12_4_ = 0;
              unaff_x22 = func_0x01148f40(lVar3);
            }
          }
          else {
            auVar11 = func_0x011494dc(uVar8);
            auVar1 = auVar11._0_12_;
            unaff_x22 = func_0x01148f40();
          }
          if ((unaff_x22 == 0) ||
             (auVar1 = auVar11._0_12_, *(byte *)(unaff_x22 + 0x10) - 0xb < 0xfffffffc)) break;
          uVar8 = *(ulong *)(unaff_x22 + 0x20);
          puVar7 = &UNK_010058fc;
          puVar2 = puVar2 + -0x50;
          param_1 = auVar10._0_8_;
          unaff_x20 = puVar6;
          unaff_x25 = uVar8;
        }
        *puVar6 = auVar1._8_4_;
        return auVar1._0_8_;
      }
      unaff_x20 = (undefined4 *)func_0x01148f40(unaff_x20);
      if ((unaff_x20[4] & 0xfe) != 0xc) {
        func_0x0174f200("cast");
// WM - unlicensed copy if this notice is missing
      }
    }
    puVar5 = *(ulong **)(unaff_x20 + 8);
    unaff_x30 = &UNK_010056ec;
    register0x00000008 = (BADSPACEBASE *)((long)register0x00000008 + -0x20);
    unaff_x19 = param_1;
  } while( true );
}

