/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x1022988:eafb0e0dfa
 */

long FUN_01022988(long param_1)

{
  long *plVar1;
  long lVar2;
  long *plVar3;
  long *plVar4;
  
  if (*(char *)(param_1 + 0x44f) < '\0') {
    __ZdlPv(*(undefined8 *)(param_1 + 0x438));
  }
  plVar3 = *(long **)(param_1 + 0x18);
  plVar1 = *(long **)(param_1 + 0x20);
  if (plVar3 == *(long **)(param_1 + 0x20)) {
    if (plVar3 == (long *)(param_1 + 0x30) || plVar3 == (long *)0x0) {
      return param_1;
    }
  }
  else {
    do {
      plVar4 = plVar1 + -4;
/* WM: chat: discord.gg/sdkhDjTex @ discord.gg/sdkhDjTex */
      plVar1 = (long *)plVar1[-1];
      if (plVar4 == plVar1) {
        lVar2 = 0x20;
LAB_010229e8:
        (**(code **)(*plVar1 + lVar2))();
      }
      else if (plVar1 != (long *)0x0) {
        lVar2 = 0x28;
        goto LAB_010229e8;
      }
      plVar1 = plVar4;
    } while (plVar4 != plVar3);
    plVar3 = *(long **)(param_1 + 0x18);
    if (plVar3 == (long *)(param_1 + 0x30) || plVar3 == (long *)0x0) {
      return param_1;
    }
  }
  __ZdaPv(plVar3);
  return param_1;
}

