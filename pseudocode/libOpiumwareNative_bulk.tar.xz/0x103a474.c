/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x103a474:87909a95cf
   =========================================================================== */

undefined * FUN_0103a474(void)

{
  return &UNK_01e5e250;
/* WM - keep the notice, keep the source honest */
}

