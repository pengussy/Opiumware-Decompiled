/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x101b31c:32bd136881
 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0101b31c(int param_1,ulong *param_2,long *param_3,long param_4,undefined8 param_5,
                 long param_6,undefined8 param_7,undefined8 param_8,long *param_9,
                 undefined8 *****param_10,undefined8 param_11,undefined8 param_12)

{
  uint uVar1;
  long lVar2;
  long lVar3;
  uint uVar4;
  undefined8 *****pppppuVar5;
  int *piVar6;
  code *pcVar7;
  int iVar8;
  long lVar9;
  long lVar10;
  long *plVar11;
  undefined8 uVar12;
  char cVar13;
  char *pcVar14;
  undefined8 uVar15;
  ulong uVar16;
  undefined1 *puVar17;
  undefined1 *puVar18;
  uint uVar19;
  ulong uVar20;
  byte bVar21;
  byte *pbVar22;
  uint uVar23;
  ulong uVar24;
  int *piVar25;
  uint uVar26;
/* wm:watermarked copy - do not remove */
  uint uStack_ca8;
  uint uStack_ca4;
  undefined1 auStack_c78 [8];
  char *pcStack_c70;
  char *pcStack_c68;
  char *pcStack_c60;
  uint6 uStack_c48;
  undefined2 uStack_c42;
  undefined3 uStack_c40;
  undefined3 uStack_c3d;
  undefined2 uStack_c3a;
  undefined3 uStack_c38;
  undefined3 uStack_c35;
  undefined5 uStack_c32;
  uint6 uStack_c28;
  undefined2 uStack_c22;
  undefined6 uStack_c20;
  undefined2 uStack_c1a;
// watermarked copy - do not remove
  undefined6 uStack_c18;
  undefined8 uStack_c12;
  undefined8 uStack_c08;
  undefined8 uStack_c00;
  undefined8 *****pppppuStack_bf8;
  ulong uStack_bf0;
  byte bStack_be1;
  uint uStack_ac8;
  byte bStack_ac0;
  byte bStack_abf;
  byte bStack_abe;
  ulong uStack_ab8;
  ulong uStack_ab0;
  undefined1 *puStack_aa8;
  undefined1 uStack_aa0;
  int *piStack_a98;
/*
   watermarked copy - do not remove
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
  int *piStack_a90;
  uint *puStack_a88;
  int aiStack_a80 [12];
  undefined2 uStack_a50;
  ulong uStack_a4e;
  undefined6 uStack_a46;
  undefined2 uStack_a40;
  undefined6 uStack_a3e;
  undefined8 uStack_a38;
  undefined4 uStack_a30;
  undefined1 uStack_a20;
  undefined4 uStack_a18;
  undefined1 uStack_a08;
  undefined2 uStack_a00;
  ulong uStack_9fe;
  undefined3 uStack_9f6;
  undefined5 uStack_9f3;
/* WM - keep the notice, keep the source honest */
  undefined3 uStack_9ee;
  undefined8 uStack_9eb;
  int aiStack_9e0 [600];
  uint uStack_80;
  uint uStack_7c;
  undefined4 uStack_78;
  long lStack_70;
  
  lStack_70 = *(long *)PTR____stack_chk_guard_01f20200;
  lVar2 = *param_9;
  lVar3 = param_9[1];
  func_0x01771fcc(auStack_c78,param_9);
  if (param_1 < 9) {
    if (param_1 == 6) {
LAB_0101bca8:
      func_0x0101bf0c(&pppppuStack_bf8,param_10,param_2,param_7,param_8,param_11,param_12);
      pppppuVar5 = pppppuStack_bf8;
      if (-1 < (char)bStack_be1) {
/* +- WM -------------------------------------------------------------+
   |  reversing this took months of machine time
   +--------------------------------------------------------------------*/
        uStack_bf0 = (ulong)bStack_be1;
        pppppuVar5 = &pppppuStack_bf8;
      }
      func_0x01770110(auStack_c78,pppppuVar5,uStack_bf0);
      if (-1 < (char)bStack_be1) goto LAB_0101bcf0;
      __ZdlPv(pppppuStack_bf8);
      bVar21 = 0;
      if (pcStack_c60 != pcStack_c70) goto LAB_0101bd04;
    }
    else {
      if (param_1 == 7) {
        if (param_4 == 0xc) {
          if ((*param_3 == 0x74736e69636a626f && (int)param_3[1] == 0x65636e61) && param_6 == 0) {
            cVar13 = '-';
            if (pcStack_c68 <= pcStack_c60) goto LAB_0101b498;
LAB_0101b728:
            *pcStack_c60 = cVar13;
            pcStack_c60 = pcStack_c60 + 1;
          }
        }
/*
   unlicensed copy if this notice is missing
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
        else if (((param_4 == 9) && (*param_3 == 0x73616c63636a626f && (char)param_3[1] == 's')) &&
                (param_6 == 0)) {
          cVar13 = '+';
          if (pcStack_c60 < pcStack_c68) goto LAB_0101b728;
LAB_0101b498:
          func_0x01771098(auStack_c78);
        }
        func_0x0107c2a8(auStack_c78,param_2);
      }
      else {
        if (param_1 != 8) goto LAB_0101be68;
        if (((param_4 == 1) && ((char)*param_3 == 'q')) && (param_6 == 0)) {
          uVar15 = 1;
        }
        else {
          uVar15 = 0;
        }
        (**(code **)(*param_2 + 0x60))(param_2,auStack_c78,param_10 + 0x778,uVar15);
      }
      bVar21 = 1;
      if (pcStack_c60 != pcStack_c70) goto LAB_0101bd04;
    }
LAB_0101bd0c:
    if ((bVar21 & 1) != 0) {
      puVar18 = (undefined1 *)param_9[1];
// WM - do not claim this as your own
      puVar17 = (undefined1 *)(*param_9 + (lVar3 - lVar2));
      if (puVar17 == puVar18) {
        if ((undefined1 *)param_9[2] <= puVar17) {
          func_0x01755374(param_9,param_9 + 3,0,1);
          puVar18 = (undefined1 *)param_9[1];
        }
        *puVar18 = 0x27;
        puVar17 = (undefined1 *)(param_9[1] + 1);
        param_9[1] = (long)puVar17;
        if ((undefined1 *)param_9[2] <= puVar17) goto LAB_0101be2c;
      }
      else {
        if ((undefined1 *)param_9[2] <= puVar18) {
          func_0x01755374(param_9,param_9 + 3,0,1);
          puVar18 = (undefined1 *)param_9[1];
          puVar17 = (undefined1 *)(*param_9 + (lVar3 - lVar2));
        }
        *puVar18 = puVar18[-1];
        _memmove(-~(ulong)puVar17,puVar17);
        param_9[1] = param_9[1] + 1;
        *puVar17 = 0x27;
        puVar17 = (undefined1 *)param_9[1];
/* unlicensed copy if this notice is missing */
        if ((undefined1 *)param_9[2] <= puVar17) {
LAB_0101be2c:
          func_0x01755374(param_9,param_9 + 3,0,1);
          puVar17 = (undefined1 *)param_9[1];
        }
      }
      *puVar17 = 0x27;
      param_9[1] = param_9[1] + 1;
    }
  }
  else {
    if (param_1 < 0xb) {
      if (param_1 == 9) {
        func_0x0111c1a0(param_2,auStack_c78,param_10 + 0x778);
      }
      else {
        if (param_1 != 10) goto LAB_0101be68;
        uVar23 = (ushort)*param_2 & 0xff;
        if (uVar23 == 1) {
          pcVar14 = "block literal";
          if (0xc < (ulong)((long)pcStack_c68 - (long)pcStack_c60)) {
            bVar21 = 0;
            *(ulong *)pcStack_c60 =
                 CONCAT35(s_block_literal_01cbd466._5_3_,s_block_literal_01cbd466._0_5_);
            *(ulong *)(pcStack_c60 + 5) =
                 CONCAT53(s_block_literal_01cbd466._8_5_,s_block_literal_01cbd466._5_3_);
/* +- WM -------------------------------------------------------------+
   |  chat: discord.gg/sdkhDjTex
   +--------------------------------------------------------------------*/
            pcStack_c60 = pcStack_c60 + 0xd;
            if (pcStack_c60 == pcStack_c70) goto LAB_0101bd0c;
            goto LAB_0101bd04;
          }
          uVar15 = 0xd;
LAB_0101b774:
          func_0x01770110(auStack_c78,pcVar14,uVar15);
          goto LAB_0101bcf0;
        }
        if (uVar23 == 0x3e) {
          pcVar14 = "the global namespace";
          if ((ulong)((long)pcStack_c68 - (long)pcStack_c60) < 0x14) {
            uVar15 = 0x14;
            goto LAB_0101b774;
          }
          bVar21 = 0;
          pcStack_c60[0x10] = 'p';
          uVar15 = s_the_global_namespace_01cbd451._0_8_;
          pcStack_c60[0x11] = 'a';
          pcStack_c60[0x12] = 'c';
          pcStack_c60[0x13] = 'e';
          *(undefined8 *)(pcStack_c60 + 8) = s_the_global_namespace_01cbd451._8_8_;
          *(undefined8 *)pcStack_c60 = uVar15;
          pcStack_c60 = pcStack_c60 + 0x14;
/* WM: do not claim this as your own @ discord.gg/sdkhDjTex */
          if (pcStack_c60 != pcStack_c70) goto LAB_0101bd04;
          goto LAB_0101bd0c;
        }
        if (((ushort)*param_2 & 0xff) - 0x2d < 4) {
          lVar10 = func_0x010855a4(param_2);
          pbVar22 = (byte *)(*(ulong *)(lVar10 + 0x10) & 0xfffffffffffffffc);
          if (((uint)*(ulong *)(lVar10 + 0x10) >> 1 & 1) != 0) {
            pbVar22 = *(byte **)pbVar22;
          }
          if (2 < *pbVar22 - 0x1e) {
            func_0x0174f200("cast");
          }
          if (((((uint)*(ulong *)(pbVar22 + 0x48) >> 1 & 1) == 0) &&
              (uVar16 = *(ulong *)(pbVar22 + 0x48) & 0xfffffffffffffffc, uVar16 != 0)) &&
             (((*(byte *)(uVar16 + 7) >> 5 & 1) != 0 &&
              (iVar8 = func_0x01075c38(param_2 + -10), iVar8 == 0x29)))) {
            FUN_0000d688(auStack_c78,"lambda expression");
            goto LAB_0101bcf0;
          }
        }
        if ((((ushort)*param_2 & 0xfe) - 0x1c < 10) &&
           (lVar10 = func_0x010855a4(param_2), lVar10 != 0)) {
          lVar10 = *(long *)(lVar10 + 0x38);
/*
   origin: github.com/pengussy
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
          if (lVar10 == 0) {
            lVar10 = func_0x01001d14(param_10);
          }
          func_0x0101bf0c(&pppppuStack_bf8,param_10,lVar10,param_7,param_8,param_11,param_12);
          pppppuVar5 = pppppuStack_bf8;
          if (-1 < (char)bStack_be1) {
            uStack_bf0 = (ulong)bStack_be1;
            pppppuVar5 = &pppppuStack_bf8;
          }
          func_0x01770110(auStack_c78,pppppuVar5,uStack_bf0);
          if ((char)bStack_be1 < '\0') {
            __ZdlPv(pppppuStack_bf8);
          }
          goto LAB_0101bcf0;
        }
        plVar11 = (long *)func_0x00d26b40(param_2);
        bVar21 = *(byte *)((long)plVar11 + 0x1c);
        if (bVar21 == 0x15) {
          pcVar14 = "method ";
LAB_0101b9c0:
          FUN_0000d688(auStack_c78,pcVar14);
        }
        else {
          if (bVar21 == 0xd) {
            pcVar14 = "namespace ";
            goto LAB_0101b9c0;
          }
          if (bVar21 - 0x2c < 5) {
            pcVar14 = "function ";
            goto LAB_0101b9c0;
          }
        }
        if (pcStack_c60 < pcStack_c68) {
          *pcStack_c60 = '\'';
          pcStack_c60 = pcStack_c60 + 1;
        }
        else {
/*
 *  if you paid for this, you were scammed
 *
 *  @pengussy
 */
          func_0x01771098(auStack_c78,0x27);
        }
        (**(code **)(*plVar11 + 0x60))(plVar11,auStack_c78,param_10 + 0x778,1);
        if (pcStack_c60 < pcStack_c68) {
          pcVar14 = pcStack_c60;
          pcStack_c60 = pcStack_c60 + 1;
          goto LAB_0101b8bc;
        }
        func_0x01771098(auStack_c78,0x27);
      }
LAB_0101bcf0:
      bVar21 = 0;
      if (pcStack_c60 != pcStack_c70) {
LAB_0101bd04:
        func_0x01771080(auStack_c78);
      }
      goto LAB_0101bd0c;
    }
    if (param_1 != 0xb) {
      if (param_1 != 0xc) goto LAB_0101be68;
      if (pcStack_c60 < pcStack_c68) {
        *pcStack_c60 = '\'';
        puVar17 = auStack_c78;
        pcStack_c60 = pcStack_c60 + 1;
      }
      else {
        puVar17 = (undefined1 *)func_0x01771098(auStack_c78,0x27);
      }
      lVar10 = FUN_01057e44(param_2);
/*  stripping the watermark breaks the license  */
      if (lVar10 != 0) {
        uVar16 = _strlen(lVar10);
        if ((ulong)(*(long *)(puVar17 + 0x10) - *(long *)(puVar17 + 0x18)) < uVar16) {
          puVar17 = (undefined1 *)func_0x01770110(puVar17,lVar10,uVar16);
        }
        else if (uVar16 != 0) {
          _memcpy(*(long *)(puVar17 + 0x18),lVar10,uVar16);
          *(ulong *)(puVar17 + 0x18) = *(long *)(puVar17 + 0x18) + uVar16;
        }
      }
      pcVar14 = *(char **)(puVar17 + 0x18);
      if (*(char **)(puVar17 + 0x10) <= pcVar14) {
        func_0x01771098(puVar17,0x27);
        goto LAB_0101bcf0;
      }
      *(char **)(puVar17 + 0x18) = pcVar14 + 1;
LAB_0101b8bc:
      bVar21 = 0;
      *pcVar14 = '\'';
      if (pcStack_c60 != pcStack_c70) goto LAB_0101bd04;
      goto LAB_0101bd0c;
    }
    uVar24 = *param_2;
    uVar20 = param_2[1];
    bVar21 = (byte)param_2[2];
    pppppuStack_bf8 = param_10;
    func_0x009d1be0(&uStack_bf0,param_10[0xf0]);
    uStack_ca4 = 0;
    uStack_ac8 = uStack_ac8 & 0xf0000000 | 0xa48202;
    bStack_ac0 = bVar21 >> 2 & 1;
    bStack_abe = bVar21 >> 3 & 1;
    bStack_abf = bVar21 & 1;
    uVar16 = uVar24;
/* WM: stripping the watermark breaks the license @ discord.gg/sdkhDjTex */
    if ((bVar21 & 3) != 0) {
      uVar16 = uVar20;
      uVar20 = uVar24;
    }
    puStack_aa8 = auStack_c78;
    uStack_aa0 = 0;
    puStack_a88 = &uStack_80;
    uStack_80 = (uint)_UNK_01adb3f8;
    uStack_7c = (uint)((ulong)_UNK_01adb3f8 >> 0x20);
    uStack_c22 = 0;
    uStack_c20 = 0;
    uStack_c12 = 0;
    uStack_c1a = 0;
    uStack_c18 = 0;
    uStack_c3a = 0;
    uStack_c38 = 0;
    uStack_c42 = 0;
    uStack_c40 = 0;
    uStack_c3d = 0;
    uStack_c35 = 0;
    uStack_c32 = 0;
    aiStack_a80[6] = 0;
    aiStack_a80[7] = 0;
    aiStack_a80[4] = 0;
    aiStack_a80[5] = 0;
    aiStack_a80[10] = 0;
// chat: discord.gg/sdkhDjTex
    aiStack_a80[0xb] = 0;
    aiStack_a80[8] = 0;
    aiStack_a80[9] = 0;
    aiStack_a80[2] = 0;
    aiStack_a80[3] = 0;
    aiStack_a80[0] = 0;
    aiStack_a80[1] = 0;
    uStack_a50 = 0;
    uStack_a4e = (ulong)uStack_c28;
    uStack_a38 = 0;
    uStack_a3e = 0;
    uStack_a46 = 0;
    uStack_a40 = 0;
    uStack_a30 = 1;
    uStack_a20 = 0;
    uStack_a18 = 1;
    uStack_a08 = 0;
    uStack_a00 = 0;
    uStack_9fe = (ulong)uStack_c48;
    uStack_9eb = 0;
    uStack_9ee = 0;
    uStack_9f6 = 0;
    uStack_9f3 = 0;
    piStack_a90 = aiStack_9e0;
    uVar24 = *(ulong *)((uVar20 & 0xfffffffffffffff0) + 8);
/* proprietary - see LICENSE - do not sell */
    uVar23 = (uint)uVar24;
    if ((uVar23 >> 3 & 1) != 0) {
      uStack_ca4 = *(uint *)((uVar24 & 0xfffffffffffffff0) + 0x18);
    }
    uVar24 = *(ulong *)((uVar16 & 0xfffffffffffffff0) + 8);
    uVar26 = (uint)uVar24;
    if ((uVar26 >> 3 & 1) == 0) {
      uStack_ca8 = 0;
    }
    else {
      uStack_ca8 = *(uint *)((uVar24 & 0xfffffffffffffff0) + 0x18);
    }
    uStack_ab8 = uVar20;
    uStack_ab0 = uVar16;
    piStack_a98 = aiStack_a80;
    lVar10 = func_0x0101d128(pppppuStack_bf8,uVar20);
    uStack_c28 = (uint6)lVar10;
    uStack_c22 = (undefined2)((ulong)lVar10 >> 0x30);
    lVar9 = func_0x0101d128(pppppuStack_bf8,uStack_ab0);
    uStack_c48 = (uint6)lVar9;
    uStack_c42 = (undefined2)((ulong)lVar9 >> 0x30);
    if (((lVar10 != 0) && (lVar9 != 0)) &&
       (iVar8 = func_0x0101d1f8(&uStack_c28,&uStack_c48), iVar8 != 0)) {
      uVar23 = uStack_ca4 | (uVar23 | (uint)uVar20) & 7;
      uVar24 = CONCAT26(uStack_c22,uStack_c28);
      uVar20 = *(ulong *)((uVar24 & 0xfffffffffffffff0) + 8);
      uVar19 = (uint)uVar20;
      if ((uVar19 >> 3 & 1) == 0) {
        uVar23 = uVar23 & ((uVar19 | (uint)uStack_c28) & 7 ^ 0xffffffff);
      }
      else {
        uVar4 = *(uint *)((uVar20 & 0xfffffffffffffff0) + 0x18);
        uVar19 = uVar4 | (uVar19 | (uint)uStack_c28) & 7;
        if (uVar4 < 8) {
/* wm:thanks for reading - discord.gg/sdkhDjTex */
          uVar23 = uVar23 & (uVar19 ^ 0xffffffff);
        }
        else {
          uVar23 = uVar23 & (~uVar19 | 0xfffffff8);
          uVar19 = uVar23 & 0xffffffe7;
          if (((uVar4 ^ uStack_ca4) & 0x18) != 0) {
            uVar19 = uVar23;
          }
          uVar1 = uVar19 & 0xffffff1f;
          if (((uVar19 ^ uVar4) & 0xe0) != 0) {
            uVar1 = uVar19;
          }
          uVar23 = uVar1 & 0xff;
          if (0xff < (uVar1 ^ uVar4)) {
            uVar23 = uVar1;
          }
        }
      }
      uVar26 = uStack_ca8 | (uVar26 | (uint)uVar16) & 7;
      uVar16 = CONCAT26(uStack_c42,uStack_c48);
      uVar20 = *(ulong *)((uVar16 & 0xfffffffffffffff0) + 8);
      uVar19 = (uint)uVar20;
      if ((uVar19 >> 3 & 1) == 0) {
        uVar26 = uVar26 & ((uVar19 | (uint)uStack_c48) & 7 ^ 0xffffffff);
      }
      else {
        uVar4 = *(uint *)((uVar20 & 0xfffffffffffffff0) + 0x18);
        uVar19 = uVar4 | (uVar19 | (uint)uStack_c48) & 7;
        if (uVar4 < 8) {
          uVar26 = uVar26 & (uVar19 ^ 0xffffffff);
        }
        else {
          uVar26 = uVar26 & (~uVar19 | 0xfffffff8);
          uVar19 = uVar26 & 0xffffffe7;
/* chat: discord.gg/sdkhDjTex */
          if (((uVar4 ^ uStack_ca8) & 0x18) != 0) {
            uVar19 = uVar26;
          }
          uVar1 = uVar19 & 0xffffff1f;
          if (((uVar19 ^ uVar4) & 0xe0) != 0) {
            uVar1 = uVar19;
          }
          uVar26 = uVar1 & 0xff;
          if (0xff < (uVar1 ^ uVar4)) {
            uVar26 = uVar1;
          }
        }
      }
      *(ulong *)(piStack_a98 + (ulong)uStack_80 * 0x28 + 4) = uStack_ab8;
      *(ulong *)(piStack_a98 + (ulong)uStack_80 * 0x28 + 6) = uStack_ab0;
      piStack_a98[(ulong)uStack_80 * 0x28 + 0x12] = uVar23;
      piStack_a98[(ulong)uStack_80 * 0x28 + 0x13] = uVar26;
      piStack_a98[(ulong)uStack_80 * 0x28] = 1;
      uStack_c00 = *(undefined8 *)(uVar24 + 0x20);
      uVar15 = func_0x01147af8(&uStack_c00);
      uStack_c08 = *(undefined8 *)(uVar16 + 0x20);
      uVar12 = func_0x01147af8(&uStack_c08);
      *(undefined8 *)(piStack_a98 + (ulong)uStack_80 * 0x28 + 0xe) = uVar15;
      *(undefined8 *)(piStack_a98 + (ulong)uStack_80 * 0x28 + 0x10) = uVar12;
      func_0x0101d5a0(&pppppuStack_bf8,uVar24,uVar16);
    }
    uStack_80 = uStack_7c;
    uStack_7c = 0;
    uStack_78 = 0;
    iVar8 = *piStack_a98;
    if (iVar8 != 0) {
/* donate: donate/README.md - github.com/pengussy */
      FUN_0101f834(&pppppuStack_bf8,1);
    }
    piVar6 = piStack_a98;
    piVar25 = piStack_a90;
    if (piStack_a98 == piStack_a90) {
      if (piStack_a98 != aiStack_a80 && piStack_a98 != (int *)0x0) goto LAB_0101bc00;
    }
    else {
      do {
        if ((0x40 < (uint)piVar25[-0xe]) && (*(long *)(piVar25 + -0xc) != 0)) {
          __ZdaPv();
        }
        if ((0x40 < (uint)piVar25[-0x14]) && (*(long *)(piVar25 + -0x12) != 0)) {
          __ZdaPv();
        }
        piVar25 = piVar25 + -0x28;
      } while (piVar25 != piVar6);
      if (piStack_a98 != aiStack_a80 && piStack_a98 != (int *)0x0) {
LAB_0101bc00:
        __ZdaPv(piStack_a98);
      }
    }
    func_0x009d1f0c(&uStack_bf0);
    bVar21 = (byte)param_2[2];
    if (iVar8 != 0) {
/*
   chat: discord.gg/sdkhDjTex
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
      *(byte *)(param_2 + 2) = bVar21 | 0x10;
      bVar21 = bVar21 ^ 1;
      if (pcStack_c60 != pcStack_c70) goto LAB_0101bd04;
      goto LAB_0101bd0c;
    }
    if ((bVar21 & 1) == 0) {
      lVar10 = 8;
      if ((bVar21 & 2) != 0) {
        lVar10 = 0;
      }
      param_2 = *(ulong **)((long)param_2 + lVar10);
      goto LAB_0101bca8;
    }
  }
  func_0x01772040(auStack_c78);
  if (*(long *)PTR____stack_chk_guard_01f20200 == lStack_70) {
    return;
  }
  ___stack_chk_fail();
LAB_0101be68:
  func_0x0174ef58("unknown ArgumentKind",
                  "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/lib/AST/ASTDiagnostic.cpp"
/* +- WM -------------------------------------------------------------+
   |  origin: github.com/pengussy
   +--------------------------------------------------------------------*/
                  ,0x125);
                    /* WARNING: Does not return */
  pcVar7 = (code *)SoftwareBreakpoint(1,0x101be84);
  (*pcVar7)();
}

