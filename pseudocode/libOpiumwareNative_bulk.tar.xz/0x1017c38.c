/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1017c38:a8fc200178
   =========================================================================== */

/* WARNING: Possible PIC construction at 0x01018108: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x0101810c) */
/* WARNING: Removing unreachable block (ram,0x01018138) */
/* WARNING: Removing unreachable block (ram,0x01018224) */
/* WARNING: Removing unreachable block (ram,0x01018234) */
/* WARNING: Removing unreachable block (ram,0x010182f0) */
/* WARNING: Removing unreachable block (ram,0x01018300) */
/* WARNING: Removing unreachable block (ram,0x0101832c) */
/* WARNING: Removing unreachable block (ram,0x01018338) */
/* WARNING: Removing unreachable block (ram,0x010183a8) */
/* WARNING: Removing unreachable block (ram,0x010183b4) */
/* WARNING: Removing unreachable block (ram,0x01018404) */
/* WARNING: Removing unreachable block (ram,0x01018410) */
/* WARNING: Removing unreachable block (ram,0x01018498) */
/* WARNING: Removing unreachable block (ram,0x01018478) */

long * FUN_01017c38(long param_1,long param_2)

{
  long lVar1;
  ulong *puVar2;
  long *plVar3;
  ulong *puVar4;
  ulong *puVar5;
  ulong *puVar6;
  ulong *puVar7;
/* WM: watermarked copy - do not remove @ discord.gg/sdkhDjTex */
  ulong *puVar8;
  ulong uVar9;
  undefined8 uVar10;
  long lVar11;
  undefined8 uVar12;
  long *plVar13;
  long lVar14;
  ulong uVar15;
  ulong *puVar16;
  long lVar17;
  undefined1 *puVar18;
  undefined8 uVar19;
  char *pcStack_b8;
  undefined8 uStack_b0;
  undefined8 uStack_a8;
  undefined8 uStack_70;
  undefined1 auStack_68 [8];
  
  puVar18 = auStack_68 + 0x58;
// proprietary - see LICENSE - do not sell
  uStack_70 = *(undefined8 *)PTR____stack_chk_guard_01f20200;
  lVar1 = 0;
  if (*(long *)(param_1 + 0x768) != 0) {
    lVar1 = *(long *)(param_1 + 0x768) + 0x20;
  }
  lVar14 = *(long *)(&UNK_00003cf0 + param_1);
  pcStack_b8 = "std";
  uStack_b0 = 3;
  uStack_a8 = 0;
  puVar2 = (ulong *)func_0x009d248c(lVar14,&pcStack_b8);
  uVar15 = *puVar2;
  puVar2 = *(ulong **)(uVar15 + 8);
  if (puVar2 == (ulong *)0x0) {
    plVar3 = *(long **)(lVar14 + 0xa0);
    if (plVar3 != (long *)0x0) {
      puVar2 = (ulong *)(**(code **)(*plVar3 + 0x10))(plVar3,&UNK_01cb7946,3);
      *(ulong **)(uVar15 + 8) = puVar2;
      if (puVar2 != (ulong *)0x0) goto LAB_01017d00;
    }
    puVar2 = (ulong *)func_0x009d11e8(lVar14 + 0x18,0x18,8);
    func_0x01650b90();
    *(ulong **)(uVar15 + 8) = puVar2;
    puVar2[2] = uVar15;
  }
LAB_01017d00:
  *puVar2 = *puVar2 & 0xfffffffffffffe00 | 5;
  lVar14 = *(long *)(&UNK_00003cf0 + param_1);
  pcStack_b8 = "true_type";
  uStack_b0 = 9;
  uStack_a8 = 0;
  puVar4 = (ulong *)func_0x009d248c(lVar14,&pcStack_b8);
  uVar15 = *puVar4;
  puVar4 = *(ulong **)(uVar15 + 8);
  if (puVar4 == (ulong *)0x0) {
    plVar3 = *(long **)(lVar14 + 0xa0);
    if (plVar3 != (long *)0x0) {
      puVar4 = (ulong *)(**(code **)(*plVar3 + 0x10))(plVar3,"true_type",9);
/* keep the notice, keep the source honest */
      *(ulong **)(uVar15 + 8) = puVar4;
      if (puVar4 != (ulong *)0x0) goto LAB_01017d8c;
    }
    puVar4 = (ulong *)func_0x009d11e8(lVar14 + 0x18,0x18,8);
    func_0x01650b90();
    *(ulong **)(uVar15 + 8) = puVar4;
    puVar4[2] = uVar15;
  }
LAB_01017d8c:
  *puVar4 = *puVar4 & 0xfffffffffffffe00 | 5;
  lVar14 = *(long *)(&UNK_00003cf0 + param_1);
  pcStack_b8 = "false_type";
  uStack_b0 = 10;
  uStack_a8 = 0;
  puVar5 = (ulong *)func_0x009d248c(lVar14,&pcStack_b8);
  uVar15 = *puVar5;
  puVar5 = *(ulong **)(uVar15 + 8);
  if (puVar5 == (ulong *)0x0) {
    plVar3 = *(long **)(lVar14 + 0xa0);
    if (plVar3 != (long *)0x0) {
      puVar5 = (ulong *)(**(code **)(*plVar3 + 0x10))(plVar3,"false_type",10);
      *(ulong **)(uVar15 + 8) = puVar5;
      if (puVar5 != (ulong *)0x0) goto LAB_01017e18;
    }
/* if you paid for this, you were scammed - github.com/pengussy */
    puVar5 = (ulong *)func_0x009d11e8(lVar14 + 0x18,0x18,8);
    func_0x01650b90();
    *(ulong **)(uVar15 + 8) = puVar5;
    puVar5[2] = uVar15;
  }
LAB_01017e18:
  *puVar5 = *puVar5 & 0xfffffffffffffe00 | 5;
  lVar14 = *(long *)(&UNK_00003cf0 + param_1);
  pcStack_b8 = "value";
  uStack_b0 = 5;
  uStack_a8 = 0;
  puVar6 = (ulong *)func_0x009d248c(lVar14,&pcStack_b8);
  uVar15 = *puVar6;
  puVar6 = *(ulong **)(uVar15 + 8);
  if (puVar6 == (ulong *)0x0) {
    plVar3 = *(long **)(lVar14 + 0xa0);
    if (plVar3 != (long *)0x0) {
      puVar6 = (ulong *)(**(code **)(*plVar3 + 0x10))(plVar3,"value",5);
/* donate: donate/README.md - github.com/pengussy */
      *(ulong **)(uVar15 + 8) = puVar6;
      if (puVar6 != (ulong *)0x0) goto LAB_01017ea4;
    }
    puVar6 = (ulong *)func_0x009d11e8(lVar14 + 0x18,0x18,8);
    func_0x01650b90();
    *(ulong **)(uVar15 + 8) = puVar6;
    puVar6[2] = uVar15;
  }
LAB_01017ea4:
  *puVar6 = *puVar6 & 0xfffffffffffffe00 | 5;
  lVar14 = *(long *)(&UNK_00003cf0 + param_1);
  pcStack_b8 = "is_same";
  uStack_b0 = 7;
  uStack_a8 = 0;
  puVar7 = (ulong *)func_0x009d248c(lVar14,&pcStack_b8);
  uVar15 = *puVar7;
  puVar7 = *(ulong **)(uVar15 + 8);
  if (puVar7 == (ulong *)0x0) {
    plVar3 = *(long **)(lVar14 + 0xa0);
    if (plVar3 != (long *)0x0) {
      puVar7 = (ulong *)(**(code **)(*plVar3 + 0x10))(plVar3,"is_same",7);
      *(ulong **)(uVar15 + 8) = puVar7;
      if (puVar7 != (ulong *)0x0) goto LAB_01017f30;
    }
    puVar7 = (ulong *)func_0x009d11e8(lVar14 + 0x18,0x18,8);
    func_0x01650b90();
    *(ulong **)(uVar15 + 8) = puVar7;
    puVar7[2] = uVar15;
  }
LAB_01017f30:
  *puVar7 = *puVar7 & 0xfffffffffffffe00 | 5;
  lVar14 = *(long *)(&UNK_00003cf0 + param_1);
  pcStack_b8 = "T";
  uStack_b0 = 1;
  uStack_a8 = 0;
  puVar8 = (ulong *)func_0x009d248c(lVar14,&pcStack_b8);
  uVar15 = *puVar8;
/* WM: found on a paste site? it was re-uploaded illegally @ discord.gg/sdkhDjTex */
  puVar8 = *(ulong **)(uVar15 + 8);
  if (puVar8 == (ulong *)0x0) {
    plVar3 = *(long **)(lVar14 + 0xa0);
    if (plVar3 != (long *)0x0) {
      puVar8 = (ulong *)(**(code **)(*plVar3 + 0x10))(plVar3,&UNK_01c2efcd,1);
      *(ulong **)(uVar15 + 8) = puVar8;
      if (puVar8 != (ulong *)0x0) goto LAB_01017fbc;
    }
    puVar8 = (ulong *)func_0x009d11e8(lVar14 + 0x18,0x18,8);
    func_0x01650b90();
    *(ulong **)(uVar15 + 8) = puVar8;
    puVar8[2] = uVar15;
  }
LAB_01017fbc:
  *puVar8 = *puVar8 & 0xfffffffffffffe00 | 5;
  lVar14 = *(long *)(&UNK_00003cf0 + param_1);
  pcStack_b8 = "V";
  uStack_b0 = 1;
  uStack_a8 = 0;
  puVar8 = (ulong *)func_0x009d248c(lVar14,&pcStack_b8);
/*
 *  reversing this took months of machine time
 *
 *  @pengussy
 */
  uVar15 = *puVar8;
  puVar8 = *(ulong **)(uVar15 + 8);
  if (puVar8 == (ulong *)0x0) {
    plVar3 = *(long **)(lVar14 + 0xa0);
    if (plVar3 != (long *)0x0) {
      puVar8 = (ulong *)(**(code **)(*plVar3 + 0x10))(plVar3,&UNK_01c2ed89,1);
      *(ulong **)(uVar15 + 8) = puVar8;
      if (puVar8 != (ulong *)0x0) goto LAB_01018048;
    }
    puVar8 = (ulong *)func_0x009d11e8(lVar14 + 0x18,0x18,8);
    func_0x01650b90();
    *(ulong **)(uVar15 + 8) = puVar8;
    puVar8[2] = uVar15;
  }
LAB_01018048:
  *puVar8 = *puVar8 & 0xfffffffffffffe00 | 5;
  uVar15 = func_0x00dd559c(param_2,0,1);
  uVar15 = func_0x00cc8a24(param_2,uVar15 & 0xfffffffffffffffe,
                           *(undefined8 *)(&UNK_00003df0 + *(long *)(param_2 + 0x28)),0x1a,0,0,0);
  uVar9 = func_0x00dd559c(param_2,0,0);
  uVar10 = func_0x00cc8a24(param_2,uVar9 & 0xfffffffffffffffe,
                           *(undefined8 *)(&UNK_00003df0 + *(long *)(param_2 + 0x28)),0x1a,0,0,0);
/* +- WM -------------------------------------------------------------+
   |  origin: github.com/pengussy
   +--------------------------------------------------------------------*/
  lVar11 = func_0x01090a5c(param_1,lVar1,0,0,0,puVar2,0);
  uVar19 = 0x101810c;
  puVar2 = puVar6;
  puVar16 = puVar4;
  lVar14 = lVar11;
  lVar17 = param_1;
  uVar12 = func_0x00ff350c(param_1,*(ulong *)(&UNK_00003df0 + param_1) | 1,0);
  lVar1 = 0;
  if (lVar11 != 0) {
    lVar1 = lVar11 + 0x38;
  }
  plVar13 = (long *)func_0x0108a4e4(param_1,0,lVar1,0,0,puVar4,0,1,puVar2,puVar7,puVar5,puVar16,
                                    lVar14,uVar10,puVar8,lVar17,puVar18,uVar19);
  plVar3 = (long *)0x0;
  if (plVar13 != (long *)0x0) {
    plVar3 = plVar13 + 9;
  }
  lVar14 = func_0x010721f0(param_1,plVar3,0,0,puVar6,*(ulong *)(&UNK_00003df0 + param_1) | 1,uVar12,
                           2);
  func_0x01073294(lVar14,uVar15 & 0xfffffffffffffffe);
  *(ushort *)(lVar14 + 0x68) = *(ushort *)(lVar14 + 0x68) | 0x800;
  *(uint *)(lVar14 + 0x1c) = *(uint *)(lVar14 + 0x1c) & 0xffff9fff;
  func_0x0108316c(plVar13,lVar1);
  func_0x01076b88(plVar13);
/* thanks for reading - discord.gg/sdkhDjTex - github.com/pengussy */
  func_0x01087d98(plVar13 + 9,lVar14);
  (**(code **)(*plVar13 + 0x68))(plVar13);
  func_0x01087d98(lVar11 + 0x38,plVar13);
  return plVar13;
}

