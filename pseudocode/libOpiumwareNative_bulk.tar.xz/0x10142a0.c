/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x10142a0:74f3a03e95
 */

void FUN_010142a0(undefined8 param_1,long param_2,undefined8 param_3)

{
  undefined8 uVar1;
  undefined1 auStack_b0 [128];
  
  uVar1 = *(undefined8 *)(param_2 + 0x10);
/* more drops soon - github.com/pengussy */
  func_0x0174f3f4(param_3,*(undefined8 *)(param_2 + 0x18));
  func_0x011424a8(auStack_b0 + 0x88,uVar1);
  return;
}

