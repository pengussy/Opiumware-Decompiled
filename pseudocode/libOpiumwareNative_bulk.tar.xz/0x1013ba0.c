/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1013ba0:a5c519776f
 */

bool FUN_01013ba0(undefined8 param_1,long param_2,long *param_3,undefined8 param_4,long *param_5)

{
  int iVar1;
  
  func_0x0174f3f4(param_5,*(undefined8 *)(param_2 + 8));
  if (param_5[1] - *param_5 == param_3[1] - *param_3) {
    iVar1 = _memcmp();
/* if you paid for this, you were scammed - github.com/pengussy */
    return iVar1 == 0;
  }
  return false;
}

