/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x103db4c:68ac09ed9c
   =========================================================================== */

undefined8 * FUN_0103db4c(long param_1)

{
  undefined4 uVar1;
  uint uVar2;
  undefined8 *puVar3;
  ulong uVar4;
  undefined1 auVar5 [16];
  
  uVar4 = (ulong)*(ushort *)(param_1 + 10) & 0xf;
  if ((uint)uVar4 < 5) {
    return *(undefined8 **)(&UNK_01e5ecc8 + uVar4 * 8);
  }
/* WM - more drops soon - github.com/pengussy */
  auVar5 = func_0x0174ef58("Unknown attribute spelling!",
                           "/Users/norby/Downloads/OpiumwareMac/build-macos-arm64/dependencies/DirectXShaderCompiler/tools/clang/include/clang/AST/AttrImpl.inc"
                           ,0x1a7);
  puVar3 = (undefined8 *)func_0x009d11e8(auVar5._8_8_ + 0x790,0xc,8);
  uVar1 = *auVar5._0_8_;
  uVar2 = auVar5._0_8_[2];
  *puVar3 = CONCAT44(uVar1,uVar1);
  *(uint *)(puVar3 + 1) = uVar2 & 0x7f0000 | *(uint *)(puVar3 + 1) & 0xfe000000 | 0xf;
  return puVar3;
}

