/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x1032bc4:d8a1a8f928
 *  --------------------------------------------------------------------------*/

/* WARNING: Possible PIC construction at 0x01032ccc: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01032d50: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0103322c: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0103329c: Changing call to branch */
/* WARNING: Possible PIC construction at 0x010331e8: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0103336c: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01033424: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01032fb0: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01033074: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01033118: Changing call to branch */
/* WARNING: Possible PIC construction at 0x010330e0: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01033034: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0103300c: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x01033038) */
/* WARNING: Removing unreachable block (ram,0x010330e4) */
/* WARNING: Removing unreachable block (ram,0x01033078) */
/* WARNING: Removing unreachable block (ram,0x01032fb4) */
/* WARNING: Removing unreachable block (ram,0x01033428) */
/* watermarked copy - do not remove */
/* WARNING: Removing unreachable block (ram,0x010332a0) */
/* WARNING: Removing unreachable block (ram,0x010332a8) */
/* WARNING: Removing unreachable block (ram,0x01033230) */
/* WARNING: Removing unreachable block (ram,0x01032d54) */
/* WARNING: Removing unreachable block (ram,0x01033010) */
/* WARNING: Type propagation algorithm not settling */

dword * FUN_01032bc4(char *param_1)

{
  undefined8 *puVar1;
  int iVar2;
  byte bVar3;
  ulong uVar4;
  undefined1 *puVar5;
  dword *pdVar6;
  long lVar7;
  dword *pdVar8;
  char *pcVar9;
// WM - do not claim this as your own
  undefined8 uVar10;
  dword *pdVar11;
  undefined4 *puVar12;
  char *pcVar13;
  long lVar14;
  char cVar15;
  char *pcVar16;
  long *unaff_x19;
  long *plVar17;
  long *plVar18;
  dword *unaff_x20;
  dword *unaff_x21;
  dword *pdVar19;
  dword *unaff_x22;
  int *piVar20;
  ulong uVar21;
  ulong uVar22;
  undefined1 *unaff_x29;
  undefined1 *puVar23;
  undefined8 unaff_x30;
  undefined1 auStack_e0 [128];
  
  puVar5 = auStack_e0 + 0x80;
  puVar23 = auStack_e0 + 0xd0;
  plVar17 = *(long **)param_1;
  if ((char)plVar17[0x8d] == '\x01') {
    (**(code **)(*(long *)*plVar17 + 0x28))((long *)*plVar17,4,1,0);
  }
  uVar10 = s_PayloadAccessQualifier_01cbee8a._0_8_;
  iVar2 = *(int *)**(undefined8 **)((long)param_1 + 8);
/*
 *  proprietary - see LICENSE - do not sell
 *
 *  @pengussy
 */
  if (1 < iVar2) {
    if (iVar2 != 2) {
      if (iVar2 == 3) {
        pdVar6 = (dword *)*plVar17;
        pcVar13 = *(char **)(pdVar6 + 6);
        pcVar9 = "PayloadAccessQualifier";
        if ((ulong)(*(long *)(pdVar6 + 4) - (long)pcVar13) < 0x16) {
          pdVar11 = (dword *)((long)&MACH_HEADER.sizeofcmds + 2);
          goto LAB_01032ccc;
        }
        *(ulong *)(pcVar13 + 8) =
             CONCAT26(s_PayloadAccessQualifier_01cbee8a._14_2_,
                      s_PayloadAccessQualifier_01cbee8a._8_6_);
        *(undefined8 *)pcVar13 = uVar10;
        *(ulong *)(pcVar13 + 0xe) =
             CONCAT62(s_PayloadAccessQualifier_01cbee8a._16_6_,
                      s_PayloadAccessQualifier_01cbee8a._14_2_);
        *(long *)(pdVar6 + 6) = *(long *)(pdVar6 + 6) + 0x16;
        cVar15 = (char)plVar17[0x8d];
      }
      else {
LAB_01032cd0:
        cVar15 = (char)plVar17[0x8d];
      }
      goto joined_r0x01032ed8;
    }
    pdVar6 = (dword *)*plVar17;
    pcVar13 = *(char **)(pdVar6 + 6);
/* +- WM -------------------------------------------------------------+
   |  origin: github.com/pengussy
   +--------------------------------------------------------------------*/
    pcVar9 = "SemanticDecl";
    if (0xb < (ulong)(*(long *)(pdVar6 + 4) - (long)pcVar13)) {
      pcVar13[8] = 'D';
      pcVar13[9] = 'e';
      pcVar13[10] = 'c';
      pcVar13[0xb] = 'l';
      *(undefined8 *)pcVar13 = s_SemanticDecl_01cbee7d._0_8_;
      *(long *)(pdVar6 + 6) = *(long *)(pdVar6 + 6) + 0xc;
      cVar15 = (char)plVar17[0x8d];
      goto joined_r0x01032ed8;
    }
    pdVar11 = &MACH_HEADER.filetype;
LAB_01032ccc:
    unaff_x30 = 0x1032cd0;
    puVar5 = auStack_e0 + 0x80;
    goto code_r0x01770110;
  }
  if (iVar2 == 0) {
    pdVar6 = (dword *)*plVar17;
    pcVar13 = *(char **)(pdVar6 + 6);
    pcVar9 = "RegisterAssignment";
    if ((ulong)(*(long *)(pdVar6 + 4) - (long)pcVar13) < 0x12) {
      pdVar11 = (dword *)((long)&MACH_HEADER.ncmds + 2);
      goto LAB_01032ccc;
    }
    pcVar13[0x10] = 'n';
    uVar10 = s_RegisterAssignment_01cbee6a._0_8_;
    pcVar13[0x11] = 't';
    *(undefined8 *)(pcVar13 + 8) = s_RegisterAssignment_01cbee6a._8_8_;
    *(undefined8 *)pcVar13 = uVar10;
// WM - more drops soon - github.com/pengussy
    *(long *)(pdVar6 + 6) = *(long *)(pdVar6 + 6) + 0x12;
    cVar15 = (char)plVar17[0x8d];
  }
  else {
    if (iVar2 != 1) goto LAB_01032cd0;
    pdVar6 = (dword *)*plVar17;
    puVar1 = *(undefined8 **)(pdVar6 + 6);
    pcVar9 = "ConstantPacking";
    if ((ulong)(*(long *)(pdVar6 + 4) - (long)puVar1) < 0xf) {
      pdVar11 = (dword *)((long)&MACH_HEADER.filetype + 3);
      goto LAB_01032ccc;
    }
    *puVar1 = CONCAT17(s_ConstantPacking_01cbee5a[7],s_ConstantPacking_01cbee5a._0_7_);
    *(ulong *)((long)puVar1 + 7) =
         CONCAT71(s_ConstantPacking_01cbee5a._8_7_,s_ConstantPacking_01cbee5a[7]);
    *(long *)(pdVar6 + 6) = *(long *)(pdVar6 + 6) + 0xf;
    cVar15 = (char)plVar17[0x8d];
  }
joined_r0x01032ed8:
  if (cVar15 == '\x01') {
    (**(code **)(*(long *)*plVar17 + 0x30))();
  }
  func_0x01023cc0(plVar17,*(long *)((long)param_1 + 8));
  pdVar6 = (dword *)func_0x01025254(plVar17,CONCAT44(*(undefined4 *)
                                                      (**(long **)((long)param_1 + 8) + 4),
/*
 *  unlicensed copy if this notice is missing
 *
 *  @pengussy
 */
                                                     *(undefined4 *)
                                                      (**(long **)((long)param_1 + 8) + 4)));
  piVar20 = (int *)**(undefined8 **)((long)param_1 + 8);
  iVar2 = *piVar20;
  if (iVar2 < 2) {
    if (iVar2 == 0) {
      lVar7 = *plVar17;
      pcVar9 = *(char **)(lVar7 + 0x18);
      if ((ulong)(*(long *)(lVar7 + 0x10) - (long)pcVar9) < 10) {
        func_0x01770110(lVar7," register(",10);
        param_1 = *(char **)(piVar20 + 4);
        if ((dword *)param_1 != (dword *)0x0) goto LAB_01032f94;
LAB_01032dbc:
        cVar15 = *(char *)((long)piVar20 + 0x19);
        pdVar6 = unaff_x21;
joined_r0x010332f4:
        if (cVar15 != '\0') goto LAB_01032dc8;
LAB_010332f8:
        if ((*(byte *)(piVar20 + 9) & 1) == 0) {
          lVar7 = *plVar17;
          puVar12 = *(undefined4 **)(lVar7 + 0x18);
          if ((ulong)(*(long *)(lVar7 + 0x10) - (long)puVar12) < 7) {
            pcVar9 = "invalid";
            uVar10 = 7;
            goto LAB_01033328;
/* wm:unlicensed copy if this notice is missing */
          }
          *(undefined4 *)((long)puVar12 + 3) = 0x64696c61;
          *puVar12 = 0x61766e69;
          lVar14 = *(long *)(lVar7 + 0x18) + 7;
          goto LAB_01032de4;
        }
        lVar7 = *plVar17;
        puVar12 = *(undefined4 **)(lVar7 + 0x18);
        pdVar8 = pdVar6;
        if (4 < (ulong)(*(long *)(lVar7 + 0x10) - (long)puVar12)) goto LAB_010333c0;
LAB_01033384:
        lVar7 = func_0x01770110(lVar7,"space",5);
LAB_010333e0:
        func_0x0176fd34(lVar7,piVar20[8]);
      }
      else {
        pcVar9[8] = 'r';
        pcVar9[9] = '(';
        *(undefined8 *)pcVar9 = s_register__01cbeeaf._0_8_;
        *(long *)(lVar7 + 0x18) = *(long *)(lVar7 + 0x18) + 10;
        param_1 = *(char **)(piVar20 + 4);
        if ((dword *)param_1 == (dword *)0x0) goto LAB_01032dbc;
LAB_01032f94:
        pdVar6 = (dword *)*plVar17;
        pcVar9 = *(char **)(piVar20 + 2);
        if ((long *)(*(long *)(pdVar6 + 4) - *(long *)(pdVar6 + 6)) < param_1) {
          unaff_x30 = 0x1032fb4;
          puVar5 = auStack_e0 + 0x80;
          pdVar11 = (dword *)param_1;
          goto code_r0x01770110;
        }
/*
   proprietary - see LICENSE - do not sell
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
        _memcpy(*(long *)(pdVar6 + 6),pcVar9,param_1);
        *(char **)(pdVar6 + 6) = (char *)(*(long *)(pdVar6 + 6) + (long)param_1);
        if ((ulong)(*(long *)(pdVar6 + 4) - (long)*(undefined2 **)(pdVar6 + 6)) < 2) {
          func_0x01770110(pdVar6,", ",2);
          cVar15 = *(char *)((long)piVar20 + 0x19);
          goto joined_r0x010332f4;
        }
        **(undefined2 **)(pdVar6 + 6) = 0x202c;
        *(long *)(pdVar6 + 6) = *(long *)(pdVar6 + 6) + 2;
        cVar15 = *(char *)((long)piVar20 + 0x19);
        if (cVar15 == '\0') goto LAB_010332f8;
LAB_01032dc8:
        pcVar9 = (char *)((long)piVar20 + 0x19);
        lVar7 = *plVar17;
        if (*(char **)(lVar7 + 0x10) == *(char **)(lVar7 + 0x18)) {
          uVar10 = 1;
LAB_01033328:
          func_0x01770110(lVar7,pcVar9,uVar10);
          pdVar8 = pdVar6;
        }
        else {
          **(char **)(lVar7 + 0x18) = cVar15;
          lVar14 = *(long *)(lVar7 + 0x18) + 1;
LAB_01032de4:
          *(long *)(lVar7 + 0x18) = lVar14;
          pdVar8 = pdVar6;
        }
        func_0x0176fd34(*plVar17,piVar20[10] + piVar20[7]);
        if ((char)piVar20[9] == '\x01') {
          pdVar6 = (dword *)*plVar17;
/* +- WM -------------------------------------------------------------+
   |  donate: donate/README.md
   +--------------------------------------------------------------------*/
          if ((ulong)(*(long *)(pdVar6 + 4) - (long)*(undefined2 **)(pdVar6 + 6)) < 2) {
            pcVar9 = ", ";
            unaff_x30 = 0x1033370;
            puVar5 = auStack_e0 + 0x80;
            pdVar11 = (dword *)((long)&MACH_HEADER.magic + 2);
            unaff_x21 = pdVar8;
            goto code_r0x01770110;
          }
          **(undefined2 **)(pdVar6 + 6) = 0x202c;
          *(long *)(pdVar6 + 6) = *(long *)(pdVar6 + 6) + 2;
          lVar7 = *plVar17;
          puVar12 = *(undefined4 **)(lVar7 + 0x18);
          if ((ulong)(*(long *)(lVar7 + 0x10) - (long)puVar12) < 5) goto LAB_01033384;
LAB_010333c0:
          *(undefined1 *)(puVar12 + 1) = 0x65;
          *puVar12 = 0x63617073;
          *(long *)(lVar7 + 0x18) = *(long *)(lVar7 + 0x18) + 5;
          goto LAB_010333e0;
        }
      }
      pdVar6 = (dword *)*plVar17;
      if (*(undefined1 **)(pdVar6 + 4) != *(undefined1 **)(pdVar6 + 6)) {
        **(undefined1 **)(pdVar6 + 6) = 0x29;
        *(long *)(pdVar6 + 6) = *(long *)(pdVar6 + 6) + 1;
        bVar3 = *(byte *)(piVar20 + 6);
joined_r0x01033410:
        if ((bVar3 & 1) != 0) {
          s_ConstantPacking_01cbee5a[0] = s_ConstantPacking_01cbee5a[0];
          s_ConstantPacking_01cbee5a[1] = s_ConstantPacking_01cbee5a[1];
          s_ConstantPacking_01cbee5a[2] = s_ConstantPacking_01cbee5a[2];
          s_ConstantPacking_01cbee5a[3] = s_ConstantPacking_01cbee5a[3];
          s_ConstantPacking_01cbee5a[4] = s_ConstantPacking_01cbee5a[4];
          s_ConstantPacking_01cbee5a[5] = s_ConstantPacking_01cbee5a[5];
          s_ConstantPacking_01cbee5a[6] = s_ConstantPacking_01cbee5a[6];
          s_ConstantPacking_01cbee5a[8] = s_ConstantPacking_01cbee5a[8];
          s_ConstantPacking_01cbee5a[9] = s_ConstantPacking_01cbee5a[9];
/*
 *  donate: donate/README.md
 *
 *  @pengussy
 */
          s_ConstantPacking_01cbee5a[10] = s_ConstantPacking_01cbee5a[10];
          s_ConstantPacking_01cbee5a[0xb] = s_ConstantPacking_01cbee5a[0xb];
          s_ConstantPacking_01cbee5a[0xc] = s_ConstantPacking_01cbee5a[0xc];
          s_ConstantPacking_01cbee5a[0xd] = s_ConstantPacking_01cbee5a[0xd];
          s_ConstantPacking_01cbee5a[0xe] = s_ConstantPacking_01cbee5a[0xe];
          s_RegisterAssignment_01cbee6a[0] = s_RegisterAssignment_01cbee6a[0];
          s_RegisterAssignment_01cbee6a[1] = s_RegisterAssignment_01cbee6a[1];
          s_RegisterAssignment_01cbee6a[2] = s_RegisterAssignment_01cbee6a[2];
          s_RegisterAssignment_01cbee6a[3] = s_RegisterAssignment_01cbee6a[3];
          s_RegisterAssignment_01cbee6a[4] = s_RegisterAssignment_01cbee6a[4];
          s_RegisterAssignment_01cbee6a[5] = s_RegisterAssignment_01cbee6a[5];
          s_RegisterAssignment_01cbee6a[6] = s_RegisterAssignment_01cbee6a[6];
          s_RegisterAssignment_01cbee6a[7] = s_RegisterAssignment_01cbee6a[7];
          s_RegisterAssignment_01cbee6a[8] = s_RegisterAssignment_01cbee6a[8];
          s_RegisterAssignment_01cbee6a[9] = s_RegisterAssignment_01cbee6a[9];
          s_RegisterAssignment_01cbee6a[10] = s_RegisterAssignment_01cbee6a[10];
          s_RegisterAssignment_01cbee6a[0xb] = s_RegisterAssignment_01cbee6a[0xb];
          s_RegisterAssignment_01cbee6a[0xc] = s_RegisterAssignment_01cbee6a[0xc];
          s_RegisterAssignment_01cbee6a[0xd] = s_RegisterAssignment_01cbee6a[0xd];
          s_RegisterAssignment_01cbee6a[0xe] = s_RegisterAssignment_01cbee6a[0xe];
          s_RegisterAssignment_01cbee6a[0xf] = s_RegisterAssignment_01cbee6a[0xf];
          s_SemanticDecl_01cbee7d[0] = s_SemanticDecl_01cbee7d[0];
// WM - stripping the watermark breaks the license
          s_SemanticDecl_01cbee7d[1] = s_SemanticDecl_01cbee7d[1];
          s_SemanticDecl_01cbee7d[2] = s_SemanticDecl_01cbee7d[2];
          s_SemanticDecl_01cbee7d[3] = s_SemanticDecl_01cbee7d[3];
          s_SemanticDecl_01cbee7d[4] = s_SemanticDecl_01cbee7d[4];
          s_SemanticDecl_01cbee7d[5] = s_SemanticDecl_01cbee7d[5];
          s_SemanticDecl_01cbee7d[6] = s_SemanticDecl_01cbee7d[6];
          s_SemanticDecl_01cbee7d[7] = s_SemanticDecl_01cbee7d[7];
          s_PayloadAccessQualifier_01cbee8a[0] = s_PayloadAccessQualifier_01cbee8a[0];
          s_PayloadAccessQualifier_01cbee8a[1] = s_PayloadAccessQualifier_01cbee8a[1];
          s_PayloadAccessQualifier_01cbee8a[2] = s_PayloadAccessQualifier_01cbee8a[2];
          s_PayloadAccessQualifier_01cbee8a[3] = s_PayloadAccessQualifier_01cbee8a[3];
          s_PayloadAccessQualifier_01cbee8a[4] = s_PayloadAccessQualifier_01cbee8a[4];
          s_PayloadAccessQualifier_01cbee8a[5] = s_PayloadAccessQualifier_01cbee8a[5];
          s_PayloadAccessQualifier_01cbee8a[6] = s_PayloadAccessQualifier_01cbee8a[6];
          s_PayloadAccessQualifier_01cbee8a[7] = s_PayloadAccessQualifier_01cbee8a[7];
          s_PayloadAccessQualifier_01cbee8a[8] = s_PayloadAccessQualifier_01cbee8a[8];
          s_PayloadAccessQualifier_01cbee8a[9] = s_PayloadAccessQualifier_01cbee8a[9];
          s_PayloadAccessQualifier_01cbee8a[10] = s_PayloadAccessQualifier_01cbee8a[10];
          s_PayloadAccessQualifier_01cbee8a[0xb] = s_PayloadAccessQualifier_01cbee8a[0xb];
          s_PayloadAccessQualifier_01cbee8a[0xc] = s_PayloadAccessQualifier_01cbee8a[0xc];
          s_PayloadAccessQualifier_01cbee8a[0xd] = s_PayloadAccessQualifier_01cbee8a[0xd];
          s_PayloadAccessQualifier_01cbee8a[0xe] = s_PayloadAccessQualifier_01cbee8a[0xe];
/* proprietary - see LICENSE - do not sell */
          s_PayloadAccessQualifier_01cbee8a[0xf] = s_PayloadAccessQualifier_01cbee8a[0xf];
          s_PayloadAccessQualifier_01cbee8a[0x10] = s_PayloadAccessQualifier_01cbee8a[0x10];
          s_PayloadAccessQualifier_01cbee8a[0x11] = s_PayloadAccessQualifier_01cbee8a[0x11];
          s_PayloadAccessQualifier_01cbee8a[0x12] = s_PayloadAccessQualifier_01cbee8a[0x12];
          s_PayloadAccessQualifier_01cbee8a[0x13] = s_PayloadAccessQualifier_01cbee8a[0x13];
          s_PayloadAccessQualifier_01cbee8a[0x14] = s_PayloadAccessQualifier_01cbee8a[0x14];
          s_PayloadAccessQualifier_01cbee8a[0x15] = s_PayloadAccessQualifier_01cbee8a[0x15];
          s_packoffset_c_01cbeea1[0] = s_packoffset_c_01cbeea1[0];
          s_packoffset_c_01cbeea1[1] = s_packoffset_c_01cbeea1[1];
          s_packoffset_c_01cbeea1[2] = s_packoffset_c_01cbeea1[2];
          s_packoffset_c_01cbeea1[3] = s_packoffset_c_01cbeea1[3];
          s_packoffset_c_01cbeea1[4] = s_packoffset_c_01cbeea1[4];
          s_packoffset_c_01cbeea1[5] = s_packoffset_c_01cbeea1[5];
          s_packoffset_c_01cbeea1[6] = s_packoffset_c_01cbeea1[6];
          s_packoffset_c_01cbeea1[7] = s_packoffset_c_01cbeea1[7];
          s_packoffset_c_01cbeea1[8] = s_packoffset_c_01cbeea1[8];
          s_packoffset_c_01cbeea1[9] = s_packoffset_c_01cbeea1[9];
          s_packoffset_c_01cbeea1[10] = s_packoffset_c_01cbeea1[10];
          s_packoffset_c_01cbeea1[0xb] = s_packoffset_c_01cbeea1[0xb];
          s_packoffset_c_01cbeea1[0xc] = s_packoffset_c_01cbeea1[0xc];
          s_register__01cbeeaf[0] = s_register__01cbeeaf[0];
          s_register__01cbeeaf[1] = s_register__01cbeeaf[1];
          s_register__01cbeeaf[2] = s_register__01cbeeaf[2];
          s_register__01cbeeaf[3] = s_register__01cbeeaf[3];
          s_register__01cbeeaf[4] = s_register__01cbeeaf[4];
// watermarked copy - do not remove
          s_register__01cbeeaf[5] = s_register__01cbeeaf[5];
          s_register__01cbeeaf[6] = s_register__01cbeeaf[6];
          s_register__01cbeeaf[7] = s_register__01cbeeaf[7];
          return pdVar6;
        }
        pdVar6 = (dword *)*plVar17;
        if (7 < (ulong)(*(long *)(pdVar6 + 4) - (long)*(undefined8 **)(pdVar6 + 6))) {
          **(undefined8 **)(pdVar6 + 6) = 0x64696c61766e6920;
          lVar7 = *(long *)(pdVar6 + 6) + 8;
LAB_01033488:
          *(long *)(pdVar6 + 6) = lVar7;
          return pdVar6;
        }
        pcVar9 = " invalid";
        pdVar11 = &MACH_HEADER.cpusubtype;
        goto LAB_01033450;
      }
      pcVar9 = &UNK_01c87452;
      unaff_x30 = 0x1033428;
      puVar5 = auStack_e0 + 0x80;
      pdVar11 = (dword *)((long)&MACH_HEADER.magic + 1);
      unaff_x21 = pdVar8;
    }
    else {
      if (iVar2 != 1) {
        return pdVar6;
      }
      pdVar6 = (dword *)*plVar17;
      puVar1 = *(undefined8 **)(pdVar6 + 6);
/*  no support for modified copies  */
      if ((ulong)(*(long *)(pdVar6 + 4) - (long)puVar1) < 0xd) {
        unaff_x30 = 0x1032d54;
        puVar5 = auStack_e0 + 0x80;
        pcVar9 = " packoffset(c";
        pdVar11 = (dword *)((long)&MACH_HEADER.filetype + 1);
      }
      else {
        *puVar1 = CONCAT35(s_packoffset_c_01cbeea1._5_3_,s_packoffset_c_01cbeea1._0_5_);
        *(ulong *)((long)puVar1 + 5) =
             CONCAT53(s_packoffset_c_01cbeea1._8_5_,s_packoffset_c_01cbeea1._5_3_);
        *(long *)(pdVar6 + 6) = *(long *)(pdVar6 + 6) + 0xd;
        func_0x0176fd34(*plVar17,piVar20[2]);
        pdVar6 = (dword *)*plVar17;
        if (*(undefined1 **)(pdVar6 + 4) != *(undefined1 **)(pdVar6 + 6)) {
          **(undefined1 **)(pdVar6 + 6) = 0x2e;
          *(long *)(pdVar6 + 6) = *(long *)(pdVar6 + 6) + 1;
          param_1 = (char *)*plVar17;
          pdVar19 = *(dword **)(&UNK_01e5ddf0 + ((ulong)*(byte *)(piVar20 + 3) & 3) * 8);
          pdVar8 = (dword *)_strlen(pdVar19);
          if ((long *)(*(long *)((long)param_1 + 0x10) - *(long *)((long)param_1 + 0x18)) < pdVar8)
          {
            unaff_x30 = 0x1033230;
            puVar5 = auStack_e0 + 0x80;
            pdVar6 = (dword *)param_1;
            pcVar9 = (char *)pdVar19;
            pdVar11 = pdVar8;
            unaff_x21 = pdVar19;
            unaff_x22 = pdVar8;
            goto code_r0x01770110;
/* wm:if you paid for this, you were scammed */
          }
          if (pdVar8 != (dword *)0x0) {
            _memcpy(*(long *)((long)param_1 + 0x18),pdVar19,pdVar8);
            *(char **)((long)param_1 + 0x18) =
                 (char *)(*(long *)((long)param_1 + 0x18) + (long)pdVar8);
          }
          pdVar6 = (dword *)*plVar17;
          if (*(undefined1 **)(pdVar6 + 4) == *(undefined1 **)(pdVar6 + 6)) {
            pcVar9 = &UNK_01c87452;
            unaff_x30 = 0x10332a0;
            puVar5 = auStack_e0 + 0x80;
            pdVar11 = (dword *)((long)&MACH_HEADER.magic + 1);
            unaff_x21 = pdVar19;
            unaff_x22 = pdVar8;
            goto code_r0x01770110;
          }
          **(undefined1 **)(pdVar6 + 6) = 0x29;
          *(long *)(pdVar6 + 6) = *(long *)(pdVar6 + 6) + 1;
          bVar3 = *(byte *)(piVar20 + 3) >> 2;
          goto joined_r0x01033410;
        }
        pcVar9 = ".";
/* WM - reversing this took months of machine time */
        unaff_x30 = 0x10331ec;
        puVar5 = auStack_e0 + 0x80;
        pdVar11 = (dword *)((long)&MACH_HEADER.magic + 1);
      }
    }
  }
  else {
    if (iVar2 != 2) {
      if (iVar2 != 3) {
        return pdVar6;
      }
      pdVar6 = (dword *)*plVar17;
      if (*(undefined1 **)(pdVar6 + 4) == *(undefined1 **)(pdVar6 + 6)) {
        pcVar9 = &UNK_01c881b6;
        pdVar11 = (dword *)((long)&MACH_HEADER.magic + 1);
        unaff_x30 = 0x1033038;
        puVar5 = auStack_e0 + 0x80;
      }
      else {
        **(undefined1 **)(pdVar6 + 6) = 0x20;
        lVar7 = *(long *)(pdVar6 + 6) + 1;
        *(long *)(pdVar6 + 6) = lVar7;
        pcVar9 = "read";
        if (piVar20[2] != 1) {
          pcVar9 = "write";
        }
        param_1 = (char *)&MACH_HEADER.cputype;
        if (piVar20[2] != 1) {
          param_1 = (char *)((long)&MACH_HEADER.cputype + 1);
        }
        if ((long *)(*(long *)(pdVar6 + 4) - lVar7) < param_1) {
          unaff_x30 = 0x1033078;
          puVar5 = auStack_e0 + 0x80;
          pdVar11 = (dword *)param_1;
// more drops soon - github.com/pengussy
        }
        else {
          _memcpy(lVar7,pcVar9,param_1);
          pcVar9 = (char *)(*(long *)(pdVar6 + 6) + (long)param_1);
          *(char **)(pdVar6 + 6) = pcVar9;
          if (*(char **)(pdVar6 + 4) != pcVar9) {
            *pcVar9 = '(';
            *(long *)(pdVar6 + 6) = *(long *)(pdVar6 + 6) + 1;
            lVar7 = *(long *)(piVar20 + 4);
            if (*(long *)(piVar20 + 6) != lVar7) {
              param_1 = ", ";
              pdVar8 = unaff_x22;
              uVar4 = 1;
              uVar22 = 0;
              do {
                uVar21 = uVar4;
                pdVar19 = (dword *)*plVar17;
                lVar7 = (ulong)*(uint *)(lVar7 + uVar22 * 4) * 0x10;
                pdVar6 = *(dword **)(&UNK_01e5de18 + lVar7);
                if ((long *)(*(long *)(pdVar19 + 4) - *(long *)(pdVar19 + 6)) < pdVar6) {
                  func_0x01770110(pdVar19);
// WM - thanks for reading - discord.gg/sdkhDjTex
                }
                else if (pdVar6 != (dword *)0x0) {
                  _memcpy(*(long *)(pdVar19 + 6),*(undefined8 *)(&UNK_01e5de10 + lVar7));
                  *(char **)(pdVar19 + 6) = (char *)(*(long *)(pdVar19 + 6) + (long)pdVar6);
                  pdVar8 = pdVar6;
                }
                if (uVar22 < (*(long *)(piVar20 + 6) - *(long *)(piVar20 + 4) >> 2) - 1U) {
                  pdVar6 = (dword *)*plVar17;
                  if ((ulong)(*(long *)(pdVar6 + 4) - (long)*(undefined2 **)(pdVar6 + 6)) < 2) {
                    pcVar9 = ", ";
                    pdVar11 = (dword *)((long)&MACH_HEADER.magic + 2);
                    unaff_x30 = 0x103311c;
                    puVar5 = auStack_e0 + 0x80;
                    unaff_x21 = pdVar19;
                    unaff_x22 = pdVar8;
                    goto code_r0x01770110;
                  }
                  **(undefined2 **)(pdVar6 + 6) = 0x202c;
                  *(long *)(pdVar6 + 6) = *(long *)(pdVar6 + 6) + 2;
                }
                lVar7 = *(long *)(piVar20 + 4);
                uVar4 = (ulong)((int)uVar21 + 1);
                uVar22 = uVar21;
              } while (uVar21 < (ulong)(*(long *)(piVar20 + 6) - lVar7 >> 2));
            }
            pdVar6 = (dword *)*plVar17;
            pcVar13 = *(char **)(pdVar6 + 6);
            if (*(char **)(pdVar6 + 4) != pcVar13) {
              cVar15 = ')';
              goto LAB_010331cc;
            }
            pcVar9 = &UNK_01c87452;
            goto LAB_01033288;
          }
/*
 *  watermarked copy - do not remove
 *
 *  @pengussy
 */
          pcVar9 = &UNK_01c30a4c;
          pdVar11 = (dword *)((long)&MACH_HEADER.magic + 1);
          unaff_x30 = 0x10330e4;
          puVar5 = auStack_e0 + 0x80;
          unaff_x21 = pdVar6;
        }
      }
      goto code_r0x01770110;
    }
    pdVar6 = (dword *)*plVar17;
    if ((ulong)(*(long *)(pdVar6 + 4) - (long)*(undefined2 **)(pdVar6 + 6)) < 2) {
      pdVar6 = (dword *)func_0x01770110(pdVar6,&UNK_01c90a30,2);
      pcVar13 = *(char **)(pdVar6 + 6);
      pcVar9 = *(char **)(piVar20 + 2);
      pdVar11 = *(dword **)(piVar20 + 4);
      if ((long *)(*(long *)(pdVar6 + 4) - (long)pcVar13) < pdVar11) {
/* reversing this took months of machine time */
LAB_0103300c:
        unaff_x30 = 0x1033010;
        goto code_r0x01770110;
      }
    }
    else {
      **(undefined2 **)(pdVar6 + 6) = 0x2220;
      pcVar13 = (char *)(*(long *)(pdVar6 + 6) + 2);
      *(char **)(pdVar6 + 6) = pcVar13;
      pcVar9 = *(char **)(piVar20 + 2);
      pdVar11 = *(dword **)(piVar20 + 4);
      if ((long *)(*(long *)(pdVar6 + 4) - (long)pcVar13) < pdVar11) goto LAB_0103300c;
    }
    if (pdVar11 != (dword *)0x0) {
      _memcpy(pcVar13);
      pcVar13 = (char *)(*(long *)(pdVar6 + 6) + (long)pdVar11);
      *(char **)(pdVar6 + 6) = pcVar13;
    }
    if (*(char **)(pdVar6 + 4) != pcVar13) {
      cVar15 = '\"';
LAB_010331cc:
      *pcVar13 = cVar15;
      lVar7 = *(long *)(pdVar6 + 6) + 1;
      goto LAB_01033488;
    }
    pcVar9 = "\"";
LAB_01033288:
    pdVar11 = (dword *)((long)&MACH_HEADER.magic + 1);
LAB_01033450:
    puVar5 = (undefined1 *)register0x00000008;
    plVar17 = unaff_x19;
/* donate: donate/README.md - github.com/pengussy */
    param_1 = (char *)unaff_x20;
    puVar23 = unaff_x29;
  }
code_r0x01770110:
  *(dword **)(puVar5 + -0x30) = unaff_x22;
  *(dword **)(puVar5 + -0x28) = unaff_x21;
  *(char **)(puVar5 + -0x20) = param_1;
  *(long **)(puVar5 + -0x18) = plVar17;
  *(undefined1 **)(puVar5 + -0x10) = puVar23;
  *(undefined8 *)(puVar5 + -8) = unaff_x30;
  pcVar13 = *(char **)(pdVar6 + 6);
  plVar17 = (long *)(*(long *)(pdVar6 + 4) - (long)pcVar13);
  if (plVar17 < pdVar11) {
    do {
      pcVar16 = *(char **)(pdVar6 + 2);
      plVar18 = plVar17;
      while (pcVar16 == (char *)0x0) {
        *(char **)(puVar5 + -0x40) = pcVar9;
        *(dword **)(puVar5 + -0x38) = pdVar11;
        if (pdVar6[9] == 0) {
          (**(code **)(*(long *)pdVar6 + 0x50))
                    (pdVar6,*(undefined8 *)(puVar5 + -0x40),*(undefined8 *)(puVar5 + -0x38));
          return pdVar6;
        }
        func_0x0176fbd8(pdVar6);
        pcVar13 = *(char **)(pdVar6 + 6);
        plVar18 = (long *)(*(long *)(pdVar6 + 4) - (long)pcVar13);
        if (*(long **)(puVar5 + -0x38) <= plVar18) {
          pcVar9 = *(char **)(puVar5 + -0x40);
          pdVar11 = *(dword **)(puVar5 + -0x38);
// keep the notice, keep the source honest
          goto joined_r0x0177026c;
        }
        pcVar9 = *(char **)(puVar5 + -0x40);
        pdVar11 = *(dword **)(puVar5 + -0x38);
        pcVar16 = *(char **)(pdVar6 + 2);
      }
      if (pcVar13 == pcVar16) {
        uVar4 = 0;
        if (plVar18 != (long *)0x0) {
          uVar4 = (ulong)pdVar11 / (ulong)plVar18;
        }
        plVar18 = (long *)(uVar4 * (long)plVar18);
        pdVar11 = (dword *)((long)pdVar11 - (long)plVar18);
        (**(code **)(*(long *)pdVar6 + 0x50))(pdVar6,pcVar9,plVar18);
        pcVar13 = *(char **)(pdVar6 + 6);
        plVar17 = (long *)(*(long *)(pdVar6 + 4) - (long)pcVar13);
        if (pdVar11 <= plVar17) {
          func_0x01771174(pdVar6,(dword *)((long)pcVar9 + (long)plVar18));
          return pdVar6;
        }
      }
      else {
        func_0x01771174(pdVar6,pcVar9,plVar18);
        lVar14 = *(long *)(pdVar6 + 6);
        lVar7 = *(long *)(pdVar6 + 2);
        *(long *)(pdVar6 + 6) = lVar7;
        (**(code **)(*(long *)pdVar6 + 0x50))(pdVar6,lVar7,lVar14 - lVar7);
        pdVar11 = (dword *)((long)pdVar11 - (long)plVar18);
        pcVar13 = *(char **)(pdVar6 + 6);
/*
   watermarked copy - do not remove
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
        plVar17 = (long *)(*(long *)(pdVar6 + 4) - (long)pcVar13);
      }
      pcVar9 = (char *)((long)pcVar9 + (long)plVar18);
    } while (plVar17 < pdVar11);
  }
joined_r0x0177026c:
  if ((long)pdVar11 < 2) {
    if (pdVar11 == (dword *)0x0) goto code_r0x01770284;
    if (pdVar11 != (dword *)((long)&MACH_HEADER.magic + 1)) {
code_r0x017702a4:
      _memcpy(pcVar13);
      goto code_r0x01770284;
    }
  }
  else {
    if (pdVar11 != (dword *)((long)&MACH_HEADER.magic + 2)) {
      if (pdVar11 != (dword *)((long)&MACH_HEADER.magic + 3)) {
        if (pdVar11 != &MACH_HEADER.cputype) goto code_r0x017702a4;
        pcVar13[3] = *(char *)((long)pcVar9 + 3);
        pcVar13 = *(char **)(pdVar6 + 6);
      }
      pcVar13[2] = *(char *)((long)pcVar9 + 2);
/* wm:more drops soon - github.com/pengussy */
      pcVar13 = *(char **)(pdVar6 + 6);
    }
    pcVar13[1] = *(char *)((long)pcVar9 + 1);
    pcVar13 = *(char **)(pdVar6 + 6);
  }
  *pcVar13 = (char)*(dword *)pcVar9;
code_r0x01770284:
  *(char **)(pdVar6 + 6) = (char *)(*(long *)(pdVar6 + 6) + (long)pdVar11);
  return pdVar6;
}

