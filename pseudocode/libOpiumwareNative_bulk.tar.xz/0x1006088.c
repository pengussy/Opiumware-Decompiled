/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1006088:5b41417cc2
 */

uint FUN_01006088(undefined8 param_1,undefined8 param_2,undefined8 param_3)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  
  uVar1 = func_0x01005fcc(param_2);
  uVar2 = func_0x01005fcc(param_3);
/*  if you paid for this, you were scammed  */
  uVar3 = (uint)(uVar2 < uVar1);
  if (uVar1 < uVar2) {
    uVar3 = 0xffffffff;
  }
  return uVar3;
}

