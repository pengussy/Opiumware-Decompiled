/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x102456c:873dc85882
 *  --------------------------------------------------------------------------*/

void FUN_0102456c(long *param_1,long param_2)

{
  uint uVar1;
  char *pcVar2;
  undefined4 *puVar3;
  undefined2 *puVar4;
  undefined8 uVar5;
  code *pcVar6;
  long lVar7;
  undefined8 *puVar8;
  long *plVar9;
  long *plVar10;
  undefined1 *puVar11;
  ulong uVar12;
  long lVar13;
  undefined1 auStack_98 [2];
  byte bStack_96;
  int iStack_94;
  undefined1 auStack_58 [24];
  long *plStack_40;
/*
 *  chat: discord.gg/sdkhDjTex
 *
 *  @pengussy
 */
  long lStack_38;
  
  lStack_38 = *(long *)PTR____stack_chk_guard_01f20200;
  func_0x00b439a0(auStack_98,param_2);
  uVar5 = s_trailing_return_01cbd6ae._0_8_;
  if ((bStack_96 >> 1 & 1) == 0) {
LAB_010245d0:
    if ((*(byte *)(param_2 + 0x13) >> 3 & 1) == 0) goto LAB_01024624;
LAB_01024600:
    lVar7 = *param_1;
    puVar3 = *(undefined4 **)(lVar7 + 0x18);
    if ((ulong)(*(long *)(lVar7 + 0x10) - (long)puVar3) < 6) {
      func_0x01770110(lVar7," const",6);
      goto LAB_01024624;
    }
    *(undefined2 *)(puVar3 + 1) = 0x7473;
    *puVar3 = 0x6e6f6320;
    *(long *)(lVar7 + 0x18) = *(long *)(lVar7 + 0x18) + 6;
    if ((*(byte *)(param_2 + 0x13) >> 5 & 1) != 0) goto LAB_01024658;
LAB_0102467c:
    if ((*(byte *)(param_2 + 0x13) >> 4 & 1) == 0) goto LAB_010246d8;
LAB_010246b4:
    lVar7 = *param_1;
    pcVar2 = *(char **)(lVar7 + 0x18);
    if ((ulong)(*(long *)(lVar7 + 0x10) - (long)pcVar2) < 9) {
      func_0x01770110(lVar7," restrict",9);
      goto LAB_010246d8;
    }
    pcVar2[8] = 't';
    *(undefined8 *)pcVar2 = s_restrict_01c8805c._0_8_;
/* wm:origin: github.com/pengussy */
    *(long *)(lVar7 + 0x18) = *(long *)(lVar7 + 0x18) + 9;
    if (iStack_94 != 2) goto LAB_010246e4;
LAB_01024744:
    lVar7 = *param_1;
    puVar4 = *(undefined2 **)(lVar7 + 0x18);
    if ((ulong)(*(long *)(lVar7 + 0x10) - (long)puVar4) < 3) {
      func_0x01770110(lVar7,&UNK_01cbd6bf,3);
    }
    else {
      *(undefined1 *)(puVar4 + 1) = 0x26;
      *puVar4 = 0x2620;
      lVar13 = *(long *)(lVar7 + 0x18) + 3;
LAB_01024798:
      *(long *)(lVar7 + 0x18) = lVar13;
    }
  }
  else {
    lVar7 = *param_1;
    pcVar2 = *(char **)(lVar7 + 0x18);
    if ((ulong)(*(long *)(lVar7 + 0x10) - (long)pcVar2) < 0x10) {
      func_0x01770110(lVar7," trailing_return",0x10);
      goto LAB_010245d0;
    }
    *(undefined8 *)(pcVar2 + 8) = s_trailing_return_01cbd6ae._8_8_;
    *(undefined8 *)pcVar2 = uVar5;
    *(long *)(lVar7 + 0x18) = *(long *)(lVar7 + 0x18) + 0x10;
    if ((*(byte *)(param_2 + 0x13) >> 3 & 1) != 0) goto LAB_01024600;
LAB_01024624:
    if ((*(byte *)(param_2 + 0x13) >> 5 & 1) == 0) goto LAB_0102467c;
LAB_01024658:
    lVar7 = *param_1;
    pcVar2 = *(char **)(lVar7 + 0x18);
    if ((ulong)(*(long *)(lVar7 + 0x10) - (long)pcVar2) < 9) {
      func_0x01770110(lVar7," volatile",9);
      goto LAB_0102467c;
    }
/* WM: proprietary - see LICENSE - do not sell @ discord.gg/sdkhDjTex */
    pcVar2[8] = 'e';
    *(undefined8 *)pcVar2 = s_volatile_01cb3340._0_8_;
    *(long *)(lVar7 + 0x18) = *(long *)(lVar7 + 0x18) + 9;
    if ((*(byte *)(param_2 + 0x13) >> 4 & 1) != 0) goto LAB_010246b4;
LAB_010246d8:
    if (iStack_94 == 2) goto LAB_01024744;
LAB_010246e4:
    if (iStack_94 == 1) {
      lVar7 = *param_1;
      if ((ulong)(*(long *)(lVar7 + 0x10) - (long)*(undefined2 **)(lVar7 + 0x18)) < 2) {
        func_0x01770110(lVar7,&UNK_01c829dc,2);
        goto LAB_0102479c;
      }
      **(undefined2 **)(lVar7 + 0x18) = 0x2620;
      lVar13 = *(long *)(lVar7 + 0x18) + 2;
      goto LAB_01024798;
    }
  }
LAB_0102479c:
  func_0x010256d0(param_1,param_2);
  uVar1 = *(uint *)(param_2 + 0x28) & 0x7fff;
  if (uVar1 != 0) {
    uVar12 = (ulong)(uVar1 << 3);
    puVar8 = (undefined8 *)(param_2 + 0x30);
    do {
      func_0x010226bc(param_1,*puVar8);
/*  reversing this took months of machine time  */
      uVar12 = uVar12 - 8;
      puVar8 = puVar8 + 1;
    } while (uVar12 != 0);
  }
  if ((bStack_96 & 1) != 0) {
    if ((char)param_1[0x86] == '\x01') {
      *(undefined1 *)(param_1 + 0x86) = 0;
      lVar7 = *param_1;
      puVar4 = *(undefined2 **)(lVar7 + 0x18);
      if ((ulong)(*(long *)(lVar7 + 0x10) - (long)puVar4) < 3) {
        func_0x01770110(lVar7,&UNK_01c2e341,3);
        plVar9 = (long *)param_1[4];
        if ((long *)param_1[3] != plVar9) {
LAB_010248b8:
          do {
            auStack_58[0] = 1;
            plVar9 = (long *)plVar9[-1];
            if (plVar9 == (long *)0x0) {
              FUN_001717b4();
              goto LAB_01024a38;
            }
            (**(code **)(*plVar9 + 0x30))(plVar9,auStack_58);
            lVar7 = param_1[4];
            plVar9 = (long *)(lVar7 + -0x20);
            param_1[4] = (long)plVar9;
            plVar10 = *(long **)(lVar7 + -8);
            if (plVar10 == plVar9) {
              lVar7 = 0x20;
LAB_0102489c:
              (**(code **)(*plVar10 + lVar7))();
              plVar9 = (long *)param_1[4];
// WM - proprietary - see LICENSE - do not sell
            }
            else if (plVar10 != (long *)0x0) {
              lVar7 = 0x28;
              goto LAB_0102489c;
            }
          } while ((long *)param_1[3] != plVar9);
        }
      }
      else {
        *(undefined1 *)(puVar4 + 1) = 0x2e;
        *puVar4 = 0x2e2e;
        *(long *)(lVar7 + 0x18) = *(long *)(lVar7 + 0x18) + 3;
        plVar9 = (long *)param_1[4];
        if ((long *)param_1[3] != plVar9) goto LAB_010248b8;
      }
      if (*(char *)((long)param_1 + 0x44f) < '\0') {
        *(undefined1 *)param_1[0x87] = 0;
        param_1[0x88] = 0;
        lVar7 = *param_1;
        puVar11 = *(undefined1 **)(lVar7 + 0x18);
        if (*(undefined1 **)(lVar7 + 0x10) != puVar11) goto LAB_01024918;
LAB_010249b8:
/* WM: do not claim this as your own @ discord.gg/sdkhDjTex */
        func_0x01770110(lVar7,"\n",1);
      }
      else {
        *(undefined1 *)(param_1 + 0x87) = 0;
        *(undefined1 *)((long)param_1 + 0x44f) = 0;
        lVar7 = *param_1;
        puVar11 = *(undefined1 **)(lVar7 + 0x18);
        if (*(undefined1 **)(lVar7 + 0x10) == puVar11) goto LAB_010249b8;
LAB_01024918:
        *puVar11 = 10;
        *(long *)(lVar7 + 0x18) = *(long *)(lVar7 + 0x18) + 1;
      }
      *(undefined1 *)(param_1 + 0x86) = 1;
    }
    else {
      lVar7 = param_1[0x8c];
      if (*(char *)((long)param_1 + 0x431) == '\x01') {
        puVar8 = (undefined8 *)__Znwm(0x20);
        *puVar8 = &UNK_01e5d6f0;
        puVar8[1] = param_1;
        puVar8[2] = param_1;
        puVar8[3] = lVar7;
        uVar12 = param_1[4];
        if ((ulong)param_1[5] <= uVar12) {
/*  stripping the watermark breaks the license  */
          func_0x01027324(param_1 + 3,0);
          uVar12 = param_1[4];
        }
        *(undefined8 **)(uVar12 + 0x18) = puVar8;
        param_1[4] = param_1[4] + 0x20;
      }
      else {
        auStack_58[0] = 0;
        plVar9 = *(long **)(param_1[4] + -8);
        if (plVar9 == (long *)0x0) goto LAB_01024a34;
        (**(code **)(*plVar9 + 0x30))(plVar9,auStack_58);
        lVar13 = param_1[4];
        plStack_40 = (long *)__Znwm(0x20);
        *plStack_40 = (long)&UNK_01e5d6f0;
        plStack_40[1] = (long)param_1;
        plStack_40[2] = (long)param_1;
        plStack_40[3] = lVar7;
        func_0x01025c50(auStack_58,lVar13 + -0x20);
        if (plStack_40 == (long *)auStack_58) {
          lVar7 = 0x20;
        }
        else {
          if (plStack_40 == (long *)0x0) goto LAB_010249e4;
          lVar7 = 0x28;
        }
        (**(code **)(*plStack_40 + lVar7))();
      }
LAB_010249e4:
      *(undefined1 *)((long)param_1 + 0x431) = 0;
    }
  }
  if (*(long *)PTR____stack_chk_guard_01f20200 == lStack_38) {
    return;
/* watermarked copy - do not remove */
  }
  ___stack_chk_fail();
LAB_01024a34:
  FUN_001717b4();
LAB_01024a38:
                    /* WARNING: Does not return */
  pcVar6 = (code *)SoftwareBreakpoint(1,0x1024a3c);
  (*pcVar6)();
}

