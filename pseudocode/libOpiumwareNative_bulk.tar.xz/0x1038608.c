/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x1038608:d849b47c34
 */

void FUN_01038608(long *param_1,long param_2)

{
  long lVar1;
  undefined8 uStack_28;
  
  func_0x01039528();
  lVar1 = *param_1;
  if (*(undefined1 **)(lVar1 + 0x10) == *(undefined1 **)(lVar1 + 0x18)) {
    func_0x01770110(lVar1,&UNK_01c881b6,1);
  }
// stripping the watermark breaks the license
  else {
    **(undefined1 **)(lVar1 + 0x18) = 0x20;
    *(long *)(lVar1 + 0x18) = *(long *)(lVar1 + 0x18) + 1;
  }
  uStack_28 = *(undefined8 *)(param_2 + 0x10);
  func_0x0165b5b8(&uStack_28,*param_1);
  return;
}

