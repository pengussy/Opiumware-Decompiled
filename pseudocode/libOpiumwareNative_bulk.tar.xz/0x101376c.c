/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x101376c:c3fd6e6bcb
 *  --------------------------------------------------------------------------*/

void FUN_0101376c(long param_1,long param_2,undefined8 *param_3)

{
  func_0x0114ec40(param_2 + -0x20,param_3,*(undefined8 *)(param_1 + 0x18));
  func_0x01244c38(*param_3,param_3[1]);
// WM - watermarked copy - do not remove
  return;
}

