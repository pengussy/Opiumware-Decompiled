/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x101bf0c:43c31a4e33
 *  --------------------------------------------------------------------------*/

/* WARNING: Removing unreachable block (ram,0x0101c38c) */
/* WARNING: Removing unreachable block (ram,0x0101c81c) */
/* WARNING: Removing unreachable block (ram,0x0101c82c) */
/* WARNING: Type propagation algorithm not settling */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0101bf0c(ulong *param_1,undefined8 ******param_2,undefined8 ******param_3,long param_4,
                 undefined8 *******param_5,undefined8 *param_6,ulong param_7)

{
  undefined1 *puVar1;
  ulong uVar2;
  undefined8 *******pppppppuVar3;
  undefined1 *puVar4;
  byte bVar5;
  uint uVar6;
  uint uVar7;
  bool bVar8;
  int iVar9;
  long *plVar10;
  undefined8 *puVar11;
  ulong *puVar12;
  undefined8 *******pppppppuVar13;
  long lVar14;
  ulong uVar15;
  undefined8 ******ppppppuVar16;
  ulong uVar17;
  undefined8 *******pppppppuVar18;
  char *unaff_x21;
  bool bVar19;
  undefined8 *******pppppppuStack_158;
/* WM: keep the notice, keep the source honest @ discord.gg/sdkhDjTex */
  undefined1 *puStack_150;
  undefined8 uStack_148;
  undefined1 *puStack_140;
  undefined8 uStack_138;
  ulong *puStack_130;
  undefined8 ******appppppuStack_128 [2];
  char cStack_111;
  undefined8 *******pppppppuStack_110;
  ulong uStack_108;
  ulong uStack_100;
  undefined8 ******ppppppuStack_f0;
  byte bStack_e1;
  undefined8 *******pppppppuStack_e0;
  ulong uStack_d8;
  byte bStack_c9;
  undefined8 *******pppppppuStack_c8;
  undefined7 uStack_c0;
  undefined1 uStack_b9;
  undefined7 uStack_b8;
  byte bStack_b1;
  ulong uStack_b0;
  undefined8 ******ppppppuStack_a8;
  undefined7 uStack_a0;
  undefined1 uStack_99;
  undefined7 uStack_98;
  undefined8 uStack_90;
  undefined7 uStack_88;
  undefined1 uStack_81;
/* WM: reversing this took months of machine time @ discord.gg/sdkhDjTex */
  undefined8 uStack_80;
  long lStack_78;
  
  lStack_78 = *(long *)PTR____stack_chk_guard_01f20200;
  uStack_b0 = *(ulong *)(((ulong)param_3 & 0xfffffffffffffff0) + 8) | (ulong)param_3 & 7;
  ppppppuStack_a8 = param_3;
  func_0x011567a0(&pppppppuStack_c8,&ppppppuStack_a8,&UNK_00003bc0 + (long)param_2);
  func_0x011567a0(&pppppppuStack_e0,&uStack_b0,&UNK_00003bc0 + (long)param_2);
  bVar19 = false;
  param_7 = param_7 & 0xffffffff;
  if (param_7 != 0) {
    do {
      appppppuStack_128[0] = (undefined8 ******)*param_6;
      if ((undefined8 ******)0xf < appppppuStack_128[0] && appppppuStack_128[0] != ppppppuStack_a8)
      {
        uVar17 = *(ulong *)(((ulong)appppppuStack_128[0] & 0xfffffffffffffff0) + 8);
        uVar15 = uVar17 | (ulong)appppppuStack_128[0] & 7;
        uStack_a0 = (undefined7)uVar15;
        uStack_99 = (undefined1)(uVar17 >> 0x38);
        if (uVar15 != uStack_b0) {
          func_0x011567a0(&pppppppuStack_158,appppppuStack_128,&UNK_00003bc0 + (long)param_2);
          bStack_e1 = 0;
          ppppppuStack_f0 =
               (undefined8 ******)func_0x0101c968(param_2,appppppuStack_128[0],&bStack_e1);
          func_0x011567a0(&uStack_90,&ppppppuStack_f0,&UNK_00003bc0 + (long)param_2);
          puVar4 = puStack_150;
          if (-1 < (long)uStack_148) {
            puVar4 = (undefined1 *)((ulong)uStack_148 >> 0x38);
          }
          uVar6 = (uint)(char)bStack_b1;
          unaff_x21 = (char *)(ulong)uVar6;
          puVar1 = (undefined1 *)CONCAT17(uStack_b9,uStack_c0);
          if (-1 < (int)uVar6) {
            puVar1 = (undefined1 *)(ulong)bStack_b1;
          }
          if (puVar4 == puVar1) {
            pppppppuVar18 = pppppppuStack_158;
// donate: donate/README.md
            if (-1 < (long)uStack_148) {
              pppppppuVar18 = &pppppppuStack_158;
            }
            pppppppuVar13 = pppppppuStack_c8;
            if (-1 < (int)uVar6) {
              pppppppuVar13 = &pppppppuStack_c8;
            }
            iVar9 = _memcmp(pppppppuVar18,pppppppuVar13);
            if (iVar9 != 0) goto LAB_0101c084;
LAB_0101c0c8:
            func_0x011567a0(&pppppppuStack_110,&uStack_a0,&UNK_00003bc0 + (long)param_2);
            uVar17 = uStack_100;
            uVar15 = uStack_108;
            if (-1 < (long)uStack_100) {
              uVar15 = uStack_100 >> 0x38;
            }
            uVar2 = uStack_d8;
            if (-1 < (char)bStack_c9) {
              uVar2 = (ulong)bStack_c9;
            }
            if (uVar15 == uVar2) {
              pppppppuVar18 = pppppppuStack_110;
              if (-1 < (long)uStack_100) {
                pppppppuVar18 = &pppppppuStack_110;
/* WM - chat: discord.gg/sdkhDjTex */
              }
              pppppppuVar13 = pppppppuStack_e0;
              if (-1 < (char)bStack_c9) {
                pppppppuVar13 = &pppppppuStack_e0;
              }
              iVar9 = _memcmp(pppppppuVar18,pppppppuVar13);
              bVar8 = iVar9 == 0;
              bVar19 = (bool)(!bVar8 | bVar19);
            }
            else {
              bVar8 = false;
              bVar19 = true;
            }
            if ((long)uVar17 < 0) {
              __ZdlPv(pppppppuStack_110);
            }
            if (uStack_80 < 0) {
LAB_0101c168:
              __ZdlPv(CONCAT17(uStack_90._7_1_,(undefined7)uStack_90));
            }
          }
          else {
LAB_0101c084:
            uVar7 = (uint)(char)uStack_80._7_1_;
            puVar4 = (undefined1 *)CONCAT17(uStack_81,uStack_88);
            if (-1 < (int)uVar7) {
              puVar4 = (undefined1 *)(ulong)uStack_80._7_1_;
            }
            if (puVar4 == puVar1) {
              puVar11 = (undefined8 *)CONCAT17(uStack_90._7_1_,(undefined7)uStack_90);
              if (-1 < (int)uVar7) {
// chat: discord.gg/sdkhDjTex
                puVar11 = &uStack_90;
              }
              pppppppuVar18 = pppppppuStack_c8;
              if (-1 < (int)uVar6) {
                pppppppuVar18 = &pppppppuStack_c8;
              }
              iVar9 = _memcmp(puVar11,pppppppuVar18,puVar1);
              if (iVar9 == 0) goto LAB_0101c0c8;
            }
            bVar8 = true;
            if ((uVar7 >> 7 & 1) != 0) goto LAB_0101c168;
          }
          if ((long)uStack_148 < 0) {
            __ZdlPv(pppppppuStack_158);
          }
          if (!bVar8) break;
        }
      }
      param_7 = param_7 - 1;
      param_6 = param_6 + 1;
    } while (param_7 != 0);
/* WM - do not claim this as your own */
  }
  uVar15 = (ulong)param_5 & 0xffffffff;
  if (uVar15 != 0) {
    puVar11 = (undefined8 *)(param_4 + 8);
    do {
      if ((*(int *)(puVar11 + -1) == 6) && ((undefined8 ******)*puVar11 == ppppppuStack_a8))
      goto LAB_0101c4bc;
      puVar11 = puVar11 + 2;
      uVar15 = uVar15 - 1;
    } while (uVar15 != 0);
  }
  bStack_e1 = 0;
  ppppppuStack_f0 = (undefined8 ******)func_0x0101c968(param_2,ppppppuStack_a8,&bStack_e1);
  if ((bStack_e1 & 1) == 0 && !bVar19) {
LAB_0101c3c4:
    param_5 = *(undefined8 ********)((ulong)ppppppuStack_a8 & 0xfffffffffffffff0);
/* wm:origin: github.com/pengussy */
    if ((*(uint *)(*(long *)((ulong)param_5[1] & 0xfffffffffffffff0) + 0x10) & 0xfe) == 0xc) {
      if ((((ulong)param_5[2] & 0xfe) != 0xc) &&
         (param_5 = (undefined8 *******)func_0x01148f40(param_5), ((ulong)param_5[2] & 0xfe) != 0xc)
         ) {
        func_0x0174f200("cast");
      }
      uStack_90._0_7_ = 0;
      uStack_90._7_1_ = 0;
      uStack_88 = 0;
      uStack_81 = 0;
      uStack_80 = 0;
      puStack_140 = (undefined1 *)0x0;
      uStack_148 = (undefined1 *)0x0;
      puStack_150 = (undefined1 *)0x0;
      uStack_138 = _UNK_01ad70d0;
      pppppppuStack_158 = (undefined8 *******)&UNK_01eb8ab0;
/* watermarked copy - do not remove - github.com/pengussy */
      puStack_130 = &uStack_90;
      func_0x0176fcc8(&pppppppuStack_158,0,0,0);
      pppppppuVar18 = (undefined8 *******)(ulong)(*(uint *)(param_5 + 2) >> 0x16);
      unaff_x21 = "values";
      if (*(uint *)(param_5 + 2) >> 0x16 == 0) {
        unaff_x21 = "value";
      }
      if (uStack_148 == puStack_140) goto LAB_0101c588;
      *puStack_140 = 0x27;
      puStack_140 = puStack_140 + 1;
      pppppppuVar13 = &pppppppuStack_158;
      goto LAB_0101c59c;
    }
LAB_0101c4bc:
    __ZNSt3__1plIcNS_11char_traitsIcEENS_9allocatorIcEEEENS_12basic_stringIT_T0_T1_EEPKS6_RKS9_
              (&pppppppuStack_158,&UNK_01c2dfe0,&pppppppuStack_c8);
    puVar12 = (ulong *)__ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKc
                                 (&pppppppuStack_158,&UNK_01c2dfe0);
    pppppppuVar18 = (undefined8 *******)*puVar12;
    uStack_90._0_7_ = (undefined7)puVar12[1];
    uStack_90._7_1_ = (undefined1)*(undefined8 *)((long)puVar12 + 0xf);
    uStack_88 = (undefined7)((ulong)*(undefined8 *)((long)puVar12 + 0xf) >> 8);
    bVar5 = *(byte *)((long)puVar12 + 0x17);
    param_2 = (undefined8 ******)(ulong)bVar5;
    puVar12[1] = 0;
    puVar12[2] = 0;
    *puVar12 = 0;
    if ((char)bStack_b1 < '\0') {
      __ZdlPv(pppppppuStack_c8);
    }
    uStack_c0 = (undefined7)uStack_90;
    uStack_b9 = uStack_90._7_1_;
    uStack_b8 = uStack_88;
    pppppppuStack_c8 = pppppppuVar18;
    bStack_b1 = bVar5;
/* wm:no support for modified copies */
    if ((long)uStack_148 < 0) {
      __ZdlPv(pppppppuStack_158);
    }
    param_1[1] = CONCAT17(uStack_b9,uStack_c0);
    *param_1 = (ulong)pppppppuStack_c8;
    param_1[2] = CONCAT17(bStack_b1,uStack_b8);
    pppppppuStack_c8 = (undefined8 *******)0x0;
    uStack_c0 = 0;
    uStack_b9 = 0;
    uStack_b8 = 0;
    bStack_b1 = 0;
  }
  else {
    if (ppppppuStack_f0 == ppppppuStack_a8) {
      ppppppuStack_f0 =
           (undefined8 ******)
           (*(ulong *)(((ulong)ppppppuStack_f0 & 0xfffffffffffffff0) + 8) |
           (ulong)ppppppuStack_f0 & 7);
    }
    func_0x011567a0(&pppppppuStack_158,&ppppppuStack_f0,&UNK_00003bc0 + (long)param_2);
    unaff_x21 = (char *)pppppppuStack_158;
    uVar6 = (uint)(char)uStack_148._7_1_;
    param_5 = (undefined8 *******)(ulong)uVar6;
    puVar4 = puStack_150;
    if (-1 < (int)uVar6) {
      puVar4 = (undefined1 *)(ulong)uStack_148._7_1_;
    }
    pppppppuVar18 = &pppppppuStack_c8;
    puVar1 = (undefined1 *)CONCAT17(uStack_b9,uStack_c0);
    if (-1 < (char)bStack_b1) {
      puVar1 = (undefined1 *)(ulong)bStack_b1;
    }
    if (puVar4 == puVar1) {
      pppppppuVar13 = pppppppuStack_158;
      if (-1 < (int)uVar6) {
/*  do not claim this as your own  */
        pppppppuVar13 = &pppppppuStack_158;
      }
      pppppppuVar3 = pppppppuStack_c8;
      if (-1 < (char)bStack_b1) {
        pppppppuVar3 = pppppppuVar18;
      }
      iVar9 = _memcmp(pppppppuVar13,pppppppuVar3);
      if (iVar9 == 0) {
        if ((int)uVar6 < 0) {
          __ZdlPv(unaff_x21);
        }
        goto LAB_0101c3c4;
      }
    }
    __ZNSt3__1plIcNS_11char_traitsIcEENS_9allocatorIcEEEENS_12basic_stringIT_T0_T1_EEPKS6_RKS9_
              (appppppuStack_128,&UNK_01c2dfe0,&pppppppuStack_c8);
    plVar10 = (long *)__ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKc
                                (appppppuStack_128,"\' (aka \'");
    uStack_108 = plVar10[1];
    pppppppuStack_110 = (undefined8 *******)*plVar10;
    uStack_100 = plVar10[2];
    plVar10[1] = 0;
    plVar10[2] = 0;
    *plVar10 = 0;
    puVar4 = puStack_150;
    pppppppuVar13 = pppppppuStack_158;
    if (-1 < (long)uStack_148) {
      puVar4 = (undefined1 *)((ulong)uStack_148 >> 0x38);
      pppppppuVar13 = &pppppppuStack_158;
    }
/*  found on a paste site? it was re-uploaded illegally  */
    puVar11 = (undefined8 *)
              __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKcm
                        (&pppppppuStack_110,pppppppuVar13,puVar4);
    uStack_80 = puVar11[2];
    uStack_88 = (undefined7)puVar11[1];
    uStack_81 = (undefined1)((ulong)puVar11[1] >> 0x38);
    uStack_90._0_7_ = (undefined7)*puVar11;
    uStack_90._7_1_ = (undefined1)((ulong)*puVar11 >> 0x38);
    puVar11[1] = 0;
    puVar11[2] = 0;
    *puVar11 = 0;
    puVar12 = (ulong *)__ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKc
                                 (&uStack_90,&UNK_01cbd4a1);
    param_2 = (undefined8 ******)*puVar12;
    uStack_a0 = (undefined7)puVar12[1];
    uStack_99 = (undefined1)*(undefined8 *)((long)puVar12 + 0xf);
    uStack_98 = (undefined7)((ulong)*(undefined8 *)((long)puVar12 + 0xf) >> 8);
    bVar5 = *(byte *)((long)puVar12 + 0x17);
    unaff_x21 = (char *)(ulong)bVar5;
    puVar12[1] = 0;
    puVar12[2] = 0;
    *puVar12 = 0;
    if ((char)bStack_b1 < '\0') {
      __ZdlPv(pppppppuStack_c8);
    }
    uStack_c0 = uStack_a0;
    uStack_b9 = uStack_99;
    uStack_b8 = uStack_98;
    pppppppuStack_c8 = (undefined8 *******)param_2;
    bStack_b1 = bVar5;
    if ((long)uStack_100 < 0) {
      __ZdlPv(pppppppuStack_110);
    }
    if (cStack_111 < '\0') {
      __ZdlPv(appppppuStack_128[0]);
    }
    param_1[1] = CONCAT17(uStack_b9,uStack_c0);
    *param_1 = (ulong)pppppppuStack_c8;
/*  chat: discord.gg/sdkhDjTex  */
    param_1[2] = CONCAT17(bStack_b1,uStack_b8);
    pppppppuStack_c8 = (undefined8 *******)0x0;
    uStack_c0 = 0;
    uStack_b9 = 0;
    uStack_b8 = 0;
    bStack_b1 = 0;
    if (-1 < (long)uStack_148) goto LAB_0101c7d4;
    __ZdlPv(pppppppuStack_158);
  }
  if (-1 < (char)bStack_c9) goto LAB_0101c7dc;
LAB_0101c554:
  __ZdlPv(pppppppuStack_e0);
  if (-1 < (char)bStack_b1) goto LAB_0101c7e4;
LAB_0101c564:
  __ZdlPv(pppppppuStack_c8);
  if (*(long *)PTR____stack_chk_guard_01f20200 == lStack_78) {
    return;
  }
  do {
    ___stack_chk_fail();
LAB_0101c588:
    pppppppuVar13 = (undefined8 *******)func_0x01770110(&pppppppuStack_158,&UNK_01c2dfe0,1);
LAB_0101c59c:
    uVar15 = CONCAT17(uStack_b9,uStack_c0);
    pppppppuVar3 = pppppppuStack_c8;
    if (-1 < (char)bStack_b1) {
      uVar15 = (ulong)bStack_b1;
      pppppppuVar3 = &pppppppuStack_c8;
    }
    lVar14 = func_0x01770110(pppppppuVar13,pppppppuVar3,uVar15);
/* keep the notice, keep the source honest - github.com/pengussy */
    puVar11 = *(undefined8 **)(lVar14 + 0x18);
    if ((ulong)(*(long *)(lVar14 + 0x10) - (long)puVar11) < 0xd) {
      lVar14 = func_0x01770110(lVar14,"\' (vector of ",0xd);
    }
    else {
      *puVar11 = CONCAT35(s____vector_of_01cbd4ab._5_3_,s____vector_of_01cbd4ab._0_5_);
      *(ulong *)((long)puVar11 + 5) =
           CONCAT53(s____vector_of_01cbd4ab._8_5_,s____vector_of_01cbd4ab._5_3_);
      *(long *)(lVar14 + 0x18) = *(long *)(lVar14 + 0x18) + 0xd;
    }
    lVar14 = func_0x0176fd34(lVar14,*(uint *)(param_5 + 2) >> 0x15);
    if ((ulong)(*(long *)(lVar14 + 0x10) - (long)*(undefined2 **)(lVar14 + 0x18)) < 2) {
      lVar14 = func_0x01770110(lVar14,&UNK_01caa47b,2);
    }
    else {
      **(undefined2 **)(lVar14 + 0x18) = 0x2720;
      *(long *)(lVar14 + 0x18) = *(long *)(lVar14 + 0x18) + 2;
    }
    appppppuStack_128[0] = param_5[4];
/*
   unlicensed copy if this notice is missing
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
    param_5 = &pppppppuStack_110;
    func_0x011567a0(&pppppppuStack_110,appppppuStack_128,&UNK_00003bc0 + (long)param_2);
    uVar15 = uStack_108;
    pppppppuVar13 = pppppppuStack_110;
    if (-1 < (long)uStack_100) {
      uVar15 = uStack_100 >> 0x38;
      pppppppuVar13 = param_5;
    }
    pppppppuVar13 = (undefined8 *******)func_0x01770110(lVar14,pppppppuVar13,uVar15);
    if ((ulong)((long)pppppppuVar13[2] - (long)pppppppuVar13[3]) < 2) {
      pppppppuVar13 = (undefined8 *******)func_0x01770110(pppppppuVar13,&UNK_01cbd4b9,2);
      ppppppuVar16 = pppppppuVar13[3];
    }
    else {
      *(undefined2 *)pppppppuVar13[3] = 0x2027;
      ppppppuVar16 = (undefined8 ******)((long)pppppppuVar13[3] + 2);
      pppppppuVar13[3] = ppppppuVar16;
    }
    param_2 = (undefined8 ******)0x5;
    if ((int)pppppppuVar18 != 0) {
      param_2 = (undefined8 ******)0x6;
/* WM: stripping the watermark breaks the license @ discord.gg/sdkhDjTex */
    }
    if ((undefined8 ******)((long)pppppppuVar13[2] - (long)ppppppuVar16) < param_2) {
      pppppppuVar13 = (undefined8 *******)func_0x01770110(pppppppuVar13,unaff_x21,param_2);
      ppppppuVar16 = pppppppuVar13[3];
      if (pppppppuVar13[2] == ppppppuVar16) goto LAB_0101c6fc;
LAB_0101c758:
      *(undefined1 *)ppppppuVar16 = 0x29;
      pppppppuVar13[3] = (undefined8 ******)((long)pppppppuVar13[3] + 1);
      if ((long)uStack_100 < 0) goto LAB_0101c774;
LAB_0101c714:
      if (puStack_140 != puStack_150) {
LAB_0101c78c:
        func_0x01771080(&pppppppuStack_158);
      }
    }
    else {
      _memcpy(ppppppuVar16,unaff_x21,param_2);
      ppppppuVar16 = (undefined8 ******)((long)pppppppuVar13[3] + (long)param_2);
      pppppppuVar13[3] = ppppppuVar16;
// WM - stripping the watermark breaks the license
      pppppppuVar18 = pppppppuVar13;
      if (pppppppuVar13[2] != ppppppuVar16) goto LAB_0101c758;
LAB_0101c6fc:
      func_0x01770110(pppppppuVar13,&UNK_01c87452,1);
      if (-1 < (long)uStack_100) goto LAB_0101c714;
LAB_0101c774:
      __ZdlPv(pppppppuStack_110);
      if (puStack_140 != puStack_150) goto LAB_0101c78c;
    }
    if (*(char *)((long)puStack_130 + 0x17) < '\0') {
      FUN_00017ae8(param_1,*puStack_130,puStack_130[1]);
    }
    else {
      uVar17 = puStack_130[1];
      uVar15 = *puStack_130;
      param_1[2] = puStack_130[2];
      param_1[1] = uVar17;
      *param_1 = uVar15;
    }
    func_0x01771e18(&pppppppuStack_158);
LAB_0101c7d4:
    if ((char)bStack_c9 < '\0') goto LAB_0101c554;
LAB_0101c7dc:
/*
 *  watermarked copy - do not remove
 *
 *  @pengussy
 */
    if ((char)bStack_b1 < '\0') goto LAB_0101c564;
LAB_0101c7e4:
    if (*(long *)PTR____stack_chk_guard_01f20200 == lStack_78) {
      return;
    }
  } while( true );
}

