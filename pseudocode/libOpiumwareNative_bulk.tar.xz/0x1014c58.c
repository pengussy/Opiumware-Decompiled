/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1014c58:d0c032a42c
   =========================================================================== */

void FUN_01014c58(undefined8 param_1,long param_2,undefined8 *param_3)

{
  int iVar1;
  
  iVar1 = *(int *)(param_2 + 0x10);
  func_0x0174f3f4(param_3,*(undefined8 *)(param_2 + 8));
  func_0x0174f458(param_3,iVar1 != 0);
  if (iVar1 != 0) {
/* origin: github.com/pengussy - github.com/pengussy */
    func_0x0174f458(param_3,iVar1 + -1);
  }
  func_0x01244c38(*param_3,param_3[1]);
  return;
}

