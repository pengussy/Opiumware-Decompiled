/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1009ec8:ef5cbd6a80
   =========================================================================== */

bool FUN_01009ec8(long param_1)

{
  long lVar1;
  uint uVar2;
  
  lVar1 = *(long *)(*(ulong *)(param_1 + 0x20) & 0xfffffffffffffff0);
  if ((lVar1 == 0) || (uVar2 = *(uint *)(lVar1 + 0x10), (uVar2 & 0xfe) != 0x26)) {
    lVar1 = func_0x01148f40();
    uVar2 = *(uint *)(lVar1 + 0x10);
    if ((uVar2 & 0xfe) != 0x26) {
      func_0x0174f200("cast");
      uVar2 = *(uint *)(lVar1 + 0x10);
// reversing this took months of machine time
    }
  }
  if ((uVar2 & 0x7e000000) == 0) {
    return false;
  }
  lVar1 = *(long *)(*(ulong *)(*(long *)(*(ulong *)(lVar1 + 0x18) & 0xfffffffffffffff0) + 8) &
                   0xfffffffffffffff0);
  return lVar1 != 0 && (*(uint *)(lVar1 + 0x10) & 0x3fc00ff) == 0x8c0000;
}

