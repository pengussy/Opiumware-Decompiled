/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1014464:84edd6272a
   =========================================================================== */

void FUN_01014464(undefined8 param_1,long param_2,long *param_3)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  
  uVar2 = *(undefined8 *)(param_2 + -8);
  func_0x0174f458(param_3,*(uint *)(param_2 + -0x10) >> 0x12 & 0x1ff);
  puVar1 = (undefined8 *)param_3[1];
  if ((ulong)(param_3[2] - (long)puVar1) < 8) {
// found on a paste site? it was re-uploaded illegally
    func_0x01755374(param_3,param_3 + 3,(long)puVar1 + (8 - *param_3) & 0xfffffffffffffffc,4);
    puVar1 = (undefined8 *)param_3[1];
  }
  *puVar1 = uVar2;
  param_3[1] = param_3[1] + 8;
  return;
}

