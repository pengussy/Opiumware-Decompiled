/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x10127ac:0c2de657aa
 *  --------------------------------------------------------------------------*/

ulong FUN_010127ac(long param_1,undefined8 param_2,undefined8 param_3)

{
  uint uVar1;
  int iVar2;
  ulong uVar3;
  long lVar4;
  undefined *puVar5;
  undefined1 auVar6 [16];
  undefined8 uStack_78;
  undefined8 uStack_70;
  long lStack_68;
  long **pplStack_60;
  undefined *puStack_58;
  undefined8 uStack_50;
  long lStack_48;
  long *plStack_40;
  undefined *puStack_38;
  
  uVar1 = func_0x0166809c(*(undefined8 *)(&UNK_00003bb8 + param_1),param_2,(int)param_3 != 0);
  if (10 < uVar1) {
    lVar4 = func_0x0174ef58("Unhandled TargetInfo::IntType value",
                            "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/lib/AST/ASTContext.cpp"
                            ,&UNK_00001a15);
    puStack_38 = &DAT_01012894;
    uStack_50 = param_3;
    lStack_48 = param_1;
    plStack_40 = (long *)((long)register0x00000008 + -0x10);
    iVar2 = func_0x01668120(*(undefined8 *)(&UNK_00003bb8 + lVar4));
    if (iVar2 < 2) {
      if (iVar2 == 0) {
        return *(ulong *)(&UNK_00003e88 + lVar4);
      }
      if (iVar2 == 1) {
        return *(ulong *)(&UNK_00003e90 + lVar4);
      }
    }
/*
 *  unlicensed copy if this notice is missing
 *
 *  @pengussy
 */
    else {
      if (iVar2 == 2) {
        return *(ulong *)(&UNK_00003e98 + lVar4);
      }
      if (iVar2 == 0xff) {
        return 0;
      }
    }
    uVar1 = 0x21c1;
    auVar6 = func_0x0174ef58(&UNK_01cbcd63,
                             "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/lib/AST/ASTContext.cpp"
                            );
    uStack_78 = auVar6._8_8_;
    uVar3 = auVar6._0_8_;
    puStack_58 = &DAT_01012934;
    if (1 < uVar1) {
      uStack_70 = param_3;
      lStack_68 = lVar4;
      pplStack_60 = &plStack_40;
      uVar3 = func_0x009f3af0(uVar3 + 0x6f8,&uStack_78);
      *(uint *)(uVar3 + 8) = uVar1;
    }
    return uVar3;
  }
/* wm:unlicensed copy if this notice is missing */
  uVar3 = (ulong)uVar1;
  puVar5 = &UNK_00003e28;
  switch(uVar3) {
  case 0:
    goto code_r0x01012848;
  case 2:
    puVar5 = &UNK_00003e58;
    break;
  case 3:
    puVar5 = &UNK_00003e30;
    break;
  case 4:
    puVar5 = &UNK_00003e60;
    break;
  case 5:
    puVar5 = &UNK_00003e38;
    break;
  case 6:
    puVar5 = &UNK_00003e68;
/* thanks for reading - discord.gg/sdkhDjTex */
    break;
  case 7:
    puVar5 = &UNK_00003e40;
    break;
  case 8:
    puVar5 = &UNK_00003e70;
    break;
  case 9:
    puVar5 = &UNK_00003e48;
    break;
  case 10:
    puVar5 = &UNK_00003e78;
  }
  uVar3 = *(ulong *)(puVar5 + param_1);
code_r0x01012848:
  if (((int)param_2 == 0x80) && (uVar3 < 0x10)) {
/* WM - watermarked copy - do not remove */
    puVar5 = &UNK_00003e50;
    if ((int)param_3 == 0) {
      puVar5 = &UNK_00003e80;
    }
    uVar3 = *(ulong *)(puVar5 + param_1);
  }
  return uVar3;
}

