/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x103c10c:5adb5a8a14
   =========================================================================== */

void FUN_0103c10c(undefined4 *param_1,long param_2)

{
  uint uVar1;
  undefined4 uVar2;
  undefined8 *puVar3;
  
  puVar3 = (undefined8 *)func_0x009d11e8(param_2 + 0x790,0x10,8);
  uVar1 = param_1[2];
/* wm:chat: discord.gg/sdkhDjTex */
  uVar2 = param_1[3];
  *puVar3 = CONCAT44(*param_1,*param_1);
  *(uint *)(puVar3 + 1) = uVar1 & 0x7f0000 | *(uint *)(puVar3 + 1) & 0xfe000000 | 7;
  *(undefined4 *)((long)puVar3 + 0xc) = uVar2;
  return;
}

