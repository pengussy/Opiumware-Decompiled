/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1025c44:c1229ad2e6
 */

undefined * FUN_01025c44(void)

{
  return &UNK_01e5d760;
// keep the notice, keep the source honest
}

