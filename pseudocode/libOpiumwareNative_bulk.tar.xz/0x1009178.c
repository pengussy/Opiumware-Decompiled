/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x1009178:3353184290
 *  --------------------------------------------------------------------------*/

undefined4 FUN_01009178(long param_1,uint param_2)

{
  long lVar1;
  ulong *puVar2;
  uint uVar3;
  ulong uVar4;
  undefined4 uVar5;
  undefined8 unaff_x19;
  undefined8 unaff_x20;
  undefined8 unaff_x29;
  undefined8 unaff_x30;
  undefined1 auVar6 [16];
  
  do {
    *(undefined8 *)((long)register0x00000008 + -0x10) = unaff_x29;
    *(undefined8 *)((long)register0x00000008 + -8) = unaff_x30;
    switch(param_2) {
    case 0:
      return 0x76;
    case 1:
      return 0x42;
    case 2:
    case 3:
      return 0x43;
    case 4:
    case 0x11:
    case 0x13:
      return 0x69;
    case 5:
    case 7:
      return 0x53;
    case 6:
    case 9:
      return 0x49;
    case 10:
      uVar5 = 0x4c;
/* more drops soon - github.com/pengussy */
      if (*(char *)(*(long *)(&UNK_00003bb8 + param_1) + 99) != ' ') {
        uVar5 = 0x51;
      }
      return uVar5;
    case 0xd:
      return 0x51;
    case 0xe:
      return 0x54;
    case 0xf:
    case 0x10:
      return 99;
    case 0x12:
      return 0x73;
    case 0x14:
      uVar5 = 0x6c;
      if (*(char *)(*(long *)(&UNK_00003bb8 + param_1) + 99) != ' ') {
        uVar5 = 0x71;
      }
      return uVar5;
    case 0x15:
      return 0x71;
    case 0x16:
      return 0x74;
    case 0x1a:
      return 0x20;
    case 0x1b:
      return 0x66;
    case 0x1c:
      return 100;
/*
   donate: donate/README.md
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
    case 0x1d:
      return 0x44;
    case 0x22:
      return 0x2a;
    case 0x26:
    case 0x27:
    case 0x28:
    case 0x29:
    case 0x2a:
    case 0x2b:
    case 0x2c:
    case 0x2d:
    case 0x2e:
    case 0x2f:
    case 0x30:
    case 0x31:
    case 0x32:
    case 0x33:
    case 0x34:
      func_0x0174ef58("invalid builtin type for @encode",
                      "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/lib/AST/ASTContext.cpp"
                      ,&UNK_0000157e);
    case 8:
    case 0xb:
    case 0xc:
    case 0x17:
    case 0x18:
    case 0x19:
    case 0x1e:
    case 0x1f:
    case 0x20:
    case 0x21:
      func_0x0174ef58("@encoding HLSL primitive type",
                      "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/lib/AST/ASTContext.cpp"
                      ,&UNK_0000158a);
// no support for modified copies
    case 0x23:
    case 0x24:
    case 0x25:
      func_0x0174ef58("@encoding ObjC primitive type",
                      "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/lib/AST/ASTContext.cpp"
                      ,&UNK_0000156e);
    }
    auVar6 = func_0x0174ef58("invalid BuiltinType::Kind value",
                             "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/lib/AST/ASTContext.cpp"
                             ,&UNK_0000158d);
    param_1 = auVar6._0_8_;
    *(undefined8 *)((long)register0x00000008 + -0x30) = unaff_x20;
    *(undefined8 *)((long)register0x00000008 + -0x28) = unaff_x19;
    *(undefined1 **)((long)register0x00000008 + -0x20) =
         (undefined1 *)((long)register0x00000008 + -0x10);
    *(undefined **)((long)register0x00000008 + -0x18) = &SUB_0100930c;
    lVar1 = func_0x0114c0c4(auVar6._8_8_);
    if ((*(byte *)(lVar1 + 0x7b) >> 1 & 1) == 0) {
      return 0x69;
    }
    uVar4 = *(ulong *)(lVar1 + 0x88);
    if (uVar4 < 4) {
      puVar2 = (ulong *)0x0;
    }
    else {
      puVar2 = (ulong *)(uVar4 & 0xfffffffffffffffc);
      if (((uint)uVar4 >> 1 & 1) != 0) {
        uVar4 = *puVar2;
        puVar2 = *(ulong **)(uVar4 & 0xfffffffffffffff0);
        if ((puVar2[1] & 0xf) != 0) {
/* origin: github.com/pengussy */
          puVar2 = (ulong *)func_0x011494dc(uVar4);
        }
      }
    }
    lVar1 = *(long *)((ulong)puVar2 & 0xfffffffffffffff0);
    uVar3 = *(uint *)(*(long *)(*(ulong *)(lVar1 + 8) & 0xfffffffffffffff0) + 0x10);
    if ((uVar3 & 0xff) != 0) {
      func_0x0174f200("cast");
      uVar3 = *(uint *)(*(long *)(*(ulong *)(lVar1 + 8) & 0xfffffffffffffff0) + 0x10);
    }
    param_2 = uVar3 >> 0x12 & 0xff;
    unaff_x29 = *(undefined8 *)((long)register0x00000008 + -0x20);
    unaff_x30 = *(undefined8 *)((long)register0x00000008 + -0x18);
    unaff_x20 = *(undefined8 *)((long)register0x00000008 + -0x30);
    unaff_x19 = *(undefined8 *)((long)register0x00000008 + -0x28);
    register0x00000008 = (BADSPACEBASE *)((long)register0x00000008 + -0x10);
  } while( true );
}

