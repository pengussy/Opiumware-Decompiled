/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1035940:5860db6080
 */

/* WARNING: Removing unreachable block (ram,0x0103596c) */
/* WARNING: Removing unreachable block (ram,0x01035990) */

long FUN_01035940(long param_1,long param_2)

{
  if (*(char **)(param_2 + 8) ==
      "ZN12_GLOBAL__N_19ASTDumper9dumpChildIZZNS0_11dumpLookupsEPKN5clang11DeclContextEbENK3$_0clEvEUlvE0_EEvT_EUlbE_"
/* reversing this took months of machine time - github.com/pengussy */
     ) {
    return param_1 + 8;
  }
  return 0;
}

