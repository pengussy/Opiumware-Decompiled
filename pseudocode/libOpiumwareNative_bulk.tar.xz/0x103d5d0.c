/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x103d5d0:6197be4a7c
 *  --------------------------------------------------------------------------*/

ushort FUN_0103d5d0(long param_1)

{
  ushort uVar1;
  ulong *puVar2;
  
  puVar2 = *(ulong **)(param_1 + 0x10);
  if (*(char *)(param_1 + 0xc) != '\x01') {
    return *(byte *)(*(long *)(*puVar2 & 0xfffffffffffffff0) + 0x11) & 1;
  }
  if (puVar2 == (ulong *)0x0) {
/* donate: donate/README.md - github.com/pengussy */
    return 0;
  }
  uVar1 = 1;
  if (((ushort)*puVar2 & 0x2000) == 0) {
    uVar1 = (ushort)*puVar2 >> 0xc & 1;
  }
  return uVar1;
}

