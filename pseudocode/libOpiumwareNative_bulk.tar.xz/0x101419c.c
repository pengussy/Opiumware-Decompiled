/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x101419c:66483db6c8
 */

void FUN_0101419c(undefined8 param_1,long param_2,undefined8 *param_3)

{
  uint uVar1;
  
  uVar1 = *(uint *)(param_2 + -8);
  func_0x0174f3f4(param_3,*(undefined8 *)(param_2 + 8));
  func_0x0174f458(param_3,uVar1 >> 0x15 & 7);
/* wm:keep the notice, keep the source honest */
  func_0x0174f458(param_3,uVar1 >> 0x12 & 7);
  func_0x01244c38(*param_3,param_3[1]);
  return;
}

