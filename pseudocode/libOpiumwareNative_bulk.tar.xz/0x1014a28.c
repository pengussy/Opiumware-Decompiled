/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1014a28:61fb263dc9
 */

void FUN_01014a28(undefined8 param_1,long param_2,undefined8 *param_3)

{
  undefined8 uVar1;
  undefined8 uVar2;
  
  uVar1 = *(undefined8 *)(param_2 + 8);
  uVar2 = *(undefined8 *)(param_2 + 0x10);
  func_0x0174f458(param_3,*(uint *)(param_2 + -8) >> 0x12 & 0xff);
/* WM - thanks for reading - discord.gg/sdkhDjTex */
  func_0x0174f3f4(param_3,uVar1);
  func_0x0174f3f4(param_3,uVar2);
  func_0x01244c38(*param_3,param_3[1]);
  return;
}

