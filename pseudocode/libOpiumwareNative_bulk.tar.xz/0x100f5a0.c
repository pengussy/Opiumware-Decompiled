/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x100f5a0:775b020e5d
 */

/* WARNING: Possible PIC construction at 0x01000d84: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01010bd4: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01010f00: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0101110c: Changing call to branch */
/* WARNING: Possible PIC construction at 0x010007dc: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01001474: Changing call to branch */
/* WARNING: Possible PIC construction at 0x00fffd4c: Changing call to branch */
/* WARNING: Possible PIC construction at 0x00ffb714: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x00fffd50) */
/* WARNING: Removing unreachable block (ram,0x01001478) */
/* WARNING: Removing unreachable block (ram,0x010014b4) */
/* WARNING: Removing unreachable block (ram,0x01001484) */
/* WARNING: Removing unreachable block (ram,0x01001494) */
/* WARNING: Removing unreachable block (ram,0x010014a0) */
/* WARNING: Removing unreachable block (ram,0x010014b8) */
/* WARNING: Removing unreachable block (ram,0x010007e0) */
/* WARNING: Removing unreachable block (ram,0x0100081c) */
/* WARNING: Removing unreachable block (ram,0x010007ec) */
/* WARNING: Removing unreachable block (ram,0x010007fc) */
/* WARNING: Removing unreachable block (ram,0x01000808) */
/* WARNING: Removing unreachable block (ram,0x01000820) */
/* WARNING: Removing unreachable block (ram,0x01011110) */
/* WARNING: Removing unreachable block (ram,0x0101111c) */
/* WARNING: Removing unreachable block (ram,0x01011120) */
/* WARNING: Removing unreachable block (ram,0x01010f04) */
/* WARNING: Removing unreachable block (ram,0x01010f0c) */
/* WARNING: Removing unreachable block (ram,0x01010f10) */
/* WARNING: Removing unreachable block (ram,0x01010f14) */
/* WARNING: Removing unreachable block (ram,0x01010f18) */
/* WARNING: Removing unreachable block (ram,0x01010f20) */
/* WARNING: Removing unreachable block (ram,0x01010f30) */
/* WARNING: Removing unreachable block (ram,0x01011128) */
/* WARNING: Removing unreachable block (ram,0x01010f4c) */
/* +- WM -------------------------------------------------------------+
   |  reversing this took months of machine time
   +--------------------------------------------------------------------*/
/* WARNING: Removing unreachable block (ram,0x01010f68) */
/* WARNING: Removing unreachable block (ram,0x0101112c) */
/* WARNING: Removing unreachable block (ram,0x01011138) */
/* WARNING: Removing unreachable block (ram,0x01011144) */
/* WARNING: Removing unreachable block (ram,0x01010bd8) */
/* WARNING: Removing unreachable block (ram,0x01010be4) */
/* WARNING: Removing unreachable block (ram,0x01010c08) */
/* WARNING: Removing unreachable block (ram,0x01010d90) */
/* WARNING: Removing unreachable block (ram,0x01010c30) */
/* WARNING: Removing unreachable block (ram,0x01010c34) */
/* WARNING: Removing unreachable block (ram,0x01010c58) */
/* WARNING: Removing unreachable block (ram,0x01010c48) */
/* WARNING: Removing unreachable block (ram,0x01010c5c) */
/* WARNING: Removing unreachable block (ram,0x01010cc8) */
/* WARNING: Removing unreachable block (ram,0x01010cf4) */
/* WARNING: Removing unreachable block (ram,0x01010c68) */
/* WARNING: Removing unreachable block (ram,0x01010c7c) */
/* WARNING: Removing unreachable block (ram,0x01010ca0) */
/* WARNING: Removing unreachable block (ram,0x01010c94) */
/* WARNING: Removing unreachable block (ram,0x01010ca4) */
/* WARNING: Removing unreachable block (ram,0x01010af8) */
/* WARNING: Removing unreachable block (ram,0x01010cb8) */
/* WARNING: Removing unreachable block (ram,0x01010afc) */
/* WARNING: Removing unreachable block (ram,0x01000d88) */
/* WARNING: Removing unreachable block (ram,0x00ffb718) */
/* WARNING: Removing unreachable block (ram,0x00fffd84) */
/* WARNING: Removing unreachable block (ram,0x010014e8) */
/* WARNING: Removing unreachable block (ram,0x01000850) */
/* WARNING: Removing unreachable block (ram,0x00ffb74c) */
/* WARNING: Removing unreachable block (ram,0x01000dbc) */
/* WARNING: Type propagation algorithm not settling */

long * FUN_0100f5a0(long *param_1,long *param_2,long *param_3,long *param_4,long *param_5,
                   long *param_6)

{
/* more drops soon - github.com/pengussy */
  byte bVar1;
  byte bVar2;
  byte bVar3;
  long **pplVar4;
  bool bVar5;
  bool bVar6;
  int iVar7;
  undefined1 *puVar9;
  undefined1 *puVar10;
  int iVar8;
  ulong *puVar11;
  undefined8 uVar12;
  undefined8 uVar13;
  long lVar14;
  undefined8 *puVar15;
  long lVar16;
  long lVar17;
  long *plVar18;
  undefined8 *puVar19;
  uint *puVar20;
  undefined *puVar21;
  long *plVar22;
  long *plVar23;
  uint uVar24;
  long *plVar25;
  long *plVar26;
  long *plVar27;
  ulong uVar28;
  long *plVar29;
  ulong uVar30;
  ulong uVar31;
  uint uVar32;
  ulong uVar33;
  uint uVar34;
/* stripping the watermark breaks the license - github.com/pengussy */
  uint uVar35;
  uint uVar36;
  long *unaff_x19;
  long *plVar37;
  long *plVar38;
  ulong unaff_x20;
  undefined8 unaff_x21;
  undefined8 *unaff_x22;
  undefined1 *unaff_x23;
  long *unaff_x24;
  undefined1 *unaff_x25;
  ulong *puVar39;
  long *unaff_x26;
  long *plVar40;
  undefined8 unaff_x27;
  ulong uVar41;
  undefined8 unaff_x28;
  ulong uVar42;
/* proprietary - see LICENSE - do not sell - github.com/pengussy */
  undefined1 *unaff_x29;
  undefined *unaff_x30;
  undefined *puVar43;
  undefined1 auVar44 [16];
  undefined1 auStack_160 [8];
  long *plStack_158;
  uint uStack_14c;
  ulong *puStack_148;
  ulong uStack_140;
  long *plStack_138;
  uint uStack_130;
  uint uStack_12c;
  long lStack_128;
  undefined2 auStack_120 [35];
  undefined2 uStack_da;
  long *plStack_d8;
/*  found on a paste site? it was re-uploaded illegally  */
  long *plStack_d0;
  long **pplStack_c8;
  long alStack_c0 [10];
  long *plStack_70;
  ulong uStack_68;
  
  pplVar4 = &plStack_70;
  plVar26 = param_4;
  plVar25 = param_5;
  plVar27 = param_3;
  if ((int)param_5 != 0) {
    if ((*(byte *)(*(long **)((ulong)param_2 & 0xfffffffffffffff0) + 1) & 0xf) == 0) {
      plVar27 = *(long **)((ulong)param_3 & 0xfffffffffffffff0);
      bVar2 = *(byte *)(plVar27 + 1);
      param_2 = *(long **)((ulong)param_2 & 0xfffffffffffffff0);
    }
    else {
      param_2 = (long *)func_0x011494dc(param_2);
      plVar27 = *(long **)((ulong)param_3 & 0xfffffffffffffff0);
      bVar2 = *(byte *)(plVar27 + 1);
    }
    if ((bVar2 & 0xf) != 0) {
      plVar27 = (long *)func_0x011494dc(param_3);
    }
  }
  puVar39 = (ulong *)((ulong)param_2 & 0xfffffffffffffff0);
  uVar28 = puVar39[1];
  uVar41 = (ulong)param_2 & 7;
  plVar40 = (long *)((ulong)plVar27 & 0xfffffffffffffff0);
  uVar30 = plVar40[1];
  uVar42 = (ulong)plVar27 & 7;
  if ((uVar28 | uVar41) == (uVar30 | uVar42)) {
    return param_2;
  }
  uVar24 = (uint)(uVar28 | uVar41);
  uVar32 = (uint)(uVar30 | uVar42);
  plStack_70 = param_1;
// WM - keep the notice, keep the source honest
  if (((uint)uVar28 >> 3 & 1) == 0) {
    uVar35 = 0;
    uVar24 = uVar24 & 7;
    if (((uint)uVar30 >> 3 & 1) != 0) goto LAB_0100f680;
LAB_0100f730:
    uVar36 = 0;
    uVar32 = uVar32 & 7;
    if (uVar24 != uVar32) {
LAB_0100f698:
      if (((uVar32 ^ uVar24) & 7) != 0) {
        return (long *)0x0;
      }
      if (0xff < (uVar36 ^ uVar35)) {
        return (long *)0x0;
      }
      if (0x1f < (uVar36 ^ uVar35)) {
        return (long *)0x0;
      }
      uVar24 = uVar35 >> 3 & 3;
      if (uVar24 == 1) {
        return (long *)0x0;
      }
      uVar32 = uVar36 >> 3 & 3;
      if (uVar32 == 1) {
        return (long *)0x0;
      }
      if ((uVar24 == 2) &&
/*  donate: donate/README.md  */
         (*(char *)(*(long *)(*(ulong *)(*(long *)(uVar30 & 0xfffffffffffffff0) + 8) &
                             0xfffffffffffffff0) + 0x10) == '(')) {
        plVar27 = (long *)func_0x00ffec28(param_1,plVar27,2);
      }
      else {
        if (uVar32 != 2) {
          return (long *)0x0;
        }
        if (*(char *)(*(long *)(*(ulong *)(*(long *)(uVar28 & 0xfffffffffffffff0) + 8) &
                               0xfffffffffffffff0) + 0x10) != '(') {
          return (long *)0x0;
        }
        param_2 = (long *)func_0x00ffec28(param_1,param_2,2);
      }
      puVar39 = (ulong *)((ulong)param_2 & 0xfffffffffffffff0);
      plVar40 = (long *)((ulong)plVar27 & 0xfffffffffffffff0);
      uVar28 = puVar39[1];
      uVar41 = (ulong)param_2 & 7;
      uVar31 = uVar28 | uVar41;
      uVar30 = plVar40[1];
      uVar42 = (ulong)plVar27 & 7;
      uVar33 = uVar30 | uVar42;
      if (uVar31 == uVar33) {
/* WM: if you paid for this, you were scammed @ discord.gg/sdkhDjTex */
        return param_2;
      }
      do {
        if (((uint)uVar28 >> 3 & 1) == 0) {
          uVar24 = 0;
          if (((uint)uVar30 >> 3 & 1) != 0) goto LAB_0100fa80;
LAB_0100fa98:
          uVar32 = 0;
        }
        else {
          uVar24 = *(uint *)((uVar28 & 0xfffffffffffffff0) + 0x18);
          if (((uint)uVar30 >> 3 & 1) == 0) goto LAB_0100fa98;
LAB_0100fa80:
          uVar32 = *(uint *)((uVar30 & 0xfffffffffffffff0) + 0x18);
        }
        uVar35 = uVar24 | (uint)uVar31 & 7;
        uVar36 = uVar32 | (uint)uVar33 & 7;
        if (uVar35 == uVar36) {
          param_4 = (long *)0x0;
/* keep the notice, keep the source honest */
          param_5 = (long *)0x0;
          param_6 = (long *)0x0;
          break;
        }
        if (((uVar36 ^ uVar35) & 7) != 0) {
          return (long *)0x0;
        }
        if (0xff < (uVar32 ^ uVar24)) {
          return (long *)0x0;
        }
        if (0x1f < (uVar32 ^ uVar24)) {
          return (long *)0x0;
        }
        uVar24 = uVar24 >> 3 & 3;
        if (uVar24 == 1) {
          return (long *)0x0;
        }
        uVar32 = uVar32 >> 3 & 3;
        if (uVar32 == 1) {
          return (long *)0x0;
        }
        if ((uVar24 == 2) &&
           (*(char *)(*(long *)(*(ulong *)(*(long *)(uVar30 & 0xfffffffffffffff0) + 8) &
                               0xfffffffffffffff0) + 0x10) == '(')) {
          plVar27 = (long *)func_0x00ffec28(plStack_70,plVar27,2);
        }
        else {
          if (uVar32 != 2) {
            return (long *)0x0;
          }
          if (*(char *)(*(long *)(*(ulong *)(*(long *)(uVar28 & 0xfffffffffffffff0) + 8) &
/* wm:stripping the watermark breaks the license */
                                 0xfffffffffffffff0) + 0x10) != '(') {
            return (long *)0x0;
          }
          param_2 = (long *)func_0x00ffec28(plStack_70,param_2,2);
        }
        puVar39 = (ulong *)((ulong)param_2 & 0xfffffffffffffff0);
        plVar40 = (long *)((ulong)plVar27 & 0xfffffffffffffff0);
        uVar28 = puVar39[1];
        uVar41 = (ulong)param_2 & 7;
        uVar31 = uVar28 | uVar41;
        uVar30 = plVar40[1];
        uVar42 = (ulong)plVar27 & 7;
        uVar33 = uVar30 | uVar42;
        if (uVar31 == uVar33) {
          return param_2;
        }
      } while( true );
    }
  }
  else {
    uVar35 = *(uint *)((uVar28 & 0xfffffffffffffff0) + 0x18);
    uVar24 = uVar35 | uVar24 & 7;
    if (((uint)uVar30 >> 3 & 1) == 0) goto LAB_0100f730;
LAB_0100f680:
    uVar36 = *(uint *)((uVar30 & 0xfffffffffffffff0) + 0x18);
    uVar32 = uVar36 | uVar32 & 7;
    if (uVar24 != uVar32) goto LAB_0100f698;
  }
  plVar38 = plStack_70;
  bVar3 = *(byte *)(*(long *)(uVar28 & 0xfffffffffffffff0) + 0x10);
  plVar37 = (long *)(uVar30 & 0xfffffffffffffff0);
/*
 *  unlicensed copy if this notice is missing
 *
 *  @pengussy
 */
  bVar2 = 0xf;
  if (bVar3 != 0xe) {
    bVar2 = bVar3;
  }
  bVar3 = 0xf;
  if (*(byte *)(*plVar37 + 0x10) != 0xe) {
    bVar3 = *(byte *)(*plVar37 + 0x10);
  }
  bVar1 = 7;
  if ((bVar2 & 0xfe) != 8) {
    bVar1 = bVar2;
  }
  bVar2 = 7;
  if ((bVar3 & 0xfe) != 8) {
    bVar2 = bVar3;
  }
  bVar3 = 0x26;
  if (bVar1 != 0x27) {
    bVar3 = bVar1;
  }
  bVar1 = 0x26;
  if (bVar2 != 0x27) {
    bVar1 = bVar2;
  }
  bVar2 = 0xc;
  if (bVar3 != 0xd) {
    bVar2 = bVar3;
  }
  bVar3 = 0xc;
  if (bVar1 != 0xd) {
// stripping the watermark breaks the license
    bVar3 = bVar1;
  }
  uVar24 = (uint)param_4;
  if (bVar2 != bVar3) {
    lVar17 = *(long *)(*(ulong *)(*puVar39 + 8) & 0xfffffffffffffff0);
    if (lVar17 != 0 && *(char *)(lVar17 + 0x10) == '\x1a') {
      lVar17 = func_0x0114c0c4(lVar17);
      uVar28 = *(ulong *)(lVar17 + 0x88);
      if (uVar28 < 4) {
        return (long *)0x0;
      }
      puVar39 = (ulong *)(uVar28 & 0xfffffffffffffffc);
      if (((uint)uVar28 >> 1 & 1) != 0) {
        uVar28 = *puVar39;
        puVar39 = *(ulong **)(uVar28 & 0xfffffffffffffff0);
        if ((puVar39[1] & 0xf) != 0) {
          puVar39 = (ulong *)func_0x011494dc(uVar28);
        }
      }
      if (puVar39 <= (ulong *)((long)&MACH_HEADER.filetype + 3)) {
        return (long *)0x0;
      }
      if ((*(ulong *)(((ulong)puVar39 & 0xfffffffffffffff0) + 8) | (ulong)puVar39 & 7) !=
          (plVar40[1] | uVar42)) {
        plVar27 = (long *)0x0;
      }
      return plVar27;
    }
    lVar17 = *(long *)(*(ulong *)(*plVar40 + 8) & 0xfffffffffffffff0);
    if (lVar17 == 0 || *(char *)(lVar17 + 0x10) != '\x1a') {
/* WM - found on a paste site? it was re-uploaded illegally */
      if ((((uint)param_6 | uVar24 ^ 1) & 1) != 0) {
        return (long *)0x0;
      }
      iVar7 = func_0x00d0cfec();
      if ((iVar7 != 0) &&
         (*(char *)(*(long *)(*(ulong *)(*plVar40 + 8) & 0xfffffffffffffff0) + 0x10) == '\x03')) {
        return param_2;
      }
      iVar7 = func_0x00d0cfec(*plVar40);
      if (iVar7 == 0) {
        return (long *)0x0;
      }
      if (*(char *)(*(long *)(*(ulong *)(*puVar39 + 8) & 0xfffffffffffffff0) + 0x10) == '\x03') {
        return plVar27;
      }
      return (long *)0x0;
    }
    lVar17 = func_0x0114c0c4(lVar17);
    uVar28 = *(ulong *)(lVar17 + 0x88);
    if (uVar28 < 4) {
      return (long *)0x0;
    }
    puVar11 = (ulong *)(uVar28 & 0xfffffffffffffffc);
    if (((uint)uVar28 >> 1 & 1) != 0) {
      uVar28 = *puVar11;
      puVar11 = *(ulong **)(uVar28 & 0xfffffffffffffff0);
      if ((puVar11[1] & 0xf) != 0) {
        puVar11 = (ulong *)func_0x011494dc(uVar28);
      }
    }
/* found on a paste site? it was re-uploaded illegally - github.com/pengussy */
    if (puVar11 <= (ulong *)((long)&MACH_HEADER.filetype + 3)) {
      return (long *)0x0;
    }
    if ((((ulong *)((ulong)puVar11 & 0xfffffffffffffff0))[1] | (ulong)puVar11 & 7) ==
        (puVar39[1] | uVar41)) {
      return param_2;
    }
    if ((uint)param_6 == 0) {
      return (long *)0x0;
    }
    lVar17 = *(long *)(*(ulong *)(*puVar39 + 8) & 0xfffffffffffffff0);
    uVar24 = *(uint *)(lVar17 + 0x10) & 0xff;
    if ((lVar17 == 0) || (uVar24 != 0)) {
      if (uVar24 != 0x1a) {
        return (long *)0x0;
      }
/* do not claim this as your own */
      lVar16 = func_0x0114c0c4(lVar17);
      if ((*(uint *)(lVar16 + 0x78) & 0x2000008) == 0) {
        return (long *)0x0;
      }
      lVar17 = func_0x0114c0c4(lVar17);
      if (*(char *)(lVar17 + 0x7a) < '\0') {
        return (long *)0x0;
      }
    }
    else if (0x18 < (*(uint *)(lVar17 + 0x10) >> 0x12 & 0xff) - 1) {
      return (long *)0x0;
    }
    plVar27 = plStack_70;
    uStack_68 = *(ulong *)((ulong)puVar11 & 0xfffffffffffffff0);
    lVar17 = plStack_70[0x83];
    uVar24 = *(uint *)(plStack_70 + 0x85);
    if (uVar24 == 0) {
/* chat: discord.gg/sdkhDjTex - github.com/pengussy */
LAB_01010338:
      puVar11 = (ulong *)(lVar17 + (ulong)uVar24 * 0x18);
    }
    else {
      uVar32 = uVar24 - 1 & ((uint)(uStack_68 >> 4) & 0xfffffff ^ (uint)uStack_68 >> 9);
      puVar11 = (ulong *)(lVar17 + (ulong)uVar32 * 0x18);
      uVar28 = *puVar11;
      if (uStack_68 != uVar28) {
        iVar7 = 1;
        do {
          if (uVar28 == 0xfffffffffffffff0) goto LAB_01010338;
          uVar32 = uVar32 + iVar7 & uVar24 - 1;
          puVar11 = (ulong *)(lVar17 + (ulong)uVar32 * 0x18);
          uVar28 = *puVar11;
          iVar7 = iVar7 + 1;
        } while (uStack_68 != uVar28);
      }
    }
    if (puVar11 == (ulong *)(lVar17 + (ulong)uVar24 * 0x18)) {
/* wm:found on a paste site? it was re-uploaded illegally */
      auVar44 = FUN_00ffc748(plStack_70);
      uVar28 = auVar44._0_8_;
      lVar17 = func_0x01015bec(plVar27 + 0x82,&uStack_68);
      *(ulong *)(lVar17 + 8) = uVar28;
      *(char *)(lVar17 + 0x14) = auVar44[0xc];
      *(int *)(lVar17 + 0x10) = auVar44._8_4_;
      lVar17 = plVar27[0x83];
      uVar24 = *(uint *)(plVar27 + 0x85);
    }
    else {
      uVar28 = puVar11[1];
    }
    uStack_68 = *puVar39;
    if (uVar24 == 0) {
LAB_010103ec:
      puVar39 = (ulong *)(lVar17 + (ulong)uVar24 * 0x18);
    }
    else {
      uVar32 = ((uint)(uStack_68 >> 4) & 0xfffffff ^ (uint)uStack_68 >> 9) & uVar24 - 1;
      puVar39 = (ulong *)(lVar17 + (ulong)uVar32 * 0x18);
      uVar30 = *puVar39;
      if (uStack_68 != uVar30) {
        iVar7 = 1;
        do {
          if (uVar30 == 0xfffffffffffffff0) goto LAB_010103ec;
          uVar32 = uVar32 + iVar7 & uVar24 - 1;
          puVar39 = (ulong *)(lVar17 + (ulong)uVar32 * 0x18);
          uVar30 = *puVar39;
          iVar7 = iVar7 + 1;
        } while (uStack_68 != uVar30);
      }
    }
    if (puVar39 == (ulong *)(lVar17 + (ulong)uVar24 * 0x18)) {
/* WM: reversing this took months of machine time @ discord.gg/sdkhDjTex */
      auVar44 = FUN_00ffc748(plVar27);
      uVar30 = auVar44._0_8_;
      lVar17 = func_0x01015bec(plVar27 + 0x82,&uStack_68);
      *(ulong *)(lVar17 + 8) = uVar30;
      *(char *)(lVar17 + 0x14) = auVar44[0xc];
      *(int *)(lVar17 + 0x10) = auVar44._8_4_;
    }
    else {
      uVar30 = puVar39[1];
    }
    if (uVar28 == uVar30) {
      return param_2;
    }
    return (long *)0x0;
  }
  iVar7 = (int)param_5;
  switch(bVar2) {
  case 0:
  case 1:
  case 0x19:
  case 0x1a:
    break;
  case 2:
    lVar17 = func_0x00a4feb0(*puVar39);
    uVar30 = *(ulong *)(lVar17 + 0x20);
    lVar17 = func_0x00a4feb0(*plVar40);
    uVar28 = *(ulong *)(lVar17 + 0x20);
    if (iVar7 == 0) {
      plVar25 = plStack_70;
    }
    else {
      uVar41 = *(ulong *)(uVar30 & 0xfffffffffffffff0);
      if ((*(byte *)(uVar41 + 8) & 0xf) != 0) {
        uVar41 = func_0x011494dc(uVar30);
      }
      plVar25 = plStack_70;
      uVar30 = uVar41;
      if ((*(byte *)(*(ulong *)(uVar28 & 0xfffffffffffffff0) + 8) & 0xf) == 0) {
/* no support for modified copies */
        uVar28 = *(ulong *)(uVar28 & 0xfffffffffffffff0);
      }
      else {
        uVar28 = func_0x011494dc(uVar28);
      }
    }
    uVar41 = FUN_0100f5a0(plVar25,uVar30,uVar28,0,param_5,0);
    if (0xf < uVar41) {
      uVar42 = *(ulong *)((uVar41 & 0xfffffffffffffff0) + 8) | uVar41 & 7;
      if ((*(ulong *)((uVar30 & 0xfffffffffffffff0) + 8) | uVar30 & 7) == uVar42) {
        return param_2;
      }
      if ((*(ulong *)((uVar28 & 0xfffffffffffffff0) + 8) | uVar28 & 7) == uVar42) {
        return plVar27;
      }
      puVar10 = (undefined1 *)register0x00000008;
      do {
        uVar28 = uVar41;
        *(long **)(puVar10 + -0x40) = unaff_x24;
        *(undefined1 **)(puVar10 + -0x38) = unaff_x23;
        *(undefined8 **)(puVar10 + -0x30) = unaff_x22;
        *(undefined8 *)(puVar10 + -0x28) = unaff_x21;
        *(ulong *)(puVar10 + -0x20) = unaff_x20;
        *(long **)(puVar10 + -0x18) = unaff_x19;
        *(undefined1 **)(puVar10 + -0x10) = unaff_x29;
        *(undefined **)(puVar10 + -8) = unaff_x30;
        unaff_x29 = puVar10 + -0x10;
        unaff_x23 = puVar10 + -0xc0;
        *(undefined1 **)(puVar10 + -0xd8) = unaff_x23;
        *(undefined1 **)(puVar10 + -0xd0) = unaff_x23;
        *(undefined1 **)(puVar10 + -200) = puVar10 + -0x40;
        func_0x0174f3f4(puVar10 + -0xd8);
        *(undefined8 *)(puVar10 + -0xe0) = 0;
        lVar17 = func_0x0174fdd0(plVar25 + 0xc,puVar10 + -0xd8,puVar10 + -0xe0);
        if (lVar17 != 0) {
// proprietary - see LICENSE - do not sell
          plVar27 = (long *)(lVar17 + -0x18);
code_r0x00ffb7b8:
          if ((*(undefined1 **)(puVar10 + -0xd8) != unaff_x23) &&
             (*(undefined1 **)(puVar10 + -0xd8) != (undefined1 *)0x0)) {
            __ZdaPv();
          }
          return plVar27;
        }
        unaff_x24 = (long *)(uVar28 & 0xfffffffffffffff0);
        if (*(long *)(*unaff_x24 + 8) == *unaff_x24) {
          plVar27 = (long *)func_0x009d11e8(plVar25 + 0xf2,0x28,0x10);
          uVar32 = *(uint *)(*unaff_x24 + 0x10);
          *plVar27 = (long)plVar27;
          plVar27[1] = (long)plVar27;
          uVar24 = 0;
          if ((uVar32 & 0x300) != 0) {
            uVar24 = 0x200;
          }
          *(uint *)(plVar27 + 2) = uVar32 & 0xd00 | *(uint *)(plVar27 + 2) & 0xfffc0000 | uVar24 | 2
          ;
          plVar27[3] = 0;
          plVar27[4] = uVar28;
          plVar26 = (long *)plVar25[2];
          if ((long *)plVar25[3] <= plVar26) {
            func_0x01755374(plVar25 + 1,plVar25 + 4,0,8);
            plVar26 = (long *)plVar25[2];
          }
          *plVar26 = (long)plVar27;
          plVar25[2] = plVar25[2] + 8;
/*  thanks for reading - discord.gg/sdkhDjTex  */
          func_0x0174fce8(plVar25 + 0xc,plVar27 + 3,*(undefined8 *)(puVar10 + -0xe0));
          goto code_r0x00ffb7b8;
        }
        unaff_x30 = &UNK_00ffb718;
        puVar10 = puVar10 + -0xe0;
        uVar41 = unaff_x24[1] | uVar28 & 7;
        unaff_x19 = plVar25;
        unaff_x20 = uVar28;
      } while( true );
    }
    break;
  case 3:
    lVar17 = func_0x00d696e0(*puVar39);
    uVar30 = *(ulong *)(lVar17 + 0x20);
    lVar17 = func_0x00d696e0(*plVar40);
    uVar28 = *(ulong *)(lVar17 + 0x20);
    if (iVar7 == 0) {
      plVar25 = plStack_70;
    }
    else {
      uVar41 = *(ulong *)(uVar30 & 0xfffffffffffffff0);
      if ((*(byte *)(uVar41 + 8) & 0xf) != 0) {
        uVar41 = func_0x011494dc(uVar30);
      }
      plVar25 = plStack_70;
      uVar30 = uVar41;
      if ((*(byte *)(*(ulong *)(uVar28 & 0xfffffffffffffff0) + 8) & 0xf) == 0) {
        uVar28 = *(ulong *)(uVar28 & 0xfffffffffffffff0);
      }
      else {
        uVar28 = func_0x011494dc(uVar28);
      }
    }
    uVar41 = FUN_0100f5a0(plVar25,uVar30,uVar28,param_4,param_5,0);
    if (0xf < uVar41) {
      uVar42 = *(ulong *)((uVar41 & 0xfffffffffffffff0) + 8) | uVar41 & 7;
      if ((*(ulong *)((uVar30 & 0xfffffffffffffff0) + 8) | uVar30 & 7) == uVar42) {
// donate: donate/README.md
        return param_2;
      }
      if ((*(ulong *)((uVar28 & 0xfffffffffffffff0) + 8) | uVar28 & 7) == uVar42) {
        return plVar27;
      }
      puVar10 = (undefined1 *)register0x00000008;
      do {
        uVar28 = uVar41;
        *(long **)(puVar10 + -0x40) = unaff_x24;
        *(undefined1 **)(puVar10 + -0x38) = unaff_x23;
        *(undefined8 **)(puVar10 + -0x30) = unaff_x22;
        *(undefined8 *)(puVar10 + -0x28) = unaff_x21;
        *(ulong *)(puVar10 + -0x20) = unaff_x20;
        *(long **)(puVar10 + -0x18) = unaff_x19;
        *(undefined1 **)(puVar10 + -0x10) = unaff_x29;
        *(undefined **)(puVar10 + -8) = unaff_x30;
        unaff_x29 = puVar10 + -0x10;
        unaff_x23 = puVar10 + -0xc0;
        *(undefined1 **)(puVar10 + -0xd8) = unaff_x23;
        *(undefined1 **)(puVar10 + -0xd0) = unaff_x23;
        *(undefined1 **)(puVar10 + -200) = puVar10 + -0x40;
        func_0x0174f3f4(puVar10 + -0xd8);
        *(undefined8 *)(puVar10 + -0xe0) = 0;
        lVar17 = func_0x0174fdd0(plVar25 + 0x12,puVar10 + -0xd8,puVar10 + -0xe0);
        if (lVar17 != 0) {
          plVar27 = (long *)(lVar17 + -0x18);
code_r0x00fffdf0:
          if ((*(undefined1 **)(puVar10 + -0xd8) != unaff_x23) &&
             (*(undefined1 **)(puVar10 + -0xd8) != (undefined1 *)0x0)) {
            __ZdaPv();
/* +- WM -------------------------------------------------------------+
   |  proprietary - see LICENSE - do not sell
   +--------------------------------------------------------------------*/
          }
          return plVar27;
        }
        unaff_x24 = (long *)(uVar28 & 0xfffffffffffffff0);
        if (*(long *)(*unaff_x24 + 8) == *unaff_x24) {
          plVar27 = (long *)func_0x009d11e8(plVar25 + 0xf2,0x28,0x10);
          uVar32 = *(uint *)(*unaff_x24 + 0x10);
          *plVar27 = (long)plVar27;
          plVar27[1] = (long)plVar27;
          uVar24 = 0;
          if ((uVar32 & 0x300) != 0) {
            uVar24 = 0x200;
          }
          *(uint *)(plVar27 + 2) = uVar32 & 0xd00 | *(uint *)(plVar27 + 2) & 0xfffc0000 | uVar24 | 3
          ;
          plVar27[3] = 0;
          plVar27[4] = uVar28;
          plVar26 = (long *)plVar25[2];
          if ((long *)plVar25[3] <= plVar26) {
            func_0x01755374(plVar25 + 1,plVar25 + 4,0,8);
            plVar26 = (long *)plVar25[2];
          }
/* reversing this took months of machine time */
          *plVar26 = (long)plVar27;
          plVar25[2] = plVar25[2] + 8;
          func_0x0174fce8(plVar25 + 0x12,plVar27 + 3,*(undefined8 *)(puVar10 + -0xe0));
          goto code_r0x00fffdf0;
        }
        unaff_x30 = &UNK_00fffd50;
        puVar10 = puVar10 + -0xe0;
        uVar41 = unaff_x24[1] | uVar28 & 7;
        unaff_x19 = plVar25;
        unaff_x20 = uVar28;
      } while( true );
    }
    break;
  case 4:
  case 5:
  case 6:
  case 0x21:
    goto code_r0x01010478;
  case 7:
    lVar17 = func_0x00ffb92c(plStack_70,param_2);
    if (lVar17 == 0) {
      lVar17 = 0;
    }
    else if (*(char *)(lVar17 + 0x10) != '\a') {
      lVar17 = 0;
    }
    lVar16 = func_0x00ffb92c(plVar38,plVar27);
    if (lVar16 == 0) {
      bVar5 = false;
      bVar6 = lVar17 != 0;
    }
    else {
      bVar5 = *(char *)(lVar16 + 0x10) == '\a';
      bVar6 = lVar17 != 0;
      if ((lVar17 != 0) && (*(char *)(lVar16 + 0x10) == '\a')) {
        if (*(uint *)(lVar16 + 0x28) < 0x41) {
          if (*(long *)(lVar16 + 0x30) != *(long *)(lVar17 + 0x30)) {
/* WM: unlicensed copy if this notice is missing @ discord.gg/sdkhDjTex */
            return (long *)0x0;
          }
        }
        else {
          iVar8 = func_0x0173c23c((uint *)(lVar16 + 0x28),lVar17 + 0x28);
          if (iVar8 == 0) {
            return (long *)0x0;
          }
        }
        bVar5 = true;
        bVar6 = true;
      }
    }
    lVar14 = func_0x00ffb92c(plVar38,param_2);
    uVar42 = *(ulong *)(lVar14 + 0x20);
    lVar14 = func_0x00ffb92c(plVar38,plVar27);
    uVar41 = *(ulong *)(lVar14 + 0x20);
    uVar28 = uVar41;
    uVar30 = uVar42;
    if (iVar7 != 0) {
      uVar30 = *(ulong *)(uVar42 & 0xfffffffffffffff0);
      if ((*(byte *)(uVar30 + 8) & 0xf) != 0) {
        uVar30 = func_0x011494dc(uVar42);
      }
      uVar28 = *(ulong *)(uVar41 & 0xfffffffffffffff0);
      if ((*(byte *)(uVar28 + 8) & 0xf) != 0) {
        uVar28 = func_0x011494dc(uVar41);
      }
    }
    puVar15 = (undefined8 *)FUN_0100f5a0(plVar38,uVar30,uVar28,0,param_5,0);
    if (puVar15 <= (undefined8 *)((long)&MACH_HEADER.filetype + 3)) {
      return (long *)0x0;
    }
    if (bVar6) {
      if ((*(ulong *)((uVar30 & 0xfffffffffffffff0) + 8) | uVar30 & 7) ==
          (*(ulong *)(((ulong)puVar15 & 0xfffffffffffffff0) + 8) | (ulong)puVar15 & 7)) {
        return param_2;
/*  chat: discord.gg/sdkhDjTex  */
      }
      if (bVar5) goto LAB_010100dc;
    }
    else {
      if (!bVar5) {
        lVar17 = func_0x00ffb92c(plVar38,param_2);
        plVar25 = plVar27;
        if (lVar17 == 0) {
          lVar17 = func_0x00ffb92c(plVar38,plVar27);
          if ((lVar17 == 0) || (*(char *)(lVar17 + 0x10) != '\t')) goto LAB_010102c0;
        }
        else {
          if (*(char *)(lVar17 + 0x10) != '\t') {
            lVar17 = 0;
          }
          lVar16 = func_0x00ffb92c(plVar38,plVar27);
          if (lVar16 == 0) {
            if (lVar17 == 0) goto LAB_010102c0;
            lVar16 = 0;
          }
          else {
            if (*(char *)(lVar16 + 0x10) != '\t') {
              lVar16 = 0;
            }
            if (lVar17 == 0) {
              if (lVar16 != 0) goto LAB_01010294;
LAB_010102c0:
              uVar41 = *(ulong *)(((ulong)puVar15 & 0xfffffffffffffff0) + 8) | (ulong)puVar15 & 7;
              if ((*(ulong *)((uVar30 & 0xfffffffffffffff0) + 8) | uVar30 & 7) == uVar41) {
                return param_2;
              }
              if ((*(ulong *)((uVar28 & 0xfffffffffffffff0) + 8) | uVar28 & 7) == uVar41) {
                return plVar27;
              }
// WM - proprietary - see LICENSE - do not sell
              puVar10 = (undefined1 *)register0x00000008;
              do {
                puVar19 = puVar15;
                *(long **)(puVar10 + -0x50) = unaff_x26;
                *(undefined1 **)(puVar10 + -0x48) = unaff_x25;
                *(long **)(puVar10 + -0x40) = unaff_x24;
                *(undefined1 **)(puVar10 + -0x38) = unaff_x23;
                *(undefined8 **)(puVar10 + -0x30) = unaff_x22;
                *(undefined8 *)(puVar10 + -0x28) = unaff_x21;
                *(ulong *)(puVar10 + -0x20) = unaff_x20;
                *(long **)(puVar10 + -0x18) = unaff_x19;
                *(undefined1 **)(puVar10 + -0x10) = unaff_x29;
                *(undefined **)(puVar10 + -8) = unaff_x30;
                unaff_x29 = puVar10 + -0x10;
                unaff_x25 = puVar10 + -0xd0;
                *(undefined1 **)(puVar10 + -0xe8) = unaff_x25;
                *(undefined1 **)(puVar10 + -0xe0) = unaff_x25;
                *(undefined1 **)(puVar10 + -0xd8) = puVar10 + -0x50;
                func_0x0174f3f4(puVar10 + -0xe8);
                func_0x0174f458(puVar10 + -0xe8,0);
                func_0x0174f458(puVar10 + -0xe8,0);
                *(undefined8 *)(puVar10 + -0xf0) = 0;
                lVar17 = func_0x0174fdd0(plVar38 + 0x21,puVar10 + -0xe8,puVar10 + -0xf0);
                if (lVar17 != 0) {
                  plVar27 = (long *)(lVar17 + -0x18);
                  puVar10 = *(undefined1 **)(puVar10 + -0xe8);
joined_r0x01001414:
                  if ((puVar10 != unaff_x25) && (puVar10 != (undefined1 *)0x0)) {
                    __ZdaPv();
                  }
                  return plVar27;
                }
/*  unlicensed copy if this notice is missing  */
                unaff_x26 = (long *)((ulong)puVar19 & 0xfffffffffffffff0);
                if ((((ulong)puVar19 & 0xf) == 0) && (*(long *)(*unaff_x26 + 8) == *unaff_x26)) {
                  plVar27 = (long *)func_0x009d11e8(plVar38 + 0xf2,0x28,0x10);
                  uVar32 = *(uint *)(*unaff_x26 + 0x10);
                  *plVar27 = (long)plVar27;
                  plVar27[1] = (long)plVar27;
                  uVar24 = 0;
                  if ((uVar32 & 0x300) != 0) {
                    uVar24 = 0x200;
                  }
                  plVar27[3] = 0;
                  plVar27[4] = (long)puVar19;
                  *(uint *)(plVar27 + 2) =
                       uVar32 & 0xd00 | uVar24 | (uint)*(byte *)((long)plVar27 + 0x13) << 0x18 | 8;
                  func_0x0174fce8(plVar38 + 0x21,plVar27 + 3,*(undefined8 *)(puVar10 + -0xf0));
                  plVar25 = (long *)plVar38[2];
                  if ((long *)plVar38[3] <= plVar25) {
                    func_0x01755374(plVar38 + 1,plVar38 + 4,0,8);
                    plVar25 = (long *)plVar38[2];
                  }
                  *plVar25 = (long)plVar27;
/* WM - proprietary - see LICENSE - do not sell */
                  plVar38[2] = plVar38[2] + 8;
                  puVar10 = *(undefined1 **)(puVar10 + -0xe8);
                  goto joined_r0x01001414;
                }
                uVar32 = (uint)unaff_x26[1];
                uVar24 = uVar32 | (uint)puVar19;
                puVar15 = (undefined8 *)(unaff_x26[1] & 0xfffffffffffffff0);
                if ((uVar32 >> 3 & 1) == 0) {
                  uVar24 = uVar24 & 7;
                }
                else {
                  uVar24 = *(uint *)(puVar15 + 3) | uVar24 & 7;
                  puVar15 = (undefined8 *)*puVar15;
                }
                unaff_x23 = (undefined1 *)(ulong)uVar24;
                unaff_x30 = &UNK_01001478;
                puVar10 = puVar10 + -0xf0;
                unaff_x19 = plVar38;
                unaff_x20 = 0;
                unaff_x21 = 0;
                unaff_x22 = puVar19;
              } while( true );
            }
          }
          if ((*(ulong *)((uVar30 & 0xfffffffffffffff0) + 8) | uVar30 & 7) ==
              (*(ulong *)(((ulong)puVar15 & 0xfffffffffffffff0) + 8) | (ulong)puVar15 & 7)) {
            return param_2;
/* WM: do not claim this as your own @ discord.gg/sdkhDjTex */
          }
          plVar25 = param_2;
          if (lVar16 == 0) {
            return param_2;
          }
        }
LAB_01010294:
        if ((*(ulong *)((uVar28 & 0xfffffffffffffff0) + 8) | uVar28 & 7) !=
            (*(ulong *)(((ulong)puVar15 & 0xfffffffffffffff0) + 8) | (ulong)puVar15 & 7)) {
          plVar27 = plVar25;
        }
        return plVar27;
      }
LAB_010100dc:
      if ((*(ulong *)((uVar28 & 0xfffffffffffffff0) + 8) | uVar28 & 7) ==
          (*(ulong *)(((ulong)puVar15 & 0xfffffffffffffff0) + 8) | (ulong)puVar15 & 7)) {
        return plVar27;
      }
      if (!bVar6) goto LAB_01010200;
/* found on a paste site? it was re-uploaded illegally */
    }
    lVar16 = lVar17;
LAB_01010200:
    puVar20 = (uint *)(lVar16 + 0x28);
    puVar10 = (undefined1 *)register0x00000008;
    do {
      puVar19 = puVar15;
      *(undefined8 *)(puVar10 + -0x60) = unaff_x28;
      *(undefined8 *)(puVar10 + -0x58) = unaff_x27;
      *(long **)(puVar10 + -0x50) = unaff_x26;
      *(undefined1 **)(puVar10 + -0x48) = unaff_x25;
      *(long **)(puVar10 + -0x40) = unaff_x24;
      *(undefined1 **)(puVar10 + -0x38) = unaff_x23;
      *(undefined8 **)(puVar10 + -0x30) = unaff_x22;
      *(undefined8 *)(puVar10 + -0x28) = unaff_x21;
      *(ulong *)(puVar10 + -0x20) = unaff_x20;
      *(long **)(puVar10 + -0x18) = unaff_x19;
      *(undefined1 **)(puVar10 + -0x10) = unaff_x29;
      *(undefined **)(puVar10 + -8) = unaff_x30;
      unaff_x29 = puVar10 + -0x10;
      uVar24 = *puVar20;
      *(uint *)(puVar10 + -0x70) = uVar24;
      *(undefined8 *)(puVar10 + -0x68) = 0;
      if (uVar24 < 0x41) {
        *(undefined8 *)(puVar10 + -0x68) = *(undefined8 *)(puVar20 + 2);
        plVar27 = (long *)plVar38[0x777];
        uVar28 = *(ulong *)(((ulong)puVar19 & 0xfffffffffffffff0) + 8);
        if (((uint)uVar28 >> 3 & 1) != 0) goto code_r0x0100067c;
code_r0x010006c4:
        uVar28 = (ulong)*(byte *)((long)plVar27 + 0x53);
      }
      else {
        func_0x0173a170(puVar10 + -0x70,puVar20);
// WM - if you paid for this, you were scammed
        plVar27 = (long *)plVar38[0x777];
        uVar28 = *(ulong *)(((ulong)puVar19 & 0xfffffffffffffff0) + 8);
        if (((uint)uVar28 >> 3 & 1) == 0) goto code_r0x010006c4;
code_r0x0100067c:
        uVar24 = *(uint *)((uVar28 & 0xfffffffffffffff0) + 0x18) >> 8;
        if (0xfffffff8 < uVar24 - 0xffff07) {
          uVar24 = *(uint *)(plVar38[0x775] + (ulong)(uVar24 - 0xffff00) * 4);
        }
        if (uVar24 == 0) goto code_r0x010006c4;
        uVar28 = (**(code **)(*plVar27 + 0x110))();
      }
      unaff_x26 = (long *)((ulong)puVar19 & 0xfffffffffffffff0);
      func_0x0173dba4(puVar10 + -0x108,puVar10 + -0x70,uVar28);
      if ((0x40 < *(uint *)(puVar10 + -0x70)) && (*(long *)(puVar10 + -0x68) != 0)) {
        __ZdaPv();
      }
/* watermarked copy - do not remove */
      *(undefined8 *)(puVar10 + -0x68) = *(undefined8 *)(puVar10 + -0x100);
      *(undefined4 *)(puVar10 + -0x70) = *(undefined4 *)(puVar10 + -0x108);
      unaff_x25 = puVar10 + -0xf0;
      *(undefined1 **)(puVar10 + -0x108) = unaff_x25;
      *(undefined1 **)(puVar10 + -0x100) = unaff_x25;
      *(undefined1 **)(puVar10 + -0xf8) = puVar10 + -0x70;
      func_0x0174f3f4(puVar10 + -0x108,puVar19);
      puVar15 = (undefined8 *)(puVar10 + -0x68);
      if (0x40 < *(uint *)(puVar10 + -0x70)) {
        puVar15 = *(undefined8 **)(puVar10 + -0x68);
      }
      func_0x0174f4b4(puVar10 + -0x108,*puVar15);
      func_0x0174f458(puVar10 + -0x108,0);
      func_0x0174f458(puVar10 + -0x108,0);
      *(undefined8 *)(puVar10 + -0x110) = 0;
      lVar17 = func_0x0174fdd0(plVar38 + 0x1e,puVar10 + -0x108,puVar10 + -0x110);
      if (lVar17 != 0) {
        plVar27 = (long *)(lVar17 + -0x18);
        puVar9 = *(undefined1 **)(puVar10 + -0x108);
        goto joined_r0x0100077c;
      }
      if ((*(long *)(*unaff_x26 + 8) == *unaff_x26) && (((ulong)puVar19 & 0xf) == 0)) {
        plVar27 = (long *)func_0x009d11e8(plVar38 + 0xf2,0x38,0x10);
        uVar32 = *(uint *)(*unaff_x26 + 0x10);
        *plVar27 = (long)plVar27;
        plVar27[1] = (long)plVar27;
        uVar24 = 0;
        if ((uVar32 & 0x300) != 0) {
          uVar24 = 0x200;
        }
        plVar27[3] = 0;
        plVar27[4] = (long)puVar19;
        *(uint *)(plVar27 + 2) =
             uVar32 & 0xd00 | uVar24 | (uint)*(byte *)((long)plVar27 + 0x13) << 0x18 | 7;
        uVar24 = *(uint *)(puVar10 + -0x70);
        *(uint *)(plVar27 + 5) = uVar24;
        plVar27[6] = 0;
        if (uVar24 < 0x41) {
// WM - more drops soon - github.com/pengussy
          plVar27[6] = *(long *)(puVar10 + -0x68);
        }
        else {
          func_0x0173a170(plVar27 + 5,puVar10 + -0x70);
        }
        func_0x0174fce8(plVar38 + 0x1e,plVar27 + 3,*(undefined8 *)(puVar10 + -0x110));
        plVar25 = (long *)plVar38[2];
        if ((long *)plVar38[3] <= plVar25) {
          func_0x01755374(plVar38 + 1,plVar38 + 4,0,8);
          plVar25 = (long *)plVar38[2];
        }
        *plVar25 = (long)plVar27;
        plVar38[2] = plVar38[2] + 8;
        puVar9 = *(undefined1 **)(puVar10 + -0x108);
joined_r0x0100077c:
        if ((puVar9 != unaff_x25) && (puVar9 != (undefined1 *)0x0)) {
          __ZdaPv();
/*
 *  if you paid for this, you were scammed
 *
 *  @pengussy
 */
        }
        if ((0x40 < *(uint *)(puVar10 + -0x70)) && (*(long *)(puVar10 + -0x68) != 0)) {
          __ZdaPv();
        }
        return plVar27;
      }
      uVar32 = (uint)unaff_x26[1];
      uVar24 = uVar32 | (uint)puVar19;
      puVar15 = (undefined8 *)(unaff_x26[1] & 0xfffffffffffffff0);
      if ((uVar32 >> 3 & 1) == 0) {
        uVar24 = uVar24 & 7;
      }
      else {
        uVar24 = *(uint *)(puVar15 + 3) | uVar24 & 7;
        puVar15 = (undefined8 *)*puVar15;
      }
      unaff_x23 = (undefined1 *)(ulong)uVar24;
      puVar20 = (uint *)(puVar10 + -0x70);
      unaff_x30 = &UNK_010007e0;
      puVar10 = puVar10 + -0x110;
      unaff_x19 = plVar38;
      unaff_x20 = 0;
      unaff_x21 = 0;
      unaff_x22 = puVar19;
    } while( true );
  case 10:
  case 0xb:
  case 0x10:
  case 0x11:
  case 0x12:
/* WM: stripping the watermark breaks the license @ discord.gg/sdkhDjTex */
  case 0x13:
  case 0x14:
  case 0x15:
  case 0x16:
  case 0x17:
  case 0x18:
  case 0x1b:
  case 0x1c:
  case 0x1d:
  case 0x1e:
  case 0x1f:
  case 0x20:
  case 0x22:
  case 0x23:
  case 0x24:
  case 0x25:
    func_0x0174ef58("Non-canonical and dependent types shouldn\'t get here",
                    "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/lib/AST/ASTContext.cpp"
                    ,&UNK_00001e12);
  case 8:
  case 9:
  case 0xd:
  case 0xe:
  case 0x27:
    func_0x0174ef58("Types are eliminated above",
                    "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/lib/AST/ASTContext.cpp"
                    ,&UNK_00001e1f);
    goto code_r0x01010478;
  case 0xc:
    lVar17 = func_0x00b9195c(*(long *)(uVar28 & 0xfffffffffffffff0));
    lVar16 = func_0x00b9195c(*plVar37);
    if ((*(long *)(lVar17 + 0x20) == *(long *)(lVar16 + 0x20)) &&
// WM - do not claim this as your own
       ((*(uint *)(lVar16 + 0x10) ^ *(uint *)(lVar17 + 0x10)) < 0x200000)) {
      return param_2;
    }
    break;
  case 0xf:
    pplVar4 = (long **)auStack_160;
    plVar25 = alStack_c0 + 0x16;
    plStack_70 = *(long **)PTR____stack_chk_guard_01f20200;
    plVar40 = *(long **)((ulong)param_2 & 0xfffffffffffffff0);
    if (plVar40 == (long *)0x0 || (*(uint *)(plVar40 + 2) & 0xfe) != 0xe) {
      if ((*(uint *)(*(long *)(plVar40[1] & 0xfffffffffffffff0) + 0x10) & 0xfe) == 0xe) {
        plVar40 = (long *)func_0x01148f40(plVar40);
        if ((*(uint *)(plVar40 + 2) & 0xfe) != 0xe) {
          func_0x0174f200("cast");
        }
      }
      else {
        plVar40 = (long *)0x0;
      }
    }
    plVar26 = *(long **)((ulong)plVar27 & 0xfffffffffffffff0);
    if (plVar26 == (long *)0x0 || (*(uint *)(plVar26 + 2) & 0xfe) != 0xe) {
      if ((*(uint *)(*(long *)(plVar26[1] & 0xfffffffffffffff0) + 0x10) & 0xfe) == 0xe) {
        plVar26 = (long *)func_0x01148f40(plVar26);
        if ((*(uint *)(plVar26 + 2) & 0xfe) != 0xe) {
          func_0x0174f200("cast");
        }
      }
/* WM - if you paid for this, you were scammed */
      else {
        plVar26 = (long *)0x0;
      }
    }
    plVar37 = plVar40;
    if ((char)plVar40[2] != '\x0e') {
      plVar37 = (long *)0x0;
    }
    plVar23 = plVar26;
    if ((char)plVar26[2] != '\x0e') {
      plVar23 = (long *)0x0;
    }
    if (uVar24 == 0) {
      plVar22 = (long *)plVar26[3];
      plVar18 = (long *)FUN_0100f5a0(plVar38,plVar40[3],plVar22,0,param_5,0);
      if ((long *)((long)&MACH_HEADER.filetype + 3) < plVar18) goto code_r0x010107bc;
    }
    else {
      plVar22 = (long *)plVar26[3];
      uVar28 = plVar40[3];
      if (((ulong)param_5 & 1) == 0) {
        if ((((ulong)plVar22 & 0xf) == 0) && ((*(byte *)(plVar22 + 1) & 0xf) == 0)) {
          if ((uVar28 & 0xf) != 0) goto code_r0x01010754;
          bVar6 = (*(byte *)(uVar28 + 8) & 0xf) != 0;
/* donate: donate/README.md */
        }
        else {
          bVar6 = false;
        }
      }
      else {
code_r0x01010754:
        bVar6 = true;
      }
      plVar18 = (long *)FUN_0100f5a0(plVar38,uVar28,plVar22,1,bVar6,1);
      if (&MACH_HEADER.ncmds <= plVar18) {
code_r0x010107bc:
        if (iVar7 == 0) {
          uVar30 = *(ulong *)((plVar40[3] & 0xfffffffffffffff0U) + 8) | plVar40[3] & 7U;
          uVar28 = *(ulong *)((plVar26[3] & 0xfffffffffffffff0U) + 8) | plVar26[3] & 7U;
        }
        else {
          plVar29 = *(long **)((ulong)plVar18 & 0xfffffffffffffff0);
          if ((*(byte *)(plVar29 + 1) & 0xf) != 0) {
            plVar29 = (long *)func_0x011494dc(plVar18);
          }
          uVar30 = *(ulong *)(*(ulong *)((plVar40[3] & 0xfffffffffffffff0U) + 8) &
                             0xfffffffffffffff0);
          uVar28 = *(ulong *)(*(ulong *)((plVar26[3] & 0xfffffffffffffff0U) + 8) &
                             0xfffffffffffffff0);
          plVar18 = plVar29;
        }
        uVar24 = *(uint *)(plVar40 + 2);
        uVar32 = *(uint *)(plVar26 + 2);
        if (((uVar32 ^ uVar24) >> 0x12 & 0xf) == 0) {
          uVar35 = uVar24 >> 0x12 & 0x1ff;
/*  reversing this took months of machine time  */
          uVar36 = uVar32 >> 0x12 & 0x1ff;
          if (0x3f < uVar35 == 0x3f < uVar36) {
            if (uVar35 < 0x41) {
              uVar35 = 0x40;
            }
            if (uVar36 < 0x41) {
              uVar36 = 0x40;
            }
            if (((uVar36 ^ uVar35) < 0x40) && (((uVar32 ^ uVar24) >> 0x17 & 1) == 0)) {
              uVar41 = *(ulong *)(((ulong)plVar18 & 0xfffffffffffffff0) + 8) | (ulong)plVar18 & 7;
              uVar35 = uVar32 >> 0x12 & 0x10;
              bVar6 = (uVar24 >> 0x12 & 0x10) != 0;
              bVar5 = bVar6 || uVar35 != 0;
              uStack_14c = 0x10;
              if (!bVar6 && uVar35 == 0) {
                uStack_14c = 0;
              }
              uStack_12c = (uint)(uVar41 == uVar30) & ((uint)bVar5 ^ uVar24 >> 0x16 ^ 0xffffffff);
              uStack_130 = 0;
              if (uVar41 == uVar28) {
                uStack_130 = (uint)((uVar35 == 0) != bVar5);
              }
              uStack_14c = uStack_14c | uVar24 >> 0x12 & 0x1ef;
              uStack_da = (undefined2)uStack_14c;
              plVar29 = param_2;
              if ((plVar37 == (long *)0x0) || (plVar23 == (long *)0x0)) {
                plVar40 = plVar37;
/* +- WM -------------------------------------------------------------+
   |  donate: donate/README.md
   +--------------------------------------------------------------------*/
                if (plVar37 == (long *)0x0) {
                  plVar40 = plVar23;
                }
                uVar24 = plVar37 == (long *)0x0 & uStack_130;
                uVar32 = plVar23 == (long *)0x0 & uStack_12c;
                param_5 = (long *)(ulong)uVar32;
                if (plVar40 == (long *)0x0) {
                  if (uVar32 == 0) {
                    plVar29 = plVar27;
                  }
                  if (uVar32 == 0 && uVar24 == 0) {
                    plVar22 = (long *)&uStack_da;
                    plVar29 = (long *)func_0x00ffee88(plVar38,plVar18);
                  }
                  goto code_r0x01010ac0;
                }
                if ((*(uint *)(plVar40 + 5) >> 0x1d & 1) == 0) {
                  uVar28 = (ulong)*(uint *)(plVar40 + 5) & 0x7fff;
                  if ((int)uVar28 != 0) {
                    puVar39 = (ulong *)(plVar40 + 6);
                    do {
                      plVar26 = (long *)(*puVar39 & 0xfffffffffffffff0);
                      lVar17 = *plVar26;
                      lVar16 = *(long *)(*(ulong *)(lVar17 + 8) & 0xfffffffffffffff0);
                      if (lVar16 != 0 && *(char *)(lVar16 + 0x10) == '\x1a') {
                        lVar17 = func_0x0114c0c4(lVar16);
                        uVar30 = *(ulong *)(lVar17 + 0x88);
                        if (uVar30 < 4) goto code_r0x01010abc;
                        puVar11 = (ulong *)(uVar30 & 0xfffffffffffffffc);
                        if (((uint)uVar30 >> 1 & 1) != 0) {
                          uVar30 = *puVar11;
                          puVar11 = *(ulong **)(uVar30 & 0xfffffffffffffff0);
/* +- WM -------------------------------------------------------------+
   |  chat: discord.gg/sdkhDjTex
   +--------------------------------------------------------------------*/
                          if ((puVar11[1] & 0xf) != 0) {
                            puVar11 = (ulong *)func_0x011494dc(uVar30);
                          }
                        }
                        if (puVar11 < &MACH_HEADER.ncmds) goto code_r0x01010abc;
                        plVar26 = (long *)((ulong)puVar11 & 0xfffffffffffffff0);
                        lVar17 = *plVar26;
                      }
                      uVar30 = func_0x0114dc4c(lVar17);
                      if (((uVar30 & 1) != 0) ||
                         (plVar38[0x7d1] == *(long *)(plVar26[1] & 0xfffffffffffffff0)))
                      goto code_r0x01010abc;
                      uVar28 = uVar28 - 1;
                      puVar39 = puVar39 + 1;
                    } while (uVar28 != 0);
                  }
                  if (uVar32 == 0) {
                    plVar29 = plVar27;
                  }
                  if (uVar32 == 0 && uVar24 == 0) {
                    func_0x00b439a0(&plStack_d8,plVar40);
                    plStack_d8 = (long *)CONCAT62(plStack_d8._2_6_,(short)uStack_14c);
                    plVar22 = plVar40 + 6;
                    uVar32 = *(uint *)(plVar40 + 5);
                    uVar28 = (ulong)uVar32 & 0x7fff;
                    uVar24 = uVar32 >> 0xf & 0x1ff;
                    if ((uVar32 & 0xf000000) != 0x2000000) {
                      uVar24 = 0;
                    }
                    plVar29 = (long *)func_0x00fff058(plVar38,plVar18,plVar22,uVar28,&plStack_d8,
                                                      plVar22 + uVar28 + uVar24,uVar28);
                  }
                  goto code_r0x01010ac0;
                }
              }
              else if ((((*(uint *)(plVar26 + 5) ^ *(uint *)(plVar37 + 5)) & 0x20007fff) == 0) &&
/*
   origin: github.com/pengussy
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
                      (((uVar32 ^ uVar24) & 0x38000000) == 0)) {
                plStack_158 = alStack_c0;
                pplStack_c8 = &plStack_70;
                uStack_140 = (ulong)*(uint *)(plVar37 + 5) & 0x7fff;
                plStack_d8 = plStack_158;
                plStack_d0 = plStack_158;
                if ((int)uStack_140 == 0) {
                  if ((uStack_12c == 0) && (plVar29 = plVar27, uStack_130 == 0)) {
                    func_0x00b439a0(auStack_120,plVar40);
                    auStack_120[0] = (undefined2)uStack_14c;
                    uVar32 = *(uint *)(plVar37 + 5);
                    uVar24 = uVar32 >> 0xf & 0x1ff;
                    if ((uVar32 & 0xf000000) != 0x2000000) {
                      uVar24 = 0;
                    }
                    plVar22 = plStack_d8;
                    plVar29 = (long *)func_0x00fff058(plVar38,plVar18,plStack_d8,
                                                      (long)plStack_d0 - (long)plStack_d8 >> 3,
                                                      auStack_120,
                                                      plVar37 + ((ulong)uVar32 & 0x7fff) +
                                                                (ulong)uVar24 + 6);
                  }
                  if ((plStack_d8 != plStack_158) && (plStack_d8 != (long *)0x0)) {
                    __ZdaPv(plStack_d8);
                  }
                  goto code_r0x01010ac0;
                }
                puVar39 = (ulong *)(plVar26 + 6);
                plStack_138 = plVar40 + 7;
                lStack_128 = *(long *)(plVar40[6] & 0xfffffffffffffff0);
/* unlicensed copy if this notice is missing */
                if ((*(byte *)(lStack_128 + 8) & 0xf) != 0) {
                  lStack_128 = func_0x011494dc();
                }
                auVar44._8_8_ = lStack_128;
                auVar44._0_8_ = plVar38;
                puVar21 = *(undefined **)(*puVar39 & 0xfffffffffffffff0);
                puStack_148 = puVar39;
                if ((puVar21[8] & 0xf) != 0) {
                  puVar21 = (undefined *)func_0x011494dc();
                }
                puVar43 = &UNK_01010bd8;
                plVar26 = param_4;
                plVar25 = param_5;
                plVar37 = plVar27;
                goto code_r0x010104a8;
              }
            }
          }
        }
      }
    }
code_r0x01010abc:
    plVar29 = (long *)0x0;
code_r0x01010ac0:
    if (*(long **)PTR____stack_chk_guard_01f20200 == plStack_70) {
      return plVar29;
    }
    plVar26 = (long *)___stack_chk_fail(plVar29);
    if (plStack_d8 == plStack_158 || plStack_d8 == (long *)0x0) {
      __Unwind_Resume(plVar26);
    }
    __ZdaPv();
    puVar21 = &DAT_01010e08;
    auVar44 = __Unwind_Resume(plVar26);
    plVar37 = auVar44._0_8_;
    puVar10 = auStack_160;
    plVar38 = auVar44._8_8_;
    do {
/* stripping the watermark breaks the license */
      while( true ) {
        plVar23 = plVar22;
        plVar29 = plVar38;
        *(long **)(puVar10 + -0x40) = param_5;
        *(long **)(puVar10 + -0x38) = plVar40;
        *(long **)(puVar10 + -0x30) = plVar18;
        *(long **)(puVar10 + -0x28) = param_2;
        *(long **)(puVar10 + -0x20) = plVar27;
        *(long **)(puVar10 + -0x18) = plVar26;
        *(long **)(puVar10 + -0x10) = plVar25;
        *(undefined **)(puVar10 + -8) = puVar21;
        plVar25 = (long *)(puVar10 + -0x10);
        plVar18 = (long *)((ulong)plVar29 & 0xfffffffffffffff0);
        uVar30 = plVar18[1];
        uVar42 = uVar30 | (ulong)plVar29 & 7;
        uVar41 = ((long *)((ulong)plVar23 & 0xfffffffffffffff0))[1];
        uVar28 = uVar41 | (ulong)plVar23 & 7;
        if (uVar42 == uVar28) {
          return plVar29;
        }
        lVar17 = *(long *)(uVar41 & 0xfffffffffffffff0);
        uVar24 = *(uint *)(*(long *)(*(ulong *)(lVar17 + 8) & 0xfffffffffffffff0) + 0x10);
        if ((uVar24 & 0xfe) != 0xe) break;
        lVar16 = *(long *)(uVar30 & 0xfffffffffffffff0);
        if ((*(uint *)(*(long *)(*(ulong *)(lVar16 + 8) & 0xfffffffffffffff0) + 0x10) & 0xfe) != 0xe
           ) {
          return (long *)0x0;
        }
        if ((*(uint *)(lVar17 + 0x10) & 0xfe) != 0xe) {
          func_0x0174f200("cast");
          lVar16 = *(long *)(uVar30 & 0xfffffffffffffff0);
        }
        plVar26 = *(long **)(lVar17 + 0x18);
        if ((*(uint *)(lVar16 + 0x10) & 0xfe) != 0xe) {
          func_0x0174f200("cast");
        }
        puVar21 = &UNK_01010f04;
        puVar10 = puVar10 + -0x80;
// WM - watermarked copy - do not remove
        plVar38 = *(long **)(lVar16 + 0x18);
        plVar22 = plVar26;
        plVar27 = plVar37;
        param_2 = *(long **)(lVar16 + 0x18);
      }
      uVar32 = (uint)uVar42;
      uVar35 = (uint)uVar28;
      if (((uint)uVar30 >> 3 & 1) == 0) {
        uVar36 = 0;
        uVar32 = uVar32 & 7;
        if (((uint)uVar41 >> 3 & 1) != 0) goto code_r0x01010f8c;
code_r0x01011024:
        uVar34 = 0;
        uVar35 = uVar35 & 7;
        if (uVar32 != uVar35) {
code_r0x01010fa0:
          if (((uVar35 ^ uVar32) & 7) != 0) {
            return (long *)0x0;
          }
          if (0xff < (uVar34 ^ uVar36)) {
            return (long *)0x0;
          }
          uVar24 = uVar36 >> 3 & 3;
/*
   donate: donate/README.md
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
          if (uVar24 == 1) {
            return (long *)0x0;
          }
          uVar32 = uVar34 >> 3 & 3;
          if (uVar32 == 1) {
            return (long *)0x0;
          }
          if (uVar24 == 2) {
            return plVar29;
          }
          if (uVar32 != 2) {
            plVar23 = (long *)0x0;
          }
          return plVar23;
        }
      }
      else {
        uVar36 = *(uint *)((uVar30 & 0xfffffffffffffff0) + 0x18);
        uVar32 = uVar36 | uVar32 & 7;
        if (((uint)uVar41 >> 3 & 1) == 0) goto code_r0x01011024;
code_r0x01010f8c:
        uVar34 = *(uint *)((long *)(uVar41 & 0xfffffffffffffff0) + 3);
        uVar35 = uVar34 | uVar35 & 7;
        if (uVar32 != uVar35) goto code_r0x01010fa0;
      }
      if ((uVar24 & 0xff) != 0x28) {
        return (long *)0x0;
      }
      if (*(char *)(*(long *)(*(ulong *)(*(long *)(uVar30 & 0xfffffffffffffff0) + 8) &
                             0xfffffffffffffff0) + 0x10) != '(') {
        return (long *)0x0;
      }
      lVar17 = *plVar18;
      if ((lVar17 == 0) || (*(char *)(lVar17 + 0x10) != '(')) {
        lVar17 = func_0x01148f40(lVar17);
        plVar40 = plVar37;
// no support for modified copies
        if (*(char *)(lVar17 + 0x10) != '(') {
          func_0x0174f200("cast");
        }
      }
      plVar26 = *(long **)(lVar17 + 0x20);
      lVar17 = *(long *)((ulong)plVar23 & 0xfffffffffffffff0);
      if ((lVar17 == 0) || (*(char *)(lVar17 + 0x10) != '(')) {
        lVar17 = func_0x01148f40(lVar17);
        plVar40 = plVar37;
        if (*(char *)(lVar17 + 0x10) != '(') {
          func_0x0174f200("cast");
        }
      }
      plVar27 = *(long **)(lVar17 + 0x20);
      puVar21 = &UNK_01011110;
      puVar10 = puVar10 + -0x80;
      plVar38 = plVar26;
      plVar22 = plVar27;
      param_2 = plVar23;
      plVar18 = plVar29;
    } while( true );
  case 0x26:
    uVar12 = func_0x009c31e8(*puVar39);
    uVar13 = func_0x009c31e8(*plVar40);
    iVar7 = func_0x0100d104(plStack_70,uVar12,uVar13);
    goto LAB_0100fcf0;
  case 0x28:
    uVar12 = func_0x00dd9a94(*puVar39);
    uVar13 = func_0x00dd9a94(*plVar40);
    if (uVar24 == 0) {
      iVar7 = func_0x0100cd08(plStack_70,uVar12,uVar13);
    }
    else {
      iVar7 = func_0x0100d7b4(plStack_70,uVar12,uVar13,param_6);
    }
LAB_0100fcf0:
    if (iVar7 == 0) {
/* thanks for reading - discord.gg/sdkhDjTex - github.com/pengussy */
      param_2 = (long *)0x0;
    }
    return param_2;
  case 0x29:
    lVar17 = func_0x00b5b4e4(*puVar39);
    uVar30 = *(ulong *)(lVar17 + 0x20);
    lVar17 = func_0x00b5b4e4(*plVar40);
    uVar28 = *(ulong *)(lVar17 + 0x20);
    if (iVar7 == 0) {
      plVar25 = plStack_70;
    }
    else {
      uVar41 = *(ulong *)(uVar30 & 0xfffffffffffffff0);
      if ((*(byte *)(uVar41 + 8) & 0xf) != 0) {
        uVar41 = func_0x011494dc(uVar30);
      }
      plVar25 = plStack_70;
      uVar30 = uVar41;
      if ((*(byte *)(*(ulong *)(uVar28 & 0xfffffffffffffff0) + 8) & 0xf) == 0) {
        uVar28 = *(ulong *)(uVar28 & 0xfffffffffffffff0);
      }
      else {
        uVar28 = func_0x011494dc(uVar28);
      }
    }
    uVar41 = FUN_0100f5a0(plVar25,uVar30,uVar28,0,param_5,0);
    if (0xf < uVar41) {
      uVar42 = *(ulong *)((uVar41 & 0xfffffffffffffff0) + 8) | uVar41 & 7;
      if ((*(ulong *)((uVar30 & 0xfffffffffffffff0) + 8) | uVar30 & 7) == uVar42) {
        return param_2;
      }
      if ((*(ulong *)((uVar28 & 0xfffffffffffffff0) + 8) | uVar28 & 7) == uVar42) {
        return plVar27;
      }
      puVar10 = (undefined1 *)register0x00000008;
      do {
        uVar28 = uVar41;
        *(long **)(puVar10 + -0x40) = unaff_x24;
/*
   watermarked copy - do not remove
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
        *(undefined1 **)(puVar10 + -0x38) = unaff_x23;
        *(undefined8 **)(puVar10 + -0x30) = unaff_x22;
        *(undefined8 *)(puVar10 + -0x28) = unaff_x21;
        *(ulong *)(puVar10 + -0x20) = unaff_x20;
        *(long **)(puVar10 + -0x18) = unaff_x19;
        *(undefined1 **)(puVar10 + -0x10) = unaff_x29;
        *(undefined **)(puVar10 + -8) = unaff_x30;
        unaff_x29 = puVar10 + -0x10;
        unaff_x23 = puVar10 + -0xc0;
        *(undefined1 **)(puVar10 + -0xd8) = unaff_x23;
        *(undefined1 **)(puVar10 + -0xd0) = unaff_x23;
        *(undefined1 **)(puVar10 + -200) = puVar10 + -0x40;
        func_0x0174f3f4(puVar10 + -0xd8);
        *(undefined8 *)(puVar10 + -0xe0) = 0;
        lVar17 = func_0x0174fdd0(plVar25 + 99,puVar10 + -0xd8,puVar10 + -0xe0);
        if (lVar17 != 0) {
          plVar27 = (long *)(lVar17 + -0x18);
code_r0x01000e2c:
          if ((*(undefined1 **)(puVar10 + -0xd8) != unaff_x23) &&
/* thanks for reading - discord.gg/sdkhDjTex */
             (*(undefined1 **)(puVar10 + -0xd8) != (undefined1 *)0x0)) {
            __ZdaPv();
          }
          return plVar27;
        }
        unaff_x24 = (long *)(uVar28 & 0xfffffffffffffff0);
        if (*(long *)(*unaff_x24 + 8) == *unaff_x24) {
          plVar27 = (long *)func_0x009d11e8(plVar25 + 0xf2,0x28,0x10);
          uVar32 = *(uint *)(*unaff_x24 + 0x10);
          *plVar27 = (long)plVar27;
          plVar27[1] = (long)plVar27;
          uVar24 = 0;
          if ((uVar32 & 0x300) != 0) {
            uVar24 = 0x200;
          }
          *(uint *)(plVar27 + 2) =
               uVar32 & 0xd00 | *(uint *)(plVar27 + 2) & 0xfffc0000 | uVar24 | 0x29;
          plVar27[3] = 0;
          plVar27[4] = uVar28;
          plVar26 = (long *)plVar25[2];
          if ((long *)plVar25[3] <= plVar26) {
            func_0x01755374(plVar25 + 1,plVar25 + 4,0,8);
            plVar26 = (long *)plVar25[2];
/* WM - do not claim this as your own */
          }
          *plVar26 = (long)plVar27;
          plVar25[2] = plVar25[2] + 8;
          func_0x0174fce8(plVar25 + 99,plVar27 + 3,*(undefined8 *)(puVar10 + -0xe0));
          goto code_r0x01000e2c;
        }
        unaff_x30 = &UNK_01000d88;
        puVar10 = puVar10 + -0xe0;
        uVar41 = unaff_x24[1] | uVar28 & 7;
        unaff_x19 = plVar25;
        unaff_x20 = uVar28;
      } while( true );
    }
    break;
  default:
    goto LAB_01010490;
  }
  return (long *)0x0;
code_r0x01010478:
  func_0x0174ef58("C++ should never be in mergeTypes",
                  "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/lib/AST/ASTContext.cpp"
                  ,&UNK_00001e18);
LAB_01010490:
/* wm:unlicensed copy if this notice is missing */
  puVar21 = &UNK_00001eb3;
  puVar43 = &DAT_010104a8;
  auVar44 = func_0x0174ef58("Invalid Type::Class!",
                            "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/lib/AST/ASTContext.cpp"
                            ,&UNK_00001eb3);
  plVar38 = plVar37;
  plVar37 = param_2;
  param_2 = plVar27;
  plVar18 = param_5;
  plVar40 = param_4;
  param_5 = param_6;
code_r0x010104a8:
  *(long **)((long)pplVar4 + -0x40) = param_5;
  *(long **)((long)pplVar4 + -0x38) = plVar40;
  *(long **)((long)pplVar4 + -0x30) = plVar18;
  *(long **)((long)pplVar4 + -0x28) = param_2;
  *(long **)((long)pplVar4 + -0x20) = plVar37;
  *(long **)((long)pplVar4 + -0x18) = plVar38;
  *(long **)((long)pplVar4 + -0x10) = alStack_c0 + 0x16;
  *(undefined **)((long)pplVar4 + -8) = puVar43;
  lVar17 = func_0x01149e84(*(undefined8 *)(auVar44._8_8_ & 0xfffffffffffffff0));
  if ((lVar17 == 0) || (lVar17 = func_0x0114c0c4(), (*(byte *)(lVar17 + 0x1d) >> 1 & 1) == 0)) {
    return (long *)0x0;
  }
  puVar39 = (ulong *)func_0x010840b4();
  plVar27 = (long *)*puVar39;
  plVar40 = (long *)puVar39[1];
  if (plVar27 < plVar40) {
    do {
      if (*(short *)(*plVar27 + 8) == 0xcd) goto code_r0x0101055c;
      plVar27 = plVar27 + 1;
/*  do not claim this as your own  */
    } while (plVar27 != plVar40);
  }
  else {
    for (; plVar40 != plVar27; plVar40 = plVar40 + 1) {
      if (*(short *)(*plVar40 + 8) == 0xcd) {
code_r0x0101055c:
        if (plVar27 == plVar40) {
          return (long *)0x0;
        }
        uVar28 = func_0x010774fc(lVar17);
        if (uVar28 == 0) {
          return (long *)0x0;
        }
        do {
          if (2 < *(byte *)(uVar28 + 0x1c) - 0x29) {
            func_0x0174f200("cast");
          }
          lVar17 = *(long *)(*(ulong *)(uVar28 + 0x38) & 0xfffffffffffffff0);
          if ((*(byte *)(lVar17 + 8) & 0xf) != 0) {
            lVar17 = func_0x011494dc();
          }
          plVar27 = (long *)FUN_0100f5a0(auVar44._0_8_,lVar17,puVar21,plVar26,plVar25,0);
          if ((long *)((long)&MACH_HEADER.filetype + 3) < plVar27) {
            return plVar27;
          }
          do {
            uVar28 = *(ulong *)(uVar28 + 8) & 0xfffffffffffffffc;
            if (uVar28 == 0) break;
          } while (2 < *(byte *)(uVar28 + 0x1c) - 0x29);
          if (uVar28 == 0) {
/* origin: github.com/pengussy */
            return (long *)0x0;
          }
        } while( true );
      }
    }
  }
  return (long *)0x0;
}

