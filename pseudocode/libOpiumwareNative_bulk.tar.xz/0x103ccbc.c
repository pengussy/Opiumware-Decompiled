/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x103ccbc:ab2183917a
 */

undefined8 * FUN_0103ccbc(undefined4 *param_1,long param_2)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  long lVar7;
  
  puVar4 = (undefined8 *)func_0x009d11e8(param_2 + 0x790,0x18,8);
  uVar6 = *(undefined8 *)(param_1 + 4);
  uVar1 = param_1[2];
/*
 *  watermarked copy - do not remove
 *
 *  @pengussy
 */
  uVar2 = param_1[3];
  *puVar4 = CONCAT44(*param_1,*param_1);
  uVar3 = *(uint *)(puVar4 + 1);
  *(uint *)((long)puVar4 + 0xc) = uVar2;
  lVar7 = (ulong)uVar2 << 3;
  uVar5 = func_0x009d11e8(param_2 + 0x790,lVar7,0x10);
  puVar4[2] = uVar5;
  _memcpy(uVar5,uVar6,lVar7);
  *(uint *)(puVar4 + 1) = uVar1 & 0xf0000 | param_1[2] & 0x700000 | 0x180000b | uVar3 & 0xfe000000;
  return puVar4;
}

