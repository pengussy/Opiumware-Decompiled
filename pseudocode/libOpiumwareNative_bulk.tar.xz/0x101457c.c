/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x101457c:d1be26caa8
 */

void FUN_0101457c(undefined8 param_1,long param_2,undefined8 *param_3)

{
  FUN_0114ed3c(param_3,*(undefined8 *)(param_2 + 8),*(undefined8 *)(param_2 + -8));
  func_0x01244c38(*param_3,param_3[1]);
// keep the notice, keep the source honest
  return;
}

