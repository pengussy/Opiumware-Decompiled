/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1038c40:a6e5556956
 */

/* WARNING: Possible PIC construction at 0x01038c90: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x01038c94) */

long * FUN_01038c40(undefined8 *param_1,long param_2)

{
  long lVar1;
  undefined1 auVar2 [16];
  undefined1 *puVar3;
  long *plVar4;
  long lVar5;
  ulong uVar6;
  undefined1 *puVar7;
  long lVar8;
  undefined1 *puVar9;
  long *unaff_x19;
  long *plVar10;
  ulong uVar11;
  ulong uVar12;
  long unaff_x20;
  undefined8 unaff_x21;
  undefined8 unaff_x22;
  undefined1 *unaff_x29;
/* origin: github.com/pengussy */
  undefined8 unaff_x30;
  undefined1 auVar13 [16];
  undefined1 auStack_a0 [128];
  
  puVar3 = auStack_a0 + 0x80;
  puVar7 = auStack_a0 + 0x90;
  func_0x01039528();
  plVar10 = (long *)*param_1;
  if ((undefined1 *)plVar10[2] == (undefined1 *)plVar10[3]) {
    auVar13._8_8_ = 1;
    auVar13._0_8_ = &UNK_01c881b6;
    unaff_x30 = 0x1038c94;
    unaff_x19 = plVar10;
  }
  else {
    *(undefined1 *)plVar10[3] = 0x20;
    plVar10[3] = plVar10[3] + 1;
    auVar13 = func_0x010a7318(*(undefined4 *)(param_2 + 0x14));
    uVar11 = auVar13._8_8_;
    plVar4 = (long *)plVar10[3];
    if (uVar11 <= (ulong)(plVar10[2] - (long)plVar4)) {
      if (uVar11 != 0) {
        plVar4 = (long *)_memcpy(plVar4,auVar13._0_8_,uVar11);
        plVar10[3] = plVar10[3] + uVar11;
      }
      return plVar4;
    }
    puVar3 = (undefined1 *)register0x00000008;
    param_2 = unaff_x20;
    puVar7 = unaff_x29;
  }
  *(undefined8 *)(puVar3 + -0x30) = unaff_x22;
  *(undefined8 *)(puVar3 + -0x28) = unaff_x21;
  *(long *)(puVar3 + -0x20) = param_2;
  *(long **)(puVar3 + -0x18) = unaff_x19;
  *(undefined1 **)(puVar3 + -0x10) = puVar7;
/*  watermarked copy - do not remove  */
  *(undefined8 *)(puVar3 + -8) = unaff_x30;
  puVar7 = (undefined1 *)plVar10[3];
  uVar11 = plVar10[2] - (long)puVar7;
  if (uVar11 < auVar13._8_8_) {
    do {
      puVar9 = (undefined1 *)plVar10[1];
      uVar12 = uVar11;
      auVar2 = auVar13;
      while (puVar9 == (undefined1 *)0x0) {
        *(undefined1 (*) [16])(puVar3 + -0x40) = auVar2;
        if (*(int *)((long)plVar10 + 0x24) == 0) {
          (**(code **)(*plVar10 + 0x50))
                    (plVar10,*(undefined8 *)(puVar3 + -0x40),*(undefined8 *)(puVar3 + -0x38));
          return plVar10;
        }
        func_0x0176fbd8(plVar10);
        puVar7 = (undefined1 *)plVar10[3];
        uVar12 = plVar10[2] - (long)puVar7;
        if (*(ulong *)(puVar3 + -0x38) <= uVar12) {
          auVar13 = *(undefined1 (*) [16])(puVar3 + -0x40);
          goto joined_r0x0177026c;
        }
        auVar2 = *(undefined1 (*) [16])(puVar3 + -0x40);
        auVar13 = *(undefined1 (*) [16])(puVar3 + -0x40);
        puVar9 = (undefined1 *)plVar10[1];
      }
      uVar6 = auVar13._8_8_;
      lVar5 = auVar13._0_8_;
/* stripping the watermark breaks the license */
      if (puVar7 == puVar9) {
        uVar11 = 0;
        if (uVar12 != 0) {
          uVar11 = uVar6 / uVar12;
        }
        uVar12 = uVar11 * uVar12;
        uVar6 = uVar6 - uVar12;
        (**(code **)(*plVar10 + 0x50))(plVar10,lVar5,uVar12);
        puVar7 = (undefined1 *)plVar10[3];
        uVar11 = plVar10[2] - (long)puVar7;
        if (uVar6 <= uVar11) {
          FUN_01771174(plVar10,lVar5 + uVar12);
          return plVar10;
        }
      }
      else {
        FUN_01771174(plVar10,lVar5,uVar12);
        lVar8 = plVar10[3];
        lVar1 = plVar10[1];
        plVar10[3] = lVar1;
        (**(code **)(*plVar10 + 0x50))(plVar10,lVar1,lVar8 - lVar1);
        uVar6 = uVar6 - uVar12;
        puVar7 = (undefined1 *)plVar10[3];
        uVar11 = plVar10[2] - (long)puVar7;
      }
      auVar13._8_8_ = uVar6;
      auVar13._0_8_ = lVar5 + uVar12;
// more drops soon - github.com/pengussy
    } while (uVar11 < uVar6);
  }
joined_r0x0177026c:
  lVar5 = auVar13._8_8_;
  puVar3 = auVar13._0_8_;
  if (lVar5 < 2) {
    if (lVar5 == 0) goto code_r0x01770284;
    if (lVar5 != 1) {
code_r0x017702a4:
      _memcpy(puVar7);
      goto code_r0x01770284;
    }
  }
  else {
    if (lVar5 != 2) {
      if (lVar5 != 3) {
        if (lVar5 != 4) goto code_r0x017702a4;
        puVar7[3] = puVar3[3];
        puVar7 = (undefined1 *)plVar10[3];
      }
/* wm:no support for modified copies */
      puVar7[2] = puVar3[2];
      puVar7 = (undefined1 *)plVar10[3];
    }
    puVar7[1] = puVar3[1];
    puVar7 = (undefined1 *)plVar10[3];
  }
  *puVar7 = *puVar3;
code_r0x01770284:
  plVar10[3] = plVar10[3] + lVar5;
  return plVar10;
}

