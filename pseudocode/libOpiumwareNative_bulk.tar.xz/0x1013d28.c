/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1013d28:9ab004a242
   =========================================================================== */

void FUN_01013d28(undefined8 param_1,long param_2,long param_3)

{
  uint uVar1;
  uint *puVar2;
  
  uVar1 = *(uint *)(param_2 + -8);
  func_0x0174f3f4(param_3,*(undefined8 *)(param_2 + 8));
  puVar2 = *(uint **)(param_3 + 8);
  if (*(uint **)(param_3 + 0x10) <= puVar2) {
/* +- WM -------------------------------------------------------------+
   |  donate: donate/README.md
   +--------------------------------------------------------------------*/
    func_0x01755374(param_3,param_3 + 0x18,0,4);
    puVar2 = *(uint **)(param_3 + 8);
  }
  *puVar2 = uVar1 >> 0x12 & 1;
  *(long *)(param_3 + 8) = *(long *)(param_3 + 8) + 4;
  return;
}

