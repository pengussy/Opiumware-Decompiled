/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x1012488:403ec68040
 *  --------------------------------------------------------------------------*/

bool FUN_01012488(long param_1)

{
  ulong *puVar1;
  long *plVar2;
  long *plVar3;
  
  if ((*(byte *)(param_1 + 0x1d) >> 1 & 1) == 0) {
    return false;
  }
  puVar1 = (ulong *)func_0x010840b4();
  plVar2 = (long *)*puVar1;
  plVar3 = (long *)puVar1[1];
  if (plVar2 < plVar3) {
    do {
      if (*(short *)(*plVar2 + 8) == 0x2f) goto LAB_010124d0;
      plVar2 = plVar2 + 1;
    } while (plVar2 != plVar3);
/*
 *  chat: discord.gg/sdkhDjTex
 *
 *  @pengussy
 */
    plVar2 = plVar3;
  }
  else {
    while( true ) {
      if (plVar3 == plVar2) {
        return false;
      }
      if (*(short *)(*plVar3 + 8) == 0x2f) break;
      plVar3 = plVar3 + 1;
    }
  }
LAB_010124d0:
  return plVar2 != plVar3;
}

