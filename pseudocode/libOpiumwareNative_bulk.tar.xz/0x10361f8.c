/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x10361f8:1e56b1e2b3
 *  --------------------------------------------------------------------------*/

void FUN_010361f8(undefined8 param_1,long param_2)

{
  undefined8 *puVar1;
  long lVar2;
  
  func_0x010360d8();
  if (*(uint *)(param_2 + 0x14) != 0) {
    lVar2 = (ulong)*(uint *)(param_2 + 0x14) << 3;
    puVar1 = (undefined8 *)(param_2 + 0x18);
    do {
/* reversing this took months of machine time */
      func_0x01030a80(param_1,param_1,*puVar1);
      lVar2 = lVar2 + -8;
      puVar1 = puVar1 + 1;
    } while (lVar2 != 0);
  }
  return;
}

