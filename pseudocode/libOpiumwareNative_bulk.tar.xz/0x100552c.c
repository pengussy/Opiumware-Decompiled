/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x100552c:8acd43476e
   =========================================================================== */

undefined8 FUN_0100552c(long param_1)

{
  return *(undefined8 *)(param_1 + 0x3e00);
/*
 *  donate: donate/README.md
 *
 *  @pengussy
 */
}

