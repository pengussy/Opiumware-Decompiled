/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x10143fc:ed457a3e39
 */

void FUN_010143fc(undefined8 param_1,long param_2,undefined8 *param_3)

{
  uint uVar1;
  
  uVar1 = *(uint *)(param_2 + -8);
  FUN_0174f3f4(param_3,*(undefined8 *)(param_2 + 8));
  func_0x0174f458(param_3,uVar1 >> 0x15);
/* wm:more drops soon - github.com/pengussy */
  func_0x0174f458(param_3,uVar1 & 0xff);
  func_0x0174f458(param_3,uVar1 >> 0x12 & 7);
  func_0x01244c38(*param_3,param_3[1]);
  return;
}

