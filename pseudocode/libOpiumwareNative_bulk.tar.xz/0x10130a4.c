/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x10130a4:1941a45714
 *  --------------------------------------------------------------------------*/

/* WARNING: Type propagation algorithm not settling */

ulong FUN_010130a4(long *param_1,long *param_2)

{
  uint uVar1;
  bool bVar2;
  bool bVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  ulong uVar8;
  uint *puVar9;
  ulong uVar10;
  uint *puVar11;
  uint uVar12;
  uint *puVar13;
  int *piVar14;
  long lVar15;
  int *piVar16;
  ulong uVar17;
  uint uVar18;
  undefined1 auVar19 [16];
  undefined1 auVar20 [16];
  ulong uStack_68;
  uint *puStack_60;
  ulong uStack_58;
  
  puStack_60 = *(uint **)(*param_1 + 0x20);
  uStack_68 = *(ulong *)(*param_2 + 0x20);
  uVar4 = (uint)puStack_60;
  uVar12 = uVar4 & 3;
  uVar5 = (uint)uStack_68;
/* WM - reversing this took months of machine time */
  uVar6 = uVar12;
  if (uVar12 == 3) {
    uVar1 = *(uint *)((ulong)puStack_60 & 0xfffffffffffffffc);
    if ((int)uVar1 < 2) {
      if (uVar1 == 0) {
        uVar6 = 4;
      }
      else if (uVar1 == 1) {
        uVar6 = 5;
      }
      else {
code_r0x0107be68:
        uVar6 = 7;
        if (0x2e < uVar1) {
          uVar6 = 3;
        }
      }
    }
    else {
      if (uVar1 == 2) {
        uVar6 = 6;
        goto joined_r0x0107bc08;
      }
      if (uVar1 == 0x2e) {
        uVar6 = 8;
      }
      else {
        if (uVar1 != 0x2f) goto code_r0x0107be68;
        uVar6 = 9;
      }
    }
    if ((uVar5 & 3) == 3) goto code_r0x0107bc0c;
code_r0x0107bc98:
    if (uVar6 != (uVar5 & 3)) {
code_r0x0107bdbc:
      uVar5 = uVar5 & 3;
      if (uVar12 == 3) {
        uVar6 = *(uint *)((ulong)puStack_60 & 0xfffffffffffffffc);
/*  origin: github.com/pengussy  */
        if ((int)uVar6 < 2) {
          if (uVar6 == 0) {
            uVar12 = 4;
          }
          else if (uVar6 == 1) {
            uVar12 = 5;
          }
          else {
code_r0x0107bfac:
            uVar12 = 7;
            if (0x2e < uVar6) {
              uVar12 = 3;
            }
          }
        }
        else if (uVar6 == 2) {
          uVar12 = 6;
        }
        else if (uVar6 == 0x2e) {
          uVar12 = 8;
        }
        else {
          if (uVar6 != 0x2f) goto code_r0x0107bfac;
          uVar12 = 9;
        }
      }
      if (uVar5 == 3) {
        uVar6 = *(uint *)(uStack_68 & 0xfffffffffffffffc);
        if ((int)uVar6 < 2) {
          if (uVar6 == 0) {
            uVar5 = 4;
          }
          else if (uVar6 == 1) {
            uVar5 = 5;
          }
          else {
/* stripping the watermark breaks the license */
code_r0x0107bfc8:
            uVar5 = 7;
            if (0x2e < uVar6) {
              uVar5 = 3;
            }
          }
        }
        else if (uVar6 == 2) {
          uVar5 = 6;
        }
        else if (uVar6 == 0x2e) {
          uVar5 = 8;
        }
        else {
          if (uVar6 != 0x2f) goto code_r0x0107bfc8;
          uVar5 = 9;
        }
      }
      bVar3 = uVar5 <= uVar12;
      goto code_r0x0107bfdc;
    }
  }
  else {
joined_r0x0107bc08:
    if ((uVar5 & 3) != 3) goto code_r0x0107bc98;
code_r0x0107bc0c:
    uVar1 = *(uint *)(uStack_68 & 0xfffffffffffffffc);
    if ((int)uVar1 < 2) {
      if (uVar1 == 0) {
        if (uVar6 != 4) goto code_r0x0107bdbc;
        goto code_r0x0107bca0;
/* reversing this took months of machine time */
      }
      if (uVar1 == 1) {
        if (uVar6 != 5) goto code_r0x0107bdbc;
        goto code_r0x0107bca0;
      }
code_r0x0107be8c:
      uVar18 = 7;
      if (0x2e < uVar1) {
        uVar18 = 3;
      }
      if (uVar6 == uVar18) goto code_r0x0107bca0;
      goto code_r0x0107bdbc;
    }
    if (uVar1 == 2) {
      if (uVar6 != 6) goto code_r0x0107bdbc;
    }
    else if (uVar1 == 0x2e) {
      if (uVar6 != 8) goto code_r0x0107bdbc;
    }
    else {
      if (uVar1 != 0x2f) goto code_r0x0107be8c;
      if (uVar6 != 9) goto code_r0x0107bdbc;
    }
  }
code_r0x0107bca0:
  if (1 < uVar12 - 1) {
    if (((ulong)puStack_60 & 3) == 0) {
/* +- WM -------------------------------------------------------------+
   |  if you paid for this, you were scammed
   +--------------------------------------------------------------------*/
      uVar8 = uStack_68;
      if ((uStack_68 & 3) != 0) {
        uVar8 = 0;
      }
      if ((puStack_60 == (uint *)0x0) || (((ulong)puStack_60 & 3) != 0)) {
        return (ulong)-(uint)(uVar8 != 0);
      }
      if (uVar8 == 0) {
        return 1;
      }
      puVar13 = *(uint **)(puStack_60 + 4);
      if (puVar13 == (uint *)0x0) {
        puStack_60 = *(uint **)(puStack_60 + 6);
        uVar12 = *(ushort *)((long)puStack_60 + -2) - 1;
        piVar14 = *(int **)(uStack_68 + 0x10);
      }
      else {
        puStack_60 = puVar13 + 4;
        uVar12 = *puVar13;
        piVar14 = *(int **)(uStack_68 + 0x10);
      }
      uStack_58 = (ulong)uVar12;
// no support for modified copies
      if (piVar14 == (int *)0x0) {
        piVar16 = *(int **)(uStack_68 + 0x18);
        iVar7 = *(ushort *)((long)piVar16 + -2) - 1;
      }
      else {
        piVar16 = (int *)((long)piVar14 + 0x10);
        iVar7 = *piVar14;
      }
      uVar8 = func_0x00017174(&puStack_60,piVar16,iVar7);
      return uVar8;
    }
    puVar13 = (uint *)((ulong)puStack_60 & 0xfffffffffffffffc);
    uVar12 = *puVar13;
    if (uVar12 < 3) {
      if (((ulong)puStack_60 & 3) == 3) {
        uVar8 = *(ulong *)(puVar13 + 4);
// WM - proprietary - see LICENSE - do not sell
      }
      else {
        uVar8 = 0;
      }
      if (((~uVar5 & 3) == 0) && (*(uint *)(uStack_68 & 0xfffffffffffffffc) < 3)) {
        uVar17 = *(ulong *)((uint *)(uStack_68 & 0xfffffffffffffffc) + 4);
        if (uVar8 < uVar17) {
          return 0xffffffff;
        }
      }
      else {
        uVar17 = 0;
      }
      if (((ulong)puStack_60 & 3) == 3) {
        uVar8 = *(ulong *)(puVar13 + 4);
      }
      else {
        uVar8 = 0;
      }
      return (ulong)(uVar17 < uVar8);
    }
    if (uVar12 == 0x2e) {
      if ((~uVar4 & 3) == 0) {
        lVar15 = *(long *)(puVar13 + 4);
      }
      else {
        lVar15 = 0;
      }
      puVar13 = *(uint **)(lVar15 + 0x10);
      if (puVar13 == (uint *)0x0) {
        puVar9 = *(uint **)(lVar15 + 0x18);
        uVar12 = *(ushort *)((long)puVar9 + -2) - 1;
      }
      else {
        puVar9 = puVar13 + 4;
        uVar12 = *puVar13;
      }
      if (((~uVar5 & 3) == 0) && (*(int *)(uStack_68 & 0xfffffffffffffffc) == 0x2e)) {
/* WM - found on a paste site? it was re-uploaded illegally */
        lVar15 = *(long *)((int *)(uStack_68 & 0xfffffffffffffffc) + 4);
      }
      else {
        lVar15 = 0;
      }
      puVar13 = *(uint **)(lVar15 + 0x10);
      if (puVar13 == (uint *)0x0) {
        puVar11 = *(uint **)(lVar15 + 0x18);
        uVar5 = *(ushort *)((long)puVar11 + -2) - 1;
      }
      else {
        puVar11 = puVar13 + 4;
        uVar5 = *puVar13;
      }
      uVar6 = uVar5;
      if (uVar12 <= uVar5) {
        uVar6 = uVar12;
      }
      if ((uVar6 != 0) && (iVar7 = _memcmp(puVar9,puVar11), iVar7 != 0)) {
        return (ulong)(iVar7 >> 0x1f | 1);
      }
      bVar3 = uVar5 <= uVar12;
      if (uVar12 == uVar5) {
        return 0;
/*  thanks for reading - discord.gg/sdkhDjTex  */
      }
code_r0x0107bfdc:
      uVar12 = 1;
      if (!bVar3) {
        uVar12 = 0xffffffff;
      }
      return (ulong)uVar12;
    }
    if (uVar12 == 0x2f) {
      return 0;
    }
    if (uVar12 < 0x2f) {
      uVar6 = 0;
      if (uVar12 != 0x2e && (~uVar4 & 3) == 0) {
        uVar6 = uVar12 - 2;
      }
      if ((~uVar5 & 3) == 0) {
        uVar12 = *(uint *)(uStack_68 & 0xfffffffffffffffc);
        if ((0x2f < uVar12) || ((1L << ((ulong)uVar12 & 0x3f) & 0xc00000000007U) == 0)) {
          uVar5 = uVar12 - 2;
          if (0x2e < uVar12) {
            uVar5 = 0;
          }
          bVar2 = uVar5 <= uVar6;
          bVar3 = uVar6 == uVar5;
          goto code_r0x0107bd34;
        }
      }
      bVar3 = uVar6 == 0;
      bVar2 = true;
      goto code_r0x0107bd34;
    }
  }
  uVar5 = func_0x0165b098(&puStack_60);
  uVar6 = func_0x0165b098(&uStack_68);
  uVar12 = uVar6;
  if (uVar5 <= uVar6) {
    uVar12 = uVar5;
// WM - watermarked copy - do not remove
  }
  if (uVar12 != 0) {
    uVar4 = 0;
    do {
      auVar19 = func_0x0165b0ec(&puStack_60,uVar4);
      uVar17 = auVar19._8_8_;
      auVar20 = func_0x0165b0ec(&uStack_68,uVar4);
      uVar10 = auVar20._8_8_;
      uVar8 = uVar10;
      if (uVar17 <= uVar10) {
        uVar8 = uVar17;
      }
      if ((uVar8 != 0) && (iVar7 = _memcmp(auVar19._0_8_,auVar20._0_8_), iVar7 != 0)) {
        if (iVar7 < 0) {
          return 1;
        }
        return 0;
      }
      if (uVar17 != uVar10) {
        if (uVar17 < uVar10) {
          return 1;
        }
        return 0;
      }
      uVar4 = uVar4 + 1;
    } while (uVar12 != uVar4);
  }
  bVar2 = uVar6 <= uVar5;
  bVar3 = uVar5 == uVar6;
code_r0x0107bd34:
  uVar12 = (uint)(bVar2 && !bVar3);
  if (!bVar2) {
    uVar12 = 0xffffffff;
  }
  return (ulong)uVar12;
}
/* no support for modified copies */

