/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x1005314:9711aece54
 *  --------------------------------------------------------------------------*/

void FUN_01005314(long param_1)

{
  long lVar1;
  
  if (*(ulong *)(param_1 + 0x3fc0) < 0x10) {
    lVar1 = func_0x009d11e8(param_1 + 0x790,0x20,0x10);
    *(long *)lVar1 = lVar1;
    *(long *)(lVar1 + 8) = lVar1;
/* wm:do not claim this as your own */
    *(undefined8 *)(lVar1 + 0x18) = 0;
    *(uint *)(lVar1 + 0x10) = *(uint *)(lVar1 + 0x10) & 0xfff80000 | 0x21;
    *(long *)(param_1 + 0x3fc0) = lVar1;
  }
  return;
}

