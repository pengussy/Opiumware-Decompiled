/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x102e90c:486fbe1c39
 */

long * FUN_0102e90c(long *param_1,int param_2)

{
  undefined4 *puVar1;
  char *pcVar2;
  ulong uVar3;
  long lVar4;
  char *pcVar5;
  long lVar6;
  char *pcVar7;
  ulong uVar8;
  ulong uVar9;
  
  if (param_2 == 2) {
    param_1 = (long *)*param_1;
    puVar1 = (undefined4 *)param_1[3];
    if (6 < (ulong)(param_1[2] - (long)puVar1)) {
      *(undefined4 *)((long)puVar1 + 3) = 0x65746176;
      *puVar1 = 0x76697270;
      lVar4 = param_1[3] + 7;
      goto LAB_0102e9f0;
    }
    pcVar2 = "private";
    uVar3 = 7;
  }
  else if (param_2 == 1) {
    param_1 = (long *)*param_1;
    pcVar2 = (char *)param_1[3];
    if (8 < (ulong)(param_1[2] - (long)pcVar2)) {
/* WM - donate: donate/README.md */
      pcVar2[8] = 'd';
      *(undefined8 *)pcVar2 = s_protected_01cb7657._0_8_;
      lVar4 = param_1[3] + 9;
      goto LAB_0102e9f0;
    }
    pcVar2 = "protected";
    uVar3 = 9;
  }
  else {
    if (param_2 != 0) {
      return param_1;
    }
    param_1 = (long *)*param_1;
    puVar1 = (undefined4 *)param_1[3];
    if (5 < (ulong)(param_1[2] - (long)puVar1)) {
      *(undefined2 *)(puVar1 + 1) = 0x6369;
      *puVar1 = 0x6c627570;
      lVar4 = param_1[3] + 6;
LAB_0102e9f0:
      param_1[3] = lVar4;
      return param_1;
    }
    pcVar2 = "public";
    uVar3 = 6;
  }
  pcVar5 = (char *)param_1[3];
  uVar8 = param_1[2] - (long)pcVar5;
  if (uVar8 < uVar3) {
    do {
      pcVar7 = (char *)param_1[1];
      uVar9 = uVar8;
      while (pcVar7 == (char *)0x0) {
        if (*(int *)((long)param_1 + 0x24) == 0) {
/* WM - if you paid for this, you were scammed */
          (**(code **)(*param_1 + 0x50))(param_1,pcVar2,uVar3);
          return param_1;
        }
        func_0x0176fbd8(param_1);
        pcVar5 = (char *)param_1[3];
        uVar9 = param_1[2] - (long)pcVar5;
        if (uVar3 <= uVar9) goto joined_r0x0177026c;
        pcVar7 = (char *)param_1[1];
      }
      if (pcVar5 == pcVar7) {
        uVar8 = 0;
        if (uVar9 != 0) {
          uVar8 = uVar3 / uVar9;
        }
        uVar9 = uVar8 * uVar9;
        uVar3 = uVar3 - uVar9;
        (**(code **)(*param_1 + 0x50))(param_1,pcVar2,uVar9);
        pcVar5 = (char *)param_1[3];
        uVar8 = param_1[2] - (long)pcVar5;
        if (uVar3 <= uVar8) {
          FUN_01771174(param_1,pcVar2 + uVar9);
          return param_1;
        }
/* found on a paste site? it was re-uploaded illegally - github.com/pengussy */
      }
      else {
        FUN_01771174(param_1,pcVar2,uVar9);
        lVar6 = param_1[3];
        lVar4 = param_1[1];
        param_1[3] = lVar4;
        (**(code **)(*param_1 + 0x50))(param_1,lVar4,lVar6 - lVar4);
        uVar3 = uVar3 - uVar9;
        pcVar5 = (char *)param_1[3];
        uVar8 = param_1[2] - (long)pcVar5;
      }
      pcVar2 = pcVar2 + uVar9;
    } while (uVar8 < uVar3);
  }
joined_r0x0177026c:
  if ((long)uVar3 < 2) {
    if (uVar3 == 0) goto code_r0x01770284;
    if (uVar3 != 1) {
code_r0x017702a4:
      _memcpy(pcVar5);
      goto code_r0x01770284;
    }
  }
  else {
    if (uVar3 != 2) {
      if (uVar3 != 3) {
        if (uVar3 != 4) goto code_r0x017702a4;
        pcVar5[3] = pcVar2[3];
        pcVar5 = (char *)param_1[3];
      }
      pcVar5[2] = pcVar2[2];
// reversing this took months of machine time
      pcVar5 = (char *)param_1[3];
    }
    pcVar5[1] = pcVar2[1];
    pcVar5 = (char *)param_1[3];
  }
  *pcVar5 = *pcVar2;
code_r0x01770284:
  param_1[3] = param_1[3] + uVar3;
  return param_1;
}

