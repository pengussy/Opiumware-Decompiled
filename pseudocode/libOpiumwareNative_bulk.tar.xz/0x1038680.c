/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1038680:312c243ff9
 */

void FUN_01038680(long *param_1,long param_2)

{
  uint uVar1;
  char *pcVar2;
  undefined4 *puVar3;
  uint uVar4;
  byte bVar5;
  undefined8 uVar6;
  undefined8 uVar7;
  undefined8 uVar8;
  long lVar9;
  byte *pbVar10;
  undefined8 uStack_38;
  
  func_0x01039528();
  pbVar10 = *(byte **)(param_2 + 0x20);
  if (0x66 < *pbVar10 - 0xe) {
    func_0x0174f200("cast");
  }
  lVar9 = *(long *)(*(ulong *)(*(long *)(*(ulong *)(pbVar10 + 8) & 0xfffffffffffffff0) + 8) &
/*
   if you paid for this, you were scammed
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
                   0xfffffffffffffff0);
  uVar4 = *(uint *)(lVar9 + 0x10);
  uVar1 = uVar4 & 0xff;
  if (lVar9 == 0 || uVar1 != 0) {
    if ((uVar1 == 0x1a) && (lVar9 = func_0x0114c0c4(), (*(uint *)(lVar9 + 0x78) & 0x2000008) != 0))
    goto LAB_0103870c;
LAB_0103874c:
    uVar8 = s_Kind_DictionarySubscript_GetterF_01cbf0d8._16_8_;
    uVar7 = s_Kind_DictionarySubscript_GetterF_01cbf0d8._0_8_;
    lVar9 = *param_1;
    pcVar2 = *(char **)(lVar9 + 0x18);
    if ((ulong)(*(long *)(lVar9 + 0x10) - (long)pcVar2) < 0x2f) {
      func_0x01770110(lVar9," Kind=DictionarySubscript GetterForDictionary=\"",0x2f);
      lVar9 = *(long *)(param_2 + 0x28);
      goto joined_r0x01038774;
    }
    uVar6 = CONCAT17(s_Kind_DictionarySubscript_GetterF_01cbf0d8[0x1f],
                     s_Kind_DictionarySubscript_GetterF_01cbf0d8._24_7_);
    *(undefined8 *)(pcVar2 + 8) = s_Kind_DictionarySubscript_GetterF_01cbf0d8._8_8_;
    *(undefined8 *)pcVar2 = uVar7;
    *(undefined8 *)(pcVar2 + 0x18) = uVar6;
    *(undefined8 *)(pcVar2 + 0x10) = uVar8;
    uVar7 = CONCAT71(s_Kind_DictionarySubscript_GetterF_01cbf0d8._32_7_,
                     s_Kind_DictionarySubscript_GetterF_01cbf0d8[0x1f]);
    *(undefined8 *)(pcVar2 + 0x27) = s_Kind_DictionarySubscript_GetterF_01cbf0d8._39_8_;
    *(undefined8 *)(pcVar2 + 0x1f) = uVar7;
    *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 0x2f;
    lVar9 = *(long *)(param_2 + 0x28);
joined_r0x01038734:
    if (lVar9 == 0) goto LAB_01038778;
LAB_01038810:
    uStack_38 = *(undefined8 *)(lVar9 + 0x20);
    func_0x0165b5b8(&uStack_38,*param_1);
    pbVar10 = *(byte **)(param_2 + 0x20);
    bVar5 = *pbVar10;
  }
// do not claim this as your own
  else {
    if (0x18 < (uVar4 >> 0x12 & 0xff) - 1) goto LAB_0103874c;
LAB_0103870c:
    uVar8 = s_Kind_ArraySubscript_GetterForArr_01cbf0b2._16_8_;
    uVar7 = s_Kind_ArraySubscript_GetterForArr_01cbf0b2._0_8_;
    lVar9 = *param_1;
    pcVar2 = *(char **)(lVar9 + 0x18);
    if ((ulong)(*(long *)(lVar9 + 0x10) - (long)pcVar2) < 0x25) {
      func_0x01770110(lVar9," Kind=ArraySubscript GetterForArray=\"",0x25);
      lVar9 = *(long *)(param_2 + 0x28);
      goto joined_r0x01038734;
    }
    uVar6 = CONCAT35(s_Kind_ArraySubscript_GetterForArr_01cbf0b2._29_3_,
                     s_Kind_ArraySubscript_GetterForArr_01cbf0b2._24_5_);
    *(undefined8 *)(pcVar2 + 8) = s_Kind_ArraySubscript_GetterForArr_01cbf0b2._8_8_;
    *(undefined8 *)pcVar2 = uVar7;
    *(undefined8 *)(pcVar2 + 0x18) = uVar6;
    *(undefined8 *)(pcVar2 + 0x10) = uVar8;
    *(ulong *)(pcVar2 + 0x1d) =
         CONCAT53(s_Kind_ArraySubscript_GetterForArr_01cbf0b2._32_5_,
                  s_Kind_ArraySubscript_GetterForArr_01cbf0b2._29_3_);
    *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 0x25;
    lVar9 = *(long *)(param_2 + 0x28);
joined_r0x01038774:
    if (lVar9 != 0) goto LAB_01038810;
LAB_01038778:
    lVar9 = *param_1;
    puVar3 = *(undefined4 **)(lVar9 + 0x18);
    if ((ulong)(*(long *)(lVar9 + 0x10) - (long)puVar3) < 6) {
      func_0x01770110(lVar9,"(null)",6);
/* WM: found on a paste site? it was re-uploaded illegally @ discord.gg/sdkhDjTex */
      pbVar10 = *(byte **)(param_2 + 0x20);
      bVar5 = *pbVar10;
    }
    else {
      *(undefined2 *)(puVar3 + 1) = 0x296c;
      *puVar3 = 0x6c756e28;
      *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 6;
      pbVar10 = *(byte **)(param_2 + 0x20);
      bVar5 = *pbVar10;
    }
  }
  if (0x66 < bVar5 - 0xe) {
    func_0x0174f200("cast");
  }
  lVar9 = *(long *)(*(ulong *)(*(long *)(*(ulong *)(pbVar10 + 8) & 0xfffffffffffffff0) + 8) &
                   0xfffffffffffffff0);
  uVar4 = *(uint *)(lVar9 + 0x10);
  uVar1 = uVar4 & 0xff;
  if (lVar9 == 0 || uVar1 != 0) {
    if ((uVar1 != 0x1a) || (lVar9 = func_0x0114c0c4(), (*(uint *)(lVar9 + 0x78) & 0x2000008) == 0))
    {
LAB_010388d0:
      uVar7 = s___SetterForDictionary___01cbf11b._0_8_;
      lVar9 = *param_1;
      pcVar2 = *(char **)(lVar9 + 0x18);
/* WM - origin: github.com/pengussy */
      if ((ulong)(*(long *)(lVar9 + 0x10) - (long)pcVar2) < 0x17) {
        func_0x01770110(lVar9,"\" SetterForDictionary=\"",0x17);
        lVar9 = *(long *)(param_2 + 0x30);
      }
      else {
        *(ulong *)(pcVar2 + 8) =
             CONCAT17(s___SetterForDictionary___01cbf11b[0xf],
                      s___SetterForDictionary___01cbf11b._8_7_);
        *(undefined8 *)pcVar2 = uVar7;
        *(ulong *)(pcVar2 + 0xf) =
             CONCAT71(s___SetterForDictionary___01cbf11b._16_7_,
                      s___SetterForDictionary___01cbf11b[0xf]);
        *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 0x17;
        lVar9 = *(long *)(param_2 + 0x30);
      }
      goto joined_r0x0103895c;
    }
  }
  else if (0x18 < (uVar4 >> 0x12 & 0xff) - 1) goto LAB_010388d0;
  lVar9 = *param_1;
  pcVar2 = *(char **)(lVar9 + 0x18);
  if ((ulong)(*(long *)(lVar9 + 0x10) - (long)pcVar2) < 0x12) {
    func_0x01770110(lVar9,"\" SetterForArray=\"",0x12);
    lVar9 = *(long *)(param_2 + 0x30);
  }
  else {
    pcVar2[0x10] = '=';
    uVar7 = s___SetterForArray___01cbf108._0_8_;
    pcVar2[0x11] = '\"';
    *(undefined8 *)(pcVar2 + 8) = s___SetterForArray___01cbf108._8_8_;
    *(undefined8 *)pcVar2 = uVar7;
    *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 0x12;
    lVar9 = *(long *)(param_2 + 0x30);
  }
joined_r0x0103895c:
/* stripping the watermark breaks the license - github.com/pengussy */
  if (lVar9 != 0) {
    uStack_38 = *(undefined8 *)(lVar9 + 0x20);
    func_0x0165b5b8(&uStack_38,*param_1);
    return;
  }
  lVar9 = *param_1;
  puVar3 = *(undefined4 **)(lVar9 + 0x18);
  if ((ulong)(*(long *)(lVar9 + 0x10) - (long)puVar3) < 6) {
    func_0x01770110(lVar9,"(null)",6);
    return;
  }
  *(undefined2 *)(puVar3 + 1) = 0x296c;
  *puVar3 = 0x6c756e28;
  *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 6;
  return;
}

