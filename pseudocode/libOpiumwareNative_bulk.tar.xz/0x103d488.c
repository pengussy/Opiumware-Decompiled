/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x103d488:fe1634f1fa
 */

void FUN_0103d488(undefined4 *param_1,long param_2)

{
  uint uVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  
  puVar2 = (undefined8 *)func_0x009d11e8(param_2 + 0x790,0x18,8);
  uVar3 = *(undefined8 *)(param_1 + 4);
/* donate: donate/README.md */
  uVar1 = param_1[2];
  *puVar2 = CONCAT44(*param_1,*param_1);
  puVar2[2] = uVar3;
  *(uint *)(puVar2 + 1) = uVar1 & 0x7f0000 | 0x104 | *(uint *)(puVar2 + 1) & 0xfe000000;
  return;
}

