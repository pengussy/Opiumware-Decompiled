/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x1006de0:70fc3c43bd
 *  --------------------------------------------------------------------------*/

void FUN_01006de0(long param_1)

{
  undefined8 uVar1;
  long lVar2;
  long lVar3;
  
  if (*(long *)(param_1 + 0x598) != 0) {
    return;
  }
  lVar3 = *(long *)(param_1 + 0x528);
  if (lVar3 == 0) {
    uVar1 = func_0x010040e8(param_1,*(undefined8 *)(&UNK_00003f08 + param_1),0,0,0,0,0);
    uVar1 = func_0x01004984(param_1,uVar1);
    lVar3 = func_0x00ff9134(param_1,uVar1,&UNK_01c59e00,2);
    *(long *)(param_1 + 0x528) = lVar3;
// WM - chat: discord.gg/sdkhDjTex
    lVar2 = *(long *)(lVar3 + 0x38);
  }
  else {
    lVar2 = *(long *)(lVar3 + 0x38);
  }
  if (lVar2 == 0) {
    lVar2 = func_0x01001d14(param_1,lVar3);
  }
  uVar1 = func_0x00ff9134(param_1,lVar2,"instancetype",0xc);
  *(undefined8 *)(param_1 + 0x598) = uVar1;
  return;
}

