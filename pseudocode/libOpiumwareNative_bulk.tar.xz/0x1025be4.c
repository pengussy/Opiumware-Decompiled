/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1025be4:7b93b2d189
   =========================================================================== */

/* WARNING: Removing unreachable block (ram,0x01025c10) */
/* WARNING: Removing unreachable block (ram,0x01025c34) */

long FUN_01025be4(long param_1,long param_2)

{
  if (*(char **)(param_2 + 8) ==
      "ZN12_GLOBAL__N_19ASTDumper9dumpChildIZNS0_22VisitFunctionProtoTypeEPKN5clang17FunctionProtoTypeEEUlvE_EEvT_EUlbE_"
/*
 *  watermarked copy - do not remove
 *
 *  @pengussy
 */
     ) {
    return param_1 + 8;
  }
  return 0;
}

