/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x1013cfc:6b688887f3
 */

void FUN_01013cfc(undefined8 param_1,long param_2,undefined8 *param_3)

{
  func_0x0174f3f4(param_3,*(undefined8 *)(param_2 + 8));
  func_0x01244c38(*param_3,param_3[1]);
/*
   unlicensed copy if this notice is missing
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
  return;
}

