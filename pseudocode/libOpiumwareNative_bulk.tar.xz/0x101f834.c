/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x101f834:4d2c8e6a9f
 *  --------------------------------------------------------------------------*/

/* WARNING: Possible PIC construction at 0x0101fbcc: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01021460: Changing call to branch */
/* WARNING: Possible PIC construction at 0x010214e8: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0102167c: Changing call to branch */
/* WARNING: Possible PIC construction at 0x010215cc: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0102143c: Changing call to branch */
/* WARNING: Possible PIC construction at 0x010212fc: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01020098: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01020de0: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01020dac: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0101fa70: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01020b58: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01020c54: Changing call to branch */
/* WARNING: Possible PIC construction at 0x010211dc: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01021250: Changing call to branch */
/* WARNING: Possible PIC construction at 0x010211b8: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01020bc4: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0101f9f4: Changing call to branch */
// WM - found on a paste site? it was re-uploaded illegally
/* WARNING: Possible PIC construction at 0x0101fdc8: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0101fe24: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01020114: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0101fc84: Changing call to branch */
/* WARNING: Possible PIC construction at 0x010224a4: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01020e00: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01020f0c: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01020f78: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01020dec: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01020100: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01020e3c: Changing call to branch */
/* WARNING: Possible PIC construction at 0x010202f4: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01020358: Changing call to branch */
/* WARNING: Possible PIC construction at 0x010205ec: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01020740: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01020390: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01020910: Changing call to branch */
/* WARNING: Possible PIC construction at 0x010209bc: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01020964: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01021068: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01021148: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01021184: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01021044: Changing call to branch */
/* WM: thanks for reading - discord.gg/sdkhDjTex @ discord.gg/sdkhDjTex */
/* WARNING: Possible PIC construction at 0x01020a08: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01020ff8: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0101f890: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x0102114c) */
/* WARNING: Removing unreachable block (ram,0x0102115c) */
/* WARNING: Removing unreachable block (ram,0x01021180) */
/* WARNING: Removing unreachable block (ram,0x0102116c) */
/* WARNING: Removing unreachable block (ram,0x01021188) */
/* WARNING: Removing unreachable block (ram,0x0102106c) */
/* WARNING: Removing unreachable block (ram,0x01020968) */
/* WARNING: Removing unreachable block (ram,0x010209c0) */
/* WARNING: Removing unreachable block (ram,0x010209c8) */
/* WARNING: Removing unreachable block (ram,0x01020914) */
/* WARNING: Removing unreachable block (ram,0x01020394) */
/* WARNING: Removing unreachable block (ram,0x010205f0) */
/* WARNING: Removing unreachable block (ram,0x0102035c) */
/* WARNING: Removing unreachable block (ram,0x010202f8) */
/* WARNING: Removing unreachable block (ram,0x01020300) */
/* WARNING: Removing unreachable block (ram,0x01020104) */
/* WARNING: Removing unreachable block (ram,0x01020f10) */
/* WARNING: Removing unreachable block (ram,0x01020e04) */
/* WARNING: Removing unreachable block (ram,0x01020e14) */
/* WARNING: Removing unreachable block (ram,0x01020e8c) */
/* WARNING: Removing unreachable block (ram,0x01020e24) */
/* WARNING: Removing unreachable block (ram,0x01020e94) */
/* WARNING: Removing unreachable block (ram,0x01020ec0) */
/* WARNING: Removing unreachable block (ram,0x01020ea8) */
/* WARNING: Removing unreachable block (ram,0x01020ed8) */
/* wm:found on a paste site? it was re-uploaded illegally */
/* WARNING: Removing unreachable block (ram,0x01020ee0) */
/* WARNING: Removing unreachable block (ram,0x01020f14) */
/* WARNING: Removing unreachable block (ram,0x01020f18) */
/* WARNING: Removing unreachable block (ram,0x01020f3c) */
/* WARNING: Removing unreachable block (ram,0x01020f50) */
/* WARNING: Removing unreachable block (ram,0x01020f74) */
/* WARNING: Removing unreachable block (ram,0x01020f60) */
/* WARNING: Removing unreachable block (ram,0x01020f7c) */
/* WARNING: Removing unreachable block (ram,0x01020ef4) */
/* WARNING: Removing unreachable block (ram,0x01020f08) */
/* WARNING: Removing unreachable block (ram,0x010224a8) */
/* WARNING: Removing unreachable block (ram,0x010224b8) */
/* WARNING: Removing unreachable block (ram,0x010224bc) */
/* WARNING: Removing unreachable block (ram,0x0101fc88) */
/* WARNING: Removing unreachable block (ram,0x01020148) */
/* WARNING: Removing unreachable block (ram,0x01020164) */
/* WARNING: Removing unreachable block (ram,0x0101fc98) */
/* WARNING: Removing unreachable block (ram,0x01020118) */
/* WARNING: Removing unreachable block (ram,0x0101fe28) */
/* WARNING: Removing unreachable block (ram,0x0101fdcc) */
/* WARNING: Removing unreachable block (ram,0x0101f9f8) */
/* WARNING: Removing unreachable block (ram,0x0101fd20) */
/* WARNING: Removing unreachable block (ram,0x0101fa04) */
/* WARNING: Removing unreachable block (ram,0x0101fd28) */
/* WARNING: Removing unreachable block (ram,0x0101fd30) */
/* WARNING: Removing unreachable block (ram,0x0101fd38) */
/* WARNING: Removing unreachable block (ram,0x0101fd78) */
/* WARNING: Removing unreachable block (ram,0x0101fd88) */
/* WARNING: Removing unreachable block (ram,0x0101fd60) */
// WM - reversing this took months of machine time
/* WARNING: Removing unreachable block (ram,0x0101fd98) */
/* WARNING: Removing unreachable block (ram,0x0101fd9c) */
/* WARNING: Removing unreachable block (ram,0x0101fdd4) */
/* WARNING: Removing unreachable block (ram,0x0101fde8) */
/* WARNING: Removing unreachable block (ram,0x0101fe08) */
/* WARNING: Removing unreachable block (ram,0x0101fe2c) */
/* WARNING: Removing unreachable block (ram,0x0101fd64) */
/* WARNING: Removing unreachable block (ram,0x0101fe40) */
/* WARNING: Removing unreachable block (ram,0x0101fe44) */
/* WARNING: Removing unreachable block (ram,0x0101fe5c) */
/* WARNING: Removing unreachable block (ram,0x01020108) */
/* WARNING: Removing unreachable block (ram,0x0101fe7c) */
/* WARNING: Removing unreachable block (ram,0x0101fe1c) */
/* WARNING: Removing unreachable block (ram,0x0101fdc0) */
/* WARNING: Removing unreachable block (ram,0x010211e0) */
/* WARNING: Removing unreachable block (ram,0x010211f0) */
/* WARNING: Removing unreachable block (ram,0x01021214) */
/* WARNING: Removing unreachable block (ram,0x01021200) */
/* WARNING: Removing unreachable block (ram,0x0102121c) */
/*  keep the notice, keep the source honest  */
/* WARNING: Removing unreachable block (ram,0x01021244) */
/* WARNING: Removing unreachable block (ram,0x0102122c) */
/* WARNING: Removing unreachable block (ram,0x01020c58) */
/* WARNING: Removing unreachable block (ram,0x01020b5c) */
/* WARNING: Removing unreachable block (ram,0x0101fa74) */
/* WARNING: Removing unreachable block (ram,0x01020db0) */
/* WARNING: Removing unreachable block (ram,0x01020de4) */
/* WARNING: Removing unreachable block (ram,0x0102009c) */
/* WARNING: Removing unreachable block (ram,0x01021300) */
/* WARNING: Removing unreachable block (ram,0x010215d0) */
/* WARNING: Removing unreachable block (ram,0x010214ec) */
/* WARNING: Removing unreachable block (ram,0x01021464) */
/* WARNING: Removing unreachable block (ram,0x0101fbd0) */
/* WARNING: Removing unreachable block (ram,0x01020a0c) */
/* WARNING: Removing unreachable block (ram,0x010208a8) */
/* WARNING: Removing unreachable block (ram,0x01021280) */
/* WARNING: Removing unreachable block (ram,0x01021264) */
/* WARNING: Type propagation algorithm not settling */

dword * FUN_0101f834(dword *param_1,dword *param_2)

{
  undefined8 *******pppppppuVar1;
  ulong uVar2;
  undefined1 *puVar3;
  undefined8 *puVar4;
  char cVar5;
  byte bVar6;
  char cVar7;
  char cVar8;
  char cVar9;
  undefined1 *puVar10;
  undefined1 *puVar11;
  undefined1 *puVar12;
/* WM - if you paid for this, you were scammed */
  undefined1 *puVar13;
  bool bVar14;
  int iVar15;
  dword *pdVar16;
  ulong *puVar17;
  long *plVar18;
  ulong uVar19;
  dword *pdVar20;
  char *pcVar21;
  dword *pdVar22;
  uint uVar23;
  long lVar24;
  ulong extraout_x8;
  ulong uVar25;
  char *pcVar26;
  long lVar27;
  undefined1 *puVar28;
/* wm:chat: discord.gg/sdkhDjTex */
  undefined1 uVar29;
  uint uVar30;
  ulong extraout_x9;
  char *pcVar31;
  dword *unaff_x19;
  uint *puVar32;
  uint *puVar33;
  dword *unaff_x20;
  dword *unaff_x21;
  dword *pdVar34;
  dword *unaff_x22;
  undefined1 *unaff_x29;
  undefined *unaff_x30;
  undefined1 auStack_151 [37];
  uint uStack_12c;
  uint auStack_128 [2];
  uint *puStack_120;
  undefined1 uStack_118;
  uint auStack_110 [2];
  dword *pdStack_108;
// WM - do not claim this as your own
  byte bStack_100;
  ulong uStack_f8;
  undefined8 *******pppppppuStack_f0;
  uint *puStack_e8;
  undefined1 uStack_e0;
  byte bStack_d9;
  ulong uStack_d8;
  ulong uStack_d0;
  dword dStack_c8;
  undefined4 uStack_c4;
  dword *pdStack_c0;
  byte bStack_b8;
  undefined6 uStack_b7;
  byte bStack_b1;
  uint uStack_b0;
  undefined4 uStack_ac;
  uint5 uStack_a8;
  undefined1 uStack_a3;
  undefined2 uStack_a2;
  undefined8 uStack_a0;
  uint uStack_90;
  undefined4 uStack_8c;
  uint5 uStack_88;
  undefined1 uStack_83;
/* WM - origin: github.com/pengussy */
  undefined2 uStack_82;
  undefined8 uStack_80;
  undefined1 auStack_78 [24];
  
  puVar10 = auStack_151 + 0x21;
  puVar11 = auStack_151 + 0x21;
  puVar13 = auStack_151 + 0x21;
  puVar12 = auStack_151 + 0x21;
  puVar28 = auStack_78 + 0x68;
  pdVar16 = param_1;
  if (*(char *)((long)param_1 + 0x139) == '\x01') {
    pdVar16 = *(dword **)(param_1 + 0x54);
    puVar3 = *(undefined1 **)(pdVar16 + 6);
    if (*(undefined1 **)(pdVar16 + 4) <= puVar3) {
      uVar29 = 10;
      unaff_x30 = (undefined *)0x101f894;
      goto code_r0x01771098;
    }
    *(undefined1 **)(pdVar16 + 6) = puVar3 + 1;
    *puVar3 = 10;
/* wm:if you paid for this, you were scammed */
    pdVar16 = (dword *)func_0x01771360(*(long *)(param_1 + 0x54),(int)param_2 << 1);
    param_2 = (dword *)(ulong)((int)param_2 + 1);
  }
  lVar24 = *(long *)(param_1 + 0x58);
  uVar23 = param_1[0x2e0];
  iVar15 = *(int *)(lVar24 + (ulong)uVar23 * 0xa0);
  if (iVar15 < 4) {
    if (1 < iVar15) {
      if (iVar15 == 2) {
        lVar24 = lVar24 + (ulong)uVar23 * 0xa0;
        uVar19 = *(ulong *)(lVar24 + 0x10);
        uVar25 = *(ulong *)(lVar24 + 0x18);
        unaff_x21 = (dword *)(ulong)*(byte *)(lVar24 + 0x9a);
        param_2 = (dword *)(ulong)*(byte *)(lVar24 + 0x9b);
        uStack_d8 = uVar25;
        uStack_d0 = uVar19;
        if (*(char *)(lVar24 + 0x9c) != '\x01') {
          if (0xf < uVar19) goto LAB_0101feb0;
          uStack_80 = CONCAT17(0xd,(undefined7)uStack_80);
          uStack_90 = s__no_argument__01cbd52e._0_4_;
          uStack_8c = CONCAT31(s__no_argument__01cbd52e._5_3_,s__no_argument__01cbd52e[4]);
          uStack_88._0_1_ = s__no_argument__01cbd52e[8];
          uStack_88._1_1_ = s__no_argument__01cbd52e[9];
          uStack_88._2_1_ = s__no_argument__01cbd52e[10];
          uStack_88._3_1_ = s__no_argument__01cbd52e[0xb];
          uStack_88._4_1_ = s__no_argument__01cbd52e[0xc];
          uStack_83 = 0;
          goto joined_r0x0101fb4c;
        }
        pdVar20 = *(dword **)(param_1 + 0x54);
        func_0x011567a0(&uStack_90,&uStack_d0,param_1 + 2);
        pdVar22 = (dword *)CONCAT26(uStack_82,CONCAT15(uStack_83,uStack_88));
        pcVar21 = (char *)CONCAT44(uStack_8c,uStack_90);
        if (-1 < (long)uStack_80) {
          pdVar22 = (dword *)(uStack_80 >> 0x38);
          pcVar21 = (char *)&uStack_90;
/* wm:proprietary - see LICENSE - do not sell */
        }
        unaff_x30 = (undefined *)0x101fa74;
        puVar12 = auStack_151 + 0x21;
        param_2 = pdVar20;
        unaff_x21 = &uStack_90;
      }
      else {
        if (iVar15 != 3) {
          return pdVar16;
        }
        lVar24 = lVar24 + (ulong)uVar23 * 0xa0;
        pdVar34 = *(dword **)(lVar24 + 0x20);
        cVar5 = *(char *)(lVar24 + 0x30);
        if (*(char *)(lVar24 + 0x9c) == '\x01') {
          pdVar20 = *(dword **)(param_1 + 0x54);
          if (pdVar34 != (dword *)0x0) {
            puVar11 = (undefined1 *)register0x00000008;
            param_2 = pdVar34;
            pdVar34 = unaff_x21;
            puVar28 = unaff_x29;
            goto code_r0x0112ca48;
/* if you paid for this, you were scammed */
          }
          puVar4 = *(undefined8 **)(pdVar20 + 6);
          if (cVar5 == '\0') {
            if (0xc < (ulong)(*(long *)(pdVar20 + 4) - (long)puVar4)) {
              *puVar4 = CONCAT35(s__no_argument__01cbd52e._5_3_,s__no_argument__01cbd52e._0_5_);
              *(ulong *)((long)puVar4 + 5) =
                   CONCAT53(s__no_argument__01cbd52e._8_5_,s__no_argument__01cbd52e._5_3_);
              *(long *)(pdVar20 + 6) = *(long *)(pdVar20 + 6) + 0xd;
              return pdVar16;
            }
            pcVar21 = "(no argument)";
            pdVar22 = (dword *)((long)&MACH_HEADER.filetype + 1);
          }
          else {
            if (6 < (ulong)(*(long *)(pdVar20 + 4) - (long)puVar4)) {
              *(undefined4 *)((long)puVar4 + 3) = 0x7274706c;
              *(undefined4 *)puVar4 = 0x6c6c756e;
              *(long *)(pdVar20 + 6) = *(long *)(pdVar20 + 6) + 7;
              return pdVar16;
            }
            pcVar21 = "nullptr";
/* +- WM -------------------------------------------------------------+
   |  donate: donate/README.md
   +--------------------------------------------------------------------*/
            pdVar22 = (dword *)((long)&MACH_HEADER.cputype + 3);
          }
          puVar12 = (undefined1 *)register0x00000008;
          param_1 = unaff_x19;
          param_2 = unaff_x20;
          puVar28 = unaff_x29;
        }
        else {
          cVar7 = *(char *)(lVar24 + 0x9a);
          unaff_x22 = *(dword **)(param_1 + 0x54);
          pdVar16 = *(dword **)(unaff_x22 + 6);
          pdVar20 = unaff_x22;
          unaff_x21 = pdVar34;
          if ((*(byte *)((long)param_1 + 0x139) & 1) == 0) {
            pdVar22 = (dword *)((long)&MACH_HEADER.cpusubtype + 2);
            if (cVar7 == '\0') {
              pdVar22 = (dword *)0x0;
            }
            if ((uint *)(*(long *)(unaff_x22 + 4) - (long)pdVar16) < pdVar22) {
              pcVar21 = "(default) ";
              if (cVar7 == '\0') {
                pcVar21 = &UNK_01cb7848;
              }
              unaff_x30 = (undefined *)0x102009c;
              puVar12 = auStack_151 + 0x21;
              goto code_r0x01770110;
            }
            if (cVar7 == '\0') {
              *(char *)(param_1 + 0x56) = '\x01';
/*
 *  unlicensed copy if this notice is missing
 *
 *  @pengussy
 */
              if (*(char *)((long)param_1 + 0x13a) == '\x01') goto LAB_01020438;
LAB_010200b0:
              pdVar20 = *(dword **)(param_1 + 0x54);
            }
            else {
              *(undefined2 *)(pdVar16 + 2) = 0x2029;
              *(undefined8 *)pdVar16 = s__default__01cbd53c._0_8_;
              *(long *)(unaff_x22 + 6) = *(long *)(unaff_x22 + 6) + 10;
              *(char *)(param_1 + 0x56) = '\x01';
              if (*(char *)((long)param_1 + 0x13a) != '\x01') goto LAB_010200b0;
LAB_01020438:
              pdVar16 = *(dword **)(param_1 + 0x54);
              puVar12 = *(undefined1 **)(pdVar16 + 6);
              if (*(undefined1 **)(pdVar16 + 4) <= puVar12) {
                uVar29 = 0x7f;
                unaff_x30 = (undefined *)0x1020db0;
                puVar13 = auStack_151 + 0x21;
                goto code_r0x01771098;
              }
              *(undefined1 **)(pdVar16 + 6) = puVar12 + 1;
              *puVar12 = 0x7f;
              pdVar20 = *(dword **)(param_1 + 0x54);
            }
            if (pdVar34 == (dword *)0x0) {
              puVar4 = *(undefined8 **)(pdVar20 + 6);
              if (cVar5 == '\0') {
                if ((ulong)(*(long *)(pdVar20 + 4) - (long)puVar4) < 0xd) {
                  pdVar16 = (dword *)func_0x01770110(pdVar20,"(no argument)",0xd);
                  goto LAB_01020e54;
/*
 *  chat: discord.gg/sdkhDjTex
 *
 *  @pengussy
 */
                }
                *puVar4 = CONCAT35(s__no_argument__01cbd52e._5_3_,s__no_argument__01cbd52e._0_5_);
                *(ulong *)((long)puVar4 + 5) =
                     CONCAT53(s__no_argument__01cbd52e._8_5_,s__no_argument__01cbd52e._5_3_);
                lVar24 = *(long *)(pdVar20 + 6) + 0xd;
              }
              else {
                if ((ulong)(*(long *)(pdVar20 + 4) - (long)puVar4) < 7) {
                  pcVar21 = "nullptr";
                  unaff_x30 = (undefined *)0x1020de4;
                  puVar12 = auStack_151 + 0x21;
                  pdVar22 = (dword *)((long)&MACH_HEADER.cputype + 3);
                  goto code_r0x01770110;
                }
                *(undefined4 *)((long)puVar4 + 3) = 0x7274706c;
                *(undefined4 *)puVar4 = 0x6c6c756e;
                lVar24 = *(long *)(pdVar20 + 6) + 7;
              }
              *(long *)(pdVar20 + 6) = lVar24;
            }
/* watermarked copy - do not remove */
            else {
              pdVar16 = (dword *)func_0x0112ca48(pdVar34,pdVar20,0,param_1 + 2,0);
            }
LAB_01020e54:
            *(char *)(param_1 + 0x56) = '\0';
            if (*(char *)((long)param_1 + 0x13a) != '\x01') {
              return pdVar16;
            }
            pdVar16 = *(dword **)(param_1 + 0x54);
            puVar28 = *(undefined1 **)(pdVar16 + 6);
            if (puVar28 < *(undefined1 **)(pdVar16 + 4)) {
              *(undefined1 **)(pdVar16 + 6) = puVar28 + 1;
              uVar29 = 0x7f;
LAB_0102169c:
              *puVar28 = uVar29;
              return pdVar16;
            }
            uVar29 = 0x7f;
LAB_010216c4:
            puVar13 = (undefined1 *)register0x00000008;
            param_1 = unaff_x19;
            param_2 = unaff_x20;
            puVar28 = unaff_x29;
            goto code_r0x01771098;
          }
          param_2 = *(dword **)(lVar24 + 0x28);
          cVar8 = *(char *)(lVar24 + 0x31);
          cVar9 = *(char *)(lVar24 + 0x9b);
          pcVar21 = "[(default) ";
          if (cVar7 == '\0') {
            pcVar21 = &UNK_01c881b8;
          }
          pdVar22 = (dword *)((long)&MACH_HEADER.cpusubtype + 3);
          if (cVar7 == '\0') {
            pdVar22 = (dword *)((long)&MACH_HEADER.magic + 1);
          }
          if ((uint *)(*(long *)(unaff_x22 + 4) - (long)pdVar16) < pdVar22) {
            unaff_x30 = (undefined *)0x101fbd0;
/* wm:donate: donate/README.md */
            puVar12 = auStack_151 + 0x21;
          }
          else {
            _memcpy(pdVar16,pcVar21,pdVar22);
            *(char **)(unaff_x22 + 6) = (char *)(*(long *)(unaff_x22 + 6) + (long)pdVar22);
            *(char *)(param_1 + 0x56) = '\x01';
            if (*(char *)((long)param_1 + 0x13a) == '\x01') {
              lVar24 = *(long *)(param_1 + 0x54);
              puVar12 = *(undefined1 **)(lVar24 + 0x18);
              if (puVar12 < *(undefined1 **)(lVar24 + 0x10)) {
                *(undefined1 **)(lVar24 + 0x18) = puVar12 + 1;
                *puVar12 = 0x7f;
              }
              else {
                func_0x01771098(lVar24,0x7f);
              }
            }
            pdVar20 = *(dword **)(param_1 + 0x54);
            if (pdVar34 == (dword *)0x0) {
              puVar4 = *(undefined8 **)(pdVar20 + 6);
              if (cVar5 == '\0') {
                if ((ulong)(*(long *)(pdVar20 + 4) - (long)puVar4) < 0xd) {
                  pcVar21 = "(no argument)";
                  unaff_x30 = (undefined *)0x1021300;
                  puVar12 = auStack_151 + 0x21;
                  pdVar22 = (dword *)((long)&MACH_HEADER.filetype + 1);
                  goto code_r0x01770110;
                }
                *puVar4 = CONCAT35(s__no_argument__01cbd52e._5_3_,s__no_argument__01cbd52e._0_5_);
                *(ulong *)((long)puVar4 + 5) =
                     CONCAT53(s__no_argument__01cbd52e._8_5_,s__no_argument__01cbd52e._5_3_);
                lVar24 = *(long *)(pdVar20 + 6) + 0xd;
              }
              else {
                if ((ulong)(*(long *)(pdVar20 + 4) - (long)puVar4) < 7) {
                  func_0x01770110(pdVar20,"nullptr",7);
                  goto LAB_01021404;
                }
// WM - if you paid for this, you were scammed
                *(undefined4 *)((long)puVar4 + 3) = 0x7274706c;
                *(undefined4 *)puVar4 = 0x6c6c756e;
                lVar24 = *(long *)(pdVar20 + 6) + 7;
              }
              *(long *)(pdVar20 + 6) = lVar24;
            }
            else {
              func_0x0112ca48(pdVar34,pdVar20,0,param_1 + 2,0);
            }
LAB_01021404:
            *(char *)(param_1 + 0x56) = '\0';
            if (*(char *)((long)param_1 + 0x13a) == '\x01') {
              pdVar16 = *(dword **)(param_1 + 0x54);
              puVar12 = *(undefined1 **)(pdVar16 + 6);
              if (*(undefined1 **)(pdVar16 + 4) <= puVar12) {
                uVar29 = 0x7f;
                unaff_x30 = (undefined *)0x1021440;
                puVar13 = auStack_151 + 0x21;
                goto code_r0x01771098;
              }
              *(undefined1 **)(pdVar16 + 6) = puVar12 + 1;
              *puVar12 = 0x7f;
            }
            pdVar20 = *(dword **)(param_1 + 0x54);
            if (3 < (ulong)(*(long *)(pdVar20 + 4) - (long)*(undefined4 **)(pdVar20 + 6))) {
              **(undefined4 **)(pdVar20 + 6) = 0x203d2120;
              lVar24 = *(long *)(pdVar20 + 6);
              pcVar26 = (char *)(lVar24 + 4);
              *(char **)(pdVar20 + 6) = pcVar26;
              uVar19 = 10;
              if (cVar9 == '\0') {
                uVar19 = 0;
              }
/* WM: if you paid for this, you were scammed @ discord.gg/sdkhDjTex */
              if ((ulong)(*(long *)(pdVar20 + 4) - (long)pcVar26) < uVar19) {
                pcVar26 = "(default) ";
                if (cVar9 == '\0') {
                  pcVar26 = "";
                }
                func_0x01770110(pdVar20,pcVar26);
                *(char *)(param_1 + 0x56) = '\x01';
                cVar5 = *(char *)((long)param_1 + 0x13a);
joined_r0x01021540:
                if (cVar5 != '\x01') goto LAB_010214d0;
LAB_01021544:
                lVar24 = *(long *)(param_1 + 0x54);
                puVar12 = *(undefined1 **)(lVar24 + 0x18);
                if (puVar12 < *(undefined1 **)(lVar24 + 0x10)) {
                  *(undefined1 **)(lVar24 + 0x18) = puVar12 + 1;
                  *puVar12 = 0x7f;
                  pdVar20 = *(dword **)(param_1 + 0x54);
                }
                else {
/*
 *  watermarked copy - do not remove
 *
 *  @pengussy
 */
                  func_0x01771098(lVar24,0x7f);
                  pdVar20 = *(dword **)(param_1 + 0x54);
                }
              }
              else {
                if (cVar9 == '\0') {
                  *(char *)(param_1 + 0x56) = '\x01';
                  cVar5 = *(char *)((long)param_1 + 0x13a);
                  goto joined_r0x01021540;
                }
                *(undefined2 *)(lVar24 + 0xc) = 0x2029;
                *(undefined8 *)pcVar26 = s__default__01cbd53c._0_8_;
                *(long *)(pdVar20 + 6) = *(long *)(pdVar20 + 6) + 10;
                *(char *)(param_1 + 0x56) = '\x01';
                if (*(char *)((long)param_1 + 0x13a) == '\x01') goto LAB_01021544;
LAB_010214d0:
                pdVar20 = *(dword **)(param_1 + 0x54);
              }
              if (param_2 != (dword *)0x0) {
                unaff_x30 = (undefined *)0x10214ec;
                unaff_x19 = param_1;
                unaff_x20 = param_2;
code_r0x0112ca48:
                *(dword **)(puVar11 + -0x30) = unaff_x22;
                *(dword **)(puVar11 + -0x28) = pdVar34;
                *(dword **)(puVar11 + -0x20) = unaff_x20;
                *(dword **)(puVar11 + -0x18) = unaff_x19;
                *(undefined1 **)(puVar11 + -0x10) = puVar28;
                *(undefined **)(puVar11 + -8) = unaff_x30;
                *(dword **)(puVar11 + -0x178) = pdVar20;
// WM - thanks for reading - discord.gg/sdkhDjTex
                *(undefined4 *)(puVar11 + -0x170) = 0;
                *(undefined8 *)(puVar11 + -0x168) = 0;
                func_0x009d1be0(puVar11 + -0x160,param_1 + 2);
                *(dword *)(puVar11 + -0x38) = param_1[0x4c];
                plVar18 = *(long **)(puVar11 + -0x168);
                if ((plVar18 == (long *)0x0) ||
                   (uVar19 = (**(code **)(*plVar18 + 0x10))
                                       (plVar18,param_2,*(undefined8 *)(puVar11 + -0x178)),
                   (uVar19 & 1) == 0)) {
                  func_0x0112cb34(puVar11 + -0x178,param_2);
                }
                pdVar16 = (dword *)func_0x009d1f0c(puVar11 + -0x160);
                return pdVar16;
              }
              puVar4 = *(undefined8 **)(pdVar20 + 6);
              if (cVar8 == '\0') {
                if ((ulong)(*(long *)(pdVar20 + 4) - (long)puVar4) < 0xd) {
                  pcVar21 = "(no argument)";
                  unaff_x30 = (undefined *)0x10215d0;
                  puVar12 = auStack_151 + 0x21;
                  pdVar22 = (dword *)((long)&MACH_HEADER.filetype + 1);
                  goto code_r0x01770110;
                }
                *puVar4 = CONCAT35(s__no_argument__01cbd52e._5_3_,s__no_argument__01cbd52e._0_5_);
                *(ulong *)((long)puVar4 + 5) =
/* donate: donate/README.md - github.com/pengussy */
                     CONCAT53(s__no_argument__01cbd52e._8_5_,s__no_argument__01cbd52e._5_3_);
                lVar24 = *(long *)(pdVar20 + 6) + 0xd;
LAB_01021640:
                *(long *)(pdVar20 + 6) = lVar24;
              }
              else {
                if (6 < (ulong)(*(long *)(pdVar20 + 4) - (long)puVar4)) {
                  *(undefined4 *)((long)puVar4 + 3) = 0x7274706c;
                  *(undefined4 *)puVar4 = 0x6c6c756e;
                  lVar24 = *(long *)(pdVar20 + 6) + 7;
                  goto LAB_01021640;
                }
                func_0x01770110(pdVar20,"nullptr",7);
              }
              *(char *)(param_1 + 0x56) = '\0';
              if (*(char *)((long)param_1 + 0x13a) == '\x01') {
                pdVar16 = *(dword **)(param_1 + 0x54);
                puVar12 = *(undefined1 **)(pdVar16 + 6);
                if (*(undefined1 **)(pdVar16 + 4) <= puVar12) {
                  uVar29 = 0x7f;
                  unaff_x30 = (undefined *)0x1021680;
                  puVar13 = auStack_151 + 0x21;
                  goto code_r0x01771098;
                }
                *(undefined1 **)(pdVar16 + 6) = puVar12 + 1;
/*  thanks for reading - discord.gg/sdkhDjTex  */
                *puVar12 = 0x7f;
              }
              pdVar16 = *(dword **)(param_1 + 0x54);
              puVar28 = *(undefined1 **)(pdVar16 + 6);
              if (puVar28 < *(undefined1 **)(pdVar16 + 4)) {
                *(undefined1 **)(pdVar16 + 6) = puVar28 + 1;
                uVar29 = 0x5d;
                goto LAB_0102169c;
              }
              uVar29 = 0x5d;
              goto LAB_010216c4;
            }
            pcVar21 = " != ";
            unaff_x30 = (undefined *)0x1021464;
            puVar12 = auStack_151 + 0x21;
            pdVar22 = &MACH_HEADER.cputype;
          }
        }
      }
      goto code_r0x01770110;
    }
    if (iVar15 == 1) {
      lVar27 = lVar24 + (ulong)uVar23 * 0xa0;
      unaff_x22 = *(dword **)(lVar27 + 0x38);
      if (*(int *)(lVar27 + 8) == 0) {
/*  chat: discord.gg/sdkhDjTex  */
        param_1 = *(dword **)(param_1 + 0x54);
        func_0x0107ca24(&uStack_90,unaff_x22 + 8);
        pdVar22 = (dword *)CONCAT26(uStack_82,CONCAT15(uStack_83,uStack_88));
        pcVar21 = (char *)CONCAT44(uStack_8c,uStack_90);
        if (-1 < (long)uStack_80) {
          pdVar22 = (dword *)(uStack_80 >> 0x38);
          pcVar21 = (char *)&uStack_90;
        }
        unaff_x30 = (undefined *)0x101fc88;
        puVar12 = auStack_151 + 0x21;
        pdVar20 = param_1;
        param_2 = &uStack_90;
      }
      else {
        lVar24 = lVar24 + (ulong)uVar23 * 0xa0;
        func_0x010218b8(param_1,*(undefined4 *)(lVar24 + 0x48),*(undefined4 *)(lVar24 + 0x4c));
        pdVar20 = *(dword **)(param_1 + 0x54);
        func_0x0107ca24(&uStack_90,unaff_x22 + 8);
        pdVar22 = (dword *)CONCAT26(uStack_82,CONCAT15(uStack_83,uStack_88));
        pcVar21 = (char *)CONCAT44(uStack_8c,uStack_90);
        if (-1 < (long)uStack_80) {
          pdVar22 = (dword *)(uStack_80 >> 0x38);
          pcVar21 = (char *)&uStack_90;
        }
        unaff_x30 = (undefined *)0x101f9f8;
        puVar12 = auStack_151 + 0x21;
        unaff_x21 = pdVar20;
      }
      goto code_r0x01770110;
    }
    if (iVar15 != 0) {
// WM - watermarked copy - do not remove
      return pdVar16;
    }
    func_0x0174ef58("Template diffing failed with bad DiffNode",
                    "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/lib/AST/ASTDiagnostic.cpp"
                    ,0x57a);
    uVar25 = extraout_x8;
    uVar19 = extraout_x9;
LAB_0101feb0:
    if (0xf < uVar25) {
      unaff_x22 = (dword *)(uVar19 & 0xfffffffffffffff0);
      if (*(long *)unaff_x22 == *(long *)(uVar25 & 0xfffffffffffffff0)) {
        if (((uint)uVar19 >> 3 & 1) == 0) {
          uVar23 = 0;
        }
        else {
          uVar23 = unaff_x22[6];
        }
        if (((uint)uVar25 >> 3 & 1) == 0) {
          uVar30 = 0;
        }
        else {
          uVar30 = *(uint *)((long *)(uVar25 & 0xfffffffffffffff0) + 3);
        }
        func_0x010218b8(param_1,uVar23 | (uint)uVar19 & 7,uVar30 | (uint)uVar25 & 7);
        uStack_80 = CONCAT62(uStack_80._2_6_,0x101);
        puVar17 = (ulong *)(*(ulong *)unaff_x22 & 0xfffffffffffffff0);
        uVar23 = (uint)*(ulong *)unaff_x22;
// origin: github.com/pengussy
        if ((uVar23 >> 3 & 1) == 0) {
          uVar23 = uVar23 & 7;
        }
        else {
          uVar23 = (uint)puVar17[3] | uVar23 & 7;
          puVar17 = (ulong *)*puVar17;
        }
        pdVar16 = (dword *)func_0x01156aa0(puVar17,uVar23,*(long *)(param_1 + 0x54),param_1 + 2,
                                           &uStack_90);
        return pdVar16;
      }
    }
    func_0x011567a0(&uStack_90,&uStack_d0,param_1 + 2);
joined_r0x0101fb4c:
    if (uStack_d8 < 0x10) {
      uVar23 = 0xd;
      uStack_a0 = CONCAT17(0xd,(undefined7)uStack_a0);
      uStack_b0 = s__no_argument__01cbd52e._0_4_;
      uStack_ac = CONCAT31(s__no_argument__01cbd52e._5_3_,s__no_argument__01cbd52e[4]);
      uStack_a8 = s__no_argument__01cbd52e._8_5_;
      uStack_a3 = 0;
    }
    else {
      func_0x011567a0(&uStack_b0,&uStack_d8,param_1 + 2);
      uVar23 = (uint)uStack_a0._7_1_;
/*
   watermarked copy - do not remove
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
    }
    uVar19 = CONCAT26(uStack_82,CONCAT15(uStack_83,uStack_88));
    if (-1 < (long)uStack_80) {
      uVar19 = uStack_80 >> 0x38;
    }
    uVar25 = CONCAT26(uStack_a2,CONCAT15(uStack_a3,uStack_a8));
    if (-1 < (char)uVar23) {
      uVar25 = (ulong)uVar23;
    }
    if (uVar19 == uVar25) {
      puVar32 = (uint *)CONCAT44(uStack_8c,uStack_90);
      if (-1 < (long)uStack_80) {
        puVar32 = &uStack_90;
      }
      puVar33 = (uint *)CONCAT44(uStack_ac,uStack_b0);
      if (-1 < (char)uVar23) {
        puVar33 = &uStack_b0;
      }
      iVar15 = _memcmp(puVar32,puVar33);
      if (iVar15 == 0) {
        pppppppuStack_f0 =
             (undefined8 *******)(uStack_d0 & 7 | *(ulong *)((uStack_d0 & 0xfffffffffffffff0) + 8));
        func_0x011567a0(&dStack_c8,&pppppppuStack_f0,param_1 + 2);
        uStack_f8 = uStack_d8 & 7 | *(ulong *)((uStack_d8 & 0xfffffffffffffff0) + 8);
        func_0x011567a0(&pppppppuStack_f0,&uStack_f8,param_1 + 2);
        pdVar16 = pdStack_c0;
        if (-1 < (char)bStack_b1) {
          pdVar16 = (dword *)(ulong)bStack_b1;
        }
        uVar23 = (uint)(char)bStack_d9;
        unaff_x22 = (dword *)(ulong)uVar23;
        puVar32 = puStack_e8;
        if (-1 < (int)uVar23) {
          puVar32 = (uint *)(ulong)bStack_d9;
        }
/* do not claim this as your own - github.com/pengussy */
        if (pdVar16 == puVar32) {
          pdVar16 = (dword *)CONCAT44(uStack_c4,dStack_c8);
          if (-1 < (char)bStack_b1) {
            pdVar16 = &dStack_c8;
          }
          pppppppuVar1 = pppppppuStack_f0;
          if (-1 < (int)uVar23) {
            pppppppuVar1 = &pppppppuStack_f0;
          }
          iVar15 = _memcmp(pdVar16,pppppppuVar1);
          if (iVar15 != 0) goto LAB_01020000;
        }
        else {
LAB_01020000:
          __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEEaSERKS5_
                    (&uStack_90,&dStack_c8);
/* WM - more drops soon - github.com/pengussy */
          __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEEaSERKS5_
                    (&uStack_b0,&pppppppuStack_f0);
          unaff_x22 = (dword *)(ulong)bStack_d9;
        }
        if (((uint)unaff_x22 >> 7 & 1) != 0) {
          __ZdlPv(pppppppuStack_f0);
        }
        if ((char)bStack_b1 < '\0') {
          __ZdlPv(CONCAT44(uStack_c4,dStack_c8));
        }
      }
    }
    if (*(char *)((long)param_1 + 0x139) == '\x01') {
      lVar24 = *(long *)(param_1 + 0x54);
      puVar12 = *(undefined1 **)(lVar24 + 0x18);
      if (puVar12 < *(undefined1 **)(lVar24 + 0x10)) {
        *(undefined1 **)(lVar24 + 0x18) = puVar12 + 1;
        *puVar12 = 0x5b;
/* thanks for reading - discord.gg/sdkhDjTex */
      }
      else {
        func_0x01771098(lVar24,0x5b);
      }
    }
    pdVar20 = *(dword **)(param_1 + 0x54);
    iVar15 = (int)unaff_x21;
    pdVar22 = (dword *)((long)&MACH_HEADER.cpusubtype + 2);
    if (iVar15 == 0) {
      pdVar22 = (dword *)0x0;
    }
    pcVar26 = *(char **)(pdVar20 + 6);
    if ((uint *)(*(long *)(pdVar20 + 4) - (long)pcVar26) < pdVar22) {
      pcVar21 = "(default) ";
      if (iVar15 == 0) {
        pcVar21 = &UNK_01cb7848;
// chat: discord.gg/sdkhDjTex
      }
      unaff_x30 = (undefined *)0x1020b5c;
      puVar12 = auStack_151 + 0x21;
    }
    else {
      if (iVar15 != 0) {
        pcVar26[8] = ')';
        pcVar26[9] = ' ';
        *(undefined8 *)pcVar26 = s__default__01cbd53c._0_8_;
        *(long *)(pdVar20 + 6) = *(long *)(pdVar20 + 6) + 10;
      }
      *(char *)(param_1 + 0x56) = '\x01';
      if (*(char *)((long)param_1 + 0x13a) == '\x01') {
        pdVar16 = *(dword **)(param_1 + 0x54);
        puVar12 = *(undefined1 **)(pdVar16 + 6);
        if (*(undefined1 **)(pdVar16 + 4) <= puVar12) {
          uVar29 = 0x7f;
          unaff_x30 = (undefined *)0x1020bc8;
          puVar13 = auStack_151 + 0x21;
          goto code_r0x01771098;
        }
        *(undefined1 **)(pdVar16 + 6) = puVar12 + 1;
        *puVar12 = 0x7f;
      }
      uVar19 = CONCAT26(uStack_82,CONCAT15(uStack_83,uStack_88));
// WM - more drops soon - github.com/pengussy
      puVar32 = (uint *)CONCAT44(uStack_8c,uStack_90);
      if (-1 < (long)uStack_80) {
        uVar19 = uStack_80 >> 0x38;
        puVar32 = &uStack_90;
      }
      pdVar16 = (dword *)func_0x01770110(*(long *)(param_1 + 0x54),puVar32,uVar19);
      *(char *)(param_1 + 0x56) = '\0';
      if (*(char *)((long)param_1 + 0x13a) == '\x01') {
        pdVar16 = *(dword **)(param_1 + 0x54);
        puVar12 = *(undefined1 **)(pdVar16 + 6);
        if (puVar12 < *(undefined1 **)(pdVar16 + 4)) {
          *(undefined1 **)(pdVar16 + 6) = puVar12 + 1;
          *puVar12 = 0x7f;
        }
        else {
          pdVar16 = (dword *)func_0x01771098(pdVar16,0x7f);
        }
      }
      if (*(char *)((long)param_1 + 0x139) != '\x01') goto LAB_01021254;
      pdVar20 = *(dword **)(param_1 + 0x54);
      if ((ulong)(*(long *)(pdVar20 + 4) - (long)*(undefined4 **)(pdVar20 + 6)) < 4) {
        pcVar21 = " != ";
/* wm:origin: github.com/pengussy */
        unaff_x30 = (undefined *)0x1020c58;
        puVar12 = auStack_151 + 0x21;
        pdVar22 = &MACH_HEADER.cputype;
      }
      else {
        **(undefined4 **)(pdVar20 + 6) = 0x203d2120;
        lVar24 = *(long *)(pdVar20 + 6);
        pcVar26 = (char *)(lVar24 + 4);
        *(char **)(pdVar20 + 6) = pcVar26;
        iVar15 = (int)param_2;
        uVar19 = 10;
        if (iVar15 == 0) {
          uVar19 = 0;
        }
        if ((ulong)(*(long *)(pdVar20 + 4) - (long)pcVar26) < uVar19) {
          pcVar26 = "(default) ";
          if (iVar15 == 0) {
            pcVar26 = "";
          }
          func_0x01770110(pdVar20,pcVar26);
        }
        else if (iVar15 != 0) {
          *(undefined2 *)(lVar24 + 0xc) = 0x2029;
          *(undefined8 *)pcVar26 = s__default__01cbd53c._0_8_;
          *(long *)(pdVar20 + 6) = *(long *)(pdVar20 + 6) + 10;
        }
        *(char *)(param_1 + 0x56) = '\x01';
        if (*(char *)((long)param_1 + 0x13a) == '\x01') {
          pdVar16 = *(dword **)(param_1 + 0x54);
          puVar12 = *(undefined1 **)(pdVar16 + 6);
          if (*(undefined1 **)(pdVar16 + 4) <= puVar12) {
            uVar29 = 0x7f;
            unaff_x30 = (undefined *)0x10211bc;
/*  unlicensed copy if this notice is missing  */
            puVar13 = auStack_151 + 0x21;
            goto code_r0x01771098;
          }
          *(undefined1 **)(pdVar16 + 6) = puVar12 + 1;
          *puVar12 = 0x7f;
        }
        pdVar22 = (dword *)CONCAT26(uStack_a2,CONCAT15(uStack_a3,uStack_a8));
        pcVar21 = (char *)CONCAT44(uStack_ac,uStack_b0);
        if (-1 < (long)uStack_a0) {
          pdVar22 = (dword *)(uStack_a0 >> 0x38);
          pcVar21 = (char *)&uStack_b0;
        }
        unaff_x30 = (undefined *)0x10211e0;
        puVar12 = auStack_151 + 0x21;
        pdVar20 = *(dword **)(param_1 + 0x54);
      }
    }
  }
  else if (iVar15 == 4) {
    lVar24 = lVar24 + (ulong)uVar23 * 0xa0;
    param_2 = *(dword **)(lVar24 + 0x38);
    unaff_x21 = *(dword **)(lVar24 + 0x40);
    cVar5 = *(char *)(lVar24 + 0x9a);
    cVar7 = *(char *)(lVar24 + 0x9b);
    bVar6 = *(byte *)(lVar24 + 0x9c);
/*
   unlicensed copy if this notice is missing
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
    if (param_2 == (dword *)0x0) {
      pcVar26 = "(no argument)";
      uVar19 = 0xd;
LAB_0101fcc4:
      uStack_80 = CONCAT17((char)uVar19,(undefined7)uStack_80);
      _memmove(&uStack_90,pcVar26,uVar19);
      *(undefined1 *)((long)&uStack_90 + uVar19) = 0;
      if (unaff_x21 != (dword *)0x0) goto LAB_0101fce0;
LAB_0102080c:
      pcVar26 = "(no argument)";
      unaff_x22 = (dword *)((long)&MACH_HEADER.filetype + 1);
LAB_01020818:
      uStack_a0 = CONCAT17((char)unaff_x22,(undefined7)uStack_a0);
      puVar32 = &uStack_b0;
      uVar23 = (uint)bVar6;
    }
    else {
      uVar19 = *(ulong *)(param_2 + 8);
      if (uVar19 == 0 || (uVar19 & 3) != 0) {
        uVar19 = 0;
        pcVar26 = &UNK_01cb7848;
        goto LAB_0101fcc4;
      }
      puVar32 = *(uint **)(uVar19 + 0x10);
/*  found on a paste site? it was re-uploaded illegally  */
      if (puVar32 == (uint *)0x0) {
        pcVar26 = *(char **)(uVar19 + 0x18);
        uVar23 = *(ushort *)((long)pcVar26 + -2) - 1;
      }
      else {
        pcVar26 = (char *)(puVar32 + 4);
        uVar23 = *puVar32;
      }
      uVar19 = (ulong)uVar23;
      if (uVar23 < 0x17) goto LAB_0101fcc4;
      uVar25 = (uVar19 & 0xfffffff8) + 8;
      uVar2 = 0x19;
      if (uVar25 != 0x18) {
        uVar2 = uVar25;
      }
      lVar24 = __Znwm(uVar2);
      uStack_80 = uVar2 | 0x8000000000000000;
      uStack_90 = (uint)lVar24;
      uStack_8c = (undefined4)((ulong)lVar24 >> 0x20);
      uStack_88 = (uint5)uVar23;
      uStack_83 = 0;
      uStack_82 = 0;
      _memmove(lVar24,pcVar26,uVar19);
      *(undefined1 *)(lVar24 + uVar19) = 0;
      if (unaff_x21 == (dword *)0x0) goto LAB_0102080c;
LAB_0101fce0:
      uVar19 = *(ulong *)(unaff_x21 + 8);
      if (uVar19 == 0 || (uVar19 & 3) != 0) {
        unaff_x22 = (dword *)0x0;
        pcVar26 = &UNK_01cb7848;
        goto LAB_01020818;
      }
      puVar32 = *(uint **)(uVar19 + 0x10);
      if (puVar32 == (uint *)0x0) {
        pcVar26 = *(char **)(uVar19 + 0x18);
/*  stripping the watermark breaks the license  */
        uVar23 = *(ushort *)((long)pcVar26 + -2) - 1;
      }
      else {
        pcVar26 = (char *)(puVar32 + 4);
        uVar23 = *puVar32;
      }
      unaff_x22 = (dword *)(ulong)uVar23;
      if (uVar23 < 0x17) goto LAB_01020818;
      uVar19 = ((ulong)unaff_x22 & 0xfffffff8) + 8;
      uVar25 = 0x19;
      if (uVar19 != 0x18) {
        uVar25 = uVar19;
      }
      uStack_12c = (uint)bVar6;
      puVar32 = (uint *)__Znwm(uVar25,pcVar26);
      uStack_a0 = uVar25 | 0x8000000000000000;
      uStack_b0 = (uint)puVar32;
      uStack_ac = (undefined4)((ulong)puVar32 >> 0x20);
      uStack_a8 = (uint5)uVar23;
      uStack_a3 = 0;
      uStack_a2 = 0;
      uVar23 = uStack_12c;
    }
    _memmove(puVar32,pcVar26,unaff_x22);
    *(char *)((long)puVar32 + (long)unaff_x22) = '\0';
    uVar19 = uStack_a0;
    if (param_2 != (dword *)0x0 && unaff_x21 != (dword *)0x0) {
      uVar25 = CONCAT26(uStack_82,CONCAT15(uStack_83,uStack_88));
      if (-1 < (long)uStack_80) {
/* origin: github.com/pengussy */
        uVar25 = uStack_80 >> 0x38;
      }
      uVar2 = CONCAT26(uStack_a2,CONCAT15(uStack_a3,uStack_a8));
      if (-1 < (long)uStack_a0) {
        uVar2 = uStack_a0 >> 0x38;
      }
      if (uVar25 == uVar2) {
        puVar32 = (uint *)CONCAT44(uStack_8c,uStack_90);
        if (-1 < (long)uStack_80) {
          puVar32 = &uStack_90;
        }
        unaff_x22 = (dword *)CONCAT44(uStack_ac,uStack_b0);
        pdVar16 = unaff_x22;
        if (-1 < (long)uStack_a0) {
          pdVar16 = &uStack_b0;
        }
/* more drops soon - github.com/pengussy */
        iVar15 = _memcmp(puVar32,pdVar16);
        if (iVar15 == 0) {
          func_0x01070c94(&dStack_c8,param_2);
          uStack_88 = (uint5)pdStack_c0;
          uStack_83 = (undefined1)((ulong)pdStack_c0 >> 0x28);
          uStack_82 = (undefined2)((ulong)pdStack_c0 >> 0x30);
          uStack_90 = dStack_c8;
          uStack_8c = uStack_c4;
          uStack_80 = CONCAT17(bStack_b1,CONCAT61(uStack_b7,bStack_b8));
          func_0x01070c94(&dStack_c8,unaff_x21);
          if ((long)uVar19 < 0) {
            __ZdlPv(unaff_x22);
          }
          uStack_a8 = (uint5)pdStack_c0;
          uStack_a3 = (undefined1)((ulong)pdStack_c0 >> 0x28);
          uStack_a2 = (undefined2)((ulong)pdStack_c0 >> 0x30);
          uStack_b0 = dStack_c8;
          uStack_ac = uStack_c4;
          uStack_a0 = CONCAT17(bStack_b1,CONCAT61(uStack_b7,bStack_b8));
        }
      }
    }
    if (uVar23 == 0) {
      param_2 = *(dword **)(param_1 + 0x54);
      lVar24 = *(long *)(param_2 + 6);
      pdVar20 = param_2;
      if ((*(byte *)((long)param_1 + 0x139) & 1) == 0) {
        pcVar21 = "(default) template ";
        if (cVar5 == '\0') {
/* wm:stripping the watermark breaks the license */
          pcVar21 = "template ";
        }
        pdVar22 = (dword *)((long)&MACH_HEADER.ncmds + 3);
        if (cVar5 == '\0') {
          pdVar22 = (dword *)((long)&MACH_HEADER.cpusubtype + 1);
        }
        if (pdVar22 <= (uint *)(*(long *)(param_2 + 4) - lVar24)) {
          _memcpy(lVar24,pcVar21,pdVar22);
          *(char **)(param_2 + 6) = (char *)(*(long *)(param_2 + 6) + (long)pdVar22);
          *(char *)(param_1 + 0x56) = '\x01';
          if (*(char *)((long)param_1 + 0x13a) == '\x01') {
            pdVar16 = *(dword **)(param_1 + 0x54);
            puVar12 = *(undefined1 **)(pdVar16 + 6);
            if (*(undefined1 **)(pdVar16 + 4) <= puVar12) {
              uVar29 = 0x7f;
              unaff_x30 = (undefined *)0x1020ffc;
              puVar13 = auStack_151 + 0x21;
              goto code_r0x01771098;
            }
            *(undefined1 **)(pdVar16 + 6) = puVar12 + 1;
            *puVar12 = 0x7f;
          }
          uVar19 = CONCAT26(uStack_82,CONCAT15(uStack_83,uStack_88));
          puVar32 = (uint *)CONCAT44(uStack_8c,uStack_90);
          if (-1 < (long)uStack_80) {
            uVar19 = uStack_80 >> 0x38;
            puVar32 = &uStack_90;
          }
          pdVar16 = (dword *)func_0x01770110(*(long *)(param_1 + 0x54),puVar32,uVar19);
          *(char *)(param_1 + 0x56) = '\0';
          if (*(char *)((long)param_1 + 0x13a) == '\x01') {
/*
 *  if you paid for this, you were scammed
 *
 *  @pengussy
 */
            pdVar16 = *(dword **)(param_1 + 0x54);
            puVar28 = *(undefined1 **)(pdVar16 + 6);
            if (puVar28 < *(undefined1 **)(pdVar16 + 4)) {
              *(undefined1 **)(pdVar16 + 6) = puVar28 + 1;
              *puVar28 = 0x7f;
            }
            else {
              pdVar16 = (dword *)func_0x01771098();
            }
          }
LAB_01021254:
          if ((long)uStack_a0 < 0) {
            pdVar16 = (dword *)__ZdlPv(CONCAT44(uStack_ac,uStack_b0));
          }
          return pdVar16;
        }
        unaff_x30 = (undefined *)0x1020a0c;
        unaff_x21 = pdVar22;
      }
/* watermarked copy - do not remove - github.com/pengussy */
      else {
        pcVar21 = "[(default) template ";
        if (cVar5 == '\0') {
          pcVar21 = "[template ";
        }
        pdVar34 = &MACH_HEADER.sizeofcmds;
        if (cVar5 == '\0') {
          pdVar34 = (dword *)((long)&MACH_HEADER.cpusubtype + 2);
        }
        if ((uint *)(*(long *)(param_2 + 4) - lVar24) < pdVar34) {
          unaff_x30 = (undefined *)0x1020968;
          puVar12 = auStack_151 + 0x21;
          pdVar22 = pdVar34;
          unaff_x21 = pdVar34;
        }
        else {
          _memcpy(lVar24,pcVar21,pdVar34);
          *(char **)(param_2 + 6) = (char *)(*(long *)(param_2 + 6) + (long)pdVar34);
          *(char *)(param_1 + 0x56) = '\x01';
          if (*(char *)((long)param_1 + 0x13a) == '\x01') {
            lVar24 = *(long *)(param_1 + 0x54);
            puVar12 = *(undefined1 **)(lVar24 + 0x18);
            if (puVar12 < *(undefined1 **)(lVar24 + 0x10)) {
              *(undefined1 **)(lVar24 + 0x18) = puVar12 + 1;
              *puVar12 = 0x7f;
/* +- WM -------------------------------------------------------------+
   |  proprietary - see LICENSE - do not sell
   +--------------------------------------------------------------------*/
            }
            else {
              func_0x01771098(lVar24,0x7f);
            }
          }
          uVar19 = CONCAT26(uStack_82,CONCAT15(uStack_83,uStack_88));
          puVar32 = (uint *)CONCAT44(uStack_8c,uStack_90);
          if (-1 < (long)uStack_80) {
            uVar19 = uStack_80 >> 0x38;
            puVar32 = &uStack_90;
          }
          func_0x01770110(*(long *)(param_1 + 0x54),puVar32,uVar19);
          *(char *)(param_1 + 0x56) = '\0';
          if (*(char *)((long)param_1 + 0x13a) == '\x01') {
            pdVar16 = *(dword **)(param_1 + 0x54);
            puVar12 = *(undefined1 **)(pdVar16 + 6);
            if (*(undefined1 **)(pdVar16 + 4) <= puVar12) {
              uVar29 = 0x7f;
              unaff_x30 = (undefined *)0x1021048;
              puVar13 = auStack_151 + 0x21;
code_r0x01771098:
              *(dword **)(puVar13 + -0x20) = param_2;
              *(dword **)(puVar13 + -0x18) = param_1;
              *(undefined1 **)(puVar13 + -0x10) = puVar28;
              *(undefined **)(puVar13 + -8) = unaff_x30;
              puVar28 = *(undefined1 **)(pdVar16 + 6);
              if (*(undefined1 **)(pdVar16 + 4) <= puVar28) {
                lVar24 = *(long *)(pdVar16 + 2);
                while (lVar24 == 0) {
                  *(dword **)(puVar13 + -0x30) = pdVar16;
                  if (pdVar16[9] == 0) {
                    puVar13[-0x21] = uVar29;
                    pdVar16 = *(dword **)(puVar13 + -0x30);
                    (**(code **)(*(long *)pdVar16 + 0x50))(pdVar16,puVar13 + -0x21,1);
                    return pdVar16;
                  }
// unlicensed copy if this notice is missing
                  lVar24 = *(long *)(puVar13 + -0x30);
                  func_0x0176fbd8(lVar24);
                  puVar28 = *(undefined1 **)(lVar24 + 0x18);
                  if (puVar28 < *(undefined1 **)(lVar24 + 0x10)) {
                    pdVar16 = *(dword **)(puVar13 + -0x30);
                    goto code_r0x017710b4;
                  }
                  pdVar16 = *(dword **)(puVar13 + -0x30);
                  lVar24 = *(long *)(pdVar16 + 2);
                }
                *(long *)(pdVar16 + 6) = lVar24;
                (**(code **)(*(long *)pdVar16 + 0x50))(pdVar16,lVar24,(long)puVar28 - lVar24);
                puVar28 = *(undefined1 **)(pdVar16 + 6);
              }
code_r0x017710b4:
              *(undefined1 **)(pdVar16 + 6) = puVar28 + 1;
              *puVar28 = uVar29;
              return pdVar16;
            }
            *(undefined1 **)(pdVar16 + 6) = puVar12 + 1;
            *puVar12 = 0x7f;
          }
/* no support for modified copies */
          unaff_x21 = *(dword **)(param_1 + 0x54);
          if ((ulong)(*(long *)(unaff_x21 + 4) - (long)*(undefined4 **)(unaff_x21 + 6)) < 4) {
            pcVar21 = " != ";
            pdVar22 = &MACH_HEADER.cputype;
            unaff_x30 = (undefined *)0x102106c;
            puVar12 = auStack_151 + 0x21;
            pdVar20 = unaff_x21;
            unaff_x21 = pdVar34;
          }
          else {
            **(undefined4 **)(unaff_x21 + 6) = 0x203d2120;
            lVar24 = *(long *)(unaff_x21 + 6) + 4;
            *(long *)(unaff_x21 + 6) = lVar24;
            bVar14 = cVar7 == '\0';
            pcVar26 = "(default) template ";
            if (bVar14) {
// proprietary - see LICENSE - do not sell
              pcVar26 = "template ";
            }
            param_2 = (dword *)((long)&MACH_HEADER.ncmds + 3);
            if (bVar14) {
              param_2 = (dword *)((long)&MACH_HEADER.cpusubtype + 1);
            }
            if ((uint *)(*(long *)(unaff_x21 + 4) - lVar24) < param_2) {
              func_0x01770110(unaff_x21,pcVar26,param_2);
              unaff_x21 = pdVar34;
            }
            else {
              _memcpy(lVar24,pcVar26,param_2);
              *(char **)(unaff_x21 + 6) = (char *)(*(long *)(unaff_x21 + 6) + (long)param_2);
            }
            *(char *)(param_1 + 0x56) = '\x01';
            if (*(char *)((long)param_1 + 0x13a) == '\x01') {
              lVar24 = *(long *)(param_1 + 0x54);
              puVar12 = *(undefined1 **)(lVar24 + 0x18);
              if (puVar12 < *(undefined1 **)(lVar24 + 0x10)) {
                *(undefined1 **)(lVar24 + 0x18) = puVar12 + 1;
// WM - donate: donate/README.md
                *puVar12 = 0x7f;
              }
              else {
                func_0x01771098(lVar24,0x7f);
              }
            }
            pdVar22 = (dword *)CONCAT26(uStack_a2,CONCAT15(uStack_a3,uStack_a8));
            pcVar21 = (char *)CONCAT44(uStack_ac,uStack_b0);
            if (-1 < (long)uStack_a0) {
              pdVar22 = (dword *)(uStack_a0 >> 0x38);
              pcVar21 = (char *)&uStack_b0;
            }
            unaff_x30 = (undefined *)0x102114c;
            puVar12 = auStack_151 + 0x21;
            pdVar20 = *(dword **)(param_1 + 0x54);
          }
        }
      }
    }
    else {
      param_1 = *(dword **)(param_1 + 0x54);
      pcVar26 = *(char **)(param_1 + 6);
      pdVar20 = param_1;
      if ((ulong)(*(long *)(param_1 + 4) - (long)pcVar26) < 9) {
        pcVar21 = "template ";
        unaff_x30 = (undefined *)0x1020914;
        puVar12 = auStack_151 + 0x21;
        pdVar22 = (dword *)((long)&MACH_HEADER.cpusubtype + 1);
      }
      else {
        pcVar26[8] = ' ';
        *(undefined8 *)pcVar26 = s_template_01cbd553._0_8_;
        *(long *)(param_1 + 6) = *(long *)(param_1 + 6) + 9;
        func_0x0107ca24(&dStack_c8,param_2 + 8);
        pdVar22 = pdStack_c0;
        pcVar21 = (char *)CONCAT44(uStack_c4,dStack_c8);
        if (-1 < (char)bStack_b1) {
/* WM - donate: donate/README.md */
          pdVar22 = (dword *)(ulong)bStack_b1;
          pcVar21 = (char *)&dStack_c8;
        }
        unaff_x30 = (undefined *)0x10209c0;
        puVar12 = auStack_151 + 0x21;
        unaff_x21 = &dStack_c8;
      }
    }
  }
  else {
    if (iVar15 == 5) {
      dStack_c8 = 1;
      bStack_b8 = 0;
      pppppppuStack_f0 = (undefined8 *******)CONCAT44(pppppppuStack_f0._4_4_,1);
      uStack_e0 = 0;
      lVar24 = lVar24 + (ulong)uVar23 * 0xa0;
      puVar32 = (uint *)(lVar24 + 0x50);
      unaff_x21 = *(dword **)(lVar24 + 0x20);
      param_2 = *(dword **)(lVar24 + 0x28);
      if (*puVar32 < 0x41) {
        pdStack_c0 = *(dword **)(lVar24 + 0x58);
        dStack_c8 = *puVar32;
// WM - stripping the watermark breaks the license
        uVar19 = (ulong)dStack_c8 & 0x3f;
        if ((int)uVar19 != 0) {
          uVar19 = 0xffffffffffffffff >> (-uVar19 & 0x3f);
          if (dStack_c8 < 0x41) {
            pdStack_c0 = (dword *)(uVar19 & (ulong)pdStack_c0);
          }
          else {
            uVar23 = (int)((ulong)dStack_c8 + 0x3f >> 6) - 1;
            *(ulong *)(pdStack_c0 + (ulong)uVar23 * 2) =
                 *(ulong *)(pdStack_c0 + (ulong)uVar23 * 2) & uVar19;
          }
        }
      }
      else {
        func_0x0173aac0(&dStack_c8,puVar32);
      }
      bStack_b8 = *(byte *)(lVar24 + 0x60);
      lVar24 = *(long *)(param_1 + 0x58) + (ulong)param_1[0x2e0] * 0xa0;
      puVar32 = (uint *)(lVar24 + 0x68);
      if (((uint)pppppppuStack_f0 < 0x41) && (*puVar32 < 0x41)) {
        puStack_e8 = *(uint **)(lVar24 + 0x70);
        uVar23 = *puVar32;
        pppppppuStack_f0 = (undefined8 *******)CONCAT44(pppppppuStack_f0._4_4_,uVar23);
        uVar19 = (ulong)uVar23 & 0x3f;
        if ((int)uVar19 != 0) {
          uVar19 = 0xffffffffffffffff >> (-uVar19 & 0x3f);
          if (uVar23 < 0x41) {
            puStack_e8 = (uint *)(uVar19 & (ulong)puStack_e8);
          }
          else {
            uVar23 = (int)((ulong)uVar23 + 0x3f >> 6) - 1;
            *(ulong *)(puStack_e8 + (ulong)uVar23 * 2) =
                 *(ulong *)(puStack_e8 + (ulong)uVar23 * 2) & uVar19;
          }
        }
      }
      else {
        func_0x0173aac0(&pppppppuStack_f0,puVar32);
/* donate: donate/README.md */
      }
      uStack_e0 = *(undefined1 *)(lVar24 + 0x78);
      lVar24 = *(long *)(param_1 + 0x58) + (ulong)param_1[0x2e0] * 0xa0;
      uVar29 = *(undefined1 *)(lVar24 + 0x80);
      unaff_x22 = (dword *)(ulong)*(byte *)(lVar24 + 0x81);
      auStack_110[0] = dStack_c8;
      pdStack_108 = (dword *)0x0;
      if (dStack_c8 < 0x41) {
        pdStack_108 = pdStack_c0;
      }
      else {
        func_0x0173a170(auStack_110,&dStack_c8);
      }
      bStack_100 = bStack_b8;
      auStack_128[0] = (uint)pppppppuStack_f0;
      puStack_120 = (uint *)0x0;
      if ((uint)pppppppuStack_f0 < 0x41) {
        puStack_120 = puStack_e8;
      }
      else {
        func_0x0173a170(auStack_128,&pppppppuStack_f0);
      }
      uStack_118 = uStack_e0;
      lVar24 = *(long *)(param_1 + 0x58) + (ulong)param_1[0x2e0] * 0xa0;
      if (*(char *)(lVar24 + 0x9c) == '\x01') {
        param_1 = *(dword **)(param_1 + 0x54);
        param_2 = &uStack_90;
        func_0x01744c5c(&uStack_90,auStack_110,10,(bStack_100 ^ 0xff) & 1);
        pdVar22 = (dword *)CONCAT26(uStack_82,CONCAT15(uStack_83,uStack_88));
        pcVar21 = (char *)CONCAT44(uStack_8c,uStack_90);
// WM - unlicensed copy if this notice is missing
        if (-1 < (long)uStack_80) {
          pdVar22 = (dword *)(uStack_80 >> 0x38);
          pcVar21 = (char *)param_2;
        }
        unaff_x30 = (undefined *)0x10202f8;
        puVar12 = auStack_151 + 0x21;
        pdVar20 = param_1;
      }
      else {
        cVar5 = *(char *)(lVar24 + 0x9a);
        pdVar20 = *(dword **)(param_1 + 0x54);
        pcVar26 = *(char **)(pdVar20 + 6);
        if ((*(byte *)((long)param_1 + 0x139) & 1) == 0) {
          pdVar22 = (dword *)((long)&MACH_HEADER.cpusubtype + 2);
          if (cVar5 == '\0') {
            pdVar22 = (dword *)0x0;
          }
          if (pdVar22 <= (uint *)(*(long *)(pdVar20 + 4) - (long)pcVar26)) {
            if (cVar5 != '\0') {
              pcVar26[8] = ')';
              pcVar26[9] = ' ';
              *(undefined8 *)pcVar26 = s__default__01cbd53c._0_8_;
              *(long *)(pdVar20 + 6) = *(long *)(pdVar20 + 6) + 10;
            }
            uStack_90 = auStack_110[0];
            uStack_88 = 0;
            uStack_83 = 0;
            uStack_82 = 0;
            if (auStack_110[0] < 0x41) {
              uStack_88 = (uint5)pdStack_108;
              uStack_83 = (undefined1)((ulong)pdStack_108 >> 0x28);
              uStack_82 = (undefined2)((ulong)pdStack_108 >> 0x30);
/* wm:no support for modified copies */
            }
            else {
              func_0x0173a170(&uStack_90,auStack_110);
            }
            uStack_80 = CONCAT71(uStack_80._1_7_,bStack_100);
            pdVar16 = (dword *)func_0x01022008(param_1,&uStack_90,unaff_x21,uVar29);
            if ((0x40 < uStack_90) &&
               (pdVar16 = (dword *)0x0, CONCAT26(uStack_82,CONCAT15(uStack_83,uStack_88)) != 0)) {
              pdVar16 = (dword *)__ZdaPv();
            }
LAB_01020744:
            if ((0x40 < auStack_128[0]) && (pdVar16 = (dword *)0x0, puStack_120 != (uint *)0x0)) {
              pdVar16 = (dword *)__ZdaPv();
            }
            if ((0x40 < auStack_110[0]) && (pdVar16 = (dword *)0x0, pdStack_108 != (dword *)0x0)) {
              pdVar16 = (dword *)__ZdaPv();
            }
            if ((0x40 < (uint)pppppppuStack_f0) &&
               (pdVar16 = (dword *)0x0, puStack_e8 != (uint *)0x0)) {
              pdVar16 = (dword *)__ZdaPv();
/* +- WM -------------------------------------------------------------+
   |  watermarked copy - do not remove
   +--------------------------------------------------------------------*/
            }
            if (dStack_c8 < 0x41) {
              return pdVar16;
            }
            if (pdStack_c0 == (dword *)0x0) {
              return (dword *)0x0;
            }
            pdVar16 = (dword *)__ZdaPv();
            return pdVar16;
          }
          pcVar21 = "(default) ";
          if (cVar5 == '\0') {
            pcVar21 = &UNK_01cb7848;
          }
          unaff_x30 = (undefined *)0x1020394;
          puVar12 = auStack_151 + 0x21;
        }
        else {
          cVar7 = *(char *)(lVar24 + 0x9b);
          pcVar21 = "[(default) ";
          if (cVar5 == '\0') {
            pcVar21 = &UNK_01c881b8;
          }
          pdVar22 = (dword *)((long)&MACH_HEADER.cpusubtype + 3);
          if (cVar5 == '\0') {
// WM - no support for modified copies
            pdVar22 = (dword *)((long)&MACH_HEADER.magic + 1);
          }
          if ((uint *)(*(long *)(pdVar20 + 4) - (long)pcVar26) < pdVar22) {
            unaff_x30 = (undefined *)0x102035c;
            puVar12 = auStack_151 + 0x21;
          }
          else {
            _memcpy(pcVar26,pcVar21,pdVar22);
            *(char **)(pdVar20 + 6) = (char *)(*(long *)(pdVar20 + 6) + (long)pdVar22);
            uStack_90 = auStack_110[0];
            uStack_88 = 0;
            uStack_83 = 0;
            uStack_82 = 0;
            if (auStack_110[0] < 0x41) {
              uStack_88 = (uint5)pdStack_108;
              uStack_83 = (undefined1)((ulong)pdStack_108 >> 0x28);
              uStack_82 = (undefined2)((ulong)pdStack_108 >> 0x30);
            }
            else {
/* WM: more drops soon - github.com/pengussy @ discord.gg/sdkhDjTex */
              func_0x0173a170(&uStack_90,auStack_110);
            }
            uStack_80 = CONCAT71(uStack_80._1_7_,bStack_100);
            func_0x01022008(param_1,&uStack_90,unaff_x21,uVar29);
            if ((0x40 < uStack_90) && (CONCAT26(uStack_82,CONCAT15(uStack_83,uStack_88)) != 0)) {
              __ZdaPv();
            }
            pdVar20 = *(dword **)(param_1 + 0x54);
            if (3 < (ulong)(*(long *)(pdVar20 + 4) - (long)*(undefined4 **)(pdVar20 + 6))) {
              **(undefined4 **)(pdVar20 + 6) = 0x203d2120;
              lVar24 = *(long *)(pdVar20 + 6);
              pcVar26 = (char *)(lVar24 + 4);
              *(char **)(pdVar20 + 6) = pcVar26;
              uVar19 = 10;
              if (cVar7 == '\0') {
                uVar19 = 0;
              }
              if ((ulong)(*(long *)(pdVar20 + 4) - (long)pcVar26) < uVar19) {
                pcVar26 = "(default) ";
                if (cVar7 == '\0') {
                  pcVar26 = "";
/* keep the notice, keep the source honest - github.com/pengussy */
                }
                func_0x01770110(pdVar20,pcVar26);
              }
              else if (cVar7 != '\0') {
                *(undefined2 *)(lVar24 + 0xc) = 0x2029;
                *(undefined8 *)pcVar26 = s__default__01cbd53c._0_8_;
                *(long *)(pdVar20 + 6) = *(long *)(pdVar20 + 6) + 10;
              }
              uStack_b0 = auStack_128[0];
              uStack_a8 = 0;
              uStack_a3 = 0;
              uStack_a2 = 0;
              if (auStack_128[0] < 0x41) {
                uStack_a8 = (uint5)puStack_120;
                uStack_a3 = (undefined1)((ulong)puStack_120 >> 0x28);
                uStack_a2 = (undefined2)((ulong)puStack_120 >> 0x30);
              }
              else {
                func_0x0173a170(&uStack_b0,auStack_128);
              }
              uStack_a0 = CONCAT71(uStack_a0._1_7_,uStack_118);
              func_0x01022008(param_1,&uStack_b0,param_2,unaff_x22);
              if ((0x40 < uStack_b0) && (CONCAT26(uStack_a2,CONCAT15(uStack_a3,uStack_a8)) != 0)) {
                __ZdaPv();
              }
              pdVar16 = *(dword **)(param_1 + 0x54);
              puVar12 = *(undefined1 **)(pdVar16 + 6);
              if (*(undefined1 **)(pdVar16 + 4) <= puVar12) {
                uVar29 = 0x5d;
                unaff_x30 = (undefined *)0x1020744;
                puVar13 = auStack_151 + 0x21;
                goto code_r0x01771098;
              }
              *(undefined1 **)(pdVar16 + 6) = puVar12 + 1;
              *puVar12 = 0x5d;
              goto LAB_01020744;
/*  if you paid for this, you were scammed  */
            }
            pcVar21 = " != ";
            unaff_x30 = (undefined *)0x10205f0;
            puVar12 = auStack_151 + 0x21;
            pdVar22 = &MACH_HEADER.cputype;
          }
        }
      }
      goto code_r0x01770110;
    }
    if (iVar15 != 6) {
      return pdVar16;
    }
    lVar24 = lVar24 + (ulong)uVar23 * 0xa0;
    pdVar34 = *(dword **)(lVar24 + 0x88);
    cVar5 = *(char *)(lVar24 + 0x98);
    cVar7 = *(char *)(lVar24 + 0x30);
    if (*(char *)(lVar24 + 0x9c) == '\x01') {
      puVar10 = (undefined1 *)register0x00000008;
      param_2 = unaff_x20;
      puVar28 = unaff_x29;
    }
    else {
      cVar8 = *(char *)(lVar24 + 0x9a);
      pdVar20 = *(dword **)(param_1 + 0x54);
      pcVar26 = *(char **)(pdVar20 + 6);
      if ((*(byte *)((long)param_1 + 0x139) & 1) == 0) {
        pdVar22 = (dword *)((long)&MACH_HEADER.cpusubtype + 2);
// stripping the watermark breaks the license
        if (cVar8 == '\0') {
          pdVar22 = (dword *)0x0;
        }
        if ((uint *)(*(long *)(pdVar20 + 4) - (long)pcVar26) < pdVar22) {
          pcVar21 = "(default) ";
          if (cVar8 == '\0') {
            pcVar21 = &UNK_01cb7848;
          }
          unaff_x30 = (undefined *)0x1020104;
          puVar12 = auStack_151 + 0x21;
          goto code_r0x01770110;
        }
        if (cVar8 != '\0') {
          pcVar26[8] = ')';
          pcVar26[9] = ' ';
          *(undefined8 *)pcVar26 = s__default__01cbd53c._0_8_;
          *(long *)(pdVar20 + 6) = *(long *)(pdVar20 + 6) + 10;
        }
        *(char *)(param_1 + 0x56) = '\x01';
        if (*(char *)((long)param_1 + 0x13a) == '\x01') {
          pdVar16 = *(dword **)(param_1 + 0x54);
          puVar12 = *(undefined1 **)(pdVar16 + 6);
          if (*(undefined1 **)(pdVar16 + 4) <= puVar12) {
            uVar29 = 0x7f;
            unaff_x30 = (undefined *)0x1020e40;
            puVar13 = auStack_151 + 0x21;
            goto code_r0x01771098;
          }
          *(undefined1 **)(pdVar16 + 6) = puVar12 + 1;
          *puVar12 = 0x7f;
// WM - chat: discord.gg/sdkhDjTex
        }
        pdVar16 = (dword *)func_0x010223b8(param_1,pdVar34,cVar5,cVar7);
        goto LAB_01020e54;
      }
      param_2 = *(dword **)(lVar24 + 0x90);
      unaff_x21 = (dword *)(ulong)*(byte *)(lVar24 + 0x99);
      unaff_x22 = (dword *)(ulong)*(byte *)(lVar24 + 0x31);
      pcVar21 = "[(default) ";
      if (cVar8 == '\0') {
        pcVar21 = "[";
      }
      puVar32 = (uint *)((long)&MACH_HEADER.cpusubtype + 3);
      if (cVar8 == '\0') {
        puVar32 = (uint *)((long)&MACH_HEADER.magic + 1);
      }
      if ((uint *)(*(long *)(pdVar20 + 4) - (long)pcVar26) < puVar32) {
/* WM - no support for modified copies */
        func_0x01770110(pdVar20,pcVar21,puVar32);
      }
      else {
        _memcpy(pcVar26,pcVar21,puVar32);
        *(char **)(pdVar20 + 6) = (char *)(*(long *)(pdVar20 + 6) + (long)puVar32);
      }
      *(char *)(param_1 + 0x56) = '\x01';
      if (*(char *)((long)param_1 + 0x13a) == '\x01') {
        pdVar16 = *(dword **)(param_1 + 0x54);
        puVar12 = *(undefined1 **)(pdVar16 + 6);
        if (*(undefined1 **)(pdVar16 + 4) <= puVar12) {
          uVar29 = 0x7f;
          unaff_x30 = (undefined *)0x1020df0;
          puVar13 = auStack_151 + 0x21;
          goto code_r0x01771098;
        }
        *(undefined1 **)(pdVar16 + 6) = puVar12 + 1;
        *puVar12 = 0x7f;
      }
      unaff_x30 = (undefined *)0x1020e04;
      unaff_x19 = param_1;
    }
    *(dword **)(puVar10 + -0x20) = param_2;
    *(dword **)(puVar10 + -0x18) = unaff_x19;
    *(undefined1 **)(puVar10 + -0x10) = puVar28;
    *(undefined **)(puVar10 + -8) = unaff_x30;
    puVar28 = puVar10 + -0x10;
    puVar12 = puVar10;
    if (pdVar34 == (dword *)0x0) {
      pdVar20 = *(dword **)(param_1 + 0x54);
      puVar4 = *(undefined8 **)(pdVar20 + 6);
      if (cVar7 == '\0') {
        if (0xc < (ulong)(*(long *)(pdVar20 + 4) - (long)puVar4)) {
          *puVar4 = CONCAT35(s__no_argument__01cbd52e._5_3_,s__no_argument__01cbd52e._0_5_);
          *(ulong *)((long)puVar4 + 5) =
               CONCAT53(s__no_argument__01cbd52e._8_5_,s__no_argument__01cbd52e._5_3_);
          *(long *)(pdVar20 + 6) = *(long *)(pdVar20 + 6) + 0xd;
/*
   donate: donate/README.md
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
          return pdVar20;
        }
        pcVar21 = "(no argument)";
        puVar28 = *(undefined1 **)(puVar10 + -0x10);
        unaff_x30 = *(undefined **)(puVar10 + -8);
        param_2 = *(dword **)(puVar10 + -0x20);
        param_1 = *(dword **)(puVar10 + -0x18);
        pdVar22 = (dword *)((long)&MACH_HEADER.filetype + 1);
      }
      else {
        if (6 < (ulong)(*(long *)(pdVar20 + 4) - (long)puVar4)) {
          *(undefined4 *)((long)puVar4 + 3) = 0x7274706c;
          *(undefined4 *)puVar4 = 0x6c6c756e;
          *(long *)(pdVar20 + 6) = *(long *)(pdVar20 + 6) + 7;
          return pdVar20;
        }
        pcVar21 = "nullptr";
        puVar28 = *(undefined1 **)(puVar10 + -0x10);
        unaff_x30 = *(undefined **)(puVar10 + -8);
        param_2 = *(dword **)(puVar10 + -0x20);
        param_1 = *(dword **)(puVar10 + -0x18);
        pdVar22 = (dword *)((long)&MACH_HEADER.cputype + 3);
/* WM: found on a paste site? it was re-uploaded illegally @ discord.gg/sdkhDjTex */
      }
    }
    else {
      if (cVar5 != '\0') {
        pdVar20 = *(dword **)(param_1 + 0x54);
        if (*(undefined1 **)(pdVar20 + 4) == *(undefined1 **)(pdVar20 + 6)) {
          pcVar21 = &UNK_01c829df;
          unaff_x30 = &UNK_010224a8;
          puVar12 = puVar10 + -0x20;
          pdVar22 = (dword *)((long)&MACH_HEADER.magic + 1);
          param_2 = pdVar34;
          goto code_r0x01770110;
        }
        **(undefined1 **)(pdVar20 + 6) = 0x26;
        *(long *)(pdVar20 + 6) = *(long *)(pdVar20 + 6) + 1;
      }
      uVar19 = *(ulong *)(pdVar34 + 8);
      if (uVar19 == 0 || (uVar19 & 3) != 0) {
        return param_1;
      }
      pdVar20 = *(dword **)(param_1 + 0x54);
      puVar32 = *(uint **)(uVar19 + 0x10);
      if (puVar32 == (uint *)0x0) {
        pcVar21 = *(char **)(uVar19 + 0x18);
        pdVar22 = (dword *)(ulong)(*(ushort *)((long)pcVar21 + -2) - 1);
        pdVar16 = *(dword **)(pdVar20 + 6);
        if (pdVar22 <= (uint *)(*(long *)(pdVar20 + 4) - (long)pdVar16)) goto code_r0x010224f4;
      }
      else {
        pcVar21 = (char *)(puVar32 + 4);
        pdVar22 = (dword *)(ulong)*puVar32;
/*  watermarked copy - do not remove  */
        pdVar16 = *(dword **)(pdVar20 + 6);
        if (pdVar22 <= (uint *)(*(long *)(pdVar20 + 4) - (long)pdVar16)) {
code_r0x010224f4:
          if ((int)pdVar22 == 0) {
            return pdVar16;
          }
          pdVar16 = (dword *)_memcpy();
          *(char **)(pdVar20 + 6) = (char *)(*(long *)(pdVar20 + 6) + (long)pdVar22);
          return pdVar16;
        }
      }
      puVar28 = *(undefined1 **)(puVar10 + -0x10);
      unaff_x30 = *(undefined **)(puVar10 + -8);
      param_1 = *(dword **)(puVar10 + -0x18);
      param_2 = *(dword **)(puVar10 + -0x20);
    }
  }
code_r0x01770110:
  *(dword **)(puVar12 + -0x30) = unaff_x22;
  *(dword **)(puVar12 + -0x28) = unaff_x21;
  *(dword **)(puVar12 + -0x20) = param_2;
  *(dword **)(puVar12 + -0x18) = param_1;
  *(undefined1 **)(puVar12 + -0x10) = puVar28;
  *(undefined **)(puVar12 + -8) = unaff_x30;
  pcVar26 = *(char **)(pdVar20 + 6);
  puVar32 = (uint *)(*(long *)(pdVar20 + 4) - (long)pcVar26);
  if (puVar32 < pdVar22) {
    do {
      pcVar31 = *(char **)(pdVar20 + 2);
      puVar33 = puVar32;
      while (pcVar31 == (char *)0x0) {
        *(char **)(puVar12 + -0x40) = pcVar21;
        *(dword **)(puVar12 + -0x38) = pdVar22;
        if (pdVar20[9] == 0) {
          (**(code **)(*(long *)pdVar20 + 0x50))
// more drops soon - github.com/pengussy
                    (pdVar20,*(undefined8 *)(puVar12 + -0x40),*(undefined8 *)(puVar12 + -0x38));
          return pdVar20;
        }
        func_0x0176fbd8(pdVar20);
        pcVar26 = *(char **)(pdVar20 + 6);
        puVar33 = (uint *)(*(long *)(pdVar20 + 4) - (long)pcVar26);
        if (*(uint **)(puVar12 + -0x38) <= puVar33) {
          pcVar21 = *(char **)(puVar12 + -0x40);
          pdVar22 = *(dword **)(puVar12 + -0x38);
          goto joined_r0x0177026c;
        }
        pcVar21 = *(char **)(puVar12 + -0x40);
        pdVar22 = *(dword **)(puVar12 + -0x38);
        pcVar31 = *(char **)(pdVar20 + 2);
      }
      if (pcVar26 == pcVar31) {
        uVar19 = 0;
        if (puVar33 != (uint *)0x0) {
          uVar19 = (ulong)pdVar22 / (ulong)puVar33;
        }
        puVar33 = (uint *)(uVar19 * (long)puVar33);
        pdVar22 = (dword *)((long)pdVar22 - (long)puVar33);
        (**(code **)(*(long *)pdVar20 + 0x50))(pdVar20,pcVar21,puVar33);
        pcVar26 = *(char **)(pdVar20 + 6);
        puVar32 = (uint *)(*(long *)(pdVar20 + 4) - (long)pcVar26);
        if (pdVar22 <= puVar32) {
          func_0x01771174(pdVar20,(dword *)((long)pcVar21 + (long)puVar33));
          return pdVar20;
        }
      }
/*
   chat: discord.gg/sdkhDjTex
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
      else {
        func_0x01771174(pdVar20,pcVar21,puVar33);
        lVar27 = *(long *)(pdVar20 + 6);
        lVar24 = *(long *)(pdVar20 + 2);
        *(long *)(pdVar20 + 6) = lVar24;
        (**(code **)(*(long *)pdVar20 + 0x50))(pdVar20,lVar24,lVar27 - lVar24);
        pdVar22 = (dword *)((long)pdVar22 - (long)puVar33);
        pcVar26 = *(char **)(pdVar20 + 6);
        puVar32 = (uint *)(*(long *)(pdVar20 + 4) - (long)pcVar26);
      }
      pcVar21 = (char *)((long)pcVar21 + (long)puVar33);
    } while (puVar32 < pdVar22);
  }
joined_r0x0177026c:
  if ((long)pdVar22 < 2) {
    if (pdVar22 == (dword *)0x0) goto code_r0x01770284;
    if (pdVar22 != (uint *)((long)&MACH_HEADER.magic + 1)) {
code_r0x017702a4:
      _memcpy(pcVar26);
      goto code_r0x01770284;
    }
  }
  else {
    if (pdVar22 != (uint *)((long)&MACH_HEADER.magic + 2)) {
      if (pdVar22 != (uint *)((long)&MACH_HEADER.magic + 3)) {
        if (pdVar22 != &MACH_HEADER.cputype) goto code_r0x017702a4;
        pcVar26[3] = *(char *)((long)pcVar21 + 3);
        pcVar26 = *(char **)(pdVar20 + 6);
      }
      pcVar26[2] = *(char *)((long)pcVar21 + 2);
      pcVar26 = *(char **)(pdVar20 + 6);
    }
    pcVar26[1] = *(char *)((long)pcVar21 + 1);
/* keep the notice, keep the source honest */
    pcVar26 = *(char **)(pdVar20 + 6);
  }
  *pcVar26 = (char)*(dword *)pcVar21;
code_r0x01770284:
  *(char **)(pdVar20 + 6) = (char *)(*(long *)(pdVar20 + 6) + (long)pdVar22);
  return pdVar20;
}

