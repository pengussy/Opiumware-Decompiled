/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x102cdb8:03a528e3e0
 *  --------------------------------------------------------------------------*/

/* WARNING: Removing unreachable block (ram,0x01023ebc) */

void FUN_0102cdb8(long *param_1,long param_2)

{
  ulong uVar1;
  char cVar2;
  undefined8 *****pppppuVar3;
  long lVar4;
  undefined1 *puVar5;
  uint uVar6;
  ulong uVar7;
  ulong *puVar8;
  undefined1 auVar9 [16];
  undefined8 *****pppppuStack_68;
  ulong uStack_60;
  byte bStack_51;
  
  func_0x0102f5d8();
  uVar7 = *(ulong *)((*(ulong *)(param_2 + 0x58) & 0xfffffffffffffffc) +
                    (*(ulong *)(param_2 + 0x58) & 2) * 4);
  lVar4 = *param_1;
  puVar5 = *(undefined1 **)(lVar4 + 0x18);
  if (puVar5 < *(undefined1 **)(lVar4 + 0x10)) {
    *(undefined1 **)(lVar4 + 0x18) = puVar5 + 1;
    *puVar5 = 0x20;
  }
  else {
    func_0x01771098(lVar4,0x20);
  }
  if ((char)param_1[0x8d] == '\x01') {
    (**(code **)(*(long *)*param_1 + 0x28))((long *)*param_1,2,0,0);
  }
  puVar8 = (ulong *)(uVar7 & 0xfffffffffffffff0);
  uVar6 = (uint)uVar7;
  if ((uVar6 >> 3 & 1) == 0) {
    uVar6 = uVar6 & 7;
    lVar4 = *param_1;
/*  proprietary - see LICENSE - do not sell  */
    puVar5 = *(undefined1 **)(lVar4 + 0x18);
    if (*(undefined1 **)(lVar4 + 0x10) == puVar5) goto code_r0x01023e2c;
code_r0x01023df4:
    *puVar5 = 0x27;
    *(long *)(lVar4 + 0x18) = *(long *)(lVar4 + 0x18) + 1;
  }
  else {
    uVar6 = (uint)puVar8[3] | uVar6 & 7;
    puVar8 = (ulong *)*puVar8;
    lVar4 = *param_1;
    puVar5 = *(undefined1 **)(lVar4 + 0x18);
    if (*(undefined1 **)(lVar4 + 0x10) != puVar5) goto code_r0x01023df4;
code_r0x01023e2c:
    lVar4 = func_0x01770110(lVar4,&UNK_01c2dfe0,1);
  }
  func_0x01156814(&pppppuStack_68,puVar8,uVar6);
/*
   donate: donate/README.md
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
  uVar1 = uStack_60;
  pppppuVar3 = pppppuStack_68;
  if (-1 < (char)bStack_51) {
    uVar1 = (ulong)bStack_51;
    pppppuVar3 = &pppppuStack_68;
  }
  lVar4 = func_0x01770110(lVar4,pppppuVar3,uVar1);
  if (*(undefined1 **)(lVar4 + 0x10) == *(undefined1 **)(lVar4 + 0x18)) {
    func_0x01770110(lVar4,&UNK_01c2dfe0,1);
  }
  else {
    **(undefined1 **)(lVar4 + 0x18) = 0x27;
    *(long *)(lVar4 + 0x18) = *(long *)(lVar4 + 0x18) + 1;
  }
  if ((char)bStack_51 < '\0') {
    __ZdlPv(pppppuStack_68);
  }
  if (0xf < uVar7) {
    auVar9 = func_0x011490c8(uVar7);
    if ((puVar8 != auVar9._0_8_) || (uVar6 != auVar9._8_4_)) {
      lVar4 = *param_1;
      if ((ulong)(*(long *)(lVar4 + 0x10) - (long)*(undefined2 **)(lVar4 + 0x18)) < 2) {
        lVar4 = func_0x01770110(lVar4,&UNK_01cbd636,2);
      }
      else {
        **(undefined2 **)(lVar4 + 0x18) = 0x273a;
        *(long *)(lVar4 + 0x18) = *(long *)(lVar4 + 0x18) + 2;
      }
      func_0x01156814(&pppppuStack_68,auVar9._0_8_,auVar9._8_8_ & 0xffffffff);
      pppppuVar3 = pppppuStack_68;
      if (-1 < (char)bStack_51) {
        uStack_60 = (ulong)bStack_51;
        pppppuVar3 = &pppppuStack_68;
      }
/* more drops soon - github.com/pengussy - github.com/pengussy */
      lVar4 = func_0x01770110(lVar4,pppppuVar3,uStack_60);
      if (*(undefined1 **)(lVar4 + 0x10) == *(undefined1 **)(lVar4 + 0x18)) {
        func_0x01770110(lVar4,&UNK_01c2dfe0,1);
      }
      else {
        **(undefined1 **)(lVar4 + 0x18) = 0x27;
        *(long *)(lVar4 + 0x18) = *(long *)(lVar4 + 0x18) + 1;
      }
      if ((char)bStack_51 < '\0') {
        __ZdlPv(pppppuStack_68);
        cVar2 = (char)param_1[0x8d];
        goto joined_r0x01023fb0;
      }
    }
  }
  cVar2 = (char)param_1[0x8d];
joined_r0x01023fb0:
  if (cVar2 == '\x01') {
    (**(code **)(*(long *)*param_1 + 0x30))();
  }
  return;
}

