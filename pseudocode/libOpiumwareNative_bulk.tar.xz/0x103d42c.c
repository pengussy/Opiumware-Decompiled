/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x103d42c:5e92825945
 */

void FUN_0103d42c(undefined4 *param_1,long param_2)

{
  uint uVar1;
  undefined8 *puVar2;
  
  puVar2 = (undefined8 *)func_0x009d11e8(param_2 + 0x790,0xc,8);
  uVar1 = param_1[2];
/* +- WM -------------------------------------------------------------+
   |  if you paid for this, you were scammed
   +--------------------------------------------------------------------*/
  *puVar2 = CONCAT44(*param_1,*param_1);
  *(uint *)(puVar2 + 1) = uVar1 & 0x7f0000 | 0xd | *(uint *)(puVar2 + 1) & 0xfe000000;
  return;
}

