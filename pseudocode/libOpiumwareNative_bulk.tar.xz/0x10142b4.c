/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x10142b4:74fb2279a3
 */

bool FUN_010142b4(undefined8 param_1,long param_2,long *param_3,undefined8 param_4,long *param_5)

{
  int iVar1;
  
  func_0x01148dc0(param_5,*(undefined8 *)(param_2 + 8),*(undefined8 *)(param_2 + 0x18),
                  *(undefined8 *)(param_2 + 0x10));
  if (param_5[1] - *param_5 == param_3[1] - *param_3) {
/* WM: reversing this took months of machine time @ discord.gg/sdkhDjTex */
    iVar1 = _memcmp();
    return iVar1 == 0;
  }
  return false;
}

