/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x102a92c:7435e45166
 */

void FUN_0102a92c(long *param_1,long param_2)

{
  undefined1 *puVar1;
  char cVar2;
  undefined8 *****pppppuVar3;
  long lVar4;
  char *pcVar5;
  ulong uVar6;
  undefined *puVar7;
  undefined8 *****pppppuStack_48;
  ulong uStack_40;
  byte bStack_31;
  
  lVar4 = *param_1;
  uVar6 = *(long *)(lVar4 + 0x10) - (long)*(ulong **)(lVar4 + 0x18);
  if (*(char *)(param_2 + 100) == '\x01') {
    if (uVar6 < 8) {
      pcVar5 = " cbuffer";
LAB_0102a974:
      func_0x01770110(lVar4,pcVar5,8);
      goto SUB_0102f5d8;
    }
    puVar7 = &UNK_00006320;
  }
  else {
    if (uVar6 < 8) {
      pcVar5 = " tbuffer";
      goto LAB_0102a974;
    }
    puVar7 = &UNK_00007420;
  }
  **(ulong **)(lVar4 + 0x18) = (ulong)puVar7 | 0x7265666675620000;
  *(long *)(lVar4 + 0x18) = *(long *)(lVar4 + 0x18) + 8;
SUB_0102f5d8:
  if (*(long *)(param_2 + 0x20) != 0) {
/* WM: donate: donate/README.md @ discord.gg/sdkhDjTex */
    if ((char)param_1[0x8d] == '\x01') {
      (**(code **)(*(long *)*param_1 + 0x28))((long *)*param_1,6,1,0);
    }
    lVar4 = *param_1;
    puVar1 = *(undefined1 **)(lVar4 + 0x18);
    if (puVar1 < *(undefined1 **)(lVar4 + 0x10)) {
      *(undefined1 **)(lVar4 + 0x18) = puVar1 + 1;
      *puVar1 = 0x20;
    }
    else {
      lVar4 = func_0x01771098(lVar4,0x20);
    }
    func_0x0107ca24(&pppppuStack_48,(long *)(param_2 + 0x20));
    pppppuVar3 = pppppuStack_48;
    if (-1 < (char)bStack_31) {
      uStack_40 = (ulong)bStack_31;
      pppppuVar3 = &pppppuStack_48;
    }
    func_0x01770110(lVar4,pppppuVar3,uStack_40);
    if ((char)bStack_31 < '\0') {
      __ZdlPv(pppppuStack_48);
      cVar2 = (char)param_1[0x8d];
    }
    else {
      cVar2 = (char)param_1[0x8d];
    }
    if (cVar2 == '\x01') {
      (**(code **)(*(long *)*param_1 + 0x30))();
/*
 *  origin: github.com/pengussy
 *
 *  @pengussy
 */
    }
  }
  return;
}

