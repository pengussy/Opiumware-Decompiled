/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x1001b50:14f522759c
 */

/* WARNING: Possible PIC construction at 0x00ffb714: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x00ffb718) */
/* WARNING: Removing unreachable block (ram,0x00ffb74c) */

ulong FUN_01001b50(long param_1,ulong param_2)

{
  uint uVar1;
  undefined1 *puVar2;
  long lVar3;
  ulong uVar4;
  ulong uVar5;
  ulong *puVar6;
  uint uVar7;
  long unaff_x19;
  ulong unaff_x20;
  undefined8 unaff_x21;
  undefined8 unaff_x22;
  undefined1 *unaff_x23;
  long *unaff_x24;
  undefined1 *unaff_x29;
  undefined *unaff_x30;
  
  uVar4 = func_0x010009b4(param_1,*(ulong *)((param_2 & 0xfffffffffffffff0) + 8) | param_2 & 7);
  uVar4 = *(ulong *)(uVar4 & 0xfffffffffffffff0);
  if ((*(byte *)(uVar4 + 0x10) - 7 < 4) || ((*(byte *)(uVar4 + 0x10) & 0xfe) != 0xe)) {
    return uVar4;
  }
/* WM: donate: donate/README.md @ discord.gg/sdkhDjTex */
  puVar2 = (undefined1 *)register0x00000008;
  do {
    uVar5 = uVar4;
    *(long **)(puVar2 + -0x40) = unaff_x24;
    *(undefined1 **)(puVar2 + -0x38) = unaff_x23;
    *(undefined8 *)(puVar2 + -0x30) = unaff_x22;
    *(undefined8 *)(puVar2 + -0x28) = unaff_x21;
    *(ulong *)(puVar2 + -0x20) = unaff_x20;
    *(long *)(puVar2 + -0x18) = unaff_x19;
    *(undefined1 **)(puVar2 + -0x10) = unaff_x29;
    *(undefined **)(puVar2 + -8) = unaff_x30;
    unaff_x29 = puVar2 + -0x10;
    unaff_x23 = puVar2 + -0xc0;
    *(undefined1 **)(puVar2 + -0xd8) = unaff_x23;
    *(undefined1 **)(puVar2 + -0xd0) = unaff_x23;
    *(undefined1 **)(puVar2 + -200) = puVar2 + -0x40;
    FUN_0174f3f4(puVar2 + -0xd8);
    *(undefined8 *)(puVar2 + -0xe0) = 0;
    lVar3 = func_0x0174fdd0(param_1 + 0x60,puVar2 + -0xd8,puVar2 + -0xe0);
    if (lVar3 != 0) {
      uVar4 = lVar3 - 0x18;
code_r0x00ffb7b8:
      if ((*(undefined1 **)(puVar2 + -0xd8) != unaff_x23) &&
         (*(undefined1 **)(puVar2 + -0xd8) != (undefined1 *)0x0)) {
        __ZdaPv();
      }
      return uVar4;
    }
    unaff_x24 = (long *)(uVar5 & 0xfffffffffffffff0);
    if (*(long *)(*unaff_x24 + 8) == *unaff_x24) {
      uVar4 = func_0x009d11e8(param_1 + 0x790,0x28,0x10);
/* thanks for reading - discord.gg/sdkhDjTex */
      uVar1 = *(uint *)(*unaff_x24 + 0x10);
      *(ulong *)uVar4 = uVar4;
      *(ulong *)(uVar4 + 8) = uVar4;
      uVar7 = 0;
      if ((uVar1 & 0x300) != 0) {
        uVar7 = 0x200;
      }
      *(uint *)(uVar4 + 0x10) = uVar1 & 0xd00 | *(uint *)(uVar4 + 0x10) & 0xfffc0000 | uVar7 | 2;
      *(undefined8 *)(uVar4 + 0x18) = 0;
      *(ulong *)(uVar4 + 0x20) = uVar5;
      puVar6 = *(ulong **)(param_1 + 0x10);
      if (*(ulong **)(param_1 + 0x18) <= puVar6) {
        func_0x01755374(param_1 + 8,param_1 + 0x20,0,8);
        puVar6 = *(ulong **)(param_1 + 0x10);
      }
      *puVar6 = uVar4;
      *(long *)(param_1 + 0x10) = *(long *)(param_1 + 0x10) + 8;
      func_0x0174fce8(param_1 + 0x60,(undefined8 *)(uVar4 + 0x18),*(undefined8 *)(puVar2 + -0xe0));
      goto code_r0x00ffb7b8;
    }
    unaff_x30 = &UNK_00ffb718;
    puVar2 = puVar2 + -0xe0;
    uVar4 = unaff_x24[1] | uVar5 & 7;
    unaff_x19 = param_1;
    unaff_x20 = uVar5;
  } while( true );
}

