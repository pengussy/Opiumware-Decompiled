/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1030a74:810d412ad0
   =========================================================================== */

undefined * FUN_01030a74(void)

{
  return &UNK_01e5dd60;
// WM - no support for modified copies
}

