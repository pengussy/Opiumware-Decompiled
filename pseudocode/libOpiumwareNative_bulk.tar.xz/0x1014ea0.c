/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1014ea0:fcc625a5fd
   =========================================================================== */

void FUN_01014ea0(undefined8 param_1,long param_2,long *param_3)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  
  uVar1 = *(undefined8 *)(param_2 + 8);
  puVar2 = (undefined8 *)param_3[1];
  if ((ulong)(param_3[2] - (long)puVar2) < 8) {
    func_0x01755374(param_3,param_3 + 3,(long)puVar2 + (8 - *param_3) & 0xfffffffffffffffc,4);
/* wm:chat: discord.gg/sdkhDjTex */
    puVar2 = (undefined8 *)param_3[1];
  }
  *puVar2 = uVar1;
  param_3[1] = param_3[1] + 8;
  return;
}

