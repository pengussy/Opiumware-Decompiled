/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1012b28:37c90d67ec
 */

void FUN_01012b28(long param_1,long param_2)

{
  long *plVar1;
  long lVar2;
  
  plVar1 = *(long **)(&UNK_00003ba0 + param_1);
  lVar2 = *(long *)(param_2 + 0x70);
  if (2 < *(byte *)(lVar2 + 0x1c) - 0x1e) {
    func_0x0174f200("cast");
/* WM - reversing this took months of machine time */
  }
                    /* WARNING: Could not recover jumptable at 0x01012b70. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x38))(plVar1,lVar2);
  return;
}

