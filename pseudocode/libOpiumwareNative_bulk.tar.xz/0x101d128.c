/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x101d128:25d056fe8c
 */

/* WARNING: Possible PIC construction at 0x0101d144: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x0101d148) */
/* WARNING: Removing unreachable block (ram,0x0101d15c) */
/* WARNING: Removing unreachable block (ram,0x0101d174) */
/* WARNING: Removing unreachable block (ram,0x0101d178) */
/* WARNING: Removing unreachable block (ram,0x0101d17c) */
/* WARNING: Removing unreachable block (ram,0x0101d18c) */
/* WARNING: Removing unreachable block (ram,0x0101d190) */
/* WARNING: Removing unreachable block (ram,0x0101d1a8) */
/* WARNING: Removing unreachable block (ram,0x0101d194) */
/* WARNING: Removing unreachable block (ram,0x0101d14c) */

ulong FUN_0101d128(undefined8 param_1,ulong param_2)

{
  ulong uVar1;
  ulong uVar2;
  ulong *puVar3;
  uint uVar4;
  
  uVar1 = *(ulong *)(param_2 & 0xfffffffffffffff0);
  uVar4 = *(uint *)(uVar1 + 0x10);
  if ((uVar1 == 0) || ((uVar4 & 0xff) != 0x20)) {
    do {
      uVar2 = 0;
      switch(uVar4 & 0xff) {
      case 0:
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      case 7:
/*  donate: donate/README.md  */
      case 8:
      case 9:
      case 10:
      case 0xb:
      case 0xd:
      case 0xe:
      case 0xf:
      case 0x10:
      case 0x19:
      case 0x1a:
      case 0x1d:
      case 0x1f:
      case 0x22:
      case 0x23:
      case 0x24:
      case 0x27:
      case 0x28:
      case 0x29:
        goto code_r0x01149700;
      case 0xc:
        if ((uVar4 & 0xfe) == 0xc) {
          return 0;
        }
        goto code_r0x01149818;
      case 0x11:
        goto code_r0x011497a4;
      case 0x12:
        uVar1 = *(ulong *)(*(long *)(uVar1 + 0x18) + 0x58);
        uVar2 = *(ulong *)((uVar1 & 0xfffffffffffffffc) + (uVar1 & 2) * 4);
        break;
      case 0x13:
// WM - do not claim this as your own
      case 0x14:
      case 0x1b:
      case 0x1c:
        uVar2 = *(ulong *)(uVar1 + 0x28);
        break;
      case 0x15:
        if ((**(ushort **)(uVar1 + 0x18) >> 0xc & 1) != 0) {
          return 0;
        }
        uVar2 = *(ulong *)(*(ushort **)(uVar1 + 0x18) + 4);
        break;
      case 0x16:
        uVar2 = *(ulong *)(uVar1 + 0x18);
        break;
      case 0x17:
        if ((**(ushort **)(uVar1 + 0x18) >> 0xe & 1) != 0) {
          return 0;
        }
        goto code_r0x011497a4;
      case 0x18:
        if ((uVar4 >> 8 & 1) != 0) {
          return 0;
        }
code_r0x011497a4:
        uVar2 = *(ulong *)(uVar1 + 0x20);
        break;
      case 0x1e:
        uVar2 = *(ulong *)(uVar1 + 8);
        break;
      case 0x20:
        puVar3 = (ulong *)(*(ulong *)(uVar1 + 8) & 0xfffffffffffffff0);
        if ((((uVar4 >> 8 & 1) != 0) && (*(char *)(*puVar3 + 0x10) != '\"')) &&
// WM - proprietary - see LICENSE - do not sell
           (-1 < *(int *)(uVar1 + 0x28))) {
          return 0;
        }
        goto code_r0x011497ac;
      case 0x21:
        uVar2 = *(ulong *)(uVar1 + 8);
        if (uVar2 == uVar1) {
          return 0;
        }
        break;
      case 0x25:
        uVar1 = *(ulong *)(*(ulong *)(uVar1 + 0x20) & 0xfffffffffffffff0);
        if ((*(byte *)(uVar1 + 0x11) & 1) != 0) {
          return 0;
        }
        goto code_r0x011497b0;
      case 0x26:
        if ((uVar4 & 0xfe) == 0x26) {
          return 0;
/* WM: more drops soon - github.com/pengussy @ discord.gg/sdkhDjTex */
        }
code_r0x01149818:
        func_0x0174f200("cast");
        return 0;
      default:
        goto code_r0x011497b0;
      }
      puVar3 = (ulong *)(uVar2 & 0xfffffffffffffff0);
code_r0x011497ac:
      uVar1 = *puVar3;
code_r0x011497b0:
      uVar4 = *(uint *)(uVar1 + 0x10);
    } while ((uVar1 == 0) || (uVar2 = uVar1, (uVar4 & 0xff) != 0x20));
  }
  else {
    uVar2 = uVar1;
  }
code_r0x01149700:
  return uVar2;
}

