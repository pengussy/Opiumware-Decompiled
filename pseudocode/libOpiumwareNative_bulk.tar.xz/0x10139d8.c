/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x10139d8:af8bb52be7
 */

void FUN_010139d8(long param_1,long param_2,undefined8 param_3)

{
  undefined8 uVar1;
  undefined4 uStack_38;
  uint uStack_34;
  undefined8 uStack_30;
  
  uVar1 = *(undefined8 *)(param_1 + 0x18);
  uStack_30 = *(undefined8 *)(param_2 + 0x10);
// WM - no support for modified copies
  uStack_34 = *(uint *)(param_2 + -8) >> 2;
  uStack_38 = 8;
  func_0x0174f3f4(param_3,*(undefined8 *)(param_2 + 8));
  func_0x011460a4(&uStack_38,param_3,uVar1);
  return;
}

