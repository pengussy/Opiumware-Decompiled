/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x100553c:a115c01c06
 */

/* WARNING: Possible PIC construction at 0x010056e8: Changing call to branch */
/* WARNING: Possible PIC construction at 0x010016ac: Changing call to branch */
/* WARNING: Possible PIC construction at 0x010058f8: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01001474: Changing call to branch */
/* WARNING: Possible PIC construction at 0x010007dc: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01001210: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x010007e0) */
/* WARNING: Removing unreachable block (ram,0x0100081c) */
/* WARNING: Removing unreachable block (ram,0x010007ec) */
/* WARNING: Removing unreachable block (ram,0x010007fc) */
/* WARNING: Removing unreachable block (ram,0x01000808) */
/* WARNING: Removing unreachable block (ram,0x01000820) */
/* WARNING: Removing unreachable block (ram,0x01001478) */
/* WARNING: Removing unreachable block (ram,0x010014b4) */
/* WARNING: Removing unreachable block (ram,0x01001484) */
/* WARNING: Removing unreachable block (ram,0x01001494) */
/* WARNING: Removing unreachable block (ram,0x010014a0) */
/* WARNING: Removing unreachable block (ram,0x010014b8) */
/* WARNING: Removing unreachable block (ram,0x010058fc) */
/* WARNING: Removing unreachable block (ram,0x01005924) */
/* WARNING: Removing unreachable block (ram,0x0100597c) */
/* WARNING: Removing unreachable block (ram,0x010059f8) */
/* WARNING: Removing unreachable block (ram,0x0100118c) */
/* WARNING: Removing unreachable block (ram,0x010011d0) */
/* WARNING: Removing unreachable block (ram,0x010011e8) */
/* WARNING: Removing unreachable block (ram,0x01001218) */
/* WARNING: Removing unreachable block (ram,0x01001248) */
/* WARNING: Removing unreachable block (ram,0x01001258) */
/* WARNING: Removing unreachable block (ram,0x01001264) */
/* WM - chat: discord.gg/sdkhDjTex */
/* WARNING: Removing unreachable block (ram,0x010011f8) */
/* WARNING: Removing unreachable block (ram,0x010011e0) */
/* WARNING: Removing unreachable block (ram,0x01005984) */
/* WARNING: Removing unreachable block (ram,0x01005944) */
/* WARNING: Removing unreachable block (ram,0x010059cc) */
/* WARNING: Removing unreachable block (ram,0x01000600) */
/* WARNING: Removing unreachable block (ram,0x01000660) */
/* WARNING: Removing unreachable block (ram,0x01000644) */
/* WARNING: Removing unreachable block (ram,0x0100067c) */
/* WARNING: Removing unreachable block (ram,0x0100069c) */
/* WARNING: Removing unreachable block (ram,0x010006ac) */
/* WARNING: Removing unreachable block (ram,0x010006b0) */
/* WARNING: Removing unreachable block (ram,0x0100065c) */
/* WARNING: Removing unreachable block (ram,0x010006c4) */
/* WARNING: Removing unreachable block (ram,0x010006c8) */
/* WARNING: Removing unreachable block (ram,0x010006e0) */
/* WARNING: Removing unreachable block (ram,0x010006e8) */
/* WARNING: Removing unreachable block (ram,0x010006ec) */
/* WARNING: Removing unreachable block (ram,0x01000730) */
/* WARNING: Removing unreachable block (ram,0x01000784) */
/* WARNING: Removing unreachable block (ram,0x01000794) */
/* WARNING: Removing unreachable block (ram,0x010007a4) */
/* WARNING: Removing unreachable block (ram,0x010007bc) */
/* WARNING: Removing unreachable block (ram,0x010007b4) */
/* WARNING: Removing unreachable block (ram,0x010007cc) */
/* unlicensed copy if this notice is missing */
/* WARNING: Removing unreachable block (ram,0x0100079c) */
/* WARNING: Removing unreachable block (ram,0x01000830) */
/* WARNING: Removing unreachable block (ram,0x01000850) */
/* WARNING: Removing unreachable block (ram,0x01000864) */
/* WARNING: Removing unreachable block (ram,0x010008b8) */
/* WARNING: Removing unreachable block (ram,0x010008ac) */
/* WARNING: Removing unreachable block (ram,0x010008c0) */
/* WARNING: Removing unreachable block (ram,0x0100093c) */
/* WARNING: Removing unreachable block (ram,0x010008dc) */
/* WARNING: Removing unreachable block (ram,0x01000770) */
/* WARNING: Removing unreachable block (ram,0x010008f8) */
/* WARNING: Removing unreachable block (ram,0x010008fc) */
/* WARNING: Removing unreachable block (ram,0x01000780) */
/* WARNING: Removing unreachable block (ram,0x01000900) */
/* WARNING: Removing unreachable block (ram,0x0100090c) */
/* WARNING: Removing unreachable block (ram,0x01000914) */
/* WARNING: Removing unreachable block (ram,0x01000918) */
/* WARNING: Removing unreachable block (ram,0x0100594c) */
/* WARNING: Removing unreachable block (ram,0x0100598c) */
/* WARNING: Removing unreachable block (ram,0x0100599c) */
/* WARNING: Removing unreachable block (ram,0x01000eac) */
/* WARNING: Removing unreachable block (ram,0x01000f04) */
/* WARNING: Removing unreachable block (ram,0x010010fc) */
/* WARNING: Removing unreachable block (ram,0x01000f44) */
/* WARNING: Removing unreachable block (ram,0x01000ee4) */
/* WARNING: Removing unreachable block (ram,0x01000f58) */
/* WARNING: Removing unreachable block (ram,0x01000efc) */
/* WARNING: Removing unreachable block (ram,0x01000f68) */
/* WARNING: Removing unreachable block (ram,0x01000ff8) */
/* WARNING: Removing unreachable block (ram,0x01001134) */
/* WARNING: Removing unreachable block (ram,0x01001048) */
/* WARNING: Removing unreachable block (ram,0x01000fb0) */
/* WARNING: Removing unreachable block (ram,0x01001064) */
/* WARNING: Removing unreachable block (ram,0x01000fc0) */
/* WARNING: Removing unreachable block (ram,0x01000fd0) */
/* WARNING: Removing unreachable block (ram,0x01000fdc) */
/* WARNING: Removing unreachable block (ram,0x01001070) */
/* WARNING: Removing unreachable block (ram,0x01001118) */
/*
   watermarked copy - do not remove
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
/* WARNING: Removing unreachable block (ram,0x010010b0) */
/* WARNING: Removing unreachable block (ram,0x01000ff4) */
/* WARNING: Removing unreachable block (ram,0x010010c4) */
/* WARNING: Removing unreachable block (ram,0x010010d0) */
/* WARNING: Removing unreachable block (ram,0x010010d4) */
/* WARNING: Removing unreachable block (ram,0x010010d8) */
/* WARNING: Removing unreachable block (ram,0x01005954) */
/* WARNING: Removing unreachable block (ram,0x01001390) */
/* WARNING: Removing unreachable block (ram,0x0100141c) */
/* WARNING: Removing unreachable block (ram,0x01001428) */
/* WARNING: Removing unreachable block (ram,0x01001440) */
/* WARNING: Removing unreachable block (ram,0x01001458) */
/* WARNING: Removing unreachable block (ram,0x01001450) */
/* WARNING: Removing unreachable block (ram,0x01001468) */
/* WARNING: Removing unreachable block (ram,0x01001438) */
/* WARNING: Removing unreachable block (ram,0x010014c8) */
/* WARNING: Removing unreachable block (ram,0x010014e8) */
/* WARNING: Removing unreachable block (ram,0x010014fc) */
/* WARNING: Removing unreachable block (ram,0x0100158c) */
/* WARNING: Removing unreachable block (ram,0x01001548) */
/* WARNING: Removing unreachable block (ram,0x01001408) */
// WM - chat: discord.gg/sdkhDjTex
/* WARNING: Removing unreachable block (ram,0x01001564) */
/* WARNING: Removing unreachable block (ram,0x01001568) */
/* WARNING: Removing unreachable block (ram,0x01001418) */
/* WARNING: Removing unreachable block (ram,0x0100156c) */
/* WARNING: Removing unreachable block (ram,0x010016b0) */
/* WARNING: Removing unreachable block (ram,0x010056ec) */
/* WARNING: Removing unreachable block (ram,0x010015e0) */
/* WARNING: Removing unreachable block (ram,0x01001678) */
/* WARNING: Removing unreachable block (ram,0x01001694) */
/* WARNING: Removing unreachable block (ram,0x0100168c) */
/* WARNING: Removing unreachable block (ram,0x010016c4) */
/* WARNING: Removing unreachable block (ram,0x0100174c) */
/* WARNING: Removing unreachable block (ram,0x01001708) */
/* WARNING: Removing unreachable block (ram,0x01001664) */
/* WARNING: Removing unreachable block (ram,0x01001724) */
/* WARNING: Removing unreachable block (ram,0x01001728) */
/* WARNING: Removing unreachable block (ram,0x01001674) */
/* WARNING: Removing unreachable block (ram,0x0100172c) */
/* WARNING: Removing unreachable block (ram,0x01001214) */
/* WARNING: Removing unreachable block (ram,0x01001278) */
/* WARNING: Removing unreachable block (ram,0x01001280) */
/* WARNING: Removing unreachable block (ram,0x0100129c) */
/* WARNING: Removing unreachable block (ram,0x010012b0) */
/* WARNING: Removing unreachable block (ram,0x01001354) */
/* WARNING: Removing unreachable block (ram,0x01001308) */
/* WARNING: Removing unreachable block (ram,0x01001374) */
/* WARNING: Removing unreachable block (ram,0x01001320) */

ulong FUN_0100553c(long param_1)

{
  undefined1 auVar1 [12];
/* WM: donate: donate/README.md @ discord.gg/sdkhDjTex */
  undefined1 **ppuVar2;
  undefined1 *puVar3;
  long lVar4;
  long lVar5;
  uint uVar6;
  ulong *puVar7;
  undefined4 *puVar8;
  ulong uVar9;
  undefined *puVar10;
  long unaff_x19;
  undefined4 *unaff_x20;
  undefined8 unaff_x21;
  long *plVar11;
  long unaff_x22;
  undefined8 unaff_x23;
  undefined8 unaff_x24;
  ulong unaff_x25;
  undefined8 unaff_x26;
/* WM - if you paid for this, you were scammed */
  undefined1 **ppuVar12;
  code *pcVar13;
  undefined1 auVar14 [16];
  undefined1 auVar15 [16];
  undefined1 *puStack_20;
  undefined8 uStack_18;
  
  auVar15._8_8_ = unaff_x24;
  auVar15._0_8_ = unaff_x21;
  uVar9 = (ulong)*(uint *)(*(long *)(&UNK_00003bb8 + param_1) + 0xf4);
  puVar10 = &UNK_00003e28;
  switch(uVar9) {
  case 0:
    goto code_r0x010055b0;
  case 1:
    break;
  case 2:
    puVar10 = &UNK_00003e58;
    break;
  case 3:
    puVar10 = &UNK_00003e30;
    break;
  case 4:
    puVar10 = &UNK_00003e60;
    break;
  case 5:
    puVar10 = &UNK_00003e38;
    break;
  case 6:
    puVar10 = &UNK_00003e68;
    break;
  case 7:
    puVar10 = &UNK_00003e40;
    break;
  case 8:
// WM - keep the notice, keep the source honest
    puVar10 = &UNK_00003e70;
    break;
  case 9:
    puVar10 = &UNK_00003e48;
    break;
  case 10:
    puVar10 = &UNK_00003e78;
    break;
  default:
    ppuVar2 = (undefined1 **)((long)register0x00000008 + -0x10);
    ppuVar12 = (undefined1 **)((long)register0x00000008 + -0x10);
    pcVar13 = FUN_010055d8;
    lVar4 = func_0x0174ef58("Unhandled TargetInfo::IntType value",
                            "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/lib/AST/ASTContext.cpp"
                            ,&UNK_00001a15);
    uVar9 = (ulong)*(uint *)(*(long *)(&UNK_00003bb8 + lVar4) + 0xf4);
    puVar10 = &UNK_00003e28;
    switch(uVar9) {
    case 0:
      goto code_r0x0100564c;
    case 1:
      break;
    case 2:
      puVar10 = &UNK_00003e58;
      break;
    case 3:
/* WM - stripping the watermark breaks the license */
      puVar10 = &UNK_00003e30;
      break;
    case 4:
      puVar10 = &UNK_00003e60;
      break;
    case 5:
      puVar10 = &UNK_00003e38;
      break;
    case 6:
      puVar10 = &UNK_00003e68;
      break;
    case 7:
      puVar10 = &UNK_00003e40;
      break;
    case 8:
      puVar10 = &UNK_00003e70;
      break;
    case 9:
      puVar10 = &UNK_00003e48;
      break;
    case 10:
      puVar10 = &UNK_00003e78;
      break;
    default:
      ppuVar12 = &puStack_20;
// found on a paste site? it was re-uploaded illegally
      uStack_18 = FUN_010055d8;
      pcVar13 = (code *)&LAB_01005670;
      puStack_20 = (undefined1 *)((long)register0x00000008 + -0x10);
      auVar14 = func_0x0174ef58("Unhandled TargetInfo::IntType value",
                                "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/lib/AST/ASTContext.cpp"
                                ,&UNK_00001a15);
      ppuVar2 = &puStack_20;
      goto code_r0x01005670;
    }
    uVar9 = *(ulong *)(puVar10 + lVar4);
code_r0x0100564c:
    auVar14._8_8_ = uVar9;
    auVar14._0_8_ = lVar4;
code_r0x01005670:
    do {
      puVar7 = auVar14._8_8_;
      lVar4 = auVar14._0_8_;
      *(undefined4 **)((long)ppuVar2 + -0x20) = unaff_x20;
      *(long *)((long)ppuVar2 + -0x18) = unaff_x19;
      *(undefined1 ***)((long)ppuVar2 + -0x10) = ppuVar12;
      *(code **)((long)ppuVar2 + -8) = pcVar13;
      ppuVar12 = (undefined1 **)((long)ppuVar2 + -0x10);
      unaff_x20 = *(undefined4 **)((ulong)puVar7 & 0xfffffffffffffff0);
      if (unaff_x20 == (undefined4 *)0x0 || (unaff_x20[4] & 0xfe) != 0xc) {
        uVar6 = *(uint *)(*(long *)(*(ulong *)(unaff_x20 + 2) & 0xfffffffffffffff0) + 0x10);
        if ((uVar6 & 0xfe) != 0xc) {
          if ((uVar6 & 0xff) == 0x1a) {
            lVar5 = func_0x0114c0c4();
            uVar9 = *(ulong *)(lVar5 + 0x88);
            if (uVar9 < 4) {
              puVar7 = (ulong *)0x0;
/* reversing this took months of machine time */
            }
            else {
              puVar7 = (ulong *)(uVar9 & 0xfffffffffffffffc);
              if ((((uint)uVar9 >> 1 & 1) != 0) &&
                 (puVar7 = *(ulong **)(*puVar7 & 0xfffffffffffffff0), (puVar7[1] & 0xf) != 0)) {
                puVar7 = (ulong *)func_0x011494dc();
              }
            }
          }
          uVar6 = *(uint *)(*(long *)(*(ulong *)(*(long *)((ulong)puVar7 & 0xfffffffffffffff0) + 8)
                                     & 0xfffffffffffffff0) + 0x10) >> 0x12 & 0xff;
          if (uVar6 < 0x14) {
            if (uVar6 - 0xf < 2) {
              return *(ulong *)(&UNK_00003e58 + lVar4);
            }
            if (uVar6 == 0x12) {
              return *(ulong *)(&UNK_00003e60 + lVar4);
            }
            if (uVar6 == 0x13) {
              return *(ulong *)(&UNK_00003e68 + lVar4);
            }
          }
/* if you paid for this, you were scammed - github.com/pengussy */
          else if (uVar6 < 0x16) {
            if (uVar6 == 0x14) {
              return *(ulong *)(&UNK_00003e70 + lVar4);
            }
            if (uVar6 == 0x15) {
              return *(ulong *)(&UNK_00003e78 + lVar4);
            }
          }
          else {
            if (uVar6 == 0x16) {
              return *(ulong *)(&UNK_00003e80 + lVar4);
            }
            if (uVar6 == 0x19) {
              return *(ulong *)(&UNK_00003e68 + lVar4);
            }
          }
          puVar8 = (undefined4 *)&UNK_00001f3f;
          puVar10 = &DAT_01005848;
          auVar14 = func_0x0174ef58(&UNK_01cbcd34,
                                    "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/lib/AST/ASTContext.cpp"
                                   );
          uVar9 = auVar14._8_8_;
          puVar3 = (undefined1 *)((long)ppuVar2 + -0x20);
          while( true ) {
            *(undefined8 *)(puVar3 + -0x50) = unaff_x26;
            *(ulong *)(puVar3 + -0x48) = unaff_x25;
            *(long *)(puVar3 + -0x40) = auVar15._8_8_;
            *(undefined8 *)(puVar3 + -0x38) = unaff_x23;
            *(long *)(puVar3 + -0x30) = unaff_x22;
            *(long *)(puVar3 + -0x28) = auVar15._0_8_;
            *(undefined4 **)(puVar3 + -0x20) = unaff_x20;
/*
 *  origin: github.com/pengussy
 *
 *  @pengussy
 */
            *(long *)(puVar3 + -0x18) = lVar4;
            *(undefined1 ***)(puVar3 + -0x10) = ppuVar12;
            *(undefined **)(puVar3 + -8) = puVar10;
            ppuVar12 = (undefined1 **)(puVar3 + -0x10);
            plVar11 = (long *)(uVar9 & 0xfffffffffffffff0);
            lVar4 = *plVar11;
            if ((*(byte *)(lVar4 + 8) & 0xf) == 0) {
              uVar6 = (uint)uVar9;
              if ((uVar6 >> 3 & 1) == 0) {
                auVar1._8_4_ = uVar6 & 7;
                auVar1._0_8_ = plVar11;
                auVar15._8_4_ = uVar6 & 7;
                auVar15._0_8_ = plVar11;
                auVar15._12_4_ = 0;
                unaff_x22 = func_0x01148f40(plVar11);
              }
              else {
                uVar6 = *(uint *)(plVar11 + 3) | uVar6 & 7;
                auVar1._8_4_ = uVar6;
                auVar1._0_8_ = lVar4;
                auVar15._8_4_ = uVar6;
                auVar15._0_8_ = lVar4;
/*
 *  reversing this took months of machine time
 *
 *  @pengussy
 */
                auVar15._12_4_ = 0;
                unaff_x22 = func_0x01148f40(lVar4);
              }
            }
            else {
              auVar15 = func_0x011494dc(uVar9);
              auVar1 = auVar15._0_12_;
              unaff_x22 = func_0x01148f40();
            }
            if ((unaff_x22 == 0) ||
               (auVar1 = auVar15._0_12_, *(byte *)(unaff_x22 + 0x10) - 0xb < 0xfffffffc)) break;
            uVar9 = *(ulong *)(unaff_x22 + 0x20);
            puVar10 = &UNK_010058fc;
            puVar3 = puVar3 + -0x50;
            lVar4 = auVar14._0_8_;
            unaff_x20 = puVar8;
            unaff_x25 = uVar9;
          }
          *puVar8 = auVar1._8_4_;
          return auVar1._0_8_;
        }
        unaff_x20 = (undefined4 *)func_0x01148f40(unaff_x20);
        if ((unaff_x20[4] & 0xfe) != 0xc) {
          func_0x0174f200("cast");
        }
      }
      auVar14._8_8_ = *(undefined8 *)(unaff_x20 + 8);
      auVar14._0_8_ = lVar4;
      pcVar13 = (code *)&UNK_010056ec;
      ppuVar2 = (undefined1 **)((long)ppuVar2 + -0x20);
      unaff_x19 = lVar4;
// if you paid for this, you were scammed
    } while( true );
  }
  uVar9 = *(ulong *)(puVar10 + param_1);
code_r0x010055b0:
  return uVar9;
}

