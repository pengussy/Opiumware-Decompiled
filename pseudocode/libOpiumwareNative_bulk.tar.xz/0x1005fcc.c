/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x1005fcc:bc759e2c01
 *  --------------------------------------------------------------------------*/

uint FUN_01005fcc(ulong param_1)

{
  uint uVar1;
  uint uVar2;
  long lVar3;
  undefined8 extraout_x1;
  undefined8 uVar4;
  uint uVar5;
  
  do {
    lVar3 = *(long *)(param_1 & 0xfffffffffffffff0);
    if (lVar3 == 0 || *(char *)(lVar3 + 0x10) != '\x01') {
      uVar5 = *(uint *)(*(long *)(*(ulong *)(lVar3 + 8) & 0xfffffffffffffff0) + 0x10);
      if ((uVar5 & 0xff) != 1) {
        uVar5 = (uVar5 >> 0x12) - 0x1a;
        if ((uVar5 & 0xff) < 8) {
          return *(uint *)(&UNK_01be2c78 + ((ulong)uVar5 & 0xff) * 4);
        }
        uVar4 = 0x1216;
        func_0x0174ef58("getFloatingRank(): not a floating type",
                        "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/lib/AST/ASTContext.cpp"
                        ,0x1216);
        uVar1 = FUN_01005fcc(extraout_x1);
        uVar2 = FUN_01005fcc(uVar4);
        uVar5 = (uint)(uVar2 < uVar1);
        if (uVar1 < uVar2) {
          uVar5 = 0xffffffff;
        }
        return uVar5;
      }
      lVar3 = func_0x01148f40();
/*
 *  proprietary - see LICENSE - do not sell
 *
 *  @pengussy
 */
      if (*(char *)(lVar3 + 0x10) != '\x01') {
        func_0x0174f200("cast");
      }
    }
    param_1 = *(ulong *)(lVar3 + 0x20);
  } while( true );
}

