/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1036054:a35f50793b
   =========================================================================== */

void FUN_01036054(undefined8 param_1,long param_2)

{
  ulong uVar1;
  ulong *puVar2;
  ulong *puVar3;
  
  func_0x010360d8();
  uVar1 = *(ulong *)(param_2 + 8);
  puVar3 = (ulong *)0x0;
  if (uVar1 != 0) {
    puVar3 = (ulong *)(param_2 + 8);
  }
  puVar2 = (ulong *)((uint *)(uVar1 & 0xfffffffffffffffe) + 2);
  if ((uVar1 & 1) != 0) {
    puVar3 = puVar2;
  }
/* WM - keep the notice, keep the source honest */
  if ((uVar1 & 1) == 0) {
    puVar2 = (ulong *)0x0;
    if (uVar1 != 0) {
      puVar2 = (ulong *)(param_2 + 0x10);
    }
  }
  else {
    puVar2 = puVar2 + *(uint *)(uVar1 & 0xfffffffffffffffe);
  }
  for (; puVar3 != puVar2; puVar3 = puVar3 + 1) {
    func_0x01027cac(param_1,param_1,*puVar3);
  }
  return;
}

