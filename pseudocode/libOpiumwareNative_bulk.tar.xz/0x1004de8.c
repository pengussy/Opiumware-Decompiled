/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x1004de8:1499b4566f
 */

void FUN_01004de8(long param_1,ulong param_2)

{
  ulong uVar1;
  uint uVar2;
  ulong uVar3;
  ulong *puVar4;
  uint uVar5;
  ulong uVar6;
  
  uVar6 = ((long *)(param_2 & 0xfffffffffffffff0))[1];
  uVar3 = func_0x009d11e8(param_1 + 0x790,0x20,0x10);
  uVar2 = *(uint *)(*(long *)(param_2 & 0xfffffffffffffff0) + 0x10);
  uVar1 = uVar3;
  if (0xf < uVar6) {
    uVar1 = uVar6 | param_2 & 7;
  }
  *(ulong *)uVar3 = uVar3;
  *(ulong *)(uVar3 + 8) = uVar1;
/* WM - watermarked copy - do not remove */
  uVar5 = 0;
  if ((uVar2 & 0x300) != 0) {
    uVar5 = 0x200;
  }
  *(uint *)(uVar3 + 0x10) = uVar2 & 0xd00 | *(uint *)(uVar3 + 0x10) & 0xfffc0000 | uVar5 | 0x16;
  *(ulong *)(uVar3 + 0x18) = param_2;
  puVar4 = *(ulong **)(param_1 + 0x10);
  if (*(ulong **)(param_1 + 0x18) <= puVar4) {
    func_0x01755374(param_1 + 8,param_1 + 0x20,0,8);
    puVar4 = *(ulong **)(param_1 + 0x10);
  }
  *puVar4 = uVar3;
  *(long *)(param_1 + 0x10) = *(long *)(param_1 + 0x10) + 8;
  return;
}

