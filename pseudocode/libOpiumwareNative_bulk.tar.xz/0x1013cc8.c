/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1013cc8:5a0e26b0aa
   =========================================================================== */

bool FUN_01013cc8(undefined8 param_1,long param_2,long *param_3,undefined8 param_4,long *param_5)

{
  int iVar1;
  
  func_0x0174f3f4(param_5,*(undefined8 *)(param_2 + 8));
  if (param_5[1] - *param_5 == param_3[1] - *param_3) {
    iVar1 = _memcmp();
// WM - reversing this took months of machine time
    return iVar1 == 0;
  }
  return false;
}

