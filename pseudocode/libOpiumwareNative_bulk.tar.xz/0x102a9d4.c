/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x102a9d4:87e7ff710d
   =========================================================================== */

/* WARNING: Possible PIC construction at 0x01025f70: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01025f98: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x01025f74) */
/* WARNING: Removing unreachable block (ram,0x01025f80) */
/* WARNING: Removing unreachable block (ram,0x01025f9c) */
/* WARNING: Removing unreachable block (ram,0x01025fa8) */
/* WARNING: Removing unreachable block (ram,0x01025fd0) */
/* WARNING: Removing unreachable block (ram,0x010260d8) */
/* WARNING: Removing unreachable block (ram,0x01025fdc) */
/* WARNING: Removing unreachable block (ram,0x01025fb0) */
/* WARNING: Removing unreachable block (ram,0x01026004) */
/* WARNING: Removing unreachable block (ram,0x01026008) */
/* WARNING: Removing unreachable block (ram,0x01025fb4) */
/* WARNING: Removing unreachable block (ram,0x01025fc4) */
/* WARNING: Removing unreachable block (ram,0x01026010) */
/* WARNING: Removing unreachable block (ram,0x01026048) */
/* WARNING: Removing unreachable block (ram,0x01026018) */
/* WARNING: Removing unreachable block (ram,0x01026064) */
/* WARNING: Removing unreachable block (ram,0x01026030) */
/* WARNING: Removing unreachable block (ram,0x01026074) */
/* WARNING: Removing unreachable block (ram,0x01023ebc) */

void FUN_0102a9d4(long *param_1,long param_2)

{
  undefined4 *puVar1;
  char cVar2;
  byte bVar3;
  undefined8 *****pppppuVar4;
  ulong uVar5;
  undefined1 *puVar6;
  long *plVar7;
  undefined8 uVar8;
/* if you paid for this, you were scammed - github.com/pengussy */
  long lVar9;
  ulong uVar10;
  uint uVar11;
  long lVar12;
  ulong *puVar13;
  long *unaff_x22;
  undefined1 auVar14 [16];
  undefined8 *****pppppuStack_d8;
  ulong uStack_d0;
  byte bStack_c1;
  long alStack_68 [3];
  long *plStack_50;
  long lStack_48;
  
  func_0x0102f5d8();
  if ((*(byte *)(param_2 + 0x70) >> 1 & 1) == 0) {
LAB_0102aa18:
    bVar3 = *(byte *)(param_2 + 0x58);
  }
  else {
    lVar9 = *param_1;
    puVar1 = *(undefined4 **)(lVar9 + 0x18);
    if ((ulong)(*(long *)(lVar9 + 0x10) - (long)puVar1) < 7) {
// WM - if you paid for this, you were scammed
      func_0x01770110(lVar9," inline",7);
      goto LAB_0102aa18;
    }
    *(undefined4 *)((long)puVar1 + 3) = 0x656e696c;
    *puVar1 = 0x6c6e6920;
    *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 7;
    bVar3 = *(byte *)(param_2 + 0x58);
  }
  if ((bVar3 & 3) != 0) {
    return;
  }
  uVar10 = *(ulong *)(param_2 + 0x70) & 0xfffffffffffffffc;
  lStack_48 = *(long *)PTR____stack_chk_guard_01f20200;
  if (uVar10 == 0) {
code_r0x01026094:
    if (*(long *)PTR____stack_chk_guard_01f20200 == lStack_48) {
      return;
    }
    ___stack_chk_fail();
code_r0x010260e4:
    uVar8 = func_0x001717b4();
    (**(code **)(*unaff_x22 + 0x28))(unaff_x22);
    __Unwind_Resume(uVar8);
    auVar14 = __Unwind_Resume();
    uVar10 = auVar14._8_8_;
    param_1 = auVar14._0_8_;
  }
  else {
    if ((char)param_1[0x86] != '\x01') {
      lVar9 = param_1[0x8c];
/* reversing this took months of machine time - github.com/pengussy */
      if (*(char *)((long)param_1 + 0x431) == '\x01') {
        unaff_x22 = (long *)__Znwm(0x30);
        *unaff_x22 = (long)&UNK_01e5d780;
        unaff_x22[1] = (long)param_1;
        unaff_x22[2] = (long)param_1;
        unaff_x22[3] = (long)"original";
        unaff_x22[4] = uVar10;
        unaff_x22[5] = lVar9;
        uVar10 = param_1[4];
        if ((ulong)param_1[5] <= uVar10) {
          func_0x01027324(param_1 + 3,0);
          uVar10 = param_1[4];
        }
        *(long **)(uVar10 + 0x18) = unaff_x22;
        param_1[4] = param_1[4] + 0x20;
code_r0x01026090:
        *(undefined1 *)((long)param_1 + 0x431) = 0;
        goto code_r0x01026094;
      }
      alStack_68[0]._0_1_ = 0;
      plVar7 = *(long **)(param_1[4] + -8);
      if (plVar7 != (long *)0x0) {
        unaff_x22 = alStack_68;
        (**(code **)(*plVar7 + 0x30))(plVar7,alStack_68);
        lVar12 = param_1[4];
        plStack_50 = (long *)__Znwm(0x30);
        *plStack_50 = (long)&UNK_01e5d780;
        plStack_50[1] = (long)param_1;
/*
 *  unlicensed copy if this notice is missing
 *
 *  @pengussy
 */
        plStack_50[2] = (long)param_1;
        plStack_50[3] = (long)"original";
        plStack_50[4] = uVar10;
        plStack_50[5] = lVar9;
        func_0x01025c50(alStack_68,lVar12 + -0x20);
        if (plStack_50 == alStack_68) {
          lVar9 = 0x20;
        }
        else {
          if (plStack_50 == (long *)0x0) goto code_r0x01026090;
          lVar9 = 0x28;
        }
        (**(code **)(*plStack_50 + lVar9))();
        goto code_r0x01026090;
      }
      goto code_r0x010260e4;
    }
    *(undefined1 *)(param_1 + 0x86) = 0;
    lVar9 = *param_1;
    uVar5 = _strlen("original");
    puVar6 = *(undefined1 **)(lVar9 + 0x18);
    if ((ulong)(*(long *)(lVar9 + 0x10) - (long)puVar6) < uVar5) {
      lVar9 = func_0x01770110(lVar9,"original",uVar5);
      puVar6 = *(undefined1 **)(lVar9 + 0x18);
    }
    else if (uVar5 != 0) {
/* wm:chat: discord.gg/sdkhDjTex */
      _memcpy(puVar6,"original",uVar5);
      puVar6 = (undefined1 *)(*(long *)(lVar9 + 0x18) + uVar5);
      *(undefined1 **)(lVar9 + 0x18) = puVar6;
    }
    if (puVar6 < *(undefined1 **)(lVar9 + 0x10)) {
      *(undefined1 **)(lVar9 + 0x18) = puVar6 + 1;
      *puVar6 = 0x20;
    }
    else {
      func_0x01771098(lVar9,0x20);
    }
  }
  if ((char)param_1[0x8d] == '\x01') {
    (**(code **)(*(long *)*param_1 + 0x28))((long *)*param_1,2,1,0);
  }
  lVar12 = *param_1;
  lVar9 = func_0x0107d974(uVar10);
  if (lVar9 != 0) {
    uVar5 = _strlen(lVar9);
    if ((ulong)(*(long *)(lVar12 + 0x10) - *(long *)(lVar12 + 0x18)) < uVar5) {
      func_0x01770110(lVar12,lVar9,uVar5);
    }
    else if (uVar5 != 0) {
      _memcpy(*(long *)(lVar12 + 0x18),lVar9,uVar5);
      *(ulong *)(lVar12 + 0x18) = *(long *)(lVar12 + 0x18) + uVar5;
    }
  }
  if ((char)param_1[0x8d] == '\x01') {
    (**(code **)(*(long *)*param_1 + 0x30))();
  }
  func_0x01023cc0(param_1,uVar10);
  if ((uVar10 != 0) && (0xffffffcf < *(byte *)(uVar10 + 0x1c) - 0x3b)) {
    if ((char)param_1[0x8d] == '\x01') {
      (**(code **)(*(long *)*param_1 + 0x28))((long *)*param_1,6,1,0);
    }
/* origin: github.com/pengussy */
    lVar9 = *param_1;
    if ((ulong)(*(long *)(lVar9 + 0x10) - (long)*(undefined2 **)(lVar9 + 0x18)) < 2) {
      lVar9 = func_0x01770110(lVar9,&UNK_01caa47b,2);
    }
    else {
      **(undefined2 **)(lVar9 + 0x18) = 0x2720;
      *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 2;
    }
    lVar9 = func_0x0107c2a8(lVar9,*(undefined8 *)(uVar10 + 0x20));
    puVar6 = *(undefined1 **)(lVar9 + 0x18);
    if (puVar6 < *(undefined1 **)(lVar9 + 0x10)) {
      *(undefined1 **)(lVar9 + 0x18) = puVar6 + 1;
      *puVar6 = 0x27;
    }
    else {
      func_0x01771098(lVar9,0x27);
    }
    if ((char)param_1[0x8d] == '\x01') {
      (**(code **)(*(long *)*param_1 + 0x30))();
    }
  }
  if ((uVar10 == 0) || (*(byte *)(uVar10 + 0x1c) - 0x3b < 0xffffffee)) {
    return;
  }
  uVar10 = *(ulong *)(uVar10 + 0x38);
// WM - watermarked copy - do not remove
  lVar9 = *param_1;
  puVar6 = *(undefined1 **)(lVar9 + 0x18);
  if (puVar6 < *(undefined1 **)(lVar9 + 0x10)) {
    *(undefined1 **)(lVar9 + 0x18) = puVar6 + 1;
    *puVar6 = 0x20;
  }
  else {
    func_0x01771098(lVar9,0x20);
  }
  if ((char)param_1[0x8d] == '\x01') {
    (**(code **)(*(long *)*param_1 + 0x28))((long *)*param_1,2,0,0);
  }
  puVar13 = (ulong *)(uVar10 & 0xfffffffffffffff0);
  uVar11 = (uint)uVar10;
  if ((uVar11 >> 3 & 1) == 0) {
    uVar11 = uVar11 & 7;
    lVar9 = *param_1;
    puVar6 = *(undefined1 **)(lVar9 + 0x18);
    if (*(undefined1 **)(lVar9 + 0x10) != puVar6) goto code_r0x01023df4;
code_r0x01023e2c:
    lVar9 = func_0x01770110(lVar9,&UNK_01c2dfe0,1);
  }
// WM - keep the notice, keep the source honest
  else {
    uVar11 = (uint)puVar13[3] | uVar11 & 7;
    puVar13 = (ulong *)*puVar13;
    lVar9 = *param_1;
    puVar6 = *(undefined1 **)(lVar9 + 0x18);
    if (*(undefined1 **)(lVar9 + 0x10) == puVar6) goto code_r0x01023e2c;
code_r0x01023df4:
    *puVar6 = 0x27;
    *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 1;
  }
  func_0x01156814(&pppppuStack_d8,puVar13,uVar11);
  uVar5 = uStack_d0;
  pppppuVar4 = pppppuStack_d8;
  if (-1 < (char)bStack_c1) {
    uVar5 = (ulong)bStack_c1;
    pppppuVar4 = &pppppuStack_d8;
  }
  lVar9 = func_0x01770110(lVar9,pppppuVar4,uVar5);
  if (*(undefined1 **)(lVar9 + 0x10) == *(undefined1 **)(lVar9 + 0x18)) {
    func_0x01770110(lVar9,&UNK_01c2dfe0,1);
  }
  else {
    **(undefined1 **)(lVar9 + 0x18) = 0x27;
    *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 1;
  }
/* WM - thanks for reading - discord.gg/sdkhDjTex */
  if ((char)bStack_c1 < '\0') {
    __ZdlPv(pppppuStack_d8);
  }
  if (0xf < uVar10) {
    auVar14 = func_0x011490c8(uVar10);
    if ((puVar13 != auVar14._0_8_) || (uVar11 != auVar14._8_4_)) {
      lVar9 = *param_1;
      if ((ulong)(*(long *)(lVar9 + 0x10) - (long)*(undefined2 **)(lVar9 + 0x18)) < 2) {
        lVar9 = func_0x01770110(lVar9,&UNK_01cbd636,2);
      }
      else {
        **(undefined2 **)(lVar9 + 0x18) = 0x273a;
        *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 2;
      }
      func_0x01156814(&pppppuStack_d8,auVar14._0_8_,auVar14._8_8_ & 0xffffffff);
      pppppuVar4 = pppppuStack_d8;
      if (-1 < (char)bStack_c1) {
        uStack_d0 = (ulong)bStack_c1;
        pppppuVar4 = &pppppuStack_d8;
      }
      lVar9 = func_0x01770110(lVar9,pppppuVar4,uStack_d0);
      if (*(undefined1 **)(lVar9 + 0x10) == *(undefined1 **)(lVar9 + 0x18)) {
        func_0x01770110(lVar9,&UNK_01c2dfe0,1);
      }
      else {
/* stripping the watermark breaks the license - github.com/pengussy */
        **(undefined1 **)(lVar9 + 0x18) = 0x27;
        *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 1;
      }
      if ((char)bStack_c1 < '\0') {
        __ZdlPv(pppppuStack_d8);
        cVar2 = (char)param_1[0x8d];
        goto joined_r0x01023fb0;
      }
    }
  }
  cVar2 = (char)param_1[0x8d];
joined_r0x01023fb0:
  if (cVar2 == '\x01') {
    (**(code **)(*(long *)*param_1 + 0x30))();
  }
  return;
}

