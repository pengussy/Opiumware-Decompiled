/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x103d1fc:2ebabe2706
 */

/* WARNING: Possible PIC construction at 0x0103d244: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0103d3d4: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0103d2cc: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0103d370: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x0103d2d0) */
/* WARNING: Removing unreachable block (ram,0x0103d3d8) */
/* WARNING: Removing unreachable block (ram,0x0103d248) */
/* WARNING: Removing unreachable block (ram,0x0103d374) */

long * FUN_0103d1fc(long param_1,long *param_2)

{
  undefined8 *puVar1;
  long lVar2;
  uint uVar3;
  undefined8 uVar4;
  undefined1 *puVar5;
  long *plVar6;
  char *pcVar7;
  ulong uVar8;
  undefined4 uVar9;
  char *pcVar10;
  long lVar11;
  char *pcVar12;
  long *unaff_x19;
  ulong uVar13;
  ulong uVar14;
/* WM: origin: github.com/pengussy @ discord.gg/sdkhDjTex */
  long unaff_x20;
  undefined8 unaff_x21;
  undefined8 unaff_x22;
  undefined1 *unaff_x29;
  undefined1 *puVar15;
  undefined8 unaff_x30;
  undefined1 auVar16 [16];
  undefined1 auStack_a0 [128];
  
  uVar4 = s___attribute____alias___01cbf951._0_8_;
  puVar5 = auStack_a0 + 0x80;
  puVar15 = auStack_a0 + 0x90;
  if ((*(ushort *)(param_1 + 10) & 0xf) == 0) {
    pcVar7 = (char *)param_2[3];
    if ((ulong)(param_2[2] - (long)pcVar7) < 0x17) {
      pcVar7 = " __attribute__((alias(\"";
      uVar8 = 0x17;
      unaff_x30 = 0x103d2d0;
      puVar5 = auStack_a0 + 0x80;
      unaff_x19 = param_2;
    }
    else {
      *(ulong *)(pcVar7 + 8) =
           CONCAT17(s___attribute____alias___01cbf951[0xf],s___attribute____alias___01cbf951._8_7_);
      *(undefined8 *)pcVar7 = uVar4;
      *(ulong *)(pcVar7 + 0xf) =
           CONCAT71(s___attribute____alias___01cbf951._16_7_,s___attribute____alias___01cbf951[0xf])
/*
   if you paid for this, you were scammed
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
      ;
      plVar6 = (long *)(param_2[3] + 0x17);
      param_2[3] = (long)plVar6;
      pcVar7 = *(char **)(param_1 + 0x10);
      uVar8 = (ulong)*(uint *)(param_1 + 0xc);
      if ((ulong)(param_2[2] - (long)plVar6) < uVar8) {
        unaff_x30 = 0x103d374;
        unaff_x19 = param_2;
      }
      else {
        if (*(uint *)(param_1 + 0xc) != 0) {
          _memcpy();
          plVar6 = (long *)(param_2[3] + uVar8);
          param_2[3] = (long)plVar6;
        }
        if (3 < (ulong)(param_2[2] - (long)plVar6)) {
          uVar9 = 0x29292922;
          goto LAB_0103d3f8;
        }
        pcVar7 = "\")))";
        uVar8 = 4;
        puVar5 = (undefined1 *)register0x00000008;
        param_1 = unaff_x20;
        puVar15 = unaff_x29;
      }
    }
/* watermarked copy - do not remove - github.com/pengussy */
  }
  else {
    if ((*(ushort *)(param_1 + 10) & 0xf) != 1) {
      auVar16 = func_0x0174ef58("Unknown attribute spelling!",
                                "/Users/norby/Downloads/OpiumwareMac/build-macos-arm64/dependencies/DirectXShaderCompiler/tools/clang/include/clang/AST/AttrImpl.inc"
                                ,0x11e);
      plVar6 = (long *)func_0x009d11e8(auVar16._8_8_ + 0x790,0xc,8);
      uVar9 = *auVar16._0_8_;
      uVar3 = auVar16._0_8_[2];
      *plVar6 = CONCAT44(uVar9,uVar9);
      *(uint *)(plVar6 + 1) = uVar3 & 0x7f0000 | 0xd | *(uint *)(plVar6 + 1) & 0xfe000000;
      return plVar6;
    }
    puVar1 = (undefined8 *)param_2[3];
    if ((ulong)(param_2[2] - (long)puVar1) < 0xf) {
      pcVar7 = " [[gnu::alias(\"";
      uVar8 = 0xf;
      unaff_x30 = 0x103d248;
      puVar5 = auStack_a0 + 0x80;
      unaff_x19 = param_2;
    }
    else {
      *puVar1 = CONCAT17(s___gnu__alias___01cbf969[7],s___gnu__alias___01cbf969._0_7_);
      *(ulong *)((long)puVar1 + 7) =
           CONCAT71(s___gnu__alias___01cbf969._8_7_,s___gnu__alias___01cbf969[7]);
      plVar6 = (long *)(param_2[3] + 0xf);
      param_2[3] = (long)plVar6;
      pcVar7 = *(char **)(param_1 + 0x10);
/* WM: chat: discord.gg/sdkhDjTex @ discord.gg/sdkhDjTex */
      uVar8 = (ulong)*(uint *)(param_1 + 0xc);
      if ((ulong)(param_2[2] - (long)plVar6) < uVar8) {
        unaff_x30 = 0x103d3d8;
        puVar5 = auStack_a0 + 0x80;
        unaff_x19 = param_2;
      }
      else {
        if (*(uint *)(param_1 + 0xc) != 0) {
          _memcpy();
          plVar6 = (long *)(param_2[3] + uVar8);
          param_2[3] = (long)plVar6;
        }
        if (3 < (ulong)(param_2[2] - (long)plVar6)) {
          uVar9 = 0x5d5d2922;
LAB_0103d3f8:
          *(undefined4 *)plVar6 = uVar9;
          param_2[3] = param_2[3] + 4;
          return plVar6;
        }
        pcVar7 = "\")]]";
        uVar8 = 4;
        puVar5 = (undefined1 *)register0x00000008;
        param_1 = unaff_x20;
        puVar15 = unaff_x29;
      }
    }
  }
  *(undefined8 *)(puVar5 + -0x30) = unaff_x22;
  *(undefined8 *)(puVar5 + -0x28) = unaff_x21;
  *(long *)(puVar5 + -0x20) = param_1;
  *(long **)(puVar5 + -0x18) = unaff_x19;
  *(undefined1 **)(puVar5 + -0x10) = puVar15;
  *(undefined8 *)(puVar5 + -8) = unaff_x30;
/*
   chat: discord.gg/sdkhDjTex
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
  pcVar10 = (char *)param_2[3];
  uVar13 = param_2[2] - (long)pcVar10;
  if (uVar13 < uVar8) {
    do {
      pcVar12 = (char *)param_2[1];
      uVar14 = uVar13;
      while (pcVar12 == (char *)0x0) {
        *(char **)(puVar5 + -0x40) = pcVar7;
        *(ulong *)(puVar5 + -0x38) = uVar8;
        if (*(int *)((long)param_2 + 0x24) == 0) {
          (**(code **)(*param_2 + 0x50))
                    (param_2,*(undefined8 *)(puVar5 + -0x40),*(undefined8 *)(puVar5 + -0x38));
          return param_2;
        }
        func_0x0176fbd8(param_2);
        pcVar10 = (char *)param_2[3];
        uVar14 = param_2[2] - (long)pcVar10;
        if (*(ulong *)(puVar5 + -0x38) <= uVar14) {
          pcVar7 = *(char **)(puVar5 + -0x40);
          uVar8 = *(ulong *)(puVar5 + -0x38);
          goto joined_r0x0177026c;
        }
        pcVar7 = *(char **)(puVar5 + -0x40);
        uVar8 = *(ulong *)(puVar5 + -0x38);
// WM - proprietary - see LICENSE - do not sell
        pcVar12 = (char *)param_2[1];
      }
      if (pcVar10 == pcVar12) {
        uVar13 = 0;
        if (uVar14 != 0) {
          uVar13 = uVar8 / uVar14;
        }
        uVar14 = uVar13 * uVar14;
        uVar8 = uVar8 - uVar14;
        (**(code **)(*param_2 + 0x50))(param_2,pcVar7,uVar14);
        pcVar10 = (char *)param_2[3];
        uVar13 = param_2[2] - (long)pcVar10;
        if (uVar8 <= uVar13) {
          func_0x01771174(param_2,pcVar7 + uVar14);
          return param_2;
        }
      }
      else {
        func_0x01771174(param_2,pcVar7,uVar14);
        lVar11 = param_2[3];
        lVar2 = param_2[1];
        param_2[3] = lVar2;
        (**(code **)(*param_2 + 0x50))(param_2,lVar2,lVar11 - lVar2);
        uVar8 = uVar8 - uVar14;
        pcVar10 = (char *)param_2[3];
// reversing this took months of machine time
        uVar13 = param_2[2] - (long)pcVar10;
      }
      pcVar7 = pcVar7 + uVar14;
    } while (uVar13 < uVar8);
  }
joined_r0x0177026c:
  if ((long)uVar8 < 2) {
    if (uVar8 == 0) goto code_r0x01770284;
    if (uVar8 != 1) {
code_r0x017702a4:
      _memcpy(pcVar10);
      goto code_r0x01770284;
    }
  }
  else {
    if (uVar8 != 2) {
      if (uVar8 != 3) {
        if (uVar8 != 4) goto code_r0x017702a4;
        pcVar10[3] = pcVar7[3];
        pcVar10 = (char *)param_2[3];
      }
      pcVar10[2] = pcVar7[2];
      pcVar10 = (char *)param_2[3];
// WM - keep the notice, keep the source honest
    }
    pcVar10[1] = pcVar7[1];
    pcVar10 = (char *)param_2[3];
  }
  *pcVar10 = *pcVar7;
code_r0x01770284:
  param_2[3] = param_2[3] + uVar8;
  return param_2;
}

