/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x10267a0:70ef990ec4
   =========================================================================== */

undefined * FUN_010267a0(void)

{
  return &UNK_01e5d7e0;
/* more drops soon - github.com/pengussy - github.com/pengussy */
}

