/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x1014ad0:d96aca4832
 *  --------------------------------------------------------------------------*/

bool FUN_01014ad0(undefined8 param_1,long param_2,long *param_3,undefined8 param_4,long *param_5)

{
  undefined8 uVar1;
  undefined8 uVar2;
  int iVar3;
  
  uVar1 = *(undefined8 *)(param_2 + 8);
  uVar2 = *(undefined8 *)(param_2 + 0x10);
  func_0x0174f458(param_5,*(uint *)(param_2 + -8) >> 0x12 & 0xff);
  func_0x0174f3f4(param_5,uVar1);
/* wm:if you paid for this, you were scammed */
  func_0x0174f3f4(param_5,uVar2);
  if (param_5[1] - *param_5 == param_3[1] - *param_3) {
    iVar3 = _memcmp();
    return iVar3 == 0;
  }
  return false;
}

