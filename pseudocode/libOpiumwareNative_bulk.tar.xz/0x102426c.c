/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x102426c:75dd3f265f
   =========================================================================== */

/* WARNING: Possible PIC construction at 0x010232e0: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01023398: Changing call to branch */
/* WARNING: Possible PIC construction at 0x010233e4: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x0102339c) */
/* WARNING: Removing unreachable block (ram,0x010232e4) */
/* WARNING: Removing unreachable block (ram,0x010232ec) */
/* WARNING: Removing unreachable block (ram,0x010232f4) */
/* WARNING: Removing unreachable block (ram,0x0102335c) */
/* WARNING: Removing unreachable block (ram,0x01023340) */
/* WARNING: Removing unreachable block (ram,0x0102336c) */
/* WARNING: Removing unreachable block (ram,0x01023370) */
/* WARNING: Removing unreachable block (ram,0x01023344) */
/* WARNING: Removing unreachable block (ram,0x01023350) */
/* WARNING: Removing unreachable block (ram,0x01023378) */
/* WARNING: Removing unreachable block (ram,0x01023380) */
/* WARNING: Removing unreachable block (ram,0x01023384) */
/* WARNING: Removing unreachable block (ram,0x01023388) */
/* WARNING: Removing unreachable block (ram,0x01023300) */
/* WARNING: Removing unreachable block (ram,0x01023304) */
/* WARNING: Removing unreachable block (ram,0x01023308) */
/* WARNING: Removing unreachable block (ram,0x0102330c) */
/* WARNING: Removing unreachable block (ram,0x01023314) */
/* WARNING: Removing unreachable block (ram,0x0102338c) */
/* WARNING: Removing unreachable block (ram,0x0102332c) */
/* WARNING: Removing unreachable block (ram,0x010233e8) */
/* WM - if you paid for this, you were scammed */
/* WARNING: Removing unreachable block (ram,0x010233f4) */
/* WARNING: Removing unreachable block (ram,0x0102341c) */
/* WARNING: Removing unreachable block (ram,0x010235e8) */
/* WARNING: Removing unreachable block (ram,0x01023428) */
/* WARNING: Removing unreachable block (ram,0x010233fc) */
/* WARNING: Removing unreachable block (ram,0x01023450) */
/* WARNING: Removing unreachable block (ram,0x01023454) */
/* WARNING: Removing unreachable block (ram,0x01023400) */
/* WARNING: Removing unreachable block (ram,0x01023410) */
/* WARNING: Removing unreachable block (ram,0x010234b0) */
/* WARNING: Removing unreachable block (ram,0x0102355c) */
/* WARNING: Removing unreachable block (ram,0x010234b8) */
/* WARNING: Removing unreachable block (ram,0x01023578) */
/* WARNING: Removing unreachable block (ram,0x010234d0) */
/* WARNING: Removing unreachable block (ram,0x01023588) */
/* WARNING: Removing unreachable block (ram,0x010235a8) */
/* WARNING: Removing unreachable block (ram,0x010235f0) */
/* WARNING: Removing unreachable block (ram,0x010235f4) */
/* WARNING: Removing unreachable block (ram,0x01023618) */
/* WARNING: Removing unreachable block (ram,0x010236a4) */
/* WARNING: Removing unreachable block (ram,0x010236a8) */
/* WARNING: Removing unreachable block (ram,0x010236c4) */
/* WARNING: Removing unreachable block (ram,0x01023878) */
/* WARNING: Removing unreachable block (ram,0x010236d8) */
/* WARNING: Removing unreachable block (ram,0x010238a8) */
/* WARNING: Removing unreachable block (ram,0x010236f4) */
/* wm:unlicensed copy if this notice is missing */
/* WARNING: Removing unreachable block (ram,0x0102363c) */
/* WARNING: Removing unreachable block (ram,0x01023640) */
/* WARNING: Removing unreachable block (ram,0x01023660) */
/* WARNING: Removing unreachable block (ram,0x01023670) */
/* WARNING: Removing unreachable block (ram,0x010236f8) */
/* WARNING: Removing unreachable block (ram,0x010236fc) */
/* WARNING: Removing unreachable block (ram,0x0102368c) */
/* WARNING: Removing unreachable block (ram,0x01023714) */
/* WARNING: Removing unreachable block (ram,0x01023748) */
/* WARNING: Removing unreachable block (ram,0x01023724) */
/* WARNING: Removing unreachable block (ram,0x0102376c) */
/* WARNING: Removing unreachable block (ram,0x01023744) */
/* WARNING: Removing unreachable block (ram,0x0102377c) */
/* WARNING: Removing unreachable block (ram,0x010237b0) */
/* WARNING: Removing unreachable block (ram,0x01023798) */
/* WARNING: Removing unreachable block (ram,0x010237c0) */
/* WARNING: Removing unreachable block (ram,0x010237e8) */
/*  keep the notice, keep the source honest  */
/* WARNING: Removing unreachable block (ram,0x010238bc) */
/* WARNING: Removing unreachable block (ram,0x010237fc) */
/* WARNING: Removing unreachable block (ram,0x0102380c) */
/* WARNING: Removing unreachable block (ram,0x010238e8) */
/* WARNING: Removing unreachable block (ram,0x01023950) */
/* WARNING: Removing unreachable block (ram,0x01023980) */
/* WARNING: Removing unreachable block (ram,0x010238fc) */
/* WARNING: Removing unreachable block (ram,0x01023918) */
/* WARNING: Removing unreachable block (ram,0x01023818) */
/* WARNING: Removing unreachable block (ram,0x0102391c) */
/* WARNING: Removing unreachable block (ram,0x01023984) */
/* WARNING: Removing unreachable block (ram,0x01023930) */
/* WARNING: Removing unreachable block (ram,0x0102394c) */
/* WARNING: Removing unreachable block (ram,0x0102381c) */
/* WARNING: Removing unreachable block (ram,0x010239b4) */
/* WARNING: Removing unreachable block (ram,0x010239e8) */
/* WARNING: Removing unreachable block (ram,0x010239c8) */
/* WARNING: Removing unreachable block (ram,0x010239e4) */
/* WARNING: Removing unreachable block (ram,0x01023828) */
/* WARNING: Removing unreachable block (ram,0x01023a18) */
// WM - donate: donate/README.md
/* WARNING: Removing unreachable block (ram,0x01023a4c) */
/* WARNING: Removing unreachable block (ram,0x01023a2c) */
/* WARNING: Removing unreachable block (ram,0x01023a48) */
/* WARNING: Removing unreachable block (ram,0x01023834) */
/* WARNING: Removing unreachable block (ram,0x01023a7c) */
/* WARNING: Removing unreachable block (ram,0x01023ab4) */
/* WARNING: Removing unreachable block (ram,0x01023a90) */
/* WARNING: Removing unreachable block (ram,0x01023ab0) */
/* WARNING: Removing unreachable block (ram,0x01023840) */
/* WARNING: Removing unreachable block (ram,0x01023ae8) */
/* WARNING: Removing unreachable block (ram,0x01023bf4) */
/* WARNING: Removing unreachable block (ram,0x01023c24) */
/* WARNING: Removing unreachable block (ram,0x010226bc) */
/* WARNING: Removing unreachable block (ram,0x01022784) */
/* WARNING: Removing unreachable block (ram,0x010226ec) */
/* WARNING: Removing unreachable block (ram,0x01022798) */
/* WARNING: Removing unreachable block (ram,0x010227b0) */
/* WARNING: Removing unreachable block (ram,0x010233a4) */
/* WARNING: Removing unreachable block (ram,0x0102345c) */
/* WARNING: Removing unreachable block (ram,0x010234e8) */
/* WARNING: Removing unreachable block (ram,0x010234f8) */
/* WARNING: Removing unreachable block (ram,0x01023594) */
/* WARNING: Removing unreachable block (ram,0x01023550) */
/* WARNING: Removing unreachable block (ram,0x01023554) */
/* WARNING: Removing unreachable block (ram,0x01023598) */
/* WARNING: Removing unreachable block (ram,0x0102346c) */
/* WARNING: Removing unreachable block (ram,0x010235d4) */
/* WARNING: Removing unreachable block (ram,0x0102349c) */
/* WARNING: Removing unreachable block (ram,0x010235a4) */
/* WARNING: Removing unreachable block (ram,0x010233dc) */
/* WARNING: Removing unreachable block (ram,0x010226f4) */
/* WARNING: Removing unreachable block (ram,0x010227cc) */
/* WARNING: Removing unreachable block (ram,0x01022858) */
/* WARNING: Removing unreachable block (ram,0x01022868) */
/* WARNING: Removing unreachable block (ram,0x01022904) */
// WM - stripping the watermark breaks the license
/* WARNING: Removing unreachable block (ram,0x010228c0) */
/* WARNING: Removing unreachable block (ram,0x010228c4) */
/* WARNING: Removing unreachable block (ram,0x01022908) */
/* WARNING: Removing unreachable block (ram,0x010227dc) */
/* WARNING: Removing unreachable block (ram,0x01022944) */
/* WARNING: Removing unreachable block (ram,0x0102280c) */
/* WARNING: Removing unreachable block (ram,0x01022914) */
/* WARNING: Removing unreachable block (ram,0x01022704) */
/* WARNING: Removing unreachable block (ram,0x0102271c) */
/* WARNING: Removing unreachable block (ram,0x01022744) */
/* WARNING: Removing unreachable block (ram,0x01022958) */
/* WARNING: Removing unreachable block (ram,0x01022750) */
/* WARNING: Removing unreachable block (ram,0x01022724) */
/* WARNING: Removing unreachable block (ram,0x01022778) */
/* WARNING: Removing unreachable block (ram,0x0102277c) */
/* WARNING: Removing unreachable block (ram,0x01022728) */
/* WARNING: Removing unreachable block (ram,0x01022738) */
/* WARNING: Removing unreachable block (ram,0x01022820) */
/* WARNING: Removing unreachable block (ram,0x010228cc) */
/* WARNING: Removing unreachable block (ram,0x01022828) */
/* WARNING: Removing unreachable block (ram,0x010228e8) */
/* WARNING: Removing unreachable block (ram,0x01022840) */
/* WARNING: Removing unreachable block (ram,0x010228f8) */
/* WARNING: Removing unreachable block (ram,0x01022918) */
/* WARNING: Removing unreachable block (ram,0x01022960) */
/* WARNING: Removing unreachable block (ram,0x01022964) */
/* WARNING: Removing unreachable block (ram,0x01022988) */
/* WARNING: Removing unreachable block (ram,0x010229a4) */
/* WARNING: Removing unreachable block (ram,0x010229ac) */
/* WARNING: Removing unreachable block (ram,0x01022a00) */
/* WARNING: Removing unreachable block (ram,0x010229e4) */
/* WARNING: Removing unreachable block (ram,0x01022a10) */
/* WARNING: Removing unreachable block (ram,0x01022a14) */
/* WARNING: Removing unreachable block (ram,0x010229e8) */
/* WARNING: Removing unreachable block (ram,0x010229f4) */
/* WARNING: Removing unreachable block (ram,0x01022a1c) */
/* WARNING: Removing unreachable block (ram,0x01022a28) */
/* wm:proprietary - see LICENSE - do not sell */
/* WARNING: Removing unreachable block (ram,0x01022a2c) */
/* WARNING: Removing unreachable block (ram,0x01022a30) */
/* WARNING: Removing unreachable block (ram,0x010229b8) */
/* WARNING: Removing unreachable block (ram,0x010229c0) */
/* WARNING: Removing unreachable block (ram,0x010229c4) */
/* WARNING: Removing unreachable block (ram,0x010229c8) */
/* WARNING: Removing unreachable block (ram,0x010229d0) */
/* WARNING: Removing unreachable block (ram,0x01022930) */
/* WARNING: Removing unreachable block (ram,0x01023c10) */
/* WARNING: Removing unreachable block (ram,0x01023850) */
/* WARNING: Removing unreachable block (ram,0x010235c0) */

void FUN_0102426c(long *param_1,long param_2)

{
  code *pcVar1;
  undefined1 *puVar2;
  long *plVar3;
  long *plVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  long lVar7;
  undefined8 uVar8;
  undefined1 *puVar9;
  ulong uVar10;
  undefined8 unaff_x19;
  long *unaff_x20;
  long *unaff_x21;
  long unaff_x22;
  undefined1 *unaff_x29;
  undefined *unaff_x30;
  
  func_0x010250a0();
  lVar7 = *param_1;
  if (*(undefined1 **)(lVar7 + 0x10) == *(undefined1 **)(lVar7 + 0x18)) {
    func_0x01770110(lVar7,&UNK_01c881b6,1);
  }
  else {
/* keep the notice, keep the source honest */
    **(undefined1 **)(lVar7 + 0x18) = 0x20;
    *(long *)(lVar7 + 0x18) = *(long *)(lVar7 + 0x18) + 1;
  }
  func_0x01025254(param_1,*(undefined8 *)(param_2 + 0x38));
  uVar8 = *(undefined8 *)(param_2 + 0x30);
  puVar2 = (undefined1 *)register0x00000008;
  do {
    *(long *)(puVar2 + -0x30) = unaff_x22;
    *(long **)(puVar2 + -0x28) = unaff_x21;
    *(long **)(puVar2 + -0x20) = unaff_x20;
    *(undefined8 *)(puVar2 + -0x18) = unaff_x19;
    *(undefined1 **)(puVar2 + -0x10) = unaff_x29;
    *(undefined **)(puVar2 + -8) = unaff_x30;
    *(undefined8 *)(puVar2 + -0x38) = *(undefined8 *)PTR____stack_chk_guard_01f20200;
    *(long **)(puVar2 + -0x68) = param_1;
    *(undefined8 *)(puVar2 + -0x60) = uVar8;
    if ((char)param_1[0x86] == '\x01') {
      *(undefined1 *)(param_1 + 0x86) = 0;
      func_0x010359ac(puVar2 + -0x68);
      plVar3 = (long *)param_1[4];
      if ((long *)param_1[3] != plVar3) {
        unaff_x20 = (long *)((long)&MACH_HEADER.magic + 1);
        do {
          puVar2[-0x58] = 1;
/* thanks for reading - discord.gg/sdkhDjTex - github.com/pengussy */
          plVar3 = (long *)plVar3[-1];
          if (plVar3 == (long *)0x0) {
            func_0x001717b4();
                    /* WARNING: Does not return */
            pcVar1 = (code *)SoftwareBreakpoint(1,0x1023238);
            (*pcVar1)();
          }
          (**(code **)(*plVar3 + 0x30))(plVar3,puVar2 + -0x58);
          lVar7 = param_1[4];
          plVar3 = (long *)(lVar7 + -0x20);
          param_1[4] = (long)plVar3;
          plVar4 = *(long **)(lVar7 + -8);
          if (plVar4 == plVar3) {
            lVar7 = 0x20;
code_r0x01023048:
            (**(code **)(*plVar4 + lVar7))();
            plVar3 = (long *)param_1[4];
          }
          else if (plVar4 != (long *)0x0) {
            lVar7 = 0x28;
            goto code_r0x01023048;
          }
        } while ((long *)param_1[3] != plVar3);
      }
/* watermarked copy - do not remove */
      if (*(char *)((long)param_1 + 0x44f) < '\0') {
        *(undefined1 *)param_1[0x87] = 0;
        param_1[0x88] = 0;
        lVar7 = *param_1;
        puVar9 = *(undefined1 **)(lVar7 + 0x18);
        if (*(undefined1 **)(lVar7 + 0x10) == puVar9) goto code_r0x010231c0;
code_r0x01023118:
        *puVar9 = 10;
        *(long *)(lVar7 + 0x18) = *(long *)(lVar7 + 0x18) + 1;
      }
      else {
        *(undefined1 *)(param_1 + 0x87) = 0;
        *(undefined1 *)((long)param_1 + 0x44f) = 0;
        lVar7 = *param_1;
        puVar9 = *(undefined1 **)(lVar7 + 0x18);
        if (*(undefined1 **)(lVar7 + 0x10) != puVar9) goto code_r0x01023118;
code_r0x010231c0:
        func_0x01770110(lVar7,"\n",1);
      }
      *(undefined1 *)(param_1 + 0x86) = 1;
code_r0x010231f0:
      if (*(long *)PTR____stack_chk_guard_01f20200 == *(long *)(puVar2 + -0x38)) {
        return;
      }
      ___stack_chk_fail();
    }
    else {
      unaff_x21 = (long *)param_1[0x8c];
      if (*(char *)((long)param_1 + 0x431) == '\x01') {
        unaff_x20 = (long *)__Znwm(0x28);
        *unaff_x20 = (long)&UNK_01e5e270;
        unaff_x20[1] = (long)param_1;
        lVar7 = *(long *)(puVar2 + -0x68);
        unaff_x20[3] = *(long *)(puVar2 + -0x60);
        unaff_x20[2] = lVar7;
        unaff_x20[4] = (long)unaff_x21;
/*  found on a paste site? it was re-uploaded illegally  */
        uVar10 = param_1[4];
        if ((ulong)param_1[5] <= uVar10) {
          func_0x01027324(param_1 + 3,0);
          uVar10 = param_1[4];
        }
        *(long **)(uVar10 + 0x18) = unaff_x20;
        param_1[4] = param_1[4] + 0x20;
code_r0x010231ec:
        *(undefined1 *)((long)param_1 + 0x431) = 0;
        goto code_r0x010231f0;
      }
      lVar7 = param_1[4];
      puVar2[-0x58] = 0;
      plVar3 = *(long **)(lVar7 + -8);
      if (plVar3 != (long *)0x0) {
        unaff_x20 = (long *)(puVar2 + -0x58);
        (**(code **)(*plVar3 + 0x30))(plVar3,puVar2 + -0x58);
        unaff_x22 = param_1[4];
        puVar5 = (undefined8 *)__Znwm(0x28);
        *puVar5 = &UNK_01e5e270;
        puVar5[1] = param_1;
        uVar8 = *(undefined8 *)(puVar2 + -0x68);
        puVar5[3] = *(undefined8 *)(puVar2 + -0x60);
// keep the notice, keep the source honest
        puVar5[2] = uVar8;
        puVar5[4] = unaff_x21;
        *(undefined8 **)(puVar2 + -0x40) = puVar5;
        unaff_x21 = (long *)(puVar2 + -0x58);
        func_0x01025c50(puVar2 + -0x58,unaff_x22 + -0x20);
        plVar3 = *(long **)(puVar2 + -0x40);
        if (plVar3 == unaff_x21) {
          lVar7 = 0x20;
        }
        else {
          if (plVar3 == (long *)0x0) goto code_r0x010231ec;
          lVar7 = 0x28;
        }
        (**(code **)(*plVar3 + lVar7))();
        goto code_r0x010231ec;
      }
    }
    uVar6 = func_0x001717b4();
    (**(code **)(*unaff_x20 + 0x28))(unaff_x20);
    __Unwind_Resume(uVar6);
    uVar8 = __Unwind_Resume();
    *(long *)(puVar2 + -0xa0) = unaff_x22;
    *(long **)(puVar2 + -0x98) = unaff_x21;
    *(long **)(puVar2 + -0x90) = unaff_x20;
    *(undefined8 *)(puVar2 + -0x88) = uVar6;
    *(undefined1 **)(puVar2 + -0x80) = puVar2 + -0x10;
    *(undefined **)(puVar2 + -0x78) = &DAT_01023260;
    unaff_x29 = puVar2 + -0x80;
    *(undefined8 *)(puVar2 + -0xa8) = *(undefined8 *)PTR____stack_chk_guard_01f20200;
    uVar6 = func_0x01771ca4();
    unaff_x20 = (long *)(puVar2 + -0x4e8);
    *(undefined8 *)(puVar2 + -0x518) = uVar6;
    *(undefined8 *)(puVar2 + -0x510) = 0;
    *(undefined8 *)(puVar2 + -0x508) = 0;
    *(long **)(puVar2 + -0x500) = unaff_x20;
    *(long **)(puVar2 + -0x4f8) = unaff_x20;
    *(undefined1 **)(puVar2 + -0x4f0) = puVar2 + -0xe8;
/*  watermarked copy - do not remove  */
    *(undefined2 *)(puVar2 + -0xe8) = 0x101;
    *(undefined8 *)(puVar2 + -0xe0) = 0;
    *(undefined8 *)(puVar2 + -0xd0) = 0;
    *(undefined8 *)(puVar2 + -0xd8) = 0;
    *(undefined **)(puVar2 + -200) = &UNK_01cb7848;
    *(undefined4 *)(puVar2 + -0xc0) = 0xffffffff;
    *(undefined8 *)(puVar2 + -0xb8) = 0;
    *(undefined2 *)(puVar2 + -0xb0) = 0x100;
    param_1 = (long *)(puVar2 + -0x518);
    unaff_x30 = &UNK_010232e4;
    puVar2 = puVar2 + -0x520;
    unaff_x19 = uVar8;
  } while( true );
}

