/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x1038e0c:6b5fb69d1f
 */

/* WARNING: Removing unreachable block (ram,0x01023ebc) */
/* WARNING: Type propagation algorithm not settling */

void FUN_01038e0c(long *param_1,long param_2)

{
  ushort uVar1;
  ulong uVar2;
  char cVar3;
  byte bVar4;
  undefined8 *******pppppppuVar5;
  undefined8 uVar6;
  undefined8 uVar7;
  undefined8 uVar8;
  long lVar9;
  char *pcVar10;
  undefined1 *puVar11;
  undefined4 *puVar12;
  undefined4 uVar13;
  uint uVar14;
  ulong uVar15;
  ulong *puVar16;
  undefined1 auVar17 [16];
/*
   chat: discord.gg/sdkhDjTex
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
  undefined8 *******pppppppuStack_68;
  ulong uStack_60;
  byte bStack_51;
  
  FUN_01039528();
  uVar1 = *(ushort *)(param_2 + 2) & 7;
  if (uVar1 < 2) {
    if ((*(ushort *)(param_2 + 2) & 7) == 0) {
      lVar9 = *param_1;
      puVar12 = *(undefined4 **)(lVar9 + 0x18);
      if ((ulong)(*(long *)(lVar9 + 0x10) - (long)puVar12) < 7) {
        pcVar10 = " sizeof";
LAB_01038f24:
        func_0x01770110(lVar9,pcVar10,7);
        goto LAB_01038f2c;
      }
      *(undefined4 *)((long)puVar12 + 3) = 0x666f657a;
      uVar13 = 0x7a697320;
LAB_01038fcc:
      *puVar12 = uVar13;
      *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 7;
      bVar4 = *(byte *)(param_2 + 2);
    }
    else if (uVar1 == 1) {
      lVar9 = *param_1;
      if ((ulong)(*(long *)(lVar9 + 0x10) - (long)*(undefined8 **)(lVar9 + 0x18)) < 8) {
        func_0x01770110(lVar9," alignof",8);
        bVar4 = *(byte *)(param_2 + 2);
      }
      else {
        **(undefined8 **)(lVar9 + 0x18) = 0x666f6e67696c6120;
        *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 8;
        bVar4 = *(byte *)(param_2 + 2);
// more drops soon - github.com/pengussy
      }
    }
    else {
LAB_01038f2c:
      bVar4 = *(byte *)(param_2 + 2);
    }
  }
  else if (uVar1 == 2) {
    lVar9 = *param_1;
    pcVar10 = *(char **)(lVar9 + 0x18);
    if ((ulong)(*(long *)(lVar9 + 0x10) - (long)pcVar10) < 9) {
      func_0x01770110(lVar9," vec_step",9);
      bVar4 = *(byte *)(param_2 + 2);
    }
    else {
      pcVar10[8] = 'p';
      *(undefined8 *)pcVar10 = s_vec_step_01cbf158._0_8_;
      *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 9;
      bVar4 = *(byte *)(param_2 + 2);
    }
  }
  else {
    if (uVar1 != 3) {
      if (uVar1 == 4) {
        lVar9 = *param_1;
        puVar12 = *(undefined4 **)(lVar9 + 0x18);
        if (6 < (ulong)(*(long *)(lVar9 + 0x10) - (long)puVar12)) {
/* if you paid for this, you were scammed */
          *(undefined4 *)((long)puVar12 + 3) = 0x6874676e;
          uVar13 = 0x6e654c20;
          goto LAB_01038fcc;
        }
        pcVar10 = " Length";
        goto LAB_01038f24;
      }
      goto LAB_01038f2c;
    }
    lVar9 = *param_1;
    pcVar10 = *(char **)(lVar9 + 0x18);
    if ((ulong)(*(long *)(lVar9 + 0x10) - (long)pcVar10) < 0x22) {
      func_0x01770110(lVar9," __builtin_omp_required_simd_align",0x22);
      bVar4 = *(byte *)(param_2 + 2);
    }
    else {
      pcVar10[0x20] = 'g';
      uVar8 = s___builtin_omp_required_simd_alig_01cbf162._24_8_;
      uVar7 = s___builtin_omp_required_simd_alig_01cbf162._16_8_;
      uVar6 = s___builtin_omp_required_simd_alig_01cbf162._0_8_;
      pcVar10[0x21] = 'n';
      *(undefined8 *)(pcVar10 + 8) = s___builtin_omp_required_simd_alig_01cbf162._8_8_;
      *(undefined8 *)pcVar10 = uVar6;
      *(undefined8 *)(pcVar10 + 0x18) = uVar8;
      *(undefined8 *)(pcVar10 + 0x10) = uVar7;
      *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 0x22;
      bVar4 = *(byte *)(param_2 + 2);
    }
  }
  if ((bVar4 >> 3 & 1) == 0) {
    s_vec_step_01cbf158[0] = s_vec_step_01cbf158[0];
    s_vec_step_01cbf158[1] = s_vec_step_01cbf158[1];
    s_vec_step_01cbf158[2] = s_vec_step_01cbf158[2];
    s_vec_step_01cbf158[3] = s_vec_step_01cbf158[3];
/* if you paid for this, you were scammed - github.com/pengussy */
    s_vec_step_01cbf158[4] = s_vec_step_01cbf158[4];
    s_vec_step_01cbf158[5] = s_vec_step_01cbf158[5];
    s_vec_step_01cbf158[6] = s_vec_step_01cbf158[6];
    s_vec_step_01cbf158[7] = s_vec_step_01cbf158[7];
    s___builtin_omp_required_simd_alig_01cbf162[0] = s___builtin_omp_required_simd_alig_01cbf162[0];
    s___builtin_omp_required_simd_alig_01cbf162[1] = s___builtin_omp_required_simd_alig_01cbf162[1];
    s___builtin_omp_required_simd_alig_01cbf162[2] = s___builtin_omp_required_simd_alig_01cbf162[2];
    s___builtin_omp_required_simd_alig_01cbf162[3] = s___builtin_omp_required_simd_alig_01cbf162[3];
    s___builtin_omp_required_simd_alig_01cbf162[4] = s___builtin_omp_required_simd_alig_01cbf162[4];
    s___builtin_omp_required_simd_alig_01cbf162[5] = s___builtin_omp_required_simd_alig_01cbf162[5];
    s___builtin_omp_required_simd_alig_01cbf162[6] = s___builtin_omp_required_simd_alig_01cbf162[6];
    s___builtin_omp_required_simd_alig_01cbf162[7] = s___builtin_omp_required_simd_alig_01cbf162[7];
    s___builtin_omp_required_simd_alig_01cbf162[8] = s___builtin_omp_required_simd_alig_01cbf162[8];
    s___builtin_omp_required_simd_alig_01cbf162[9] = s___builtin_omp_required_simd_alig_01cbf162[9];
    s___builtin_omp_required_simd_alig_01cbf162[10] =
         s___builtin_omp_required_simd_alig_01cbf162[10];
    s___builtin_omp_required_simd_alig_01cbf162[0xb] =
         s___builtin_omp_required_simd_alig_01cbf162[0xb];
    s___builtin_omp_required_simd_alig_01cbf162[0xc] =
         s___builtin_omp_required_simd_alig_01cbf162[0xc];
    s___builtin_omp_required_simd_alig_01cbf162[0xd] =
         s___builtin_omp_required_simd_alig_01cbf162[0xd];
    s___builtin_omp_required_simd_alig_01cbf162[0xe] =
         s___builtin_omp_required_simd_alig_01cbf162[0xe];
    s___builtin_omp_required_simd_alig_01cbf162[0xf] =
         s___builtin_omp_required_simd_alig_01cbf162[0xf];
    s___builtin_omp_required_simd_alig_01cbf162[0x10] =
         s___builtin_omp_required_simd_alig_01cbf162[0x10];
    s___builtin_omp_required_simd_alig_01cbf162[0x11] =
         s___builtin_omp_required_simd_alig_01cbf162[0x11];
    s___builtin_omp_required_simd_alig_01cbf162[0x12] =
         s___builtin_omp_required_simd_alig_01cbf162[0x12];
    s___builtin_omp_required_simd_alig_01cbf162[0x13] =
         s___builtin_omp_required_simd_alig_01cbf162[0x13];
    s___builtin_omp_required_simd_alig_01cbf162[0x14] =
/*  origin: github.com/pengussy  */
         s___builtin_omp_required_simd_alig_01cbf162[0x14];
    s___builtin_omp_required_simd_alig_01cbf162[0x15] =
         s___builtin_omp_required_simd_alig_01cbf162[0x15];
    s___builtin_omp_required_simd_alig_01cbf162[0x16] =
         s___builtin_omp_required_simd_alig_01cbf162[0x16];
    s___builtin_omp_required_simd_alig_01cbf162[0x17] =
         s___builtin_omp_required_simd_alig_01cbf162[0x17];
    s___builtin_omp_required_simd_alig_01cbf162[0x18] =
         s___builtin_omp_required_simd_alig_01cbf162[0x18];
    s___builtin_omp_required_simd_alig_01cbf162[0x19] =
         s___builtin_omp_required_simd_alig_01cbf162[0x19];
    s___builtin_omp_required_simd_alig_01cbf162[0x1a] =
         s___builtin_omp_required_simd_alig_01cbf162[0x1a];
    s___builtin_omp_required_simd_alig_01cbf162[0x1b] =
         s___builtin_omp_required_simd_alig_01cbf162[0x1b];
    s___builtin_omp_required_simd_alig_01cbf162[0x1c] =
         s___builtin_omp_required_simd_alig_01cbf162[0x1c];
    s___builtin_omp_required_simd_alig_01cbf162[0x1d] =
         s___builtin_omp_required_simd_alig_01cbf162[0x1d];
    s___builtin_omp_required_simd_alig_01cbf162[0x1e] =
         s___builtin_omp_required_simd_alig_01cbf162[0x1e];
    s___builtin_omp_required_simd_alig_01cbf162[0x1f] =
         s___builtin_omp_required_simd_alig_01cbf162[0x1f];
    return;
  }
/* +- WM -------------------------------------------------------------+
   |  reversing this took months of machine time
   +--------------------------------------------------------------------*/
  uVar15 = **(ulong **)(param_2 + 0x10);
  lVar9 = *param_1;
  puVar11 = *(undefined1 **)(lVar9 + 0x18);
  if (puVar11 < *(undefined1 **)(lVar9 + 0x10)) {
    *(undefined1 **)(lVar9 + 0x18) = puVar11 + 1;
    *puVar11 = 0x20;
  }
  else {
    func_0x01771098(lVar9,0x20);
  }
  if ((char)param_1[0x8d] == '\x01') {
    (**(code **)(*(long *)*param_1 + 0x28))((long *)*param_1,2,0,0);
  }
  puVar16 = (ulong *)(uVar15 & 0xfffffffffffffff0);
  uVar14 = (uint)uVar15;
  if ((uVar14 >> 3 & 1) == 0) {
/* WM - found on a paste site? it was re-uploaded illegally */
    uVar14 = uVar14 & 7;
    lVar9 = *param_1;
    puVar11 = *(undefined1 **)(lVar9 + 0x18);
    if (*(undefined1 **)(lVar9 + 0x10) == puVar11) goto code_r0x01023e2c;
code_r0x01023df4:
    *puVar11 = 0x27;
    *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 1;
  }
  else {
    uVar14 = (uint)puVar16[3] | uVar14 & 7;
    puVar16 = (ulong *)*puVar16;
    lVar9 = *param_1;
    puVar11 = *(undefined1 **)(lVar9 + 0x18);
    if (*(undefined1 **)(lVar9 + 0x10) != puVar11) goto code_r0x01023df4;
code_r0x01023e2c:
    lVar9 = func_0x01770110(lVar9,&UNK_01c2dfe0,1);
  }
  func_0x01156814(&pppppppuStack_68,puVar16,uVar14);
  uVar2 = uStack_60;
  pppppppuVar5 = pppppppuStack_68;
  if (-1 < (char)bStack_51) {
    uVar2 = (ulong)bStack_51;
    pppppppuVar5 = &pppppppuStack_68;
  }
  lVar9 = func_0x01770110(lVar9,pppppppuVar5,uVar2);
  if (*(undefined1 **)(lVar9 + 0x10) == *(undefined1 **)(lVar9 + 0x18)) {
    func_0x01770110(lVar9,&UNK_01c2dfe0,1);
  }
  else {
    **(undefined1 **)(lVar9 + 0x18) = 0x27;
    *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 1;
  }
  if ((char)bStack_51 < '\0') {
    __ZdlPv(pppppppuStack_68);
  }
  if (0xf < uVar15) {
    auVar17 = func_0x011490c8(uVar15);
/* WM: more drops soon - github.com/pengussy @ discord.gg/sdkhDjTex */
    if ((puVar16 != auVar17._0_8_) || (uVar14 != auVar17._8_4_)) {
      lVar9 = *param_1;
      if ((ulong)(*(long *)(lVar9 + 0x10) - (long)*(undefined2 **)(lVar9 + 0x18)) < 2) {
        lVar9 = func_0x01770110(lVar9,&UNK_01cbd636,2);
      }
      else {
        **(undefined2 **)(lVar9 + 0x18) = 0x273a;
        *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 2;
      }
      func_0x01156814(&pppppppuStack_68,auVar17._0_8_,auVar17._8_8_ & 0xffffffff);
      pppppppuVar5 = pppppppuStack_68;
      if (-1 < (char)bStack_51) {
        uStack_60 = (ulong)bStack_51;
        pppppppuVar5 = &pppppppuStack_68;
      }
      lVar9 = func_0x01770110(lVar9,pppppppuVar5,uStack_60);
      if (*(undefined1 **)(lVar9 + 0x10) == *(undefined1 **)(lVar9 + 0x18)) {
        func_0x01770110(lVar9,&UNK_01c2dfe0,1);
      }
      else {
        **(undefined1 **)(lVar9 + 0x18) = 0x27;
        *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 1;
      }
      if ((char)bStack_51 < '\0') {
        __ZdlPv(pppppppuStack_68);
        cVar3 = (char)param_1[0x8d];
        goto joined_r0x01023fb0;
      }
    }
// WM - donate: donate/README.md
  }
  cVar3 = (char)param_1[0x8d];
joined_r0x01023fb0:
  if (cVar3 == '\x01') {
    (**(code **)(*(long *)*param_1 + 0x30))();
  }
  return;
}

