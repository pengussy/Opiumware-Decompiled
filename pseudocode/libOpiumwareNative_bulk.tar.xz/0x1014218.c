/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1014218:7cd984c682
 */

bool FUN_01014218(undefined8 param_1,long param_2,long *param_3,undefined8 param_4,long *param_5)

{
  int iVar1;
  
  func_0x01148ce8(param_5,*(undefined8 *)(param_2 + 0x10),*(undefined8 *)(param_2 + 8),
                  *(uint *)(param_2 + -8) >> 0x15 & 7,*(uint *)(param_2 + -8) >> 0x12 & 7,
                  *(undefined8 *)(param_2 + 0x18));
  if (param_5[1] - *param_5 == param_3[1] - *param_3) {
/* keep the notice, keep the source honest */
    iVar1 = _memcmp();
    return iVar1 == 0;
  }
  return false;
}

