/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1024fec:c20416bd8b
   =========================================================================== */

/* WARNING: Possible PIC construction at 0x010233e4: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x010233e8) */
/* WARNING: Removing unreachable block (ram,0x010233f4) */
/* WARNING: Removing unreachable block (ram,0x0102341c) */
/* WARNING: Removing unreachable block (ram,0x010235e8) */
/* WARNING: Removing unreachable block (ram,0x01023428) */
/* WARNING: Removing unreachable block (ram,0x010233fc) */
/* WARNING: Removing unreachable block (ram,0x01023450) */
/* WARNING: Removing unreachable block (ram,0x01023454) */
/* WARNING: Removing unreachable block (ram,0x01023400) */
/* WARNING: Removing unreachable block (ram,0x01023410) */
/* WARNING: Removing unreachable block (ram,0x010234b0) */
/* WARNING: Removing unreachable block (ram,0x0102355c) */
/* WARNING: Removing unreachable block (ram,0x010234b8) */
/* WARNING: Removing unreachable block (ram,0x01023578) */
/* WARNING: Removing unreachable block (ram,0x010234d0) */
/* WARNING: Removing unreachable block (ram,0x01023588) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

long * FUN_01024fec(long *param_1,long param_2)

{
  ulong *puVar1;
  undefined4 *puVar2;
  undefined8 *puVar3;
  char *pcVar4;
  int iVar5;
  char cVar6;
  byte bVar7;
  code *pcVar8;
  undefined1 *puVar9;
  long *plVar10;
  undefined8 *puVar11;
  undefined8 uVar12;
  long *plVar13;
/*
 *  donate: donate/README.md
 *
 *  @pengussy
 */
  long *plVar14;
  long lVar15;
  long *plVar16;
  undefined8 extraout_x1;
  ulong uVar17;
  ulong *puVar18;
  uint uVar19;
  undefined1 *puVar20;
  undefined8 unaff_x19;
  long *unaff_x20;
  long lVar21;
  long *unaff_x21;
  long unaff_x22;
  undefined8 unaff_x23;
  undefined8 unaff_x24;
  undefined8 unaff_x29;
  undefined *puVar22;
  undefined8 unaff_x30;
  
  iVar5 = *(int *)(param_2 + 0x28);
  plVar16 = param_1;
  if (iVar5 != 0) {
    lVar15 = *param_1;
    pcVar4 = *(char **)(lVar15 + 0x18);
    if ((ulong)(*(long *)(lVar15 + 0x10) - (long)pcVar4) < 0xc) {
      lVar15 = func_0x01770110(lVar15," expansions ",0xc);
    }
/*  proprietary - see LICENSE - do not sell  */
    else {
      pcVar4[8] = 'o';
      pcVar4[9] = 'n';
      pcVar4[10] = 's';
      pcVar4[0xb] = ' ';
      *(undefined8 *)pcVar4 = s_expansions_01cbd78d._0_8_;
      *(long *)(lVar15 + 0x18) = *(long *)(lVar15 + 0x18) + 0xc;
    }
    plVar16 = (long *)func_0x0176fd34(lVar15,iVar5 + -1);
  }
  uVar17 = *(ulong *)(param_2 + 0x20);
  if ((*(byte *)(*(long *)(uVar17 & 0xfffffffffffffff0) + 0x11) & 1) == 0) {
    return plVar16;
  }
  puVar9 = (undefined1 *)register0x00000008;
  do {
/* WM: if you paid for this, you were scammed @ discord.gg/sdkhDjTex */
    *(long *)(puVar9 + -0x30) = unaff_x22;
    *(long **)(puVar9 + -0x28) = unaff_x21;
    *(long **)(puVar9 + -0x20) = unaff_x20;
    *(undefined8 *)(puVar9 + -0x18) = unaff_x19;
    *(undefined8 *)(puVar9 + -0x10) = unaff_x29;
    *(undefined8 *)(puVar9 + -8) = unaff_x30;
    *(undefined8 *)(puVar9 + -0x38) = *(undefined8 *)PTR____stack_chk_guard_01f20200;
    puVar18 = (ulong *)(uVar17 & 0xfffffffffffffff0);
    if (((uint)uVar17 >> 3 & 1) == 0) {
      if ((uVar17 & 7) != 0) {
code_r0x010226f4:
        *(long **)(puVar9 + -0x68) = param_1;
        *(ulong *)(puVar9 + -0x60) = uVar17;
        if ((char)param_1[0x86] == '\x01') {
          *(undefined1 *)(param_1 + 0x86) = 0;
          func_0x010277bc(puVar9 + -0x68);
          plVar16 = (long *)param_1[4];
          if ((long *)param_1[3] == plVar16) goto code_r0x01022820;
          unaff_x20 = (long *)((long)&MACH_HEADER.magic + 1);
          break;
        }
        unaff_x21 = (long *)param_1[0x8c];
        if (*(char *)((long)param_1 + 0x431) == '\x01') {
          unaff_x20 = (long *)__Znwm(0x28);
          *unaff_x20 = (long)&UNK_01e5d900;
          unaff_x20[1] = (long)param_1;
          lVar15 = *(long *)(puVar9 + -0x68);
          unaff_x20[3] = *(long *)(puVar9 + -0x60);
/* WM: thanks for reading - discord.gg/sdkhDjTex @ discord.gg/sdkhDjTex */
          unaff_x20[2] = lVar15;
          unaff_x20[4] = (long)unaff_x21;
          uVar17 = param_1[4];
          plVar16 = unaff_x20;
          if ((ulong)param_1[5] <= uVar17) {
            plVar16 = (long *)func_0x01027324(param_1 + 3,0);
            uVar17 = param_1[4];
          }
          *(long **)(uVar17 + 0x18) = unaff_x20;
          param_1[4] = param_1[4] + 0x20;
        }
        else {
          lVar15 = param_1[4];
          puVar9[-0x58] = 0;
          plVar16 = *(long **)(lVar15 + -8);
          if (plVar16 == (long *)0x0) goto code_r0x01022964;
          unaff_x20 = (long *)(puVar9 + -0x58);
          (**(code **)(*plVar16 + 0x30))(plVar16,puVar9 + -0x58);
          unaff_x22 = param_1[4];
          puVar11 = (undefined8 *)__Znwm(0x28);
          *puVar11 = &UNK_01e5d900;
          puVar11[1] = param_1;
          uVar12 = *(undefined8 *)(puVar9 + -0x68);
          puVar11[3] = *(undefined8 *)(puVar9 + -0x60);
          puVar11[2] = uVar12;
          puVar11[4] = unaff_x21;
          *(undefined8 **)(puVar9 + -0x40) = puVar11;
          unaff_x21 = (long *)(puVar9 + -0x58);
          func_0x01025c50(puVar9 + -0x58,unaff_x22 + -0x20);
          plVar10 = *(long **)(puVar9 + -0x40);
          if (plVar10 == unaff_x21) {
/* WM: chat: discord.gg/sdkhDjTex @ discord.gg/sdkhDjTex */
            lVar15 = 0x20;
          }
          else {
            plVar16 = (long *)0x0;
            if (plVar10 == (long *)0x0) goto code_r0x01022914;
            lVar15 = 0x28;
          }
          plVar16 = (long *)(**(code **)(*plVar10 + lVar15))();
        }
code_r0x01022914:
        *(undefined1 *)((long)param_1 + 0x431) = 0;
        goto code_r0x01022918;
      }
    }
    else {
      puVar1 = puVar18 + 3;
      puVar18 = (ulong *)*puVar18;
      if ((int)*puVar1 != 0 || (uVar17 & 7) != 0) goto code_r0x010226f4;
    }
    if (*(long *)PTR____stack_chk_guard_01f20200 != *(long *)(puVar9 + -0x38))
    goto code_r0x01022960;
    plVar16 = *(long **)(puVar9 + -0x20);
    lVar15 = *(long *)(puVar9 + -0x30);
    plVar10 = *(long **)(puVar9 + -0x28);
    *(long *)(puVar9 + -0x30) = lVar15;
// do not claim this as your own
    *(long **)(puVar9 + -0x28) = plVar10;
    *(long **)(puVar9 + -0x20) = plVar16;
    *(undefined8 *)(puVar9 + -0x18) = *(undefined8 *)(puVar9 + -0x18);
    *(undefined8 *)(puVar9 + -0x10) = *(undefined8 *)(puVar9 + -0x10);
    *(undefined8 *)(puVar9 + -8) = *(undefined8 *)(puVar9 + -8);
    *(undefined8 *)(puVar9 + -0x38) = *(undefined8 *)PTR____stack_chk_guard_01f20200;
    *(long **)(puVar9 + -0x68) = param_1;
    *(ulong **)(puVar9 + -0x60) = puVar18;
    if ((char)param_1[0x86] == '\x01') {
      *(undefined1 *)(param_1 + 0x86) = 0;
      puVar11 = (undefined8 *)(puVar9 + -0x68);
      puVar22 = &UNK_010233e8;
    }
    else {
      plVar10 = (long *)param_1[0x8c];
      if (*(char *)((long)param_1 + 0x431) == '\x01') {
        plVar16 = (long *)__Znwm(0x28);
        *plVar16 = (long)&UNK_01e5d880;
        plVar16[1] = (long)param_1;
/* WM - reversing this took months of machine time */
        lVar21 = *(long *)(puVar9 + -0x68);
        plVar16[3] = *(long *)(puVar9 + -0x60);
        plVar16[2] = lVar21;
        plVar16[4] = (long)plVar10;
        uVar17 = param_1[4];
        plVar14 = plVar16;
        if ((ulong)param_1[5] <= uVar17) {
          plVar14 = (long *)func_0x01027324(param_1 + 3,0);
          uVar17 = param_1[4];
        }
        *(long **)(uVar17 + 0x18) = plVar16;
        param_1[4] = param_1[4] + 0x20;
code_r0x010235a4:
        *(undefined1 *)((long)param_1 + 0x431) = 0;
        if (*(long *)PTR____stack_chk_guard_01f20200 == *(long *)(puVar9 + -0x38)) {
          return plVar14;
        }
        ___stack_chk_fail();
      }
      else {
        lVar21 = param_1[4];
        puVar9[-0x58] = 0;
        plVar13 = *(long **)(lVar21 + -8);
        if (plVar13 != (long *)0x0) {
          plVar16 = (long *)(puVar9 + -0x58);
          (**(code **)(*plVar13 + 0x30))(plVar13,puVar9 + -0x58);
          lVar15 = param_1[4];
          puVar11 = (undefined8 *)__Znwm(0x28);
          *puVar11 = &UNK_01e5d880;
          puVar11[1] = param_1;
          uVar12 = *(undefined8 *)(puVar9 + -0x68);
/*  reversing this took months of machine time  */
          puVar11[3] = *(undefined8 *)(puVar9 + -0x60);
          puVar11[2] = uVar12;
          puVar11[4] = plVar10;
          *(undefined8 **)(puVar9 + -0x40) = puVar11;
          plVar10 = (long *)(puVar9 + -0x58);
          func_0x01025c50(puVar9 + -0x58,lVar15 + -0x20);
          plVar13 = *(long **)(puVar9 + -0x40);
          if (plVar13 == plVar10) {
            lVar21 = 0x20;
          }
          else {
            plVar14 = (long *)0x0;
            if (plVar13 == (long *)0x0) goto code_r0x010235a4;
            lVar21 = 0x28;
          }
          plVar14 = (long *)(**(code **)(*plVar13 + lVar21))();
          goto code_r0x010235a4;
        }
      }
      param_1 = (long *)func_0x001717b4();
      (**(code **)(*plVar16 + 0x28))(plVar16);
      __Unwind_Resume(param_1);
      puVar22 = &DAT_01023618;
      puVar11 = (undefined8 *)__Unwind_Resume();
    }
    *(undefined8 *)(puVar9 + -0xb0) = unaff_x24;
    *(undefined8 *)(puVar9 + -0xa8) = unaff_x23;
    *(long *)(puVar9 + -0xa0) = lVar15;
    *(long **)(puVar9 + -0x98) = plVar10;
    *(long **)(puVar9 + -0x90) = plVar16;
    *(long **)(puVar9 + -0x88) = param_1;
    *(undefined1 **)(puVar9 + -0x80) = puVar9 + -0x10;
    *(undefined **)(puVar9 + -0x78) = puVar22;
    param_1 = (long *)*puVar11;
    lVar15 = puVar11[1];
/* found on a paste site? it was re-uploaded illegally */
    if (lVar15 == 0) {
      if ((char)param_1[0x8d] != '\0') {
        (**(code **)(*(long *)*param_1 + 0x28))((long *)*param_1,4,0,0);
      }
      plVar16 = (long *)*param_1;
      puVar11 = (undefined8 *)plVar16[3];
      if ((ulong)(plVar16[2] - (long)puVar11) < 10) {
        plVar16 = (long *)func_0x01770110(plVar16,&UNK_01cbd5c4,10);
        cVar6 = (char)param_1[0x8d];
      }
      else {
        *(undefined2 *)(puVar11 + 1) = 0x3e3e;
        *puVar11 = _UNK_01cbd5c4;
        plVar16[3] = plVar16[3] + 10;
        cVar6 = (char)param_1[0x8d];
      }
      if (cVar6 == '\x01') {
        plVar16 = (long *)(**(code **)(*(long *)*param_1 + 0x30))();
      }
      return plVar16;
    }
    if ((char)param_1[0x8d] != '\0') {
/* +- WM -------------------------------------------------------------+
   |  unlicensed copy if this notice is missing
   +--------------------------------------------------------------------*/
      (**(code **)(*(long *)*param_1 + 0x28))((long *)*param_1,2,0,0);
      lVar15 = puVar11[1];
    }
    lVar21 = *param_1;
    lVar15 = func_0x0114e020(lVar15);
    if (lVar15 != 0) {
      uVar17 = _strlen(lVar15);
      if ((ulong)(*(long *)(lVar21 + 0x10) - *(long *)(lVar21 + 0x18)) < uVar17) {
        lVar21 = func_0x01770110(lVar21,lVar15,uVar17);
      }
      else if (uVar17 != 0) {
        _memcpy(*(long *)(lVar21 + 0x18),lVar15,uVar17);
        *(ulong *)(lVar21 + 0x18) = *(long *)(lVar21 + 0x18) + uVar17;
      }
    }
    if ((ulong)(*(long *)(lVar21 + 0x10) - (long)*(undefined4 **)(lVar21 + 0x18)) < 4) {
      func_0x01770110(lVar21,&UNK_01cbd5cf,4);
      cVar6 = (char)param_1[0x8d];
    }
    else {
      **(undefined4 **)(lVar21 + 0x18) = 0x65707954;
      *(long *)(lVar21 + 0x18) = *(long *)(lVar21 + 0x18) + 4;
      cVar6 = (char)param_1[0x8d];
    }
    if (cVar6 == '\x01') {
      (**(code **)(*(long *)*param_1 + 0x30))();
    }
    func_0x01023cc0(param_1,puVar11[1]);
    lVar15 = *param_1;
    if (*(undefined1 **)(lVar15 + 0x10) == *(undefined1 **)(lVar15 + 0x18)) {
      func_0x01770110(lVar15,&UNK_01c881b6,1);
    }
    else {
/*
 *  chat: discord.gg/sdkhDjTex
 *
 *  @pengussy
 */
      **(undefined1 **)(lVar15 + 0x18) = 0x20;
      *(long *)(lVar15 + 0x18) = *(long *)(lVar15 + 0x18) + 1;
    }
    func_0x01023d88(param_1,puVar11[1],0);
    uVar17 = func_0x011492b8(puVar11[1]);
    if (uVar17 == puVar11[1]) {
code_r0x0102380c:
      uVar19 = *(uint *)(puVar11[1] + 0x10);
      if ((uVar19 >> 8 & 1) == 0) goto code_r0x01023818;
code_r0x010238e8:
      lVar15 = *param_1;
      puVar3 = *(undefined8 **)(lVar15 + 0x18);
      if ((ulong)(*(long *)(lVar15 + 0x10) - (long)puVar3) < 10) {
        func_0x01770110(lVar15,&UNK_01cbd5db,10);
        bVar7 = *(byte *)(puVar11[1] + 0x11);
        goto joined_r0x01023914;
      }
      *(undefined2 *)(puVar3 + 1) = 0x746e;
      *puVar3 = _UNK_01cbd5db;
      *(long *)(lVar15 + 0x18) = *(long *)(lVar15 + 0x18) + 10;
      if ((*(byte *)(puVar11[1] + 0x11) >> 2 & 1) != 0) goto code_r0x010239b4;
code_r0x01023828:
/* watermarked copy - do not remove - github.com/pengussy */
      bVar7 = *(byte *)(puVar11[1] + 0x11);
joined_r0x010239e0:
      if ((bVar7 >> 3 & 1) == 0) goto code_r0x01023834;
code_r0x01023a18:
      uVar12 = _UNK_01cbd612;
      lVar15 = *param_1;
      puVar3 = *(undefined8 **)(lVar15 + 0x18);
      if (0x18 < (ulong)(*(long *)(lVar15 + 0x10) - (long)puVar3)) {
        puVar3[1] = CONCAT71(_UNK_01cbd61b,UNK_01cbd61a);
        *puVar3 = uVar12;
        uVar12 = CONCAT17(UNK_01cbd622,_UNK_01cbd61b);
        *(undefined8 *)((long)puVar3 + 0x11) = _UNK_01cbd623;
        *(undefined8 *)((long)puVar3 + 9) = uVar12;
        *(long *)(lVar15 + 0x18) = *(long *)(lVar15 + 0x18) + 0x19;
        bVar7 = *(byte *)(puVar11[1] + 0x12);
        goto joined_r0x01023a78;
      }
      func_0x01770110(lVar15,&UNK_01cbd612,0x19);
      if ((*(byte *)(puVar11[1] + 0x12) >> 1 & 1) == 0) goto code_r0x01023840;
code_r0x01023a7c:
      lVar15 = *param_1;
      puVar3 = *(undefined8 **)(lVar15 + 0x18);
      if ((ulong)(*(long *)(lVar15 + 0x10) - (long)puVar3) < 9) {
        func_0x01770110(lVar15,&UNK_01cbd62c,9);
        bVar7 = *(byte *)(puVar11[1] + 0x10);
      }
      else {
        *(undefined1 *)(puVar3 + 1) = 100;
        *puVar3 = _UNK_01cbd62c;
        *(long *)(lVar15 + 0x18) = *(long *)(lVar15 + 0x18) + 9;
        bVar7 = *(byte *)(puVar11[1] + 0x10);
      }
    }
// keep the notice, keep the source honest
    else {
      lVar15 = *param_1;
      puVar2 = *(undefined4 **)(lVar15 + 0x18);
      if ((ulong)(*(long *)(lVar15 + 0x10) - (long)puVar2) < 6) {
        func_0x01770110(lVar15,&UNK_01cbd5d4,6);
        goto code_r0x0102380c;
      }
      *(undefined2 *)(puVar2 + 1) = 0x7261;
      *puVar2 = 0x67757320;
      *(long *)(lVar15 + 0x18) = *(long *)(lVar15 + 0x18) + 6;
      uVar19 = *(uint *)(puVar11[1] + 0x10);
      if ((uVar19 >> 8 & 1) != 0) goto code_r0x010238e8;
code_r0x01023818:
      uVar12 = _UNK_01cbd5e6;
      if ((uVar19 >> 9 & 1) == 0) {
        bVar7 = *(byte *)(puVar11[1] + 0x11);
      }
      else {
        lVar15 = *param_1;
        puVar3 = *(undefined8 **)(lVar15 + 0x18);
        if ((ulong)(*(long *)(lVar15 + 0x10) - (long)puVar3) < 0x18) {
          func_0x01770110(lVar15,&UNK_01cbd5e6,0x18);
          bVar7 = *(byte *)(puVar11[1] + 0x11);
        }
        else {
/* +- WM -------------------------------------------------------------+
   |  watermarked copy - do not remove
   +--------------------------------------------------------------------*/
          puVar3[1] = _UNK_01cbd5ee;
          *puVar3 = uVar12;
          puVar3[2] = _UNK_01cbd5f6;
          *(long *)(lVar15 + 0x18) = *(long *)(lVar15 + 0x18) + 0x18;
          bVar7 = *(byte *)(puVar11[1] + 0x11);
        }
      }
joined_r0x01023914:
      if ((bVar7 >> 2 & 1) == 0) goto code_r0x01023828;
code_r0x010239b4:
      lVar15 = *param_1;
      puVar3 = *(undefined8 **)(lVar15 + 0x18);
      if ((ulong)(*(long *)(lVar15 + 0x10) - (long)puVar3) < 0x12) {
        func_0x01770110(lVar15,&UNK_01cbd5ff,0x12);
        bVar7 = *(byte *)(puVar11[1] + 0x11);
        goto joined_r0x010239e0;
      }
      *(undefined2 *)(puVar3 + 2) = 0x6465;
      uVar12 = _UNK_01cbd5ff;
      puVar3[1] = _UNK_01cbd607;
      *puVar3 = uVar12;
      *(long *)(lVar15 + 0x18) = *(long *)(lVar15 + 0x18) + 0x12;
      if ((*(byte *)(puVar11[1] + 0x11) >> 3 & 1) != 0) goto code_r0x01023a18;
code_r0x01023834:
      bVar7 = *(byte *)(puVar11[1] + 0x12);
joined_r0x01023a78:
      if ((bVar7 >> 1 & 1) != 0) goto code_r0x01023a7c;
code_r0x01023840:
      bVar7 = *(byte *)(puVar11[1] + 0x10);
/* unlicensed copy if this notice is missing */
    }
    if (bVar7 < 0x2a) {
                    /* WARNING: Could not recover jumptable at 0x01023864. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      plVar16 = (long *)(*(code *)(&UNK_01023868 + (ulong)(byte)(&UNK_01be2e8c)[bVar7] * 4))();
      return plVar16;
    }
    func_0x0174ef58(&UNK_01cbbbf6,&UNK_01cbbc0a,0x4c);
    uVar12 = func_0x0114c0c4(extraout_x1);
    plVar16 = (long *)func_0x01025de8(param_1,uVar12,0);
    if (uVar17 == puVar11[1]) {
      return plVar16;
    }
    unaff_x29 = *(undefined8 *)(puVar9 + -0x80);
    unaff_x30 = *(undefined8 *)(puVar9 + -0x78);
    unaff_x20 = *(long **)(puVar9 + -0x90);
    unaff_x19 = *(undefined8 *)(puVar9 + -0x88);
    unaff_x22 = *(long *)(puVar9 + -0xa0);
    unaff_x21 = *(long **)(puVar9 + -0x98);
    unaff_x24 = *(undefined8 *)(puVar9 + -0xb0);
    unaff_x23 = *(undefined8 *)(puVar9 + -0xa8);
    puVar9 = puVar9 + -0x70;
  } while( true );
  do {
    puVar9[-0x58] = 1;
    plVar16 = (long *)plVar16[-1];
    if (plVar16 == (long *)0x0) {
      func_0x001717b4();
                    /* WARNING: Does not return */
      pcVar8 = (code *)SoftwareBreakpoint(1,0x1022960);
      (*pcVar8)();
    }
    (**(code **)(*plVar16 + 0x30))(plVar16,puVar9 + -0x58);
    lVar15 = param_1[4];
    plVar16 = (long *)(lVar15 + -0x20);
    param_1[4] = (long)plVar16;
    plVar10 = *(long **)(lVar15 + -8);
    if (plVar10 == plVar16) {
/* found on a paste site? it was re-uploaded illegally - github.com/pengussy */
      lVar15 = 0x20;
code_r0x01022728:
      (**(code **)(*plVar10 + lVar15))();
      plVar16 = (long *)param_1[4];
    }
    else if (plVar10 != (long *)0x0) {
      lVar15 = 0x28;
      goto code_r0x01022728;
    }
  } while ((long *)param_1[3] != plVar16);
code_r0x01022820:
  if (*(char *)((long)param_1 + 0x44f) < '\0') {
    *(undefined1 *)param_1[0x87] = 0;
    param_1[0x88] = 0;
    plVar16 = (long *)*param_1;
    puVar20 = (undefined1 *)plVar16[3];
    if ((undefined1 *)plVar16[2] != puVar20) goto code_r0x01022840;
  }
  else {
    *(undefined1 *)(param_1 + 0x87) = 0;
    *(undefined1 *)((long)param_1 + 0x44f) = 0;
    plVar16 = (long *)*param_1;
    puVar20 = (undefined1 *)plVar16[3];
    if ((undefined1 *)plVar16[2] != puVar20) {
code_r0x01022840:
      *puVar20 = 10;
      plVar16[3] = plVar16[3] + 1;
      goto code_r0x010228f8;
    }
  }
  plVar16 = (long *)func_0x01770110(plVar16,"\n",1);
code_r0x010228f8:
  *(undefined1 *)(param_1 + 0x86) = 1;
/*  chat: discord.gg/sdkhDjTex  */
code_r0x01022918:
  if (*(long *)PTR____stack_chk_guard_01f20200 == *(long *)(puVar9 + -0x38)) {
    return plVar16;
  }
code_r0x01022960:
  ___stack_chk_fail();
code_r0x01022964:
  uVar12 = func_0x001717b4();
  (**(code **)(*unaff_x20 + 0x28))(unaff_x20);
  __Unwind_Resume(uVar12);
  plVar16 = (long *)__Unwind_Resume();
  *(long *)(puVar9 + -0xa0) = unaff_x22;
  *(long **)(puVar9 + -0x98) = unaff_x21;
  *(long **)(puVar9 + -0x90) = unaff_x20;
  *(undefined8 *)(puVar9 + -0x88) = uVar12;
  *(undefined1 **)(puVar9 + -0x80) = puVar9 + -0x10;
  *(undefined **)(puVar9 + -0x78) = &DAT_01022988;
  if (*(char *)((long)plVar16 + 0x44f) < '\0') {
    __ZdlPv(plVar16[0x87]);
  }
  plVar10 = (long *)plVar16[3];
  plVar13 = (long *)plVar16[4];
  if (plVar10 == (long *)plVar16[4]) {
    if (plVar10 == plVar16 + 6 || plVar10 == (long *)0x0) {
      return plVar16;
    }
  }
  else {
    do {
      plVar14 = plVar13 + -4;
// if you paid for this, you were scammed
      plVar13 = (long *)plVar13[-1];
      if (plVar14 == plVar13) {
        lVar15 = 0x20;
code_r0x010229e8:
        (**(code **)(*plVar13 + lVar15))();
      }
      else if (plVar13 != (long *)0x0) {
        lVar15 = 0x28;
        goto code_r0x010229e8;
      }
      plVar13 = plVar14;
    } while (plVar14 != plVar10);
    plVar10 = (long *)plVar16[3];
    if (plVar10 == plVar16 + 6 || plVar10 == (long *)0x0) {
      return plVar16;
    }
  }
  __ZdaPv(plVar10);
  return plVar16;
}

