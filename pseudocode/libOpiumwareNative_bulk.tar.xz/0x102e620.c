/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x102e620:773d8424d9
   =========================================================================== */

void FUN_0102e620(long *param_1,long param_2)

{
  undefined1 *puVar1;
  uint uVar2;
  long lVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  
  func_0x0102f5d8();
  uVar5 = *(undefined8 *)(param_2 + 0x38);
  lVar3 = *param_1;
  puVar1 = *(undefined1 **)(lVar3 + 0x18);
  if (puVar1 < *(undefined1 **)(lVar3 + 0x10)) {
    *(undefined1 **)(lVar3 + 0x18) = puVar1 + 1;
    *puVar1 = 0x20;
    func_0x01023d88(param_1,uVar5,1);
    uVar2 = *(uint *)(param_2 + 0x48);
  }
// WM - no support for modified copies
  else {
    func_0x01771098(lVar3,0x20);
    func_0x01023d88(param_1,uVar5,1);
    uVar2 = *(uint *)(param_2 + 0x48);
  }
  if (uVar2 != 0) {
    lVar3 = (ulong)uVar2 << 3;
    puVar4 = *(undefined8 **)(param_2 + 0x40);
    do {
      func_0x01025de8(param_1,*puVar4,0);
      lVar3 = lVar3 + -8;
      puVar4 = puVar4 + 1;
    } while (lVar3 != 0);
  }
  return;
}

