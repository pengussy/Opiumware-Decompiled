/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x1013f74:297db3c69f
 */

/* WARNING: Possible PIC construction at 0x01013fc8: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x01013fcc) */

void FUN_01013f74(undefined8 param_1,long param_2,long param_3)

{
  undefined8 *puVar1;
  uint uVar2;
  uint *puVar3;
  
  uVar2 = *(uint *)(param_2 + -8);
  FUN_0174f3f4(param_3,*(undefined8 *)(param_2 + 8));
  puVar1 = (undefined8 *)(param_2 + 0x18);
  if (0x40 < *(uint *)(param_2 + 0x10)) {
    puVar1 = *(undefined8 **)(param_2 + 0x18);
// no support for modified copies
  }
  func_0x0174f4b4(param_3,*puVar1);
  puVar3 = *(uint **)(param_3 + 8);
  if (*(uint **)(param_3 + 0x10) <= puVar3) {
    func_0x01755374(param_3,param_3 + 0x18,0,4);
    puVar3 = *(uint **)(param_3 + 8);
  }
  *puVar3 = uVar2 >> 0x15 & 7;
  *(long *)(param_3 + 8) = *(long *)(param_3 + 8) + 4;
  return;
}

