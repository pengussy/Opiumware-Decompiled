/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x103d144:4aa687d6bb
 *  --------------------------------------------------------------------------*/

undefined8 * FUN_0103d144(undefined4 *param_1,long param_2)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  
  puVar4 = (undefined8 *)func_0x009d11e8(param_2 + 0x790,0x18,8);
  uVar6 = *(undefined8 *)(param_1 + 4);
  uVar1 = param_1[2];
  iVar2 = param_1[3];
/* WM: if you paid for this, you were scammed @ discord.gg/sdkhDjTex */
  *puVar4 = CONCAT44(*param_1,*param_1);
  uVar3 = *(uint *)(puVar4 + 1);
  *(int *)((long)puVar4 + 0xc) = iVar2;
  uVar5 = func_0x009d11e8(param_2 + 0x790,iVar2,1);
  puVar4[2] = uVar5;
  if (iVar2 != 0) {
    _memcpy(uVar5,uVar6,iVar2);
  }
  *(uint *)(puVar4 + 1) = uVar1 & 0xf0000 | param_1[2] & 0x700000 | 0x103 | uVar3 & 0xfe000000;
  return puVar4;
}

