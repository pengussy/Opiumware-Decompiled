/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1027f20:6e60e6e629
   =========================================================================== */

void FUN_01027f20(long *param_1)

{
  long *plVar1;
  char *pcVar2;
  undefined4 *puVar3;
  uint uVar4;
  char cVar5;
  byte bVar6;
  code *pcVar7;
  int iVar8;
  long lVar9;
  ulong uVar10;
  ulong *puVar11;
  undefined8 uVar12;
  undefined8 *puVar13;
  ushort *puVar14;
  uint uVar15;
  long *plVar16;
  undefined1 *puVar17;
  long lVar18;
  ulong uVar19;
  ulong *puVar20;
  ulong uVar21;
  long lVar22;
  long *plVar23;
  long lVar24;
  undefined8 *puVar25;
/* WM - stripping the watermark breaks the license */
  uint uVar26;
  long *plStack_98;
  long lStack_90;
  long lStack_88;
  ulong uStack_80;
  byte bStack_71;
  long *plStack_70;
  long lStack_68;
  
  lStack_68 = *(long *)PTR____stack_chk_guard_01f20200;
  plVar1 = (long *)*param_1;
  lVar9 = param_1[1];
  if (lVar9 == 0) {
    if ((char)plVar1[0x8d] != '\0') {
      (**(code **)(*(long *)*plVar1 + 0x28))((long *)*plVar1,4,0,0);
    }
    lVar9 = *plVar1;
    pcVar2 = *(char **)(lVar9 + 0x18);
    if ((ulong)(*(long *)(lVar9 + 0x10) - (long)pcVar2) < 10) {
      func_0x01770110(lVar9,"<<<NULL>>>",10);
      cVar5 = (char)plVar1[0x8d];
    }
    else {
      pcVar2[8] = '>';
      pcVar2[9] = '>';
      *(undefined8 *)pcVar2 = s_<<<NULL>>>_01cbd5c4._0_8_;
      *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 10;
      cVar5 = (char)plVar1[0x8d];
    }
/*  thanks for reading - discord.gg/sdkhDjTex  */
    if (cVar5 == '\x01') {
      (**(code **)(*(long *)*plVar1 + 0x30))();
    }
  }
  else {
    if ((char)plVar1[0x8d] != '\0') {
      (**(code **)(*(long *)*plVar1 + 0x28))((long *)*plVar1,2,1,0);
      lVar9 = param_1[1];
    }
    lVar22 = *plVar1;
    lVar9 = func_0x0107d974(lVar9);
    if (lVar9 != 0) {
      uVar10 = _strlen(lVar9);
      if ((ulong)(*(long *)(lVar22 + 0x10) - *(long *)(lVar22 + 0x18)) < uVar10) {
        lVar22 = func_0x01770110(lVar22,lVar9,uVar10);
      }
      else if (uVar10 != 0) {
        _memcpy(*(long *)(lVar22 + 0x18),lVar9,uVar10);
        *(ulong *)(lVar22 + 0x18) = *(long *)(lVar22 + 0x18) + uVar10;
      }
    }
    if ((ulong)(*(long *)(lVar22 + 0x10) - (long)*(undefined4 **)(lVar22 + 0x18)) < 4) {
      func_0x01770110(lVar22,"Decl",4);
      cVar5 = (char)plVar1[0x8d];
    }
    else {
      **(undefined4 **)(lVar22 + 0x18) = 0x6c636544;
      *(long *)(lVar22 + 0x18) = *(long *)(lVar22 + 0x18) + 4;
      cVar5 = (char)plVar1[0x8d];
    }
    if (cVar5 == '\x01') {
      (**(code **)(*(long *)*plVar1 + 0x30))();
    }
/* +- WM -------------------------------------------------------------+
   |  watermarked copy - do not remove
   +--------------------------------------------------------------------*/
    func_0x01023cc0(plVar1,param_1[1]);
    lVar9 = param_1[1];
    plVar23 = (long *)(*(ulong *)(lVar9 + 0x10) & 0xfffffffffffffffc);
    if (((uint)*(ulong *)(lVar9 + 0x10) >> 1 & 1) != 0) {
      if (plVar23[1] != *plVar23) {
        lVar9 = *plVar1;
        if ((ulong)(*(long *)(lVar9 + 0x10) - (long)*(undefined8 **)(lVar9 + 0x18)) < 8) {
          lVar9 = func_0x01770110(lVar9," parent ",8);
          uVar10 = *(ulong *)(param_1[1] + 0x10);
          uVar15 = (uint)uVar10;
        }
        else {
          **(undefined8 **)(lVar9 + 0x18) = 0x20746e6572617020;
          *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 8;
          uVar10 = *(ulong *)(param_1[1] + 0x10);
          uVar15 = (uint)uVar10;
        }
        puVar11 = (ulong *)(uVar10 & 0xfffffffffffffffc);
        if ((uVar15 >> 1 & 1) != 0) {
          puVar11 = (ulong *)*puVar11;
        }
        uVar12 = func_0x010855a4(puVar11);
        func_0x01770d74(lVar9,uVar12);
        lVar9 = param_1[1];
        plVar23 = (long *)(*(ulong *)(lVar9 + 0x10) & 0xfffffffffffffffc);
        if (((uint)*(ulong *)(lVar9 + 0x10) >> 1 & 1) == 0) goto LAB_010281a4;
      }
      plVar23 = (long *)*plVar23;
/*
   reversing this took months of machine time
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
    }
LAB_010281a4:
    if ((plVar23 != (long *)0x0) && (plVar16 = plVar23 + -7, (char)*plVar23 == '\v')) {
      lVar9 = *plVar1;
      if ((ulong)(*(long *)(lVar9 + 0x10) - (long)*(undefined8 **)(lVar9 + 0x18)) < 8) {
        lVar9 = func_0x01770110(lVar9," parent ",8);
        lVar22 = func_0x00e7c5a8(plVar16);
      }
      else {
        **(undefined8 **)(lVar9 + 0x18) = 0x20746e6572617020;
        *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 8;
        lVar22 = func_0x00e7c5a8(plVar16);
      }
      if (lVar22 != 0) {
        uVar10 = _strlen();
        if ((ulong)(*(long *)(lVar9 + 0x10) - *(long *)(lVar9 + 0x18)) < uVar10) {
          func_0x01770110(lVar9,lVar22,uVar10);
        }
        else if (uVar10 != 0) {
          _memcpy(*(long *)(lVar9 + 0x18),lVar22,uVar10);
          *(ulong *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + uVar10;
        }
      }
      func_0x01023cc0(plVar1,plVar16);
      lVar9 = param_1[1];
    }
    uVar15 = *(uint *)(lVar9 + 0x1c);
    if (0x3e < (uVar15 & 0xff)) {
      func_0x0174ef58("Decl that isn\'t part of DeclNodes.inc!",
// no support for modified copies
                      "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/lib/AST/ASTDumper.cpp"
                      ,0x361);
LAB_01029150:
      func_0x0174ef58("Decl that isn\'t part of DeclNodes.inc!",
                      "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/include/clang/AST/DeclVisitor.h"
                      ,0x2d);
      goto LAB_01029168;
    }
    lVar22 = *plVar1;
    switch(uVar15 & 0xff) {
    case 0xd:
      func_0x010295e0(lVar22,*(undefined8 *)(lVar9 + 0x58));
      break;
    case 0xe:
      func_0x010295e0(lVar22,*(undefined8 *)(lVar9 + 0x38));
      break;
    case 0x13:
// WM - chat: discord.gg/sdkhDjTex
      func_0x010295e0(lVar22,*(undefined8 *)(lVar9 + 0x68));
      break;
    case 0x14:
      func_0x010295e0(lVar22,*(undefined8 *)(lVar9 + 0x68));
      break;
    case 0x17:
    case 0x18:
    case 0x19:
    case 0x1a:
      func_0x010295e0(lVar22,*(undefined8 *)(lVar9 + 0x48));
      break;
    case 0x1c:
    case 0x1d:
    case 0x1e:
    case 0x1f:
    case 0x20:
      func_0x010295e0(lVar22,*(undefined8 *)(lVar9 + 0x68));
      break;
    case 0x22:
    case 0x23:
    case 0x24:
      func_0x010295e0(lVar22,*(undefined8 *)(lVar9 + 0x48));
      break;
/* proprietary - see LICENSE - do not sell - github.com/pengussy */
    case 0x25:
      func_0x01029658();
      break;
    case 0x26:
      func_0x01029724();
      break;
    case 0x28:
      func_0x010295e0(lVar22,*(undefined8 *)(lVar9 + 0x38));
      break;
    case 0x29:
    case 0x2a:
    case 0x2b:
      func_0x010297f0();
      break;
    case 0x2c:
    case 0x2d:
    case 0x2e:
    case 0x2f:
    case 0x30:
      func_0x010295e0(lVar22,*(undefined8 *)(lVar9 + 0x70));
      break;
    case 0x36:
      if ((uVar15 & 0xfe) != 0x36) {
// origin: github.com/pengussy
        func_0x0174f200("cast");
      }
    case 0x33:
    case 0x34:
    case 0x35:
    case 0x37:
      func_0x010295e0(lVar22,*(undefined8 *)(lVar9 + 0x50));
      break;
    case 0x38:
      func_0x010298c0();
      break;
    case 0x3a:
      func_0x0102998c(lVar22);
    }
    uVar12 = (**(code **)(*(long *)param_1[1] + 0x10))();
    func_0x01025254(plVar1,uVar12);
    lVar9 = *plVar1;
    puVar17 = *(undefined1 **)(lVar9 + 0x18);
    if (puVar17 < *(undefined1 **)(lVar9 + 0x10)) {
      *(undefined1 **)(lVar9 + 0x18) = puVar17 + 1;
      *puVar17 = 0x20;
    }
    else {
      func_0x01771098(lVar9,0x20);
    }
    func_0x01025380(plVar1,*(undefined4 *)(param_1[1] + 0x18));
    lVar9 = param_1[1];
    uVar15 = *(uint *)(lVar9 + 0x1c);
    if ((uVar15 >> 0xf & 1) == 0) {
// WM - if you paid for this, you were scammed
LAB_01028354:
      if (((uVar15 & 0x18000) == 0x10000) && (lVar9 = *(long *)(lVar9 + -8), lVar9 != 0)) {
        lVar22 = *plVar1;
        pcVar2 = *(char **)(lVar22 + 0x18);
        if ((ulong)(*(long *)(lVar22 + 0x10) - (long)pcVar2) < 0xc) {
          lVar22 = func_0x01770110(lVar22," in (local) ",0xc);
        }
        else {
          pcVar2[8] = 'a';
          pcVar2[9] = 'l';
          pcVar2[10] = ')';
          pcVar2[0xb] = ' ';
          *(undefined8 *)pcVar2 = s_in__local__01cbd7b6._0_8_;
          *(long *)(lVar22 + 0x18) = *(long *)(lVar22 + 0x18) + 0xc;
        }
        func_0x0165d1f8(&lStack_88,lVar9);
        uVar10 = uStack_80;
        puVar17 = (undefined1 *)CONCAT71(lStack_88._1_7_,(undefined1)lStack_88);
        if (-1 < (char)bStack_71) {
          uVar10 = (ulong)bStack_71;
          puVar17 = (undefined1 *)&lStack_88;
        }
        func_0x01770110(lVar22,puVar17,uVar10);
        goto LAB_01028438;
      }
LAB_01028440:
      uVar10 = param_1[1];
      uVar15 = *(uint *)(uVar10 + 0x1c);
    }
    else {
      lVar9 = func_0x0107d82c();
      if (lVar9 == 0) {
/*
   origin: github.com/pengussy
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
        lVar9 = param_1[1];
        uVar15 = *(uint *)(lVar9 + 0x1c);
        goto LAB_01028354;
      }
      lVar22 = *plVar1;
      if ((ulong)(*(long *)(lVar22 + 0x10) - (long)*(undefined4 **)(lVar22 + 0x18)) < 4) {
        lVar22 = func_0x01770110(lVar22," in ",4);
      }
      else {
        **(undefined4 **)(lVar22 + 0x18) = 0x206e6920;
        *(long *)(lVar22 + 0x18) = *(long *)(lVar22 + 0x18) + 4;
      }
      func_0x0165d1f8(&lStack_88,lVar9);
      uVar10 = uStack_80;
      puVar17 = (undefined1 *)CONCAT71(lStack_88._1_7_,(undefined1)lStack_88);
      if (-1 < (char)bStack_71) {
        uVar10 = (ulong)bStack_71;
        puVar17 = (undefined1 *)&lStack_88;
      }
      func_0x01770110(lVar22,puVar17,uVar10);
LAB_01028438:
      if (-1 < (char)bStack_71) goto LAB_01028440;
// WM - unlicensed copy if this notice is missing
      __ZdlPv(CONCAT71(lStack_88._1_7_,(undefined1)lStack_88));
      uVar10 = param_1[1];
      uVar15 = *(uint *)(uVar10 + 0x1c);
    }
    uVar26 = (uVar15 & 0xff) - 0x3b;
    if ((uVar10 != 0) && (0xffffffcf < uVar26)) {
      lVar9 = func_0x0107d708(uVar10);
      lVar22 = *(long *)(lVar9 + 0x620);
      uVar4 = *(uint *)(lVar9 + 0x630);
      puVar11 = (ulong *)(lVar22 + (ulong)uVar4 * 0x10);
      if (uVar4 == 0) {
LAB_010284e8:
        puVar20 = puVar11;
      }
      else {
        uVar19 = (ulong)(uVar4 - 1 & ((uint)(uVar10 >> 4) & 0xfffffff ^ (uint)uVar10 >> 9));
        puVar20 = (ulong *)(lVar22 + uVar19 * 0x10);
        uVar21 = *puVar20;
        if (uVar10 != uVar21) {
          iVar8 = 1;
          do {
            if (uVar21 == 0xfffffffffffffffc) goto LAB_010284e8;
            uVar19 = (ulong)((int)uVar19 + iVar8 & uVar4 - 1);
            uVar21 = *(ulong *)(lVar22 + uVar19 * 0x10);
            iVar8 = iVar8 + 1;
          } while (uVar10 != uVar21);
          puVar20 = (ulong *)(lVar22 + uVar19 * 0x10);
        }
      }
      if (puVar20 != puVar11) {
        puVar11 = puVar20 + 1;
        uVar19 = *puVar11;
        if (3 < uVar19) {
/* +- WM -------------------------------------------------------------+
   |  proprietary - see LICENSE - do not sell
   +--------------------------------------------------------------------*/
          if (((uint)uVar19 >> 1 & 1) == 0) {
            puVar20 = puVar20 + 2;
          }
          else {
            puVar11 = *(ulong **)(uVar19 & 0xfffffffffffffffc);
            puVar20 = (ulong *)((long *)(uVar19 & 0xfffffffffffffffc))[1];
            if (puVar20 == puVar11) goto LAB_010287c8;
          }
          do {
            while (uVar10 = *puVar11, (char)plVar1[0x86] == '\x01') {
              *(undefined1 *)(plVar1 + 0x86) = 0;
              lVar9 = *plVar1;
              if ((ulong)(*(long *)(lVar9 + 0x10) - (long)*(undefined8 **)(lVar9 + 0x18)) < 8) {
                lVar9 = func_0x01770110(lVar9,"also in ",8);
              }
              else {
                **(undefined8 **)(lVar9 + 0x18) = 0x206e69206f736c61;
                *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 8;
              }
              func_0x0165d1f8(&lStack_88,uVar10);
              uVar10 = uStack_80;
              plVar23 = (long *)CONCAT71(lStack_88._1_7_,(undefined1)lStack_88);
              if (-1 < (char)bStack_71) {
                uVar10 = (ulong)bStack_71;
                plVar23 = &lStack_88;
              }
              func_0x01770110(lVar9,plVar23,uVar10);
// WM - found on a paste site? it was re-uploaded illegally
              if ((char)bStack_71 < '\0') {
                __ZdlPv(CONCAT71(lStack_88._1_7_,(undefined1)lStack_88));
              }
              plVar16 = (long *)plVar1[4];
              plVar23 = (long *)plVar1[3];
              while (plVar23 != plVar16) {
                lStack_88._0_1_ = 1;
                plVar23 = (long *)plVar16[-1];
                if (plVar23 == (long *)0x0) {
                  FUN_001717b4();
                  goto LAB_01029168;
                }
                (**(code **)(*plVar23 + 0x30))(plVar23,&lStack_88);
                lVar9 = plVar1[4];
                plVar16 = (long *)(lVar9 + -0x20);
                plVar1[4] = (long)plVar16;
                plVar23 = *(long **)(lVar9 + -8);
                if (plVar23 == plVar16) {
                  lVar9 = 0x20;
LAB_01028670:
                  (**(code **)(*plVar23 + lVar9))();
                  plVar16 = (long *)plVar1[4];
                }
                else if (plVar23 != (long *)0x0) {
                  lVar9 = 0x28;
                  goto LAB_01028670;
                }
                plVar23 = (long *)plVar1[3];
              }
              if (*(char *)((long)plVar1 + 0x44f) < '\0') {
                *(undefined1 *)plVar1[0x87] = 0;
                plVar1[0x88] = 0;
                lVar9 = *plVar1;
                puVar17 = *(undefined1 **)(lVar9 + 0x18);
                if (*(undefined1 **)(lVar9 + 0x10) == puVar17) goto LAB_01028780;
LAB_010286ec:
                *puVar17 = 10;
/*  chat: discord.gg/sdkhDjTex  */
                *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 1;
              }
              else {
                *(undefined1 *)(plVar1 + 0x87) = 0;
                *(undefined1 *)((long)plVar1 + 0x44f) = 0;
                lVar9 = *plVar1;
                puVar17 = *(undefined1 **)(lVar9 + 0x18);
                if (*(undefined1 **)(lVar9 + 0x10) != puVar17) goto LAB_010286ec;
LAB_01028780:
                func_0x01770110(lVar9,"\n",1);
              }
              *(undefined1 *)(plVar1 + 0x86) = 1;
              puVar11 = puVar11 + 1;
              if (puVar11 == puVar20) goto LAB_010287b8;
            }
            lVar9 = plVar1[0x8c];
            if (*(char *)((long)plVar1 + 0x431) == '\x01') {
              puVar13 = (undefined8 *)__Znwm(0x28);
              *puVar13 = &UNK_01e5d980;
/* if you paid for this, you were scammed */
              puVar13[1] = plVar1;
              puVar13[2] = plVar1;
              puVar13[3] = uVar10;
              puVar13[4] = lVar9;
              uVar10 = plVar1[4];
              if ((ulong)plVar1[5] <= uVar10) {
                func_0x01027324(plVar1 + 3,0);
                uVar10 = plVar1[4];
              }
              *(undefined8 **)(uVar10 + 0x18) = puVar13;
              plVar1[4] = plVar1[4] + 0x20;
              *(undefined1 *)((long)plVar1 + 0x431) = 0;
            }
            else {
              lStack_88._0_1_ = 0;
              plVar23 = *(long **)(plVar1[4] + -8);
              if (plVar23 == (long *)0x0) goto LAB_01029130;
              (**(code **)(*plVar23 + 0x30))(plVar23,&lStack_88);
              lVar22 = plVar1[4];
              plStack_70 = (long *)__Znwm(0x28);
              *plStack_70 = (long)&UNK_01e5d980;
/* WM - keep the notice, keep the source honest */
              plStack_70[1] = (long)plVar1;
              plStack_70[2] = (long)plVar1;
              plStack_70[3] = uVar10;
              plStack_70[4] = lVar9;
              func_0x01025c50(&lStack_88,lVar22 + -0x20);
              if (plStack_70 == &lStack_88) {
                lVar9 = 0x20;
LAB_01028550:
                (**(code **)(*plStack_70 + lVar9))();
              }
              else if (plStack_70 != (long *)0x0) {
                lVar9 = 0x28;
                goto LAB_01028550;
              }
              *(undefined1 *)((long)plVar1 + 0x431) = 0;
            }
            puVar11 = puVar11 + 1;
          } while (puVar11 != puVar20);
LAB_010287b8:
          uVar10 = param_1[1];
          uVar15 = *(uint *)(uVar10 + 0x1c);
          uVar26 = (uVar15 & 0xff) - 0x3b;
        }
      }
    }
LAB_010287c8:
    if (((uVar10 == 0) || (uVar26 < 0xffffffd0)) || ((uVar15 >> 0x10 & 1) == 0)) {
LAB_010287fc:
      bVar6 = *(byte *)(param_1[1] + 0x1d);
    }
    else {
      lVar9 = *plVar1;
      puVar3 = *(undefined4 **)(lVar9 + 0x18);
      if ((ulong)(*(long *)(lVar9 + 0x10) - (long)puVar3) < 7) {
/* WM: stripping the watermark breaks the license @ discord.gg/sdkhDjTex */
        func_0x01770110(lVar9," hidden",7);
        goto LAB_010287fc;
      }
      *(undefined4 *)((long)puVar3 + 3) = 0x6e656464;
      *puVar3 = 0x64696820;
      *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 7;
      bVar6 = *(byte *)(param_1[1] + 0x1d);
    }
    if ((bVar6 >> 2 & 1) != 0) {
      lVar9 = *plVar1;
      pcVar2 = *(char **)(lVar9 + 0x18);
      if ((ulong)(*(long *)(lVar9 + 0x10) - (long)pcVar2) < 9) {
        func_0x01770110(lVar9," implicit",9);
      }
      else {
        pcVar2[8] = 't';
        *(undefined8 *)pcVar2 = s_implicit_01cbd7cb._0_8_;
        *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 9;
      }
    }
    iVar8 = func_0x010841cc(param_1[1],1);
    if (iVar8 == 0) {
      if ((*(byte *)(param_1[1] + 0x1d) >> 4 & 1) != 0) {
        lVar9 = *plVar1;
        pcVar2 = *(char **)(lVar9 + 0x18);
        if (10 < (ulong)(*(long *)(lVar9 + 0x10) - (long)pcVar2)) {
          pcVar2[7] = 'n';
          pcVar2[8] = 'c';
          pcVar2[9] = 'e';
          pcVar2[10] = 'd';
          *(undefined8 *)pcVar2 = s_referenced_01cbd7db._0_8_;
          *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 0xb;
          bVar6 = *(byte *)(param_1[1] + 0x1d);
          goto joined_r0x01028960;
/* unlicensed copy if this notice is missing - github.com/pengussy */
        }
        func_0x01770110(lVar9," referenced",0xb);
      }
LAB_010288f0:
      if ((*(byte *)(param_1[1] + 0x1d) & 1) == 0) goto LAB_01028988;
LAB_01028964:
      lVar9 = *plVar1;
      if ((ulong)(*(long *)(lVar9 + 0x10) - (long)*(undefined8 **)(lVar9 + 0x18)) < 8) {
        func_0x01770110(lVar9," invalid",8);
        goto LAB_01028988;
      }
      **(undefined8 **)(lVar9 + 0x18) = 0x64696c61766e6920;
      *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 8;
      lVar9 = param_1[1];
    }
    else {
      lVar9 = *plVar1;
/*
 *  unlicensed copy if this notice is missing
 *
 *  @pengussy
 */
      puVar3 = *(undefined4 **)(lVar9 + 0x18);
      if ((ulong)(*(long *)(lVar9 + 0x10) - (long)puVar3) < 5) {
        func_0x01770110(lVar9," used",5);
        goto LAB_010288f0;
      }
      *(undefined1 *)(puVar3 + 1) = 100;
      *puVar3 = 0x65737520;
      *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 5;
      bVar6 = *(byte *)(param_1[1] + 0x1d);
joined_r0x01028960:
      if ((bVar6 & 1) != 0) goto LAB_01028964;
LAB_01028988:
      lVar9 = param_1[1];
    }
    if (((lVar9 != 0) && (0xfffffffa < *(byte *)(lVar9 + 0x1c) - 0x31)) &&
       ((*(byte *)(lVar9 + 0xa1) >> 6 & 1) != 0)) {
      lVar9 = *plVar1;
      pcVar2 = *(char **)(lVar9 + 0x18);
      if ((ulong)(*(long *)(lVar9 + 0x10) - (long)pcVar2) < 10) {
        func_0x01770110(lVar9," constexpr",10);
      }
      else {
        pcVar2[8] = 'p';
        pcVar2[9] = 'r';
        *(undefined8 *)pcVar2 = s_constexpr_01cbd7f0._0_8_;
        *(long *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + 10;
      }
    }
    lVar9 = param_1[1];
    switch(*(undefined1 *)(lVar9 + 0x1c)) {
    case 0:
      func_0x01029e50(plVar1);
      break;
    case 1:
      func_0x01029ebc(plVar1);
      break;
/*  unlicensed copy if this notice is missing  */
    case 2:
    case 4:
    case 5:
    case 8:
    case 0x31:
    case 0x3b:
    case 0x3e:
      break;
    case 3:
      func_0x0102a698(plVar1);
      break;
    case 6:
      func_0x01022fec(plVar1,*(undefined8 *)(lVar9 + 0x20));
      break;
    case 7:
      func_0x0102a754(plVar1,*(undefined8 *)(lVar9 + 0x20));
      break;
    case 9:
      func_0x0102a7dc(*plVar1);
      break;
    case 10:
      func_0x0102a8a0(plVar1,*(undefined1 *)(lVar9 + 0x40));
      break;
    case 0xb:
      func_0x0102a92c(plVar1);
      break;
    case 0xc:
      func_0x0102f5d8(plVar1);
      break;
/* wm:thanks for reading - discord.gg/sdkhDjTex */
    case 0xd:
      func_0x0102a9d4(plVar1);
      break;
    case 0xe:
      func_0x0102aa80(plVar1);
      break;
    case 0xf:
      func_0x0102aab0(plVar1);
      break;
    case 0x10:
      func_0x0102aae0(plVar1);
      break;
    case 0x11:
      func_0x0102ab8c(plVar1);
      break;
    case 0x12:
      func_0x0102abd4(plVar1);
      break;
    case 0x13:
      func_0x0102ac60(plVar1);
      break;
    case 0x14:
// WM - no support for modified copies
      func_0x0102ad20(plVar1);
      break;
    case 0x15:
      func_0x0102ae10(plVar1);
      break;
    case 0x16:
      func_0x0102b1f4(plVar1);
      break;
    case 0x17:
      func_0x0102b6b4(plVar1);
      break;
    case 0x18:
      func_0x0102b9b8(plVar1);
      break;
    case 0x19:
      func_0x0102bd2c(plVar1);
      break;
    case 0x1a:
      func_0x0102bd98(plVar1);
      break;
    case 0x1b:
      func_0x0102c0ac(plVar1);
      break;
    case 0x1c:
/* WM: found on a paste site? it was re-uploaded illegally @ discord.gg/sdkhDjTex */
      func_0x0102c260(plVar1);
      break;
    case 0x1d:
      func_0x0102c46c(plVar1);
      break;
    case 0x1e:
      func_0x0102c5f8(plVar1);
      break;
    case 0x1f:
      func_0x0102c920(plVar1);
      break;
    case 0x20:
      func_0x0102c9b4(plVar1);
      break;
    case 0x21:
      func_0x0102ca7c(plVar1);
      break;
    case 0x22:
      func_0x0102cc34(plVar1);
      break;
    case 0x23:
      func_0x0102cdb8(plVar1);
      break;
    case 0x24:
      func_0x0102ce3c(plVar1);
      break;
    case 0x25:
      func_0x0102cf3c(plVar1);
      break;
    case 0x26:
      func_0x0102d030(plVar1);
/* stripping the watermark breaks the license - github.com/pengussy */
      break;
    case 0x27:
      func_0x0102d124(plVar1);
      break;
    case 0x28:
      func_0x0102d180(plVar1);
      break;
    case 0x29:
      func_0x0102d1e4(plVar1);
      break;
    case 0x2a:
      func_0x0102d1e4(plVar1);
      break;
    case 0x2b:
      func_0x0102d37c(plVar1);
      break;
    case 0x2c:
      func_0x0102d624(plVar1);
      break;
    case 0x2d:
      func_0x0102d624(plVar1);
      break;
    case 0x2e:
      func_0x0102d624(plVar1);
      break;
    case 0x2f:
      func_0x0102d624(plVar1);
      break;
    case 0x30:
      func_0x0102d624(plVar1);
      break;
    case 0x32:
      func_0x0102deac(plVar1);
      break;
    case 0x33:
      func_0x0102e01c(plVar1);
      break;
/* WM - do not claim this as your own */
    case 0x34:
      func_0x0102e01c(plVar1);
      break;
    case 0x35:
      func_0x0102e01c(plVar1);
      break;
    case 0x36:
      func_0x0102e420(plVar1);
      break;
    case 0x37:
      func_0x0102e4b8(plVar1);
      break;
    case 0x38:
      func_0x0102e584(plVar1);
      break;
    case 0x39:
      func_0x0102e620(plVar1);
      break;
    case 0x3a:
      func_0x0102e6cc(plVar1);
      break;
    case 0x3c:
      func_0x0102e800(plVar1);
      break;
    case 0x3d:
      func_0x0102e8d8(plVar1);
      break;
    default:
      goto LAB_01029150;
    }
    if ((*(byte *)(param_1[1] + 0x1d) >> 1 & 1) != 0) {
      puVar13 = (undefined8 *)func_0x010840b4();
      puVar13 = (undefined8 *)*puVar13;
      if ((*(byte *)(param_1[1] + 0x1d) >> 1 & 1) == 0) {
        puVar25 = (undefined8 *)0x0;
      }
      else {
/* +- WM -------------------------------------------------------------+
   |  reversing this took months of machine time
   +--------------------------------------------------------------------*/
        lVar9 = func_0x010840b4();
        puVar25 = *(undefined8 **)(lVar9 + 8);
      }
      for (; puVar13 != puVar25; puVar13 = puVar13 + 1) {
        func_0x01030a80(plVar1,plVar1,*puVar13);
      }
    }
    lVar9 = param_1[1];
    if (((lVar9 != 0) && (0xffffffcf < *(byte *)(lVar9 + 0x1c) - 0x3b)) &&
       (*(long *)(lVar9 + 0x30) != 0)) {
      lVar22 = *(long *)(lVar9 + 0x28);
      lVar9 = lVar22 + *(long *)(lVar9 + 0x30) * 8;
LAB_01028ab4:
      do {
        plStack_98 = plVar1;
        lStack_90 = lVar22;
        if ((char)plVar1[0x86] == '\x01') {
          *(undefined1 *)(plVar1 + 0x86) = 0;
          func_0x01032bc4(&plStack_98);
          plVar16 = (long *)plVar1[4];
          plVar23 = (long *)plVar1[3];
          while (plVar23 != plVar16) {
            lStack_88._0_1_ = 1;
            plVar23 = (long *)plVar16[-1];
            if (plVar23 == (long *)0x0) {
              FUN_001717b4();
              goto LAB_01029168;
            }
            (**(code **)(*plVar23 + 0x30))(plVar23,&lStack_88);
            lVar18 = plVar1[4];
            plVar16 = (long *)(lVar18 + -0x20);
            plVar1[4] = (long)plVar16;
            plVar23 = *(long **)(lVar18 + -8);
            if (plVar23 == plVar16) {
              lVar18 = 0x20;
/* chat: discord.gg/sdkhDjTex */
LAB_01028adc:
              (**(code **)(*plVar23 + lVar18))();
              plVar16 = (long *)plVar1[4];
            }
            else if (plVar23 != (long *)0x0) {
              lVar18 = 0x28;
              goto LAB_01028adc;
            }
            plVar23 = (long *)plVar1[3];
          }
          if (*(char *)((long)plVar1 + 0x44f) < '\0') {
            *(undefined1 *)plVar1[0x87] = 0;
            plVar1[0x88] = 0;
            lVar18 = *plVar1;
            puVar17 = *(undefined1 **)(lVar18 + 0x18);
            if (*(undefined1 **)(lVar18 + 0x10) == puVar17) goto LAB_01028c48;
LAB_01028bb4:
            *puVar17 = 10;
            *(long *)(lVar18 + 0x18) = *(long *)(lVar18 + 0x18) + 1;
          }
          else {
            *(undefined1 *)(plVar1 + 0x87) = 0;
            *(undefined1 *)((long)plVar1 + 0x44f) = 0;
            lVar18 = *plVar1;
            puVar17 = *(undefined1 **)(lVar18 + 0x18);
            if (*(undefined1 **)(lVar18 + 0x10) != puVar17) goto LAB_01028bb4;
LAB_01028c48:
            func_0x01770110(lVar18,"\n",1);
// more drops soon - github.com/pengussy
          }
          *(undefined1 *)(plVar1 + 0x86) = 1;
        }
        else {
          lVar18 = plVar1[0x8c];
          if (*(char *)((long)plVar1 + 0x431) != '\x01') {
            lStack_88._0_1_ = 0;
            plVar23 = *(long **)(plVar1[4] + -8);
            if (plVar23 == (long *)0x0) {
              FUN_001717b4();
              goto LAB_01029168;
            }
            (**(code **)(*plVar23 + 0x30))(plVar23,&lStack_88);
            lVar24 = plVar1[4];
            plStack_70 = (long *)__Znwm(0x28);
            *plStack_70 = (long)&UNK_01e5de60;
            plStack_70[1] = (long)plVar1;
            plStack_70[3] = lStack_90;
            plStack_70[2] = (long)plStack_98;
            plStack_70[4] = lVar18;
            func_0x01025c50(&lStack_88,lVar24 + -0x20);
            if (plStack_70 == &lStack_88) {
              lVar18 = 0x20;
LAB_01028a98:
              (**(code **)(*plStack_70 + lVar18))();
            }
            else if (plStack_70 != (long *)0x0) {
              lVar18 = 0x28;
              goto LAB_01028a98;
            }
            *(undefined1 *)((long)plVar1 + 0x431) = 0;
            lVar22 = lVar22 + 8;
            if (lVar22 == lVar9) break;
            goto LAB_01028ab4;
/* WM - reversing this took months of machine time */
          }
          puVar13 = (undefined8 *)__Znwm(0x28);
          *puVar13 = &UNK_01e5de60;
          puVar13[1] = plVar1;
          puVar13[3] = lStack_90;
          puVar13[2] = plStack_98;
          puVar13[4] = lVar18;
          uVar10 = plVar1[4];
          if ((ulong)plVar1[5] <= uVar10) {
            func_0x01027324(plVar1 + 3,0);
            uVar10 = plVar1[4];
          }
          *(undefined8 **)(uVar10 + 0x18) = puVar13;
          plVar1[4] = plVar1[4] + 0x20;
          *(undefined1 *)((long)plVar1 + 0x431) = 0;
        }
        lVar22 = lVar22 + 8;
      } while (lVar22 != lVar9);
      lVar9 = param_1[1];
    }
    uVar12 = func_0x0107d708(lVar9);
    lVar9 = func_0x00ff2270(uVar12,lVar9);
    if (lVar9 != 0) {
      plVar1[0x8c] = lVar9;
      func_0x0103a7a4(plVar1);
      plVar1[0x8c] = 0;
    }
    lVar9 = param_1[1];
    if ((4 < *(byte *)(lVar9 + 0x1c) - 0x2c && *(byte *)(lVar9 + 0x1c) != 0x15) &&
       (iVar8 = func_0x01085ffc(lVar9), iVar8 != 0)) {
      uVar10 = func_0x01085ffc(lVar9);
      if ((uVar10 & 1) == 0) {
/* WM: keep the notice, keep the source honest @ discord.gg/sdkhDjTex */
        func_0x0174f200("cast");
      }
      puVar14 = (ushort *)func_0x01085654(lVar9);
      if ((puVar14 != (ushort *)0x0) &&
         (((*puVar14 >> 8 & 1) != 0 || (*(long *)(puVar14 + 8) != 0)))) {
        lVar9 = param_1[1];
        uVar10 = func_0x01085ffc(lVar9);
        if ((uVar10 & 1) == 0) {
          func_0x0174f200("cast");
        }
        uVar12 = func_0x01085654(lVar9);
        func_0x01029234(plVar1,uVar12);
      }
    }
  }
  if (*(long *)PTR____stack_chk_guard_01f20200 == lStack_68) {
    return;
  }
  ___stack_chk_fail();
LAB_01029130:
  FUN_001717b4();
LAB_01029168:
                    /* WARNING: Does not return */
  pcVar7 = (code *)SoftwareBreakpoint(1,0x102916c);
  (*pcVar7)();
}

