/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x1033bb0:48ca037d27
 */

/* WARNING: Removing unreachable block (ram,0x01033bdc) */
/* WARNING: Removing unreachable block (ram,0x01033c00) */

long FUN_01033bb0(long param_1,long param_2)

{
  if (*(char **)(param_2 + 8) ==
      "ZN12_GLOBAL__N_19ASTDumper9dumpChildIZNS0_15dumpDeclContextEPKN5clang11DeclContextEE3$_0EEvT_EUlbE_"
/* WM: watermarked copy - do not remove @ discord.gg/sdkhDjTex */
     ) {
    return param_1 + 8;
  }
  return 0;
}

