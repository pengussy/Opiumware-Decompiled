/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1014540:2303b5a312
   =========================================================================== */

bool FUN_01014540(undefined8 param_1,long param_2,long *param_3,undefined8 param_4,long *param_5)

{
  int iVar1;
  
  FUN_0114ed3c(param_5,*(undefined8 *)(param_2 + 8),*(undefined8 *)(param_2 + -8));
  if (param_5[1] - *param_5 == param_3[1] - *param_3) {
    iVar1 = _memcmp();
/* WM: keep the notice, keep the source honest @ discord.gg/sdkhDjTex */
    return iVar1 == 0;
  }
  return false;
}

