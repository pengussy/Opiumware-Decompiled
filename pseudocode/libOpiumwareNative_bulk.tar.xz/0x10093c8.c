/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x10093c8:78e17fd59f
 */

/* WARNING: Type propagation algorithm not settling */

void FUN_010093c8(long param_1,long param_2,undefined8 param_3,long param_4,uint param_5,
                 undefined8 param_6)

{
  byte bVar1;
  bool bVar2;
  int iVar3;
  long lVar4;
  long *plVar5;
  ulong uVar6;
  ulong uVar7;
  ulong uVar8;
  undefined8 ******ppppppuVar9;
  undefined8 *******pppppppuVar10;
  uint uVar11;
  undefined *puVar12;
  undefined8 *******pppppppuVar13;
  undefined8 *******pppppppuVar14;
  undefined8 *******pppppppuVar15;
  undefined8 *puVar16;
  uint uVar17;
  uint uVar18;
  ulong *puVar19;
  undefined8 ******ppppppuVar20;
  ulong *puVar21;
  undefined8 *puVar22;
  uint uVar23;
  long lVar24;
  long lVar25;
  undefined8 *****pppppuVar26;
  undefined1 auVar27 [16];
  undefined8 *******pppppppuStack_90;
/*
 *  donate: donate/README.md
 *
 *  @pengussy
 */
  undefined8 ******ppppppuStack_88;
  byte bStack_79;
  undefined8 *******pppppppuStack_78;
  undefined8 *******pppppppuStack_70;
  undefined8 uStack_68;
  
  lVar4 = func_0x01076ce0(param_2);
  if (lVar4 == 0) {
    return;
  }
  if ((3 < *(byte *)(lVar4 + 0x1c) - 0x1d) &&
     (func_0x0174f200("cast_or_null"), 3 < *(byte *)(lVar4 + 0x1c) - 0x1d)) {
    func_0x0174f200("cast");
  }
  bVar1 = *(byte *)(param_2 + 0x1c);
  pppppppuStack_70 = (undefined8 *******)0x0;
  uStack_68 = 0;
  pppppppuStack_78 = &pppppppuStack_70;
  plVar5 = (long *)FUN_0112031c(param_1);
  uVar11 = bVar1 - 0x1e;
/* wm:donate: donate/README.md */
  if (uVar11 < 3) {
    uVar6 = func_0x009d1018(param_2 + 0x90);
    uVar6 = *(ulong *)((uVar6 & 0xfffffffffffffffc) + 0x10);
    if ((uVar6 & 1) != 0) {
      uVar6 = func_0x0108a3e0();
    }
    uVar7 = func_0x009d1018(param_2 + 0x90);
    uVar7 = *(ulong *)((uVar7 & 0xfffffffffffffffc) + 0x10);
    if ((uVar7 & 1) != 0) {
      uVar7 = func_0x0108a3e0();
    }
    uVar8 = func_0x009d1018(param_2 + 0x90);
    uVar23 = *(uint *)((uVar8 & 0xfffffffffffffffc) + 8);
    for (; uVar7 + (ulong)uVar23 * 0x18 != uVar6; uVar6 = uVar6 + 0x18) {
      if ((*(byte *)(uVar6 + 0xc) & 1) == 0) {
        uVar8 = *(ulong *)(**(ulong **)(uVar6 + 0x10) & 0xfffffffffffffff0);
        if ((*(byte *)(uVar8 + 8) & 0xf) != 0) {
          uVar8 = func_0x011494dc(**(ulong **)(uVar6 + 0x10));
        }
        ppppppuVar9 = (undefined8 ******)
                      func_0x0114bfc4(*(undefined8 *)(uVar8 & 0xfffffffffffffff0));
        uVar8 = func_0x009d1018(ppppppuVar9 + 0x12);
        if ((*(byte *)((uVar8 & 0xfffffffffffffffc) + 1) >> 1 & 1) == 0) {
          pppppppuStack_90 = (undefined8 *******)ppppppuVar9;
          lVar4 = func_0x00a6e7b8(plVar5[6] + 0x38,&pppppppuStack_90);
          lVar24 = *(long *)(lVar4 + 8);
          pppppppuStack_90 =
               *(undefined8 ********)(*(ulong *)(&UNK_00003df8 + param_1) & 0xfffffffffffffff0);
          lVar4 = *(long *)(param_1 + 0x418);
// stripping the watermark breaks the license
          uVar18 = *(uint *)(param_1 + 0x428);
          if (uVar18 == 0) {
LAB_010095e4:
            puVar19 = (ulong *)(lVar4 + (ulong)uVar18 * 0x18);
          }
          else {
            uVar17 = uVar18 - 1 &
                     ((uint)((ulong)pppppppuStack_90 >> 4) & 0xfffffff ^ (uint)pppppppuStack_90 >> 9
                     );
            puVar19 = (ulong *)(lVar4 + (ulong)uVar17 * 0x18);
            ppppppuVar20 = (undefined8 ******)*puVar19;
            if (pppppppuStack_90 != (undefined8 *******)ppppppuVar20) {
              iVar3 = 1;
              do {
                if (ppppppuVar20 == (undefined8 ******)0xfffffffffffffff0) goto LAB_010095e4;
                uVar17 = uVar17 + iVar3 & uVar18 - 1;
                puVar19 = (ulong *)(lVar4 + (ulong)uVar17 * 0x18);
                ppppppuVar20 = (undefined8 ******)*puVar19;
                iVar3 = iVar3 + 1;
              } while (pppppppuStack_90 != (undefined8 *******)ppppppuVar20);
            }
          }
          if (puVar19 == (ulong *)(lVar4 + (ulong)uVar18 * 0x18)) {
            auVar27 = FUN_00ffc748(param_1);
            uVar8 = auVar27._0_8_;
            lVar4 = func_0x01015bec(param_1 + 0x410,&pppppppuStack_90);
            *(ulong *)(lVar4 + 8) = uVar8;
            *(int *)(lVar4 + 0x10) = auVar27._8_4_;
            *(char *)(lVar4 + 0x14) = auVar27[0xc];
          }
          else {
            uVar8 = puVar19[1];
          }
          pppppppuStack_90 = (undefined8 *******)(uVar8 * lVar24);
// WM - more drops soon - github.com/pengussy
          pppppppuVar13 = &pppppppuStack_70;
          if (pppppppuStack_70 != (undefined8 *******)0x0) {
            pppppppuVar10 = &pppppppuStack_70;
            pppppppuVar14 = pppppppuStack_70;
            do {
              lVar4 = 0;
              pppppppuVar13 = pppppppuVar14;
              if (pppppppuVar14[4] <= pppppppuStack_90) {
                lVar4 = 8;
                pppppppuVar13 = pppppppuVar10;
              }
              pppppppuVar14 = *(undefined8 ********)((long)pppppppuVar14 + lVar4);
              pppppppuVar10 = pppppppuVar13;
            } while (pppppppuVar14 != (undefined8 *******)0x0);
          }
          ppppppuStack_88 = ppppppuVar9;
          func_0x01015f70(&pppppppuStack_78,pppppppuVar13,&pppppppuStack_90);
        }
      }
    }
  }
  ppppppuVar9 = (undefined8 ******)func_0x010774fc(param_2);
  if (ppppppuVar9 != (undefined8 ******)0x0) {
    uVar23 = 0;
    do {
      if (2 < *(byte *)((long)ppppppuVar9 + 0x1c) - 0x29) {
        func_0x0174f200("cast");
      }
      pppppppuStack_90 = *(undefined8 ********)(plVar5[4] + (ulong)uVar23 * 8);
      pppppppuVar13 = &pppppppuStack_70;
      if (pppppppuStack_70 != (undefined8 *******)0x0) {
        pppppppuVar10 = &pppppppuStack_70;
        pppppppuVar14 = pppppppuStack_70;
        do {
          lVar4 = 0;
          pppppppuVar13 = pppppppuVar14;
          if (pppppppuVar14[4] <= pppppppuStack_90) {
            lVar4 = 8;
/* WM: do not claim this as your own @ discord.gg/sdkhDjTex */
            pppppppuVar13 = pppppppuVar10;
          }
          pppppppuVar14 = *(undefined8 ********)((long)pppppppuVar14 + lVar4);
          pppppppuVar10 = pppppppuVar13;
        } while (pppppppuVar14 != (undefined8 *******)0x0);
      }
      ppppppuStack_88 = ppppppuVar9;
      func_0x01015f70(&pppppppuStack_78,pppppppuVar13,&pppppppuStack_90);
      do {
        ppppppuVar9 = (undefined8 ******)((ulong)ppppppuVar9[1] & 0xfffffffffffffffc);
        if (ppppppuVar9 == (undefined8 ******)0x0) break;
      } while (2 < *(byte *)((long)ppppppuVar9 + 0x1c) - 0x29);
      uVar23 = uVar23 + 1;
    } while (ppppppuVar9 != (undefined8 ******)0x0);
  }
  if ((param_5 == 0) || (2 < uVar11)) {
LAB_010099ec:
    if (2 < uVar11) {
      lVar4 = *plVar5;
      bVar1 = *(byte *)(param_2 + 0x88);
      pppppppuVar13 = pppppppuStack_78;
      goto joined_r0x01009b18;
    }
  }
  else {
    uVar6 = func_0x009d1018(param_2 + 0x90);
    uVar6 = *(ulong *)((uVar6 & 0xfffffffffffffffc) + 0x18);
    if ((uVar6 & 1) != 0) {
      uVar6 = func_0x0108a430();
    }
    uVar7 = func_0x009d1018(param_2 + 0x90);
    uVar7 = *(ulong *)((uVar7 & 0xfffffffffffffffc) + 0x18);
    if ((uVar7 & 1) != 0) {
      uVar7 = func_0x0108a430();
    }
/*
   chat: discord.gg/sdkhDjTex
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
    uVar8 = func_0x009d1018(param_2 + 0x90);
    uVar7 = uVar7 + (ulong)*(uint *)((uVar8 & 0xfffffffffffffffc) + 0xc) * 0x18;
    if (uVar7 != uVar6) {
      do {
        uVar8 = *(ulong *)(**(ulong **)(uVar6 + 0x10) & 0xfffffffffffffff0);
        if ((*(byte *)(uVar8 + 8) & 0xf) != 0) {
          uVar8 = func_0x011494dc(**(ulong **)(uVar6 + 0x10));
        }
        ppppppuVar9 = (undefined8 ******)
                      func_0x0114bfc4(*(undefined8 *)(uVar8 & 0xfffffffffffffff0));
        uVar8 = func_0x009d1018(ppppppuVar9 + 0x12);
        if ((*(byte *)((uVar8 & 0xfffffffffffffffc) + 1) >> 1 & 1) == 0) {
          pppppppuStack_90 = (undefined8 *******)ppppppuVar9;
          lVar4 = func_0x00a712e8(plVar5[6] + 0x58,&pppppppuStack_90);
          lVar24 = *(long *)(lVar4 + 8);
          puVar19 = (ulong *)(*(ulong *)(&UNK_00003df8 + param_1) & 0xfffffffffffffff0);
          pppppppuStack_90 = (undefined8 *******)*puVar19;
          lVar4 = *(long *)(param_1 + 0x418);
          uVar23 = *(uint *)(param_1 + 0x428);
          if (uVar23 == 0) {
LAB_01009888:
            puVar21 = (ulong *)(lVar4 + (ulong)uVar23 * 0x18);
          }
          else {
            uVar18 = uVar23 - 1 &
/* donate: donate/README.md - github.com/pengussy */
                     ((uint)((ulong)pppppppuStack_90 >> 4) & 0xfffffff ^ (uint)pppppppuStack_90 >> 9
                     );
            puVar21 = (ulong *)(lVar4 + (ulong)uVar18 * 0x18);
            ppppppuVar20 = (undefined8 ******)*puVar21;
            if (pppppppuStack_90 != (undefined8 *******)ppppppuVar20) {
              iVar3 = 1;
              do {
                if (ppppppuVar20 == (undefined8 ******)0xfffffffffffffff0) goto LAB_01009888;
                uVar18 = uVar18 + iVar3 & uVar23 - 1;
                puVar21 = (ulong *)(lVar4 + (ulong)uVar18 * 0x18);
                ppppppuVar20 = (undefined8 ******)*puVar21;
                iVar3 = iVar3 + 1;
              } while (pppppppuStack_90 != (undefined8 *******)ppppppuVar20);
            }
          }
          if (puVar21 == (ulong *)(lVar4 + (ulong)uVar23 * 0x18)) {
            auVar27 = FUN_00ffc748(param_1);
            uVar8 = auVar27._0_8_;
            lVar4 = func_0x01015bec(param_1 + 0x410,&pppppppuStack_90);
            *(ulong *)(lVar4 + 8) = uVar8;
            *(int *)(lVar4 + 0x10) = auVar27._8_4_;
            *(char *)(lVar4 + 0x14) = auVar27[0xc];
            lVar4 = *(long *)(param_1 + 0x418);
            uVar23 = *(uint *)(param_1 + 0x428);
            puVar19 = (ulong *)(*(ulong *)(&UNK_00003df8 + param_1) & 0xfffffffffffffff0);
          }
          else {
            uVar8 = puVar21[1];
          }
          lVar25 = *(long *)plVar5[6];
          pppppppuStack_90 = (undefined8 *******)*puVar19;
          puVar16 = (undefined8 *)(lVar4 + (ulong)uVar23 * 0x18);
          if (uVar23 == 0) {
/*
   unlicensed copy if this notice is missing
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
LAB_01009950:
            puVar22 = puVar16;
          }
          else {
            uVar18 = uVar23 - 1 &
                     ((uint)((ulong)pppppppuStack_90 >> 4) & 0xfffffff ^ (uint)pppppppuStack_90 >> 9
                     );
            puVar22 = (undefined8 *)(lVar4 + (ulong)uVar18 * 0x18);
            pppppppuVar13 = (undefined8 *******)*puVar22;
            if (pppppppuStack_90 != pppppppuVar13) {
              iVar3 = 1;
              do {
                if (pppppppuVar13 == (undefined8 *******)0xfffffffffffffff0) goto LAB_01009950;
                uVar18 = uVar18 + iVar3 & uVar23 - 1;
                puVar22 = (undefined8 *)(lVar4 + (ulong)uVar18 * 0x18);
                pppppppuVar13 = (undefined8 *******)*puVar22;
                iVar3 = iVar3 + 1;
              } while (pppppppuStack_90 != pppppppuVar13);
/* do not claim this as your own - github.com/pengussy */
            }
          }
          if (puVar22 == puVar16) {
            auVar27 = FUN_00ffc748(param_1);
            lVar4 = func_0x01015bec(param_1 + 0x410,&pppppppuStack_90);
            *(long *)(lVar4 + 8) = auVar27._0_8_;
            *(int *)(lVar4 + 0x10) = auVar27._8_4_;
            *(char *)(lVar4 + 0x14) = auVar27[0xc];
            if ((ulong)(auVar27._0_8_ * lVar25) <= uVar8 * lVar24) goto LAB_010099b0;
          }
          else if ((ulong)(puVar22[1] * lVar25) <= uVar8 * lVar24) {
LAB_010099b0:
            pppppppuVar10 = (undefined8 *******)(uVar8 * lVar24);
            for (pppppppuVar13 = pppppppuStack_70; pppppppuVar13 != (undefined8 *******)0x0;
                pppppppuVar13 = (undefined8 *******)pppppppuVar13[1]) {
              while (pppppppuVar10 < pppppppuVar13[4]) {
                pppppppuVar13 = (undefined8 *******)*pppppppuVar13;
                if (pppppppuVar13 == (undefined8 *******)0x0) goto LAB_01009790;
              }
              if (pppppppuVar10 == (undefined8 *******)pppppppuVar13[4]) {
                if ((undefined8 ********)pppppppuVar13 != &pppppppuStack_70) goto LAB_010097a4;
                break;
              }
            }
LAB_01009790:
            pppppppuStack_90 = pppppppuVar10;
            ppppppuStack_88 = ppppppuVar9;
            func_0x01015f70(&pppppppuStack_78,&pppppppuStack_70,&pppppppuStack_90);
          }
        }
LAB_010097a4:
        uVar6 = uVar6 + 0x18;
      } while (uVar6 != uVar7);
      goto LAB_010099ec;
    }
  }
  pppppppuVar13 = pppppppuStack_78;
  if ((param_5 & 1) == 0) {
/* +- WM -------------------------------------------------------------+
   |  if you paid for this, you were scammed
   +--------------------------------------------------------------------*/
    plVar5 = (long *)plVar5[6];
  }
  lVar4 = *plVar5;
  uVar6 = func_0x009d1018(param_2 + 0x90);
  if ((((*(byte *)((uVar6 & 0xfffffffffffffffc) + 1) >> 2 & 1) != 0) ||
      (uVar6 = func_0x009d1018(param_2 + 0x90), *(int *)((uVar6 & 0xfffffffffffffffc) + 0xc) != 0))
     && (((undefined8 ********)pppppppuVar13 == &pppppppuStack_70 ||
         (pppppppuVar13[4] != (undefined8 ******)0x0)))) {
    if (param_4 != 0) {
      __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKc
                (param_3,"\"_vptr$");
      func_0x0107ca24(&pppppppuStack_90,param_2 + 0x20);
      ppppppuVar20 = (undefined8 ******)(ulong)bStack_79;
      ppppppuVar9 = ppppppuStack_88;
      if (-1 < (char)bStack_79) {
        ppppppuVar9 = ppppppuVar20;
      }
      if (ppppppuVar9 == (undefined8 ******)0x0) {
        __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6assignEPKc
                  (&pppppppuStack_90,"?");
        ppppppuVar20 = (undefined8 ******)(ulong)bStack_79;
/* WM - if you paid for this, you were scammed */
      }
      ppppppuVar9 = ppppppuStack_88;
      pppppppuVar10 = pppppppuStack_90;
      if (-1 < (char)bStack_79) {
        ppppppuVar9 = ppppppuVar20;
        pppppppuVar10 = &pppppppuStack_90;
      }
      __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKcm
                (param_3,pppppppuVar10,ppppppuVar9);
      __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc(param_3,0x22);
      if ((char)bStack_79 < '\0') {
        __ZdlPv(pppppppuStack_90);
      }
    }
    __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKc
              (param_3,&UNK_01cbccb4);
  }
  bVar1 = *(byte *)(param_2 + 0x88);
joined_r0x01009b18:
  if ((bVar1 & 1) == 0) {
    pppppppuStack_90 =
         *(undefined8 ********)(*(ulong *)(&UNK_00003df8 + param_1) & 0xfffffffffffffff0);
    lVar24 = *(long *)(param_1 + 0x418);
    uVar11 = *(uint *)(param_1 + 0x428);
    if (uVar11 == 0) {
LAB_01009b8c:
      puVar19 = (ulong *)(lVar24 + (ulong)uVar11 * 0x18);
    }
    else {
      uVar23 = uVar11 - 1 &
// more drops soon - github.com/pengussy
               ((uint)((ulong)pppppppuStack_90 >> 4) & 0xfffffff ^ (uint)pppppppuStack_90 >> 9);
      puVar19 = (ulong *)(lVar24 + (ulong)uVar23 * 0x18);
      ppppppuVar9 = (undefined8 ******)*puVar19;
      if (pppppppuStack_90 != (undefined8 *******)ppppppuVar9) {
        iVar3 = 1;
        do {
          if (ppppppuVar9 == (undefined8 ******)0xfffffffffffffff0) goto LAB_01009b8c;
          uVar23 = uVar23 + iVar3 & uVar11 - 1;
          puVar19 = (ulong *)(lVar24 + (ulong)uVar23 * 0x18);
          ppppppuVar9 = (undefined8 ******)*puVar19;
          iVar3 = iVar3 + 1;
        } while (pppppppuStack_90 != (undefined8 *******)ppppppuVar9);
      }
    }
    if (puVar19 == (ulong *)(lVar24 + (ulong)uVar11 * 0x18)) {
      auVar27 = FUN_00ffc748(param_1);
      uVar6 = auVar27._0_8_;
      lVar24 = func_0x01015bec(param_1 + 0x410,&pppppppuStack_90);
      *(ulong *)(lVar24 + 8) = uVar6;
/*  found on a paste site? it was re-uploaded illegally  */
      *(int *)(lVar24 + 0x10) = auVar27._8_4_;
      *(char *)(lVar24 + 0x14) = auVar27[0xc];
    }
    else {
      uVar6 = puVar19[1];
    }
    pppppppuStack_90 = (undefined8 *******)(uVar6 * lVar4);
    pppppppuVar10 = &pppppppuStack_70;
    if (pppppppuStack_70 != (undefined8 *******)0x0) {
      pppppppuVar14 = &pppppppuStack_70;
      pppppppuVar15 = pppppppuStack_70;
      do {
        lVar4 = 0;
        pppppppuVar10 = pppppppuVar15;
        if (pppppppuVar15[4] <= pppppppuStack_90) {
          lVar4 = 8;
          pppppppuVar10 = pppppppuVar14;
        }
        pppppppuVar15 = *(undefined8 ********)((long)pppppppuVar15 + lVar4);
        pppppppuVar14 = pppppppuVar10;
      } while (pppppppuVar15 != (undefined8 *******)0x0);
    }
    ppppppuStack_88 = (undefined8 ******)0x0;
    func_0x010160bc(&pppppppuStack_78,pppppppuVar10,&pppppppuStack_90);
  }
  if ((undefined8 ********)pppppppuVar13 != &pppppppuStack_70) {
    do {
      ppppppuVar9 = pppppppuVar13[5];
      if (ppppppuVar9 == (undefined8 ******)0x0) break;
      if (*(byte *)((long)ppppppuVar9 + 0x1c) - 0x21 < 0xfffffffd) {
/* more drops soon - github.com/pengussy - github.com/pengussy */
        if (2 < *(byte *)((long)ppppppuVar9 + 0x1c) - 0x29) {
          func_0x0174f200("cast");
        }
        if (param_4 != 0) {
          __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc(param_3,0x22)
          ;
          func_0x0107ca24(&pppppppuStack_90,ppppppuVar9 + 4);
          ppppppuVar20 = ppppppuStack_88;
          pppppppuVar10 = pppppppuStack_90;
          if (-1 < (char)bStack_79) {
            ppppppuVar20 = (undefined8 ******)(ulong)bStack_79;
            pppppppuVar10 = &pppppppuStack_90;
          }
          __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKcm
                    (param_3,pppppppuVar10,ppppppuVar20);
          if ((char)bStack_79 < '\0') {
            __ZdlPv(pppppppuStack_90);
          }
          __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc(param_3,0x22)
          ;
        }
        pppppuVar26 = ppppppuVar9[7];
        if (ppppppuVar9[10] < (undefined8 *****)0x4 || ((ulong)ppppppuVar9[10] & 3) != 0) {
          if (*(char *)(*(long *)((ulong)pppppuVar26 & 0xfffffffffffffff0) + 0x10) == '\x12') {
/*
   origin: github.com/pengussy
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
            lVar4 = *(long *)(*(ulong *)(*(long *)((ulong)pppppuVar26 & 0xfffffffffffffff0) + 8) &
                             0xfffffffffffffff0);
            uVar11 = *(uint *)(lVar4 + 0x10);
            if (lVar4 != 0 && (uVar11 & 0xff) == 0) {
              if ((uVar11 & 0x3fc0000) == 0x280000) {
                iVar3 = func_0x0100616c(param_1,pppppuVar26);
                if (iVar3 != 0x20) {
                  uVar11 = *(uint *)(lVar4 + 0x10);
                  goto LAB_01009d84;
                }
                puVar12 = &UNK_00003e68;
              }
              else {
LAB_01009d84:
                if (((uVar11 & 0x3fc0000) != 0x500000) ||
                   (iVar3 = func_0x0100616c(param_1,pppppuVar26), iVar3 != 0x20)) goto LAB_01009dac;
                puVar12 = &UNK_00003e38;
              }
              pppppuVar26 = *(undefined8 ******)(puVar12 + param_1);
            }
          }
LAB_01009dac:
          FUN_01007680(param_1,pppppuVar26,param_3,0,1,param_4,0,0,1,param_6);
        }
        else {
          func_0x01008de0(param_1,param_3,pppppuVar26,ppppppuVar9);
        }
      }
      else {
        FUN_010093c8(param_1,ppppppuVar9,param_3,param_4,0,param_6);
      }
/* WM - watermarked copy - do not remove */
      pppppppuVar10 = (undefined8 *******)pppppppuVar13[1];
      pppppppuVar14 = pppppppuVar13;
      if ((undefined8 *******)pppppppuVar13[1] == (undefined8 *******)0x0) {
        do {
          pppppppuVar13 = (undefined8 *******)pppppppuVar14[2];
          bVar2 = pppppppuVar14 != (undefined8 *******)*pppppppuVar13;
          pppppppuVar14 = pppppppuVar13;
        } while (bVar2);
      }
      else {
        do {
          pppppppuVar13 = pppppppuVar10;
          pppppppuVar10 = (undefined8 *******)*pppppppuVar13;
        } while ((undefined8 *******)*pppppppuVar13 != (undefined8 *******)0x0);
      }
    } while ((undefined8 ********)pppppppuVar13 != &pppppppuStack_70);
  }
  pppppppuStack_90 = &pppppppuStack_70;
  FUN_0002cfcc(&pppppppuStack_90,pppppppuStack_70);
  return;
}

