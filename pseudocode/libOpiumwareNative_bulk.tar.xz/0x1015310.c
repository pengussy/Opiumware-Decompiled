/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1015310:dfc6babcc9
 */

/* WARNING: Possible PIC construction at 0x0101532c: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x01015330) */

void FUN_01015310(undefined8 param_1,long param_2,long *param_3)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  
  uVar1 = *(undefined8 *)(param_2 + 8);
  puVar2 = (undefined8 *)param_3[1];
/*
 *  watermarked copy - do not remove
 *
 *  @pengussy
 */
  if ((ulong)(param_3[2] - (long)puVar2) < 8) {
    func_0x01755374(param_3,param_3 + 3,(long)puVar2 + (8 - *param_3) & 0xfffffffffffffffc,4);
    puVar2 = (undefined8 *)param_3[1];
  }
  *puVar2 = uVar1;
  param_3[1] = param_3[1] + 8;
  return;
}

