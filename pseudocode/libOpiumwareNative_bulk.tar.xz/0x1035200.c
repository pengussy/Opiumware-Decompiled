/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1035200:e9b3271b8c
 */

/* WARNING: Removing unreachable block (ram,0x0103522c) */
/* WARNING: Removing unreachable block (ram,0x01035250) */

long FUN_01035200(long param_1,long param_2)

{
  if (*(char **)(param_2 + 8) ==
      "ZN12_GLOBAL__N_19ASTDumper9dumpChildIZZZNS0_11dumpLookupsEPKN5clang11DeclContextEbENK3$_0clEvENKUlvE_clEvEUlvE_EEvT_EUlbE_"
/* wm:chat: discord.gg/sdkhDjTex */
     ) {
    return param_1 + 8;
  }
  return 0;
}

