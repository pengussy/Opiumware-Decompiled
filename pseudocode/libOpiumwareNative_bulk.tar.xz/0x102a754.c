/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x102a754:fb97e4cc20
 *  --------------------------------------------------------------------------*/

/* WARNING: Possible PIC construction at 0x01027cec: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x01027cf0) */
/* WARNING: Removing unreachable block (ram,0x01027cfc) */
/* WARNING: Removing unreachable block (ram,0x01027d24) */
/* WARNING: Removing unreachable block (ram,0x01027ef0) */
/* WARNING: Removing unreachable block (ram,0x01027d30) */
/* WARNING: Removing unreachable block (ram,0x01027d04) */
/* WARNING: Removing unreachable block (ram,0x01027d58) */
/* WARNING: Removing unreachable block (ram,0x01027d5c) */
/* WARNING: Removing unreachable block (ram,0x01027d08) */
/* WARNING: Removing unreachable block (ram,0x01027d18) */
/* WARNING: Removing unreachable block (ram,0x01027db8) */
/* WARNING: Removing unreachable block (ram,0x01027e64) */
/* WARNING: Removing unreachable block (ram,0x01027dc0) */
/* WARNING: Removing unreachable block (ram,0x01027e80) */
/* WARNING: Removing unreachable block (ram,0x01027dd8) */
/* WARNING: Removing unreachable block (ram,0x01027e90) */
/* WARNING: Removing unreachable block (ram,0x01023ebc) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0102a754(long ******param_1,ulong param_2)

{
  long ******pppppplVar1;
  uint uVar2;
  char cVar3;
  byte bVar4;
  undefined1 *puVar5;
  code *pcVar6;
  int iVar7;
  long lVar8;
  long ****pppplVar9;
  undefined8 uVar10;
  long *******ppppppplVar11;
  long ******pppppplVar12;
/*  donate: donate/README.md  */
  ulong uVar13;
  undefined8 *puVar14;
  ushort *puVar15;
  uint uVar16;
  long lVar17;
  long *****ppppplVar18;
  long *****ppppplVar19;
  long ***ppplVar20;
  long *****ppppplVar21;
  long *****ppppplVar22;
  ulong *puVar23;
  long ******pppppplVar24;
  long **pplVar25;
  long ****unaff_x20;
  long *plVar26;
  long *plVar27;
  ulong *puVar28;
  undefined8 *puVar29;
  uint uVar30;
  undefined1 auVar31 [16];
  long ******pppppplStack_108;
  long *****ppppplStack_100;
/* WM - more drops soon - github.com/pengussy */
  long lStack_f8;
  ulong uStack_f0;
  byte bStack_e1;
  long *plStack_e0;
  long lStack_d8;
  long *******ppppppplStack_68;
  long ***ppplStack_60;
  undefined8 uStack_58;
  
  ppplVar20 = (long ***)(param_2 & 0xfffffffffffffffc);
  if ((((uint)param_2 >> 1 & 1) == 0) || (ppplVar20 == (long ***)0x0)) {
    if ((param_2 & 2) != 0) {
      ppplVar20 = (long ***)0x0;
    }
    lVar8 = *(long *)PTR____stack_chk_guard_01f20200;
    ppppppplStack_68 = (long *******)param_1;
    ppplStack_60 = ppplVar20;
// if you paid for this, you were scammed
    if (*(char *)(param_1 + 0x86) == '\x01') {
      *(undefined1 *)(param_1 + 0x86) = 0;
      ppppppplVar11 = (long *******)&ppppppplStack_68;
    }
    else {
      ppppplVar21 = param_1[0x8c];
      if (*(char *)((long)param_1 + 0x431) == '\x01') {
        unaff_x20 = (long ****)__Znwm(0x28);
        *unaff_x20 = (long ***)&UNK_01e5df60;
        unaff_x20[1] = (long ***)param_1;
        unaff_x20[3] = ppplStack_60;
        unaff_x20[2] = (long ***)ppppppplStack_68;
        unaff_x20[4] = (long ***)ppppplVar21;
        ppppplVar21 = param_1[4];
        if (param_1[5] <= ppppplVar21) {
          func_0x01027324(param_1 + 3,0);
          ppppplVar21 = param_1[4];
        }
        ppppplVar21[3] = unaff_x20;
        param_1[4] = param_1[4] + 4;
code_r0x01027eac:
        *(undefined1 *)((long)param_1 + 0x431) = 0;
        if (*(long *)PTR____stack_chk_guard_01f20200 == lVar8) {
          return;
// origin: github.com/pengussy
        }
        ___stack_chk_fail();
      }
      else {
        uStack_58._0_1_ = 0;
        pppplVar9 = param_1[4][-1];
        if (pppplVar9 != (long ****)0x0) {
          unaff_x20 = (long ****)&uStack_58;
          (*(code *)(*pppplVar9)[6])(pppplVar9,&uStack_58);
          ppppplVar18 = param_1[4];
          plVar26 = (long *)__Znwm(0x28);
          *plVar26 = (long)&UNK_01e5df60;
          plVar26[1] = (long)param_1;
          plVar26[3] = (long)ppplStack_60;
          plVar26[2] = (long)ppppppplStack_68;
          plVar26[4] = (long)ppppplVar21;
          func_0x01025c50(&uStack_58,ppppplVar18 + -4);
          if (plVar26 == &uStack_58) {
            lVar17 = 0x20;
          }
          else {
            if (plVar26 == (long *)0x0) goto code_r0x01027eac;
            lVar17 = 0x28;
          }
          (**(code **)(*plVar26 + lVar17))();
          goto code_r0x01027eac;
        }
      }
      uVar10 = func_0x001717b4();
      (*(code *)(*unaff_x20)[5])(unaff_x20);
      __Unwind_Resume(uVar10);
/* +- WM -------------------------------------------------------------+
   |  origin: github.com/pengussy
   +--------------------------------------------------------------------*/
      ppppppplVar11 = (long *******)__Unwind_Resume();
    }
    lStack_d8 = *(long *)PTR____stack_chk_guard_01f20200;
    pppppplVar1 = *ppppppplVar11;
    pppppplVar12 = ppppppplVar11[1];
    if (pppppplVar12 == (long ******)0x0) {
      if (*(char *)(pppppplVar1 + 0x8d) != '\0') {
        (*(code *)(**pppppplVar1)[5])(*pppppplVar1,4,0,0);
      }
      ppppplVar21 = *pppppplVar1;
      pppplVar9 = ppppplVar21[3];
      if ((ulong)((long)ppppplVar21[2] - (long)pppplVar9) < 10) {
        func_0x01770110(ppppplVar21,&UNK_01cbd5c4,10);
        cVar3 = *(char *)(pppppplVar1 + 0x8d);
      }
      else {
        *(undefined2 *)(pppplVar9 + 1) = 0x3e3e;
        *pppplVar9 = _UNK_01cbd5c4;
        ppppplVar21[3] = (long ****)((long)ppppplVar21[3] + 10);
        cVar3 = *(char *)(pppppplVar1 + 0x8d);
      }
      if (cVar3 == '\x01') {
        (*(code *)(**pppppplVar1)[6])();
      }
    }
    else {
/*
   proprietary - see LICENSE - do not sell
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
      if (*(char *)(pppppplVar1 + 0x8d) != '\0') {
        (*(code *)(**pppppplVar1)[5])(*pppppplVar1,2,1,0);
        pppppplVar12 = ppppppplVar11[1];
      }
      ppppplVar21 = *pppppplVar1;
      lVar8 = func_0x0107d974(pppppplVar12);
      if (lVar8 != 0) {
        uVar13 = _strlen(lVar8);
        if ((ulong)((long)ppppplVar21[2] - (long)ppppplVar21[3]) < uVar13) {
          ppppplVar21 = (long *****)func_0x01770110(ppppplVar21,lVar8,uVar13);
        }
        else if (uVar13 != 0) {
          _memcpy(ppppplVar21[3],lVar8,uVar13);
          ppppplVar21[3] = (long ****)((long)ppppplVar21[3] + uVar13);
        }
      }
      if ((ulong)((long)ppppplVar21[2] - (long)ppppplVar21[3]) < 4) {
        func_0x01770110(ppppplVar21,&UNK_01cbd7a3,4);
        cVar3 = *(char *)(pppppplVar1 + 0x8d);
      }
      else {
        *(undefined4 *)ppppplVar21[3] = 0x6c636544;
        ppppplVar21[3] = (long ****)((long)ppppplVar21[3] + 4);
        cVar3 = *(char *)(pppppplVar1 + 0x8d);
      }
/* WM: watermarked copy - do not remove @ discord.gg/sdkhDjTex */
      if (cVar3 == '\x01') {
        (*(code *)(**pppppplVar1)[6])();
      }
      func_0x01023cc0(pppppplVar1,ppppppplVar11[1]);
      pppppplVar12 = ppppppplVar11[1];
      plVar26 = (long *)((ulong)pppppplVar12[2] & 0xfffffffffffffffc);
      if (((uint)pppppplVar12[2] >> 1 & 1) != 0) {
        if (plVar26[1] != *plVar26) {
          ppppplVar21 = *pppppplVar1;
          if ((ulong)((long)ppppplVar21[2] - (long)ppppplVar21[3]) < 8) {
            ppppplVar21 = (long *****)func_0x01770110(ppppplVar21,&UNK_01cbd7a8,8);
            ppppplVar18 = ppppppplVar11[1][2];
            uVar16 = (uint)ppppplVar18;
          }
          else {
            *ppppplVar21[3] = (long ***)0x20746e6572617020;
            ppppplVar21[3] = ppppplVar21[3] + 1;
            ppppplVar18 = ppppppplVar11[1][2];
            uVar16 = (uint)ppppplVar18;
          }
          puVar28 = (ulong *)((ulong)ppppplVar18 & 0xfffffffffffffffc);
          if ((uVar16 >> 1 & 1) != 0) {
            puVar28 = (ulong *)*puVar28;
          }
/*
 *  donate: donate/README.md
 *
 *  @pengussy
 */
          uVar10 = func_0x010855a4(puVar28);
          func_0x01770d74(ppppplVar21,uVar10);
          pppppplVar12 = ppppppplVar11[1];
          plVar26 = (long *)((ulong)pppppplVar12[2] & 0xfffffffffffffffc);
          if (((uint)pppppplVar12[2] >> 1 & 1) == 0) goto code_r0x010281a4;
        }
        plVar26 = (long *)*plVar26;
      }
code_r0x010281a4:
      if ((plVar26 != (long *)0x0) && (plVar27 = plVar26 + -7, (char)*plVar26 == '\v')) {
        ppppplVar21 = *pppppplVar1;
        if ((ulong)((long)ppppplVar21[2] - (long)ppppplVar21[3]) < 8) {
          ppppplVar21 = (long *****)func_0x01770110(ppppplVar21,&UNK_01cbd7a8,8);
          lVar8 = func_0x00e7c5a8(plVar27);
        }
        else {
          *ppppplVar21[3] = (long ***)0x20746e6572617020;
          ppppplVar21[3] = ppppplVar21[3] + 1;
/* WM: do not claim this as your own @ discord.gg/sdkhDjTex */
          lVar8 = func_0x00e7c5a8(plVar27);
        }
        if (lVar8 != 0) {
          uVar13 = _strlen();
          if ((ulong)((long)ppppplVar21[2] - (long)ppppplVar21[3]) < uVar13) {
            func_0x01770110(ppppplVar21,lVar8,uVar13);
          }
          else if (uVar13 != 0) {
            _memcpy(ppppplVar21[3],lVar8,uVar13);
            ppppplVar21[3] = (long ****)((long)ppppplVar21[3] + uVar13);
          }
        }
        func_0x01023cc0(pppppplVar1,plVar27);
        pppppplVar12 = ppppppplVar11[1];
      }
      uVar16 = *(uint *)((long)pppppplVar12 + 0x1c);
      if (0x3e < (uVar16 & 0xff)) {
        func_0x0174ef58("Decl that isn\'t part of DeclNodes.inc!",&UNK_01cbd7fb,0x361);
code_r0x01029150:
        func_0x0174ef58("Decl that isn\'t part of DeclNodes.inc!",
                        "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/include/clang/AST/DeclVisitor.h"
                        ,0x2d);
        goto code_r0x01029168;
      }
      ppppplVar21 = *pppppplVar1;
      switch(uVar16 & 0xff) {
      case 0xd:
        FUN_010295e0(ppppplVar21,pppppplVar12[0xb]);
        break;
      case 0xe:
        FUN_010295e0(ppppplVar21,pppppplVar12[7]);
        break;
      case 0x13:
        FUN_010295e0(ppppplVar21,pppppplVar12[0xd]);
        break;
      case 0x14:
/* +- WM -------------------------------------------------------------+
   |  reversing this took months of machine time
   +--------------------------------------------------------------------*/
        FUN_010295e0(ppppplVar21,pppppplVar12[0xd]);
        break;
      case 0x17:
      case 0x18:
      case 0x19:
      case 0x1a:
        FUN_010295e0(ppppplVar21,pppppplVar12[9]);
        break;
      case 0x1c:
      case 0x1d:
      case 0x1e:
      case 0x1f:
      case 0x20:
        FUN_010295e0(ppppplVar21,pppppplVar12[0xd]);
        break;
      case 0x22:
      case 0x23:
      case 0x24:
        FUN_010295e0(ppppplVar21,pppppplVar12[9]);
        break;
/* wm:found on a paste site? it was re-uploaded illegally */
      case 0x25:
        func_0x01029658();
        break;
      case 0x26:
        func_0x01029724();
        break;
      case 0x28:
        FUN_010295e0(ppppplVar21,pppppplVar12[7]);
        break;
      case 0x29:
      case 0x2a:
      case 0x2b:
        func_0x010297f0();
        break;
      case 0x2c:
      case 0x2d:
      case 0x2e:
      case 0x2f:
      case 0x30:
        FUN_010295e0(ppppplVar21,pppppplVar12[0xe]);
        break;
      case 0x36:
        if ((uVar16 & 0xfe) != 0x36) {
          func_0x0174f200("cast");
        }
      case 0x33:
      case 0x34:
      case 0x35:
      case 0x37:
        FUN_010295e0(ppppplVar21,pppppplVar12[10]);
        break;
      case 0x38:
        func_0x010298c0();
        break;
/* keep the notice, keep the source honest */
      case 0x3a:
        func_0x0102998c(ppppplVar21);
      }
      uVar10 = (*(code *)(*ppppppplVar11[1])[2])();
      func_0x01025254(pppppplVar1,uVar10);
      ppppplVar21 = *pppppplVar1;
      pppplVar9 = ppppplVar21[3];
      if (pppplVar9 < ppppplVar21[2]) {
        ppppplVar21[3] = (long ****)((long)pppplVar9 + 1);
        *(undefined1 *)pppplVar9 = 0x20;
      }
      else {
        func_0x01771098(ppppplVar21,0x20);
      }
      func_0x01025380(pppppplVar1,*(undefined4 *)(ppppppplVar11[1] + 3));
      pppppplVar12 = ppppppplVar11[1];
      uVar16 = *(uint *)((long)pppppplVar12 + 0x1c);
      if ((uVar16 >> 0xf & 1) == 0) {
code_r0x01028354:
        if (((uVar16 & 0x18000) == 0x10000) &&
           (ppppplVar21 = pppppplVar12[-1], ppppplVar21 != (long *****)0x0)) {
          ppppplVar18 = *pppppplVar1;
          pppplVar9 = ppppplVar18[3];
          if ((ulong)((long)ppppplVar18[2] - (long)pppplVar9) < 0xc) {
            ppppplVar18 = (long *****)func_0x01770110(ppppplVar18,&UNK_01cbd7b6,0xc);
          }
          else {
            *(undefined4 *)(pppplVar9 + 1) = 0x20296c61;
            *pppplVar9 = _UNK_01cbd7b6;
            ppppplVar18[3] = (long ****)((long)ppppplVar18[3] + 0xc);
/*
 *  proprietary - see LICENSE - do not sell
 *
 *  @pengussy
 */
          }
          func_0x0165d1f8(&lStack_f8,ppppplVar21);
          uVar13 = uStack_f0;
          puVar5 = (undefined1 *)CONCAT71(lStack_f8._1_7_,(undefined1)lStack_f8);
          if (-1 < (char)bStack_e1) {
            uVar13 = (ulong)bStack_e1;
            puVar5 = (undefined1 *)&lStack_f8;
          }
          func_0x01770110(ppppplVar18,puVar5,uVar13);
          goto code_r0x01028438;
        }
code_r0x01028440:
        pppppplVar12 = ppppppplVar11[1];
        uVar16 = *(uint *)((long)pppppplVar12 + 0x1c);
      }
      else {
        lVar8 = func_0x0107d82c();
        if (lVar8 == 0) {
          pppppplVar12 = ppppppplVar11[1];
          uVar16 = *(uint *)((long)pppppplVar12 + 0x1c);
          goto code_r0x01028354;
        }
        ppppplVar21 = *pppppplVar1;
        if ((ulong)((long)ppppplVar21[2] - (long)ppppplVar21[3]) < 4) {
          ppppplVar21 = (long *****)func_0x01770110(ppppplVar21,&UNK_01cbd7b1,4);
        }
        else {
          *(undefined4 *)ppppplVar21[3] = 0x206e6920;
          ppppplVar21[3] = (long ****)((long)ppppplVar21[3] + 4);
        }
        func_0x0165d1f8(&lStack_f8,lVar8);
/* WM: donate: donate/README.md @ discord.gg/sdkhDjTex */
        uVar13 = uStack_f0;
        puVar5 = (undefined1 *)CONCAT71(lStack_f8._1_7_,(undefined1)lStack_f8);
        if (-1 < (char)bStack_e1) {
          uVar13 = (ulong)bStack_e1;
          puVar5 = (undefined1 *)&lStack_f8;
        }
        func_0x01770110(ppppplVar21,puVar5,uVar13);
code_r0x01028438:
        if (-1 < (char)bStack_e1) goto code_r0x01028440;
        __ZdlPv(CONCAT71(lStack_f8._1_7_,(undefined1)lStack_f8));
        pppppplVar12 = ppppppplVar11[1];
        uVar16 = *(uint *)((long)pppppplVar12 + 0x1c);
      }
      uVar30 = (uVar16 & 0xff) - 0x3b;
      if ((pppppplVar12 != (long ******)0x0) && (0xffffffcf < uVar30)) {
        lVar8 = func_0x0107d708(pppppplVar12);
        lVar17 = *(long *)(lVar8 + 0x620);
        uVar2 = *(uint *)(lVar8 + 0x630);
        puVar28 = (ulong *)(lVar17 + (ulong)uVar2 * 0x10);
        if (uVar2 == 0) {
code_r0x010284e8:
          puVar23 = puVar28;
        }
        else {
          uVar13 = (ulong)(uVar2 - 1 &
                          ((uint)((ulong)pppppplVar12 >> 4) & 0xfffffff ^ (uint)pppppplVar12 >> 9));
/* found on a paste site? it was re-uploaded illegally */
          puVar23 = (ulong *)(lVar17 + uVar13 * 0x10);
          pppppplVar24 = (long ******)*puVar23;
          if (pppppplVar12 != pppppplVar24) {
            iVar7 = 1;
            do {
              if (pppppplVar24 == (long ******)0xfffffffffffffffc) goto code_r0x010284e8;
              uVar13 = (ulong)((int)uVar13 + iVar7 & uVar2 - 1);
              pppppplVar24 = *(long *******)(lVar17 + uVar13 * 0x10);
              iVar7 = iVar7 + 1;
            } while (pppppplVar12 != pppppplVar24);
            puVar23 = (ulong *)(lVar17 + uVar13 * 0x10);
          }
        }
        if (puVar23 != puVar28) {
          puVar28 = puVar23 + 1;
          uVar13 = *puVar28;
          if (3 < uVar13) {
            if (((uint)uVar13 >> 1 & 1) == 0) {
              puVar23 = puVar23 + 2;
            }
            else {
              puVar28 = *(ulong **)(uVar13 & 0xfffffffffffffffc);
              puVar23 = (ulong *)((long *)(uVar13 & 0xfffffffffffffffc))[1];
              if (puVar23 == puVar28) goto code_r0x010287c8;
            }
            do {
              while (ppplVar20 = (long ***)*puVar28, *(char *)(pppppplVar1 + 0x86) == '\x01') {
                *(undefined1 *)(pppppplVar1 + 0x86) = 0;
/* wm:donate: donate/README.md */
                ppppplVar21 = *pppppplVar1;
                if ((ulong)((long)ppppplVar21[2] - (long)ppppplVar21[3]) < 8) {
                  ppppplVar21 = (long *****)func_0x01770110(ppppplVar21,&UNK_01cbd873,8);
                }
                else {
                  *ppppplVar21[3] = (long ***)0x206e69206f736c61;
                  ppppplVar21[3] = ppppplVar21[3] + 1;
                }
                func_0x0165d1f8(&lStack_f8,ppplVar20);
                uVar13 = uStack_f0;
                plVar26 = (long *)CONCAT71(lStack_f8._1_7_,(undefined1)lStack_f8);
                if (-1 < (char)bStack_e1) {
                  uVar13 = (ulong)bStack_e1;
                  plVar26 = &lStack_f8;
                }
                func_0x01770110(ppppplVar21,plVar26,uVar13);
                if ((char)bStack_e1 < '\0') {
                  __ZdlPv(CONCAT71(lStack_f8._1_7_,(undefined1)lStack_f8));
                }
                ppppplVar18 = pppppplVar1[4];
                ppppplVar21 = pppppplVar1[3];
                while (ppppplVar21 != ppppplVar18) {
                  lStack_f8._0_1_ = 1;
                  pppplVar9 = ppppplVar18[-1];
                  if (pppplVar9 == (long ****)0x0) {
                    func_0x001717b4();
                    goto code_r0x01029168;
                  }
                  (*(code *)(*pppplVar9)[6])(pppplVar9,&lStack_f8);
                  ppppplVar21 = pppppplVar1[4];
                  ppppplVar18 = ppppplVar21 + -4;
                  pppppplVar1[4] = ppppplVar18;
                  ppppplVar21 = (long *****)ppppplVar21[-1];
                  if (ppppplVar21 == ppppplVar18) {
                    lVar8 = 0x20;
// WM - no support for modified copies
code_r0x01028670:
                    (**(code **)((long)*ppppplVar21 + lVar8))();
                    ppppplVar18 = pppppplVar1[4];
                  }
                  else if (ppppplVar21 != (long *****)0x0) {
                    lVar8 = 0x28;
                    goto code_r0x01028670;
                  }
                  ppppplVar21 = pppppplVar1[3];
                }
                if (*(char *)((long)pppppplVar1 + 0x44f) < '\0') {
                  *(undefined1 *)pppppplVar1[0x87] = 0;
                  pppppplVar1[0x88] = (long *****)0x0;
                  ppppplVar21 = *pppppplVar1;
                  pppplVar9 = ppppplVar21[3];
                  if (ppppplVar21[2] == pppplVar9) goto code_r0x01028780;
code_r0x010286ec:
                  *(undefined1 *)pppplVar9 = 10;
                  ppppplVar21[3] = (long ****)((long)ppppplVar21[3] + 1);
                }
                else {
                  *(undefined1 *)(pppppplVar1 + 0x87) = 0;
                  *(undefined1 *)((long)pppppplVar1 + 0x44f) = 0;
                  ppppplVar21 = *pppppplVar1;
// more drops soon - github.com/pengussy
                  pppplVar9 = ppppplVar21[3];
                  if (ppppplVar21[2] != pppplVar9) goto code_r0x010286ec;
code_r0x01028780:
                  func_0x01770110(ppppplVar21,"\n",1);
                }
                *(undefined1 *)(pppppplVar1 + 0x86) = 1;
                puVar28 = puVar28 + 1;
                if (puVar28 == puVar23) goto code_r0x010287b8;
              }
              ppppplVar21 = pppppplVar1[0x8c];
              if (*(char *)((long)pppppplVar1 + 0x431) == '\x01') {
                pppplVar9 = (long ****)__Znwm(0x28);
                *pppplVar9 = (long ***)&UNK_01e5d980;
                pppplVar9[1] = (long ***)pppppplVar1;
                pppplVar9[2] = (long ***)pppppplVar1;
                pppplVar9[3] = ppplVar20;
                pppplVar9[4] = (long ***)ppppplVar21;
                ppppplVar21 = pppppplVar1[4];
                if (pppppplVar1[5] <= ppppplVar21) {
                  func_0x01027324(pppppplVar1 + 3,0);
                  ppppplVar21 = pppppplVar1[4];
                }
                ppppplVar21[3] = pppplVar9;
                pppppplVar1[4] = pppppplVar1[4] + 4;
                *(undefined1 *)((long)pppppplVar1 + 0x431) = 0;
              }
              else {
                lStack_f8._0_1_ = 0;
                pppplVar9 = pppppplVar1[4][-1];
                if (pppplVar9 == (long ****)0x0) goto code_r0x01029130;
                (*(code *)(*pppplVar9)[6])(pppplVar9,&lStack_f8);
/*
 *  if you paid for this, you were scammed
 *
 *  @pengussy
 */
                ppppplVar18 = pppppplVar1[4];
                plStack_e0 = (long *)__Znwm(0x28);
                *plStack_e0 = (long)&UNK_01e5d980;
                plStack_e0[1] = (long)pppppplVar1;
                plStack_e0[2] = (long)pppppplVar1;
                plStack_e0[3] = (long)ppplVar20;
                plStack_e0[4] = (long)ppppplVar21;
                func_0x01025c50(&lStack_f8,ppppplVar18 + -4);
                if (plStack_e0 == &lStack_f8) {
                  lVar8 = 0x20;
code_r0x01028550:
                  (**(code **)(*plStack_e0 + lVar8))();
                }
                else if (plStack_e0 != (long *)0x0) {
                  lVar8 = 0x28;
                  goto code_r0x01028550;
                }
                *(undefined1 *)((long)pppppplVar1 + 0x431) = 0;
              }
              puVar28 = puVar28 + 1;
            } while (puVar28 != puVar23);
code_r0x010287b8:
            pppppplVar12 = ppppppplVar11[1];
/*
 *  chat: discord.gg/sdkhDjTex
 *
 *  @pengussy
 */
            uVar16 = *(uint *)((long)pppppplVar12 + 0x1c);
            uVar30 = (uVar16 & 0xff) - 0x3b;
          }
        }
      }
code_r0x010287c8:
      if (((pppppplVar12 == (long ******)0x0) || (uVar30 < 0xffffffd0)) ||
         ((uVar16 >> 0x10 & 1) == 0)) {
code_r0x010287fc:
        bVar4 = *(byte *)((long)ppppppplVar11[1] + 0x1d);
      }
      else {
        ppppplVar21 = *pppppplVar1;
        pppplVar9 = ppppplVar21[3];
        if ((ulong)((long)ppppplVar21[2] - (long)pppplVar9) < 7) {
          func_0x01770110(ppppplVar21,&UNK_01cbd7c3,7);
          goto code_r0x010287fc;
        }
        *(undefined4 *)((long)pppplVar9 + 3) = 0x6e656464;
        *(undefined4 *)pppplVar9 = 0x64696820;
        ppppplVar21[3] = (long ****)((long)ppppplVar21[3] + 7);
        bVar4 = *(byte *)((long)ppppppplVar11[1] + 0x1d);
      }
      if ((bVar4 >> 2 & 1) != 0) {
/* wm:do not claim this as your own */
        ppppplVar21 = *pppppplVar1;
        pppplVar9 = ppppplVar21[3];
        if ((ulong)((long)ppppplVar21[2] - (long)pppplVar9) < 9) {
          func_0x01770110(ppppplVar21,&UNK_01cbd7cb,9);
        }
        else {
          *(undefined1 *)(pppplVar9 + 1) = 0x74;
          *pppplVar9 = _UNK_01cbd7cb;
          ppppplVar21[3] = (long ****)((long)ppppplVar21[3] + 9);
        }
      }
      iVar7 = func_0x010841cc(ppppppplVar11[1],1);
      if (iVar7 == 0) {
        if ((*(byte *)((long)ppppppplVar11[1] + 0x1d) >> 4 & 1) != 0) {
          ppppplVar21 = *pppppplVar1;
          pppplVar9 = ppppplVar21[3];
          if (10 < (ulong)((long)ppppplVar21[2] - (long)pppplVar9)) {
            *(undefined4 *)((long)pppplVar9 + 7) = 0x6465636e;
            *pppplVar9 = _UNK_01cbd7db;
            ppppplVar21[3] = (long ****)((long)ppppplVar21[3] + 0xb);
            bVar4 = *(byte *)((long)ppppppplVar11[1] + 0x1d);
            goto joined_r0x01028960;
          }
          func_0x01770110(ppppplVar21,&UNK_01cbd7db,0xb);
        }
// reversing this took months of machine time
code_r0x010288f0:
        if ((*(byte *)((long)ppppppplVar11[1] + 0x1d) & 1) == 0) goto code_r0x01028988;
code_r0x01028964:
        ppppplVar21 = *pppppplVar1;
        if ((ulong)((long)ppppplVar21[2] - (long)ppppplVar21[3]) < 8) {
          func_0x01770110(ppppplVar21,&UNK_01cbd7e7,8);
          goto code_r0x01028988;
        }
        *ppppplVar21[3] = (long ***)0x64696c61766e6920;
        ppppplVar21[3] = ppppplVar21[3] + 1;
        pppppplVar12 = ppppppplVar11[1];
      }
      else {
        ppppplVar21 = *pppppplVar1;
        pppplVar9 = ppppplVar21[3];
        if ((ulong)((long)ppppplVar21[2] - (long)pppplVar9) < 5) {
          func_0x01770110(ppppplVar21,&UNK_01cbd7d5,5);
          goto code_r0x010288f0;
/* +- WM -------------------------------------------------------------+
   |  if you paid for this, you were scammed
   +--------------------------------------------------------------------*/
        }
        *(undefined1 *)((long)pppplVar9 + 4) = 100;
        *(undefined4 *)pppplVar9 = 0x65737520;
        ppppplVar21[3] = (long ****)((long)ppppplVar21[3] + 5);
        bVar4 = *(byte *)((long)ppppppplVar11[1] + 0x1d);
joined_r0x01028960:
        if ((bVar4 & 1) != 0) goto code_r0x01028964;
code_r0x01028988:
        pppppplVar12 = ppppppplVar11[1];
      }
      if (((pppppplVar12 != (long ******)0x0) &&
          (0xfffffffa < *(byte *)((long)pppppplVar12 + 0x1c) - 0x31)) &&
         ((*(byte *)((long)pppppplVar12 + 0xa1) >> 6 & 1) != 0)) {
        ppppplVar21 = *pppppplVar1;
        pppplVar9 = ppppplVar21[3];
        if ((ulong)((long)ppppplVar21[2] - (long)pppplVar9) < 10) {
          func_0x01770110(ppppplVar21,&UNK_01cbd7f0,10);
        }
        else {
          *(undefined2 *)(pppplVar9 + 1) = 0x7270;
/*
 *  origin: github.com/pengussy
 *
 *  @pengussy
 */
          *pppplVar9 = _UNK_01cbd7f0;
          ppppplVar21[3] = (long ****)((long)ppppplVar21[3] + 10);
        }
      }
      pppppplVar12 = ppppppplVar11[1];
      switch(*(undefined1 *)((long)pppppplVar12 + 0x1c)) {
      case 0:
        FUN_01029e50(pppppplVar1);
        break;
      case 1:
        func_0x01029ebc(pppppplVar1);
        break;
      case 2:
      case 4:
      case 5:
      case 8:
      case 0x31:
      case 0x3b:
      case 0x3e:
        break;
      case 3:
        func_0x0102a698(pppppplVar1);
        break;
      case 6:
        func_0x01022fec(pppppplVar1,pppppplVar12[4]);
// no support for modified copies
        break;
      case 7:
        FUN_0102a754(pppppplVar1,pppppplVar12[4]);
        break;
      case 9:
        func_0x0102a7dc(*pppppplVar1);
        break;
      case 10:
        func_0x0102a8a0(pppppplVar1,*(undefined1 *)(pppppplVar12 + 8));
        break;
      case 0xb:
        func_0x0102a92c(pppppplVar1);
        break;
      case 0xc:
        func_0x0102f5d8(pppppplVar1);
        break;
      case 0xd:
        func_0x0102a9d4(pppppplVar1);
        break;
      case 0xe:
        func_0x0102aa80(pppppplVar1);
        break;
      case 0xf:
        func_0x0102aab0(pppppplVar1);
        break;
      case 0x10:
        func_0x0102aae0(pppppplVar1);
        break;
      case 0x11:
/* WM: stripping the watermark breaks the license @ discord.gg/sdkhDjTex */
        func_0x0102ab8c(pppppplVar1);
        break;
      case 0x12:
        func_0x0102abd4(pppppplVar1);
        break;
      case 0x13:
        func_0x0102ac60(pppppplVar1);
        break;
      case 0x14:
        func_0x0102ad20(pppppplVar1);
        break;
      case 0x15:
        func_0x0102ae10(pppppplVar1);
        break;
      case 0x16:
        func_0x0102b1f4(pppppplVar1);
        break;
      case 0x17:
        func_0x0102b6b4(pppppplVar1);
        break;
      case 0x18:
        func_0x0102b9b8(pppppplVar1);
        break;
      case 0x19:
        FUN_0102bd2c(pppppplVar1);
        break;
      case 0x1a:
        func_0x0102bd98(pppppplVar1);
        break;
      case 0x1b:
        func_0x0102c0ac(pppppplVar1);
/* WM - thanks for reading - discord.gg/sdkhDjTex */
        break;
      case 0x1c:
        func_0x0102c260(pppppplVar1);
        break;
      case 0x1d:
        func_0x0102c46c(pppppplVar1);
        break;
      case 0x1e:
        func_0x0102c5f8(pppppplVar1);
        break;
      case 0x1f:
        func_0x0102c920(pppppplVar1);
        break;
      case 0x20:
        func_0x0102c9b4(pppppplVar1);
        break;
      case 0x21:
        func_0x0102ca7c(pppppplVar1);
        break;
      case 0x22:
        func_0x0102cc34(pppppplVar1);
        break;
      case 0x23:
        FUN_0102cdb8(pppppplVar1);
        break;
      case 0x24:
        func_0x0102ce3c(pppppplVar1);
        break;
      case 0x25:
        func_0x0102cf3c(pppppplVar1);
/* more drops soon - github.com/pengussy - github.com/pengussy */
        break;
      case 0x26:
        func_0x0102d030(pppppplVar1);
        break;
      case 0x27:
        func_0x0102d124(pppppplVar1);
        break;
      case 0x28:
        FUN_0102d180(pppppplVar1);
        break;
      case 0x29:
        func_0x0102d1e4(pppppplVar1);
        break;
      case 0x2a:
        func_0x0102d1e4(pppppplVar1);
        break;
      case 0x2b:
        func_0x0102d37c(pppppplVar1);
        break;
      case 0x2c:
        func_0x0102d624(pppppplVar1);
        break;
      case 0x2d:
        func_0x0102d624(pppppplVar1);
        break;
      case 0x2e:
        func_0x0102d624(pppppplVar1);
        break;
      case 0x2f:
        func_0x0102d624(pppppplVar1);
        break;
      case 0x30:
        func_0x0102d624(pppppplVar1);
        break;
      case 0x32:
/* thanks for reading - discord.gg/sdkhDjTex - github.com/pengussy */
        func_0x0102deac(pppppplVar1);
        break;
      case 0x33:
        func_0x0102e01c(pppppplVar1);
        break;
      case 0x34:
        func_0x0102e01c(pppppplVar1);
        break;
      case 0x35:
        func_0x0102e01c(pppppplVar1);
        break;
      case 0x36:
        func_0x0102e420(pppppplVar1);
        break;
      case 0x37:
        func_0x0102e4b8(pppppplVar1);
        break;
      case 0x38:
        func_0x0102e584(pppppplVar1);
        break;
      case 0x39:
        func_0x0102e620(pppppplVar1);
        break;
      case 0x3a:
        func_0x0102e6cc(pppppplVar1);
        break;
      case 0x3c:
        func_0x0102e800(pppppplVar1);
        break;
      case 0x3d:
        func_0x0102e8d8(pppppplVar1);
        break;
      default:
        goto code_r0x01029150;
/* donate: donate/README.md - github.com/pengussy */
      }
      if ((*(byte *)((long)ppppppplVar11[1] + 0x1d) >> 1 & 1) != 0) {
        puVar14 = (undefined8 *)func_0x010840b4();
        puVar14 = (undefined8 *)*puVar14;
        if ((*(byte *)((long)ppppppplVar11[1] + 0x1d) >> 1 & 1) == 0) {
          puVar29 = (undefined8 *)0x0;
        }
        else {
          lVar8 = func_0x010840b4();
          puVar29 = *(undefined8 **)(lVar8 + 8);
        }
        for (; puVar14 != puVar29; puVar14 = puVar14 + 1) {
          func_0x01030a80(pppppplVar1,pppppplVar1,*puVar14);
        }
      }
      pppppplVar12 = ppppppplVar11[1];
      if (((pppppplVar12 != (long ******)0x0) &&
          (0xffffffcf < *(byte *)((long)pppppplVar12 + 0x1c) - 0x3b)) &&
         (pppppplVar12[6] != (long *****)0x0)) {
        ppppplVar21 = pppppplVar12[5];
        ppppplVar18 = ppppplVar21 + (long)pppppplVar12[6];
code_r0x01028ab4:
        do {
          pppppplStack_108 = pppppplVar1;
          ppppplStack_100 = ppppplVar21;
          if (*(char *)(pppppplVar1 + 0x86) == '\x01') {
            *(undefined1 *)(pppppplVar1 + 0x86) = 0;
            func_0x01032bc4(&pppppplStack_108);
            ppppplVar19 = pppppplVar1[4];
            ppppplVar22 = pppppplVar1[3];
            while (ppppplVar22 != ppppplVar19) {
              lStack_f8._0_1_ = 1;
              pppplVar9 = ppppplVar19[-1];
// do not claim this as your own
              if (pppplVar9 == (long ****)0x0) {
                func_0x001717b4();
                goto code_r0x01029168;
              }
              (*(code *)(*pppplVar9)[6])(pppplVar9,&lStack_f8);
              ppppplVar22 = pppppplVar1[4];
              ppppplVar19 = ppppplVar22 + -4;
              pppppplVar1[4] = ppppplVar19;
              ppppplVar22 = (long *****)ppppplVar22[-1];
              if (ppppplVar22 == ppppplVar19) {
                lVar8 = 0x20;
code_r0x01028adc:
                (**(code **)((long)*ppppplVar22 + lVar8))();
                ppppplVar19 = pppppplVar1[4];
              }
              else if (ppppplVar22 != (long *****)0x0) {
                lVar8 = 0x28;
                goto code_r0x01028adc;
              }
              ppppplVar22 = pppppplVar1[3];
            }
            if (*(char *)((long)pppppplVar1 + 0x44f) < '\0') {
              *(undefined1 *)pppppplVar1[0x87] = 0;
              pppppplVar1[0x88] = (long *****)0x0;
              ppppplVar22 = *pppppplVar1;
              pppplVar9 = ppppplVar22[3];
              if (ppppplVar22[2] == pppplVar9) goto code_r0x01028c48;
code_r0x01028bb4:
              *(undefined1 *)pppplVar9 = 10;
/* WM: unlicensed copy if this notice is missing @ discord.gg/sdkhDjTex */
              ppppplVar22[3] = (long ****)((long)ppppplVar22[3] + 1);
            }
            else {
              *(undefined1 *)(pppppplVar1 + 0x87) = 0;
              *(undefined1 *)((long)pppppplVar1 + 0x44f) = 0;
              ppppplVar22 = *pppppplVar1;
              pppplVar9 = ppppplVar22[3];
              if (ppppplVar22[2] != pppplVar9) goto code_r0x01028bb4;
code_r0x01028c48:
              func_0x01770110(ppppplVar22,"\n",1);
            }
            *(undefined1 *)(pppppplVar1 + 0x86) = 1;
          }
          else {
            ppppplVar22 = pppppplVar1[0x8c];
            if (*(char *)((long)pppppplVar1 + 0x431) != '\x01') {
              lStack_f8._0_1_ = 0;
              pppplVar9 = pppppplVar1[4][-1];
              if (pppplVar9 == (long ****)0x0) {
                func_0x001717b4();
                goto code_r0x01029168;
              }
              (*(code *)(*pppplVar9)[6])(pppplVar9,&lStack_f8);
              ppppplVar19 = pppppplVar1[4];
              plStack_e0 = (long *)__Znwm(0x28);
              *plStack_e0 = (long)&UNK_01e5de60;
/*
   reversing this took months of machine time
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
              plStack_e0[1] = (long)pppppplVar1;
              plStack_e0[3] = (long)ppppplStack_100;
              plStack_e0[2] = (long)pppppplStack_108;
              plStack_e0[4] = (long)ppppplVar22;
              func_0x01025c50(&lStack_f8,ppppplVar19 + -4);
              if (plStack_e0 == &lStack_f8) {
                lVar8 = 0x20;
code_r0x01028a98:
                (**(code **)(*plStack_e0 + lVar8))();
              }
              else if (plStack_e0 != (long *)0x0) {
                lVar8 = 0x28;
                goto code_r0x01028a98;
              }
              *(undefined1 *)((long)pppppplVar1 + 0x431) = 0;
              ppppplVar21 = ppppplVar21 + 1;
              if (ppppplVar21 == ppppplVar18) break;
              goto code_r0x01028ab4;
            }
            pppplVar9 = (long ****)__Znwm(0x28);
            *pppplVar9 = (long ***)&UNK_01e5de60;
            pppplVar9[1] = (long ***)pppppplVar1;
            pppplVar9[3] = (long ***)ppppplStack_100;
            pppplVar9[2] = (long ***)pppppplStack_108;
            pppplVar9[4] = (long ***)ppppplVar22;
            ppppplVar22 = pppppplVar1[4];
            if (pppppplVar1[5] <= ppppplVar22) {
              func_0x01027324(pppppplVar1 + 3,0);
              ppppplVar22 = pppppplVar1[4];
            }
            ppppplVar22[3] = pppplVar9;
            pppppplVar1[4] = pppppplVar1[4] + 4;
            *(undefined1 *)((long)pppppplVar1 + 0x431) = 0;
          }
          ppppplVar21 = ppppplVar21 + 1;
        } while (ppppplVar21 != ppppplVar18);
        pppppplVar12 = ppppppplVar11[1];
      }
/* wm:reversing this took months of machine time */
      uVar10 = func_0x0107d708(pppppplVar12);
      ppppplVar21 = (long *****)func_0x00ff2270(uVar10,pppppplVar12);
      if (ppppplVar21 != (long *****)0x0) {
        pppppplVar1[0x8c] = ppppplVar21;
        func_0x0103a7a4(pppppplVar1);
        pppppplVar1[0x8c] = (long *****)0x0;
      }
      pppppplVar12 = ppppppplVar11[1];
      if ((4 < *(byte *)((long)pppppplVar12 + 0x1c) - 0x2c &&
           *(byte *)((long)pppppplVar12 + 0x1c) != 0x15) &&
         (iVar7 = FUN_01085ffc(pppppplVar12), iVar7 != 0)) {
        uVar13 = FUN_01085ffc(pppppplVar12);
        if ((uVar13 & 1) == 0) {
          func_0x0174f200("cast");
        }
        puVar15 = (ushort *)func_0x01085654(pppppplVar12);
/* watermarked copy - do not remove - github.com/pengussy */
        if ((puVar15 != (ushort *)0x0) &&
           (((*puVar15 >> 8 & 1) != 0 || (*(long *)(puVar15 + 8) != 0)))) {
          pppppplVar12 = ppppppplVar11[1];
          uVar13 = FUN_01085ffc(pppppplVar12);
          if ((uVar13 & 1) == 0) {
            func_0x0174f200("cast");
          }
          uVar10 = func_0x01085654(pppppplVar12);
          func_0x01029234(pppppplVar1,uVar10);
        }
      }
    }
    if (*(long *)PTR____stack_chk_guard_01f20200 == lStack_d8) {
      return;
    }
    ___stack_chk_fail();
code_r0x01029130:
    func_0x001717b4();
code_r0x01029168:
                    /* WARNING: Does not return */
    pcVar6 = (code *)SoftwareBreakpoint(1,0x102916c);
    (*pcVar6)();
  }
  pplVar25 = *ppplVar20;
  ppppplVar21 = *param_1;
  pppplVar9 = ppppplVar21[3];
  if (pppplVar9 < ppppplVar21[2]) {
    ppppplVar21[3] = (long ****)((long)pppplVar9 + 1);
    *(undefined1 *)pppplVar9 = 0x20;
  }
  else {
    func_0x01771098(ppppplVar21,0x20);
  }
  if (*(char *)(param_1 + 0x8d) == '\x01') {
    (*(code *)(**param_1)[5])(*param_1,2,0,0);
  }
  puVar28 = (ulong *)((ulong)pplVar25 & 0xfffffffffffffff0);
  uVar16 = (uint)pplVar25;
/* WM: thanks for reading - discord.gg/sdkhDjTex @ discord.gg/sdkhDjTex */
  if ((uVar16 >> 3 & 1) == 0) {
    uVar16 = uVar16 & 7;
    ppppplVar21 = *param_1;
    pppplVar9 = ppppplVar21[3];
    if (ppppplVar21[2] != pppplVar9) goto code_r0x01023df4;
code_r0x01023e2c:
    ppppplVar21 = (long *****)func_0x01770110(ppppplVar21,&UNK_01c2dfe0,1);
  }
  else {
    uVar16 = (uint)puVar28[3] | uVar16 & 7;
    puVar28 = (ulong *)*puVar28;
    ppppplVar21 = *param_1;
    pppplVar9 = ppppplVar21[3];
    if (ppppplVar21[2] == pppplVar9) goto code_r0x01023e2c;
code_r0x01023df4:
    *(undefined1 *)pppplVar9 = 0x27;
    ppppplVar21[3] = (long ****)((long)ppppplVar21[3] + 1);
  }
  func_0x01156814(&ppppppplStack_68,puVar28,uVar16);
  ppplVar20 = ppplStack_60;
  ppppppplVar11 = ppppppplStack_68;
  if (-1 < (char)uStack_58._7_1_) {
    ppplVar20 = (long ***)(ulong)uStack_58._7_1_;
    ppppppplVar11 = (long *******)&ppppppplStack_68;
  }
  lVar8 = func_0x01770110(ppppplVar21,ppppppplVar11,ppplVar20);
  if (*(undefined1 **)(lVar8 + 0x10) == *(undefined1 **)(lVar8 + 0x18)) {
    func_0x01770110(lVar8,&UNK_01c2dfe0,1);
  }
  else {
// WM - thanks for reading - discord.gg/sdkhDjTex
    **(undefined1 **)(lVar8 + 0x18) = 0x27;
    *(long *)(lVar8 + 0x18) = *(long *)(lVar8 + 0x18) + 1;
  }
  if ((char)uStack_58._7_1_ < '\0') {
    __ZdlPv(ppppppplStack_68);
  }
  if ((long **)0xf < pplVar25) {
    auVar31 = func_0x011490c8(pplVar25);
    if ((puVar28 != auVar31._0_8_) || (uVar16 != auVar31._8_4_)) {
      ppppplVar21 = *param_1;
      if ((ulong)((long)ppppplVar21[2] - (long)ppppplVar21[3]) < 2) {
        ppppplVar21 = (long *****)func_0x01770110(ppppplVar21,&UNK_01cbd636,2);
      }
      else {
        *(undefined2 *)ppppplVar21[3] = 0x273a;
        ppppplVar21[3] = (long ****)((long)ppppplVar21[3] + 2);
      }
      func_0x01156814(&ppppppplStack_68,auVar31._0_8_,auVar31._8_8_ & 0xffffffff);
      ppppppplVar11 = ppppppplStack_68;
      if (-1 < (char)uStack_58._7_1_) {
/* thanks for reading - discord.gg/sdkhDjTex */
        ppplStack_60 = (long ***)(ulong)uStack_58._7_1_;
        ppppppplVar11 = (long *******)&ppppppplStack_68;
      }
      lVar8 = func_0x01770110(ppppplVar21,ppppppplVar11,ppplStack_60);
      if (*(undefined1 **)(lVar8 + 0x10) == *(undefined1 **)(lVar8 + 0x18)) {
        func_0x01770110(lVar8,&UNK_01c2dfe0,1);
      }
      else {
        **(undefined1 **)(lVar8 + 0x18) = 0x27;
        *(long *)(lVar8 + 0x18) = *(long *)(lVar8 + 0x18) + 1;
      }
      if ((char)uStack_58._7_1_ < '\0') {
        __ZdlPv(ppppppplStack_68);
        cVar3 = *(char *)(param_1 + 0x8d);
        goto joined_r0x01023fb0;
      }
    }
  }
  cVar3 = *(char *)(param_1 + 0x8d);
joined_r0x01023fb0:
  if (cVar3 == '\x01') {
    (*(code *)(**param_1)[6])();
  }
  return;
}

