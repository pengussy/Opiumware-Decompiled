/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x1029e44:e0d37aea06
 */

undefined * FUN_01029e44(void)

{
  return &UNK_01e5d9e0;
/* donate: donate/README.md - github.com/pengussy */
}

