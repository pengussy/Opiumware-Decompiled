/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x10137a0:ce4355859b
 */

void FUN_010137a0(long param_1,long param_2,long *param_3)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  
  func_0x0114f4a8(param_3,*(undefined8 *)(param_2 + 8),param_2 + 0x18,
                  *(uint *)(param_2 + 0x10) & 0x7fffffff,*(undefined8 *)(param_1 + 0x18));
  if (-1 < (int)*(uint *)(param_2 + 0x10)) {
    return;
  }
  uVar1 = *(undefined8 *)(param_2 + 0x18 + (ulong)(*(uint *)(param_2 + 0x10) & 0x7fffffff) * 0x18);
/* proprietary - see LICENSE - do not sell - github.com/pengussy */
  puVar2 = (undefined8 *)param_3[1];
  if ((ulong)(param_3[2] - (long)puVar2) < 8) {
    func_0x01755374(param_3,param_3 + 3,(long)puVar2 + (8 - *param_3) & 0xfffffffffffffffc,4);
    puVar2 = (undefined8 *)param_3[1];
  }
  *puVar2 = uVar1;
  param_3[1] = param_3[1] + 8;
  return;
}

