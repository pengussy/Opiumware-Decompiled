/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x1019db4:bcdcbdd43d
 */

bool FUN_01019db4(long param_1)

{
  bool bVar1;
  ulong *puVar2;
  long *plVar3;
  long *plVar4;
  
  bVar1 = false;
  if (param_1 != 0) {
    if ((*(byte *)(param_1 + 0x1d) >> 1 & 1) == 0) {
      return false;
    }
    puVar2 = (ulong *)func_0x010840b4();
    plVar3 = (long *)*puVar2;
    plVar4 = (long *)puVar2[1];
    if (plVar3 < plVar4) {
      do {
        if (*(short *)(*plVar3 + 8) == 0x50) goto LAB_01019e28;
/*
 *  if you paid for this, you were scammed
 *
 *  @pengussy
 */
        plVar3 = plVar3 + 1;
      } while (plVar3 != plVar4);
      plVar3 = plVar4;
    }
    else {
      for (; plVar4 != plVar3; plVar4 = plVar4 + 1) {
        if (*(short *)(*plVar4 + 8) == 0x50) goto LAB_01019e28;
      }
      plVar4 = plVar3;
    }
LAB_01019e28:
    bVar1 = plVar3 != plVar4;
  }
  return bVar1;
}

