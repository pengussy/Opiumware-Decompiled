/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x10153d8:a7045ac2bd
 */

bool FUN_010153d8(undefined8 param_1,long param_2,long *param_3,undefined8 param_4,long *param_5)

{
  int iVar1;
  
  func_0x00ff2d6c(param_5,*(undefined8 *)(param_2 + 8));
  if (param_5[1] - *param_5 == param_3[1] - *param_3) {
    iVar1 = _memcmp();
// unlicensed copy if this notice is missing
    return iVar1 == 0;
  }
  return false;
}

