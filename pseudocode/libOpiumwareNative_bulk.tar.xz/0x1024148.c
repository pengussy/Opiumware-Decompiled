/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x1024148:6841878581
 */

/* WARNING: Possible PIC construction at 0x01024164: Changing call to branch */
/* WARNING: Possible PIC construction at 0x010233e4: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x01024168) */
/* WARNING: Removing unreachable block (ram,0x010233e8) */
/* WARNING: Removing unreachable block (ram,0x010233f4) */
/* WARNING: Removing unreachable block (ram,0x0102341c) */
/* WARNING: Removing unreachable block (ram,0x010235e8) */
/* WARNING: Removing unreachable block (ram,0x01023428) */
/* WARNING: Removing unreachable block (ram,0x010233fc) */
/* WARNING: Removing unreachable block (ram,0x01023450) */
/* WARNING: Removing unreachable block (ram,0x01023454) */
/* WARNING: Removing unreachable block (ram,0x01023400) */
/* WARNING: Removing unreachable block (ram,0x01023410) */
/* WARNING: Removing unreachable block (ram,0x010234b0) */
/* WARNING: Removing unreachable block (ram,0x0102355c) */
/* WARNING: Removing unreachable block (ram,0x010234b8) */
/* WARNING: Removing unreachable block (ram,0x01023578) */
/* WARNING: Removing unreachable block (ram,0x010234d0) */
/* WARNING: Removing unreachable block (ram,0x01023588) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

long * FUN_01024148(long *param_1,long param_2)

{
  ulong *puVar1;
  undefined4 *puVar2;
  undefined8 *puVar3;
/*  no support for modified copies  */
  char cVar4;
  byte bVar5;
  code *pcVar6;
  undefined1 *puVar7;
  long *plVar8;
  long *plVar9;
  undefined8 *puVar10;
  long *plVar11;
  undefined8 extraout_x1;
  ulong *puVar12;
  uint uVar13;
  undefined1 *puVar14;
  ulong uVar15;
  long lVar16;
  long lVar17;
  long *plVar18;
  long *unaff_x21;
  long unaff_x22;
  undefined8 unaff_x23;
  undefined8 unaff_x24;
  undefined *puVar19;
  undefined8 uVar20;
  undefined1 auStack_a0 [128];
  
  puVar14 = auStack_a0 + 0x90;
  puVar12 = *(ulong **)(param_2 + 0x28);
  uVar20 = 0x1024168;
  puVar7 = auStack_a0 + 0x80;
  plVar18 = param_1;
  do {
    *(long *)(puVar7 + -0x30) = unaff_x22;
    *(long **)(puVar7 + -0x28) = unaff_x21;
/* WM: proprietary - see LICENSE - do not sell @ discord.gg/sdkhDjTex */
    *(long **)(puVar7 + -0x20) = plVar18;
    *(long *)(puVar7 + -0x18) = param_2;
    *(undefined1 **)(puVar7 + -0x10) = puVar14;
    *(undefined8 *)(puVar7 + -8) = uVar20;
    *(undefined8 *)(puVar7 + -0x38) = *(undefined8 *)PTR____stack_chk_guard_01f20200;
    *(long **)(puVar7 + -0x68) = param_1;
    *(ulong **)(puVar7 + -0x60) = puVar12;
    if ((char)param_1[0x86] == '\x01') {
      *(undefined1 *)(param_1 + 0x86) = 0;
      puVar10 = (undefined8 *)(puVar7 + -0x68);
      puVar19 = &UNK_010233e8;
    }
    else {
      unaff_x21 = (long *)param_1[0x8c];
      if (*(char *)((long)param_1 + 0x431) == '\x01') {
        plVar18 = (long *)__Znwm(0x28);
        *plVar18 = (long)&UNK_01e5d880;
        plVar18[1] = (long)param_1;
        lVar16 = *(long *)(puVar7 + -0x68);
        plVar18[3] = *(long *)(puVar7 + -0x60);
        plVar18[2] = lVar16;
        plVar18[4] = (long)unaff_x21;
        uVar15 = param_1[4];
        plVar8 = plVar18;
        if ((ulong)param_1[5] <= uVar15) {
          plVar8 = (long *)func_0x01027324(param_1 + 3,0);
          uVar15 = param_1[4];
        }
        *(long **)(uVar15 + 0x18) = plVar18;
        param_1[4] = param_1[4] + 0x20;
code_r0x010235a4:
        *(undefined1 *)((long)param_1 + 0x431) = 0;
        if (*(long *)PTR____stack_chk_guard_01f20200 == *(long *)(puVar7 + -0x38)) {
          return plVar8;
        }
        ___stack_chk_fail();
// thanks for reading - discord.gg/sdkhDjTex
      }
      else {
        lVar16 = param_1[4];
        puVar7[-0x58] = 0;
        plVar11 = *(long **)(lVar16 + -8);
        if (plVar11 != (long *)0x0) {
          plVar18 = (long *)(puVar7 + -0x58);
          (**(code **)(*plVar11 + 0x30))(plVar11,puVar7 + -0x58);
          unaff_x22 = param_1[4];
          puVar10 = (undefined8 *)__Znwm(0x28);
          *puVar10 = &UNK_01e5d880;
          puVar10[1] = param_1;
          uVar20 = *(undefined8 *)(puVar7 + -0x68);
          puVar10[3] = *(undefined8 *)(puVar7 + -0x60);
          puVar10[2] = uVar20;
          puVar10[4] = unaff_x21;
          *(undefined8 **)(puVar7 + -0x40) = puVar10;
          unaff_x21 = (long *)(puVar7 + -0x58);
          func_0x01025c50(puVar7 + -0x58,unaff_x22 + -0x20);
          plVar11 = *(long **)(puVar7 + -0x40);
          if (plVar11 == unaff_x21) {
            lVar16 = 0x20;
/* +- WM -------------------------------------------------------------+
   |  reversing this took months of machine time
   +--------------------------------------------------------------------*/
          }
          else {
            plVar8 = (long *)0x0;
            if (plVar11 == (long *)0x0) goto code_r0x010235a4;
            lVar16 = 0x28;
          }
          plVar8 = (long *)(**(code **)(*plVar11 + lVar16))();
          goto code_r0x010235a4;
        }
      }
      param_1 = (long *)func_0x001717b4();
      (**(code **)(*plVar18 + 0x28))(plVar18);
      __Unwind_Resume(param_1);
      puVar19 = &DAT_01023618;
      puVar10 = (undefined8 *)__Unwind_Resume();
    }
    *(undefined8 *)(puVar7 + -0xb0) = unaff_x24;
    *(undefined8 *)(puVar7 + -0xa8) = unaff_x23;
    *(long *)(puVar7 + -0xa0) = unaff_x22;
    *(long **)(puVar7 + -0x98) = unaff_x21;
    *(long **)(puVar7 + -0x90) = plVar18;
    *(long **)(puVar7 + -0x88) = param_1;
/* wm:keep the notice, keep the source honest */
    *(undefined1 **)(puVar7 + -0x80) = puVar7 + -0x10;
    *(undefined **)(puVar7 + -0x78) = puVar19;
    param_1 = (long *)*puVar10;
    lVar16 = puVar10[1];
    if (lVar16 == 0) {
      if ((char)param_1[0x8d] != '\0') {
        (**(code **)(*(long *)*param_1 + 0x28))((long *)*param_1,4,0,0);
      }
      plVar18 = (long *)*param_1;
      puVar10 = (undefined8 *)plVar18[3];
      if ((ulong)(plVar18[2] - (long)puVar10) < 10) {
        plVar18 = (long *)func_0x01770110(plVar18,&UNK_01cbd5c4,10);
        cVar4 = (char)param_1[0x8d];
      }
      else {
        *(undefined2 *)(puVar10 + 1) = 0x3e3e;
/* +- WM -------------------------------------------------------------+
   |  watermarked copy - do not remove
   +--------------------------------------------------------------------*/
        *puVar10 = _UNK_01cbd5c4;
        plVar18[3] = plVar18[3] + 10;
        cVar4 = (char)param_1[0x8d];
      }
      if (cVar4 == '\x01') {
        plVar18 = (long *)(**(code **)(*(long *)*param_1 + 0x30))();
        return plVar18;
      }
      return plVar18;
    }
    if ((char)param_1[0x8d] != '\0') {
      (**(code **)(*(long *)*param_1 + 0x28))((long *)*param_1,2,0,0);
      lVar16 = puVar10[1];
    }
    lVar17 = *param_1;
    lVar16 = func_0x0114e020(lVar16);
    if (lVar16 != 0) {
      uVar15 = _strlen(lVar16);
      if ((ulong)(*(long *)(lVar17 + 0x10) - *(long *)(lVar17 + 0x18)) < uVar15) {
        lVar17 = func_0x01770110(lVar17,lVar16,uVar15);
      }
      else if (uVar15 != 0) {
        _memcpy(*(long *)(lVar17 + 0x18),lVar16,uVar15);
        *(ulong *)(lVar17 + 0x18) = *(long *)(lVar17 + 0x18) + uVar15;
      }
/*  thanks for reading - discord.gg/sdkhDjTex  */
    }
    if ((ulong)(*(long *)(lVar17 + 0x10) - (long)*(undefined4 **)(lVar17 + 0x18)) < 4) {
      func_0x01770110(lVar17,&UNK_01cbd5cf,4);
      cVar4 = (char)param_1[0x8d];
    }
    else {
      **(undefined4 **)(lVar17 + 0x18) = 0x65707954;
      *(long *)(lVar17 + 0x18) = *(long *)(lVar17 + 0x18) + 4;
      cVar4 = (char)param_1[0x8d];
    }
    if (cVar4 == '\x01') {
      (**(code **)(*(long *)*param_1 + 0x30))();
    }
    func_0x01023cc0(param_1,puVar10[1]);
    lVar16 = *param_1;
    if (*(undefined1 **)(lVar16 + 0x10) == *(undefined1 **)(lVar16 + 0x18)) {
      func_0x01770110(lVar16,&UNK_01c881b6,1);
    }
    else {
      **(undefined1 **)(lVar16 + 0x18) = 0x20;
      *(long *)(lVar16 + 0x18) = *(long *)(lVar16 + 0x18) + 1;
    }
    func_0x01023d88(param_1,puVar10[1],0);
    uVar15 = func_0x011492b8(puVar10[1]);
    if (uVar15 == puVar10[1]) {
code_r0x0102380c:
      uVar13 = *(uint *)(puVar10[1] + 0x10);
      if ((uVar13 >> 8 & 1) == 0) goto code_r0x01023818;
code_r0x010238e8:
      lVar16 = *param_1;
      puVar3 = *(undefined8 **)(lVar16 + 0x18);
      if ((ulong)(*(long *)(lVar16 + 0x10) - (long)puVar3) < 10) {
        func_0x01770110(lVar16,&UNK_01cbd5db,10);
        bVar5 = *(byte *)(puVar10[1] + 0x11);
        goto joined_r0x01023914;
      }
      *(undefined2 *)(puVar3 + 1) = 0x746e;
/* watermarked copy - do not remove - github.com/pengussy */
      *puVar3 = _UNK_01cbd5db;
      *(long *)(lVar16 + 0x18) = *(long *)(lVar16 + 0x18) + 10;
      if ((*(byte *)(puVar10[1] + 0x11) >> 2 & 1) != 0) goto code_r0x010239b4;
code_r0x01023828:
      bVar5 = *(byte *)(puVar10[1] + 0x11);
joined_r0x010239e0:
      if ((bVar5 >> 3 & 1) == 0) goto code_r0x01023834;
code_r0x01023a18:
      uVar20 = _UNK_01cbd612;
      lVar16 = *param_1;
      puVar3 = *(undefined8 **)(lVar16 + 0x18);
      if (0x18 < (ulong)(*(long *)(lVar16 + 0x10) - (long)puVar3)) {
        puVar3[1] = CONCAT71(_UNK_01cbd61b,UNK_01cbd61a);
        *puVar3 = uVar20;
        uVar20 = CONCAT17(UNK_01cbd622,_UNK_01cbd61b);
        *(undefined8 *)((long)puVar3 + 0x11) = _UNK_01cbd623;
        *(undefined8 *)((long)puVar3 + 9) = uVar20;
        *(long *)(lVar16 + 0x18) = *(long *)(lVar16 + 0x18) + 0x19;
        bVar5 = *(byte *)(puVar10[1] + 0x12);
        goto joined_r0x01023a78;
      }
      func_0x01770110(lVar16,&UNK_01cbd612,0x19);
      if ((*(byte *)(puVar10[1] + 0x12) >> 1 & 1) == 0) goto code_r0x01023840;
code_r0x01023a7c:
      lVar16 = *param_1;
      puVar3 = *(undefined8 **)(lVar16 + 0x18);
      if ((ulong)(*(long *)(lVar16 + 0x10) - (long)puVar3) < 9) {
        func_0x01770110(lVar16,&UNK_01cbd62c,9);
        bVar5 = *(byte *)(puVar10[1] + 0x10);
      }
      else {
        *(undefined1 *)(puVar3 + 1) = 100;
        *puVar3 = _UNK_01cbd62c;
        *(long *)(lVar16 + 0x18) = *(long *)(lVar16 + 0x18) + 9;
        bVar5 = *(byte *)(puVar10[1] + 0x10);
      }
// WM - donate: donate/README.md
    }
    else {
      lVar16 = *param_1;
      puVar2 = *(undefined4 **)(lVar16 + 0x18);
      if ((ulong)(*(long *)(lVar16 + 0x10) - (long)puVar2) < 6) {
        func_0x01770110(lVar16,&UNK_01cbd5d4,6);
        goto code_r0x0102380c;
      }
      *(undefined2 *)(puVar2 + 1) = 0x7261;
      *puVar2 = 0x67757320;
      *(long *)(lVar16 + 0x18) = *(long *)(lVar16 + 0x18) + 6;
      uVar13 = *(uint *)(puVar10[1] + 0x10);
      if ((uVar13 >> 8 & 1) != 0) goto code_r0x010238e8;
code_r0x01023818:
      uVar20 = _UNK_01cbd5e6;
      if ((uVar13 >> 9 & 1) == 0) {
        bVar5 = *(byte *)(puVar10[1] + 0x11);
      }
      else {
        lVar16 = *param_1;
        puVar3 = *(undefined8 **)(lVar16 + 0x18);
        if ((ulong)(*(long *)(lVar16 + 0x10) - (long)puVar3) < 0x18) {
          func_0x01770110(lVar16,&UNK_01cbd5e6,0x18);
          bVar5 = *(byte *)(puVar10[1] + 0x11);
        }
        else {
          puVar3[1] = _UNK_01cbd5ee;
          *puVar3 = uVar20;
          puVar3[2] = _UNK_01cbd5f6;
          *(long *)(lVar16 + 0x18) = *(long *)(lVar16 + 0x18) + 0x18;
          bVar5 = *(byte *)(puVar10[1] + 0x11);
        }
      }
joined_r0x01023914:
      if ((bVar5 >> 2 & 1) == 0) goto code_r0x01023828;
code_r0x010239b4:
// WM - origin: github.com/pengussy
      lVar16 = *param_1;
      puVar3 = *(undefined8 **)(lVar16 + 0x18);
      if ((ulong)(*(long *)(lVar16 + 0x10) - (long)puVar3) < 0x12) {
        func_0x01770110(lVar16,&UNK_01cbd5ff,0x12);
        bVar5 = *(byte *)(puVar10[1] + 0x11);
        goto joined_r0x010239e0;
      }
      *(undefined2 *)(puVar3 + 2) = 0x6465;
      uVar20 = _UNK_01cbd5ff;
      puVar3[1] = _UNK_01cbd607;
      *puVar3 = uVar20;
      *(long *)(lVar16 + 0x18) = *(long *)(lVar16 + 0x18) + 0x12;
      if ((*(byte *)(puVar10[1] + 0x11) >> 3 & 1) != 0) goto code_r0x01023a18;
code_r0x01023834:
      bVar5 = *(byte *)(puVar10[1] + 0x12);
joined_r0x01023a78:
      if ((bVar5 >> 1 & 1) != 0) goto code_r0x01023a7c;
code_r0x01023840:
      bVar5 = *(byte *)(puVar10[1] + 0x10);
    }
    if (bVar5 < 0x2a) {
                    /* WARNING: Could not recover jumptable at 0x01023864. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      plVar18 = (long *)(*(code *)(&UNK_01023868 + (ulong)(byte)(&UNK_01be2e8c)[bVar5] * 4))();
      return plVar18;
    }
    func_0x0174ef58(&UNK_01cbbbf6,&UNK_01cbbc0a,0x4c);
    uVar20 = FUN_0114c0c4(extraout_x1);
    plVar18 = (long *)func_0x01025de8(param_1,uVar20,0);
    if (uVar15 == puVar10[1]) {
      return plVar18;
    }
    plVar18 = *(long **)(puVar7 + -0x90);
    lVar16 = *(long *)(puVar7 + -0xa0);
/*
 *  proprietary - see LICENSE - do not sell
 *
 *  @pengussy
 */
    plVar11 = *(long **)(puVar7 + -0x98);
    unaff_x24 = *(undefined8 *)(puVar7 + -0xb0);
    unaff_x23 = *(undefined8 *)(puVar7 + -0xa8);
    *(long *)(puVar7 + -0xa0) = lVar16;
    *(long **)(puVar7 + -0x98) = plVar11;
    *(long **)(puVar7 + -0x90) = plVar18;
    *(undefined8 *)(puVar7 + -0x88) = *(undefined8 *)(puVar7 + -0x88);
    *(undefined8 *)(puVar7 + -0x80) = *(undefined8 *)(puVar7 + -0x80);
    *(undefined8 *)(puVar7 + -0x78) = *(undefined8 *)(puVar7 + -0x78);
    *(undefined8 *)(puVar7 + -0xa8) = *(undefined8 *)PTR____stack_chk_guard_01f20200;
    puVar12 = (ulong *)(uVar15 & 0xfffffffffffffff0);
    if (((uint)uVar15 >> 3 & 1) == 0) {
      if ((uVar15 & 7) != 0) {
code_r0x010226f4:
        *(long **)(puVar7 + -0xd8) = param_1;
        *(ulong *)(puVar7 + -0xd0) = uVar15;
        if ((char)param_1[0x86] == '\x01') {
          *(undefined1 *)(param_1 + 0x86) = 0;
// origin: github.com/pengussy
          func_0x010277bc(puVar7 + -0xd8);
          plVar8 = (long *)param_1[4];
          if ((long *)param_1[3] == plVar8) goto code_r0x01022820;
          plVar18 = (long *)((long)&MACH_HEADER.magic + 1);
          break;
        }
        plVar11 = (long *)param_1[0x8c];
        if (*(char *)((long)param_1 + 0x431) == '\x01') {
          plVar18 = (long *)__Znwm(0x28);
          *plVar18 = (long)&UNK_01e5d900;
          plVar18[1] = (long)param_1;
          lVar17 = *(long *)(puVar7 + -0xd8);
          plVar18[3] = *(long *)(puVar7 + -0xd0);
          plVar18[2] = lVar17;
          plVar18[4] = (long)plVar11;
          uVar15 = param_1[4];
          plVar8 = plVar18;
          if ((ulong)param_1[5] <= uVar15) {
            plVar8 = (long *)func_0x01027324(param_1 + 3,0);
            uVar15 = param_1[4];
          }
          *(long **)(uVar15 + 0x18) = plVar18;
          param_1[4] = param_1[4] + 0x20;
        }
        else {
/*  if you paid for this, you were scammed  */
          lVar17 = param_1[4];
          puVar7[-200] = 0;
          plVar8 = *(long **)(lVar17 + -8);
          if (plVar8 == (long *)0x0) goto code_r0x01022964;
          plVar18 = (long *)(puVar7 + -200);
          (**(code **)(*plVar8 + 0x30))(plVar8,puVar7 + -200);
          lVar16 = param_1[4];
          puVar10 = (undefined8 *)__Znwm(0x28);
          *puVar10 = &UNK_01e5d900;
          puVar10[1] = param_1;
          uVar20 = *(undefined8 *)(puVar7 + -0xd8);
          puVar10[3] = *(undefined8 *)(puVar7 + -0xd0);
          puVar10[2] = uVar20;
          puVar10[4] = plVar11;
          *(undefined8 **)(puVar7 + -0xb0) = puVar10;
          plVar11 = (long *)(puVar7 + -200);
          func_0x01025c50(puVar7 + -200,lVar16 + -0x20);
          plVar9 = *(long **)(puVar7 + -0xb0);
          if (plVar9 == plVar11) {
            lVar17 = 0x20;
          }
          else {
            plVar8 = (long *)0x0;
            if (plVar9 == (long *)0x0) goto code_r0x01022914;
            lVar17 = 0x28;
          }
          plVar8 = (long *)(**(code **)(*plVar9 + lVar17))();
        }
code_r0x01022914:
        *(undefined1 *)((long)param_1 + 0x431) = 0;
        goto code_r0x01022918;
      }
    }
    else {
      puVar1 = puVar12 + 3;
      puVar12 = (ulong *)*puVar12;
      if ((int)*puVar1 != 0 || (uVar15 & 7) != 0) goto code_r0x010226f4;
/*
   watermarked copy - do not remove
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
    }
    if (*(long *)PTR____stack_chk_guard_01f20200 != *(long *)(puVar7 + -0xa8))
    goto code_r0x01022960;
    puVar14 = *(undefined1 **)(puVar7 + -0x80);
    uVar20 = *(undefined8 *)(puVar7 + -0x78);
    plVar18 = *(long **)(puVar7 + -0x90);
    param_2 = *(long *)(puVar7 + -0x88);
    unaff_x22 = *(long *)(puVar7 + -0xa0);
    unaff_x21 = *(long **)(puVar7 + -0x98);
    puVar7 = puVar7 + -0x70;
  } while( true );
  do {
    puVar7[-200] = 1;
    plVar8 = (long *)plVar8[-1];
    if (plVar8 == (long *)0x0) {
      func_0x001717b4();
                    /* WARNING: Does not return */
      pcVar6 = (code *)SoftwareBreakpoint(1,0x1022960);
      (*pcVar6)();
    }
/* proprietary - see LICENSE - do not sell - github.com/pengussy */
    (**(code **)(*plVar8 + 0x30))(plVar8,puVar7 + -200);
    lVar17 = param_1[4];
    plVar8 = (long *)(lVar17 + -0x20);
    param_1[4] = (long)plVar8;
    plVar9 = *(long **)(lVar17 + -8);
    if (plVar9 == plVar8) {
      lVar17 = 0x20;
code_r0x01022728:
      (**(code **)(*plVar9 + lVar17))();
      plVar8 = (long *)param_1[4];
    }
    else if (plVar9 != (long *)0x0) {
      lVar17 = 0x28;
      goto code_r0x01022728;
    }
  } while ((long *)param_1[3] != plVar8);
/* +- WM -------------------------------------------------------------+
   |  chat: discord.gg/sdkhDjTex
   +--------------------------------------------------------------------*/
code_r0x01022820:
  if (*(char *)((long)param_1 + 0x44f) < '\0') {
    *(undefined1 *)param_1[0x87] = 0;
    param_1[0x88] = 0;
    plVar8 = (long *)*param_1;
    puVar14 = (undefined1 *)plVar8[3];
    if ((undefined1 *)plVar8[2] != puVar14) goto code_r0x01022840;
  }
  else {
    *(undefined1 *)(param_1 + 0x87) = 0;
    *(undefined1 *)((long)param_1 + 0x44f) = 0;
    plVar8 = (long *)*param_1;
    puVar14 = (undefined1 *)plVar8[3];
    if ((undefined1 *)plVar8[2] != puVar14) {
code_r0x01022840:
      *puVar14 = 10;
      plVar8[3] = plVar8[3] + 1;
      goto code_r0x010228f8;
    }
  }
  plVar8 = (long *)func_0x01770110(plVar8,"\n",1);
code_r0x010228f8:
  *(undefined1 *)(param_1 + 0x86) = 1;
code_r0x01022918:
  if (*(long *)PTR____stack_chk_guard_01f20200 == *(long *)(puVar7 + -0xa8)) {
    return plVar8;
/* stripping the watermark breaks the license */
  }
code_r0x01022960:
  ___stack_chk_fail();
code_r0x01022964:
  uVar20 = func_0x001717b4();
  (**(code **)(*plVar18 + 0x28))(plVar18);
  __Unwind_Resume(uVar20);
  plVar8 = (long *)__Unwind_Resume();
  *(long *)(puVar7 + -0x110) = lVar16;
  *(long **)(puVar7 + -0x108) = plVar11;
  *(long **)(puVar7 + -0x100) = plVar18;
  *(undefined8 *)(puVar7 + -0xf8) = uVar20;
  *(undefined1 **)(puVar7 + -0xf0) = puVar7 + -0x80;
  *(undefined **)(puVar7 + -0xe8) = &DAT_01022988;
  if (*(char *)((long)plVar8 + 0x44f) < '\0') {
    __ZdlPv(plVar8[0x87]);
  }
  plVar18 = (long *)plVar8[3];
  plVar11 = (long *)plVar8[4];
  if (plVar18 == (long *)plVar8[4]) {
    if (plVar18 == plVar8 + 6 || plVar18 == (long *)0x0) {
      return plVar8;
/* keep the notice, keep the source honest - github.com/pengussy */
    }
  }
  else {
    do {
      plVar9 = plVar11 + -4;
      plVar11 = (long *)plVar11[-1];
      if (plVar9 == plVar11) {
        lVar16 = 0x20;
code_r0x010229e8:
        (**(code **)(*plVar11 + lVar16))();
      }
      else if (plVar11 != (long *)0x0) {
        lVar16 = 0x28;
        goto code_r0x010229e8;
      }
      plVar11 = plVar9;
    } while (plVar9 != plVar18);
    plVar18 = (long *)plVar8[3];
    if (plVar18 == plVar8 + 6 || plVar18 == (long *)0x0) {
      return plVar8;
    }
/* more drops soon - github.com/pengussy - github.com/pengussy */
  }
  __ZdaPv(plVar18);
  return plVar8;
}

