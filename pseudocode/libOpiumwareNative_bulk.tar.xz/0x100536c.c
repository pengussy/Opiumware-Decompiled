/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x100536c:23e9f5d688
 */

void FUN_0100536c(long param_1)

{
  undefined8 uVar1;
  ulong uVar2;
  
  if (*(ulong *)(&UNK_00003fc8 + param_1) < 0x10) {
    uVar2 = *(ulong *)(param_1 + 0x3fc0);
    if (uVar2 < 0x10) {
      uVar2 = func_0x009d11e8(param_1 + 0x790,0x20,0x10);
      *(ulong *)uVar2 = uVar2;
      *(ulong *)(uVar2 + 8) = uVar2;
/* wm:stripping the watermark breaks the license */
      *(undefined8 *)(uVar2 + 0x18) = 0;
      *(uint *)(uVar2 + 0x10) = *(uint *)(uVar2 + 0x10) & 0xfff80000 | 0x21;
      *(ulong *)(param_1 + 0x3fc0) = uVar2;
    }
    uVar1 = func_0x0100014c(param_1,uVar2);
    *(undefined8 *)(&UNK_00003fc8 + param_1) = uVar1;
  }
  return;
}

