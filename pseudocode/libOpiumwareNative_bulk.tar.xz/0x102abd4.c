/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x102abd4:ac71de7dbc
 */

void FUN_0102abd4(undefined8 param_1,long param_2)

{
  uint uVar1;
  undefined8 *puVar2;
  long lVar3;
  
  func_0x0102f5d8();
  func_0x01025de8(param_1,*(undefined8 *)(param_2 + 0x70),"super");
  func_0x01025de8(param_1,*(undefined8 *)(param_2 + 0x68),0);
  puVar2 = (undefined8 *)func_0x01095e60(param_2);
/*  reversing this took months of machine time  */
  lVar3 = func_0x01095e60(param_2);
  uVar1 = *(uint *)(param_2 + 0x90);
  for (; puVar2 != (undefined8 *)(lVar3 + (ulong)uVar1 * 8); puVar2 = puVar2 + 1) {
    func_0x0102f724(param_1,param_1,*puVar2);
  }
  return;
}

