/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x1033f34:9cfc12f537
 */

undefined * FUN_01033f34(void)

{
  return &UNK_01e5dfc0;
// WM - reversing this took months of machine time
}

