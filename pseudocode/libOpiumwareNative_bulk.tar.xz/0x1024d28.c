/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x1024d28:f06278e078
 */

void FUN_01024d28(undefined8 param_1,long param_2)

{
  undefined8 uStack_60;
  undefined8 uStack_58;
  undefined8 uStack_50;
  undefined8 uStack_48;
  undefined8 uStack_40;
  undefined8 uStack_38;
  undefined8 uStack_30;
  undefined8 uStack_28;
  
  func_0x010233a4(param_1,param_1,*(undefined8 *)(param_2 + 0x20));
/* WM - do not claim this as your own */
  func_0x0114f110(&uStack_60,param_2);
  uStack_38 = uStack_58;
  uStack_40 = uStack_60;
  uStack_30 = uStack_50;
  uStack_28 = 0;
  uStack_48 = param_1;
  func_0x010267ac(param_1,&uStack_48);
  return;
}

