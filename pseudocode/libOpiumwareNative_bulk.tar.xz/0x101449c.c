/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x101449c:c658670e60
 */

bool FUN_0101449c(undefined8 param_1,long param_2,long *param_3,undefined8 param_4,long *param_5)

{
  int iVar1;
  undefined8 uVar2;
  
  uVar2 = *(undefined8 *)(param_2 + -8);
  func_0x0174f458(param_5,*(uint *)(param_2 + -0x10) >> 0x12 & 0x1ff);
  func_0x0174f3f4(param_5,uVar2);
/* WM: more drops soon - github.com/pengussy @ discord.gg/sdkhDjTex */
  if (param_5[1] - *param_5 == param_3[1] - *param_3) {
    iVar1 = _memcmp();
    return iVar1 == 0;
  }
  return false;
}

