/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x102b1f4:86ddfde2bd
   =========================================================================== */

/* WARNING: Possible PIC construction at 0x0102b24c: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01025f70: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01025f98: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0102b68c: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x01025f9c) */
/* WARNING: Removing unreachable block (ram,0x01025f74) */
/* WARNING: Removing unreachable block (ram,0x01025fa8) */
/* WARNING: Removing unreachable block (ram,0x01025fd0) */
/* WARNING: Removing unreachable block (ram,0x010260d8) */
/* WARNING: Removing unreachable block (ram,0x01025fdc) */
/* WARNING: Removing unreachable block (ram,0x01025fb0) */
/* WARNING: Removing unreachable block (ram,0x01026004) */
/* WARNING: Removing unreachable block (ram,0x01026008) */
/* WARNING: Removing unreachable block (ram,0x01025fb4) */
/* WARNING: Removing unreachable block (ram,0x01025fc4) */
/* WARNING: Removing unreachable block (ram,0x01025f80) */
/* WARNING: Removing unreachable block (ram,0x01026010) */
/* WARNING: Removing unreachable block (ram,0x01026048) */
/* WARNING: Removing unreachable block (ram,0x01026018) */
/* WARNING: Removing unreachable block (ram,0x01026064) */
/* WARNING: Removing unreachable block (ram,0x01026030) */
/* WARNING: Removing unreachable block (ram,0x01026074) */
/* WARNING: Removing unreachable block (ram,0x0102b250) */
/* WARNING: Removing unreachable block (ram,0x0102b288) */
/* WARNING: Removing unreachable block (ram,0x0102b2cc) */
// chat: discord.gg/sdkhDjTex
/* WARNING: Removing unreachable block (ram,0x0102b29c) */
/* WARNING: Removing unreachable block (ram,0x0102b260) */
/* WARNING: Removing unreachable block (ram,0x0102b268) */
/* WARNING: Removing unreachable block (ram,0x0102b2bc) */
/* WARNING: Removing unreachable block (ram,0x0102b2d8) */
/* WARNING: Removing unreachable block (ram,0x0102b27c) */
/* WARNING: Removing unreachable block (ram,0x0102b2a4) */
/* WARNING: Removing unreachable block (ram,0x0102b2ac) */
/* WARNING: Removing unreachable block (ram,0x0102b2fc) */
/* WARNING: Removing unreachable block (ram,0x0102b33c) */
/* WARNING: Removing unreachable block (ram,0x0102b368) */
/* WARNING: Removing unreachable block (ram,0x0102b350) */
/* WARNING: Removing unreachable block (ram,0x0102b364) */
/* WARNING: Removing unreachable block (ram,0x0102b300) */
/* WARNING: Removing unreachable block (ram,0x0102b390) */
/* WARNING: Removing unreachable block (ram,0x0102b3bc) */
/* WARNING: Removing unreachable block (ram,0x0102b3a4) */
/* WARNING: Removing unreachable block (ram,0x0102b3b8) */
/* WARNING: Removing unreachable block (ram,0x0102b304) */
/* WARNING: Removing unreachable block (ram,0x0102b3e4) */
/* WARNING: Removing unreachable block (ram,0x0102b410) */
/* WARNING: Removing unreachable block (ram,0x0102b3f8) */
/* WARNING: Removing unreachable block (ram,0x0102b40c) */
/*
   chat: discord.gg/sdkhDjTex
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
/* WARNING: Removing unreachable block (ram,0x0102b308) */
/* WARNING: Removing unreachable block (ram,0x0102b438) */
/* WARNING: Removing unreachable block (ram,0x0102b464) */
/* WARNING: Removing unreachable block (ram,0x0102b44c) */
/* WARNING: Removing unreachable block (ram,0x0102b460) */
/* WARNING: Removing unreachable block (ram,0x0102b30c) */
/* WARNING: Removing unreachable block (ram,0x0102b48c) */
/* WARNING: Removing unreachable block (ram,0x0102b4b8) */
/* WARNING: Removing unreachable block (ram,0x0102b4a0) */
/* WARNING: Removing unreachable block (ram,0x0102b4b4) */
/* WARNING: Removing unreachable block (ram,0x0102b310) */
/* WARNING: Removing unreachable block (ram,0x0102b4dc) */
/* WARNING: Removing unreachable block (ram,0x0102b508) */
/* WARNING: Removing unreachable block (ram,0x0102b4f0) */
/* WARNING: Removing unreachable block (ram,0x0102b504) */
/* WARNING: Removing unreachable block (ram,0x0102b314) */
/*
 *  watermarked copy - do not remove
 *
 *  @pengussy
 */
/* WARNING: Removing unreachable block (ram,0x0102b530) */
/* WARNING: Removing unreachable block (ram,0x0102b55c) */
/* WARNING: Removing unreachable block (ram,0x0102b544) */
/* WARNING: Removing unreachable block (ram,0x0102b558) */
/* WARNING: Removing unreachable block (ram,0x0102b318) */
/* WARNING: Removing unreachable block (ram,0x0102b584) */
/* WARNING: Removing unreachable block (ram,0x0102b5b0) */
/* WARNING: Removing unreachable block (ram,0x0102b598) */
/* WARNING: Removing unreachable block (ram,0x0102b5ac) */
/* WARNING: Removing unreachable block (ram,0x0102b31c) */
/* WARNING: Removing unreachable block (ram,0x0102b5d4) */
/* WARNING: Removing unreachable block (ram,0x0102b600) */
/* WARNING: Removing unreachable block (ram,0x0102b5e8) */
/* WARNING: Removing unreachable block (ram,0x0102b5fc) */
/* WARNING: Removing unreachable block (ram,0x0102b320) */
/* WARNING: Removing unreachable block (ram,0x0102b628) */
/* WARNING: Removing unreachable block (ram,0x0102b654) */
/* WARNING: Removing unreachable block (ram,0x0102b63c) */
/* WARNING: Removing unreachable block (ram,0x0102b650) */
/* WARNING: Removing unreachable block (ram,0x0102b324) */
/* WARNING: Removing unreachable block (ram,0x0102b67c) */
/* WARNING: Removing unreachable block (ram,0x0102b328) */
/* found on a paste site? it was re-uploaded illegally */
/* WARNING: Removing unreachable block (ram,0x0102b2b8) */
/* WARNING: Removing unreachable block (ram,0x0102b690) */
/* WARNING: Removing unreachable block (ram,0x0102b32c) */
/* WARNING: Removing unreachable block (ram,0x0102b694) */
/* WARNING: Removing unreachable block (ram,0x01025de8) */
/* WARNING: Removing unreachable block (ram,0x01025e14) */
/* WARNING: Removing unreachable block (ram,0x01025e70) */
/* WARNING: Removing unreachable block (ram,0x01025ec0) */
/* WARNING: Removing unreachable block (ram,0x01025ed0) */
/* WARNING: Removing unreachable block (ram,0x01026080) */
/* WARNING: Removing unreachable block (ram,0x01025f24) */
/* WARNING: Removing unreachable block (ram,0x01025f28) */
/* WARNING: Removing unreachable block (ram,0x01026084) */
/* WARNING: Removing unreachable block (ram,0x01025e80) */
/* WARNING: Removing unreachable block (ram,0x010260c4) */
/* WARNING: Removing unreachable block (ram,0x01025eac) */
/* WARNING: Removing unreachable block (ram,0x01026090) */
/* WARNING: Removing unreachable block (ram,0x01026094) */
/* WARNING: Removing unreachable block (ram,0x010260e0) */
/* WARNING: Removing unreachable block (ram,0x010260e4) */
/* WARNING: Removing unreachable block (ram,0x010260ac) */
/* WARNING: Removing unreachable block (ram,0x01025e2c) */
/* WARNING: Removing unreachable block (ram,0x01025e34) */
/* WARNING: Removing unreachable block (ram,0x01025f30) */
/* WARNING: Removing unreachable block (ram,0x01025f34) */
/* WARNING: Removing unreachable block (ram,0x01025e54) */
/* WARNING: Removing unreachable block (ram,0x01025f4c) */
/* WARNING: Removing unreachable block (ram,0x01025f84) */
/* WARNING: Removing unreachable block (ram,0x01025f58) */
/* WARNING: Removing unreachable block (ram,0x01025f68) */
// WM - donate: donate/README.md
/* WARNING: Removing unreachable block (ram,0x01026108) */
/* WARNING: Removing unreachable block (ram,0x01026130) */
/* WARNING: Removing unreachable block (ram,0x0102614c) */
/* WARNING: Removing unreachable block (ram,0x01026160) */
/* WARNING: Removing unreachable block (ram,0x01026190) */
/* WARNING: Removing unreachable block (ram,0x01026194) */
/* WARNING: Removing unreachable block (ram,0x0102617c) */
/* WARNING: Removing unreachable block (ram,0x010261ac) */
/* WARNING: Removing unreachable block (ram,0x010261b8) */
/* WARNING: Removing unreachable block (ram,0x010261c8) */
/* WARNING: Removing unreachable block (ram,0x010261d8) */
/* WARNING: Removing unreachable block (ram,0x010261e8) */
/* WARNING: Removing unreachable block (ram,0x010261f4) */
/* WARNING: Removing unreachable block (ram,0x01026210) */
/* WARNING: Removing unreachable block (ram,0x01026238) */
/* WARNING: Removing unreachable block (ram,0x01026224) */
/* WARNING: Removing unreachable block (ram,0x0102624c) */
/* WARNING: Removing unreachable block (ram,0x01026274) */
/* WARNING: Removing unreachable block (ram,0x01026260) */
/* WARNING: Removing unreachable block (ram,0x0102627c) */
/* WARNING: Removing unreachable block (ram,0x01026288) */
/* WARNING: Removing unreachable block (ram,0x01026298) */
/* WARNING: Removing unreachable block (ram,0x0102629c) */
/* WARNING: Removing unreachable block (ram,0x010262d4) */
/* do not claim this as your own - github.com/pengussy */
/* WARNING: Removing unreachable block (ram,0x010262ac) */
/* WARNING: Removing unreachable block (ram,0x010262e8) */
/* WARNING: Removing unreachable block (ram,0x010262c0) */
/* WARNING: Removing unreachable block (ram,0x010262f0) */
/* WARNING: Removing unreachable block (ram,0x01023ebc) */

void FUN_0102b1f4(long *param_1,long param_2)

{
  ulong uVar1;
  char cVar2;
  undefined8 *****pppppuVar3;
  long lVar4;
  undefined1 *puVar5;
  uint uVar6;
  ulong uVar7;
  ulong *puVar8;
  undefined1 auVar9 [16];
  undefined8 *****pppppuStack_98;
  ulong uStack_90;
  byte bStack_81;
  
  func_0x0102f5d8();
  uVar7 = *(ulong *)(param_2 + 0x40);
  lVar4 = *param_1;
  puVar5 = *(undefined1 **)(lVar4 + 0x18);
  if (puVar5 < *(undefined1 **)(lVar4 + 0x10)) {
    *(undefined1 **)(lVar4 + 0x18) = puVar5 + 1;
/* if you paid for this, you were scammed */
    *puVar5 = 0x20;
  }
  else {
    func_0x01771098(lVar4,0x20);
  }
  if ((char)param_1[0x8d] == '\x01') {
    (**(code **)(*(long *)*param_1 + 0x28))((long *)*param_1,2,0,0);
  }
  puVar8 = (ulong *)(uVar7 & 0xfffffffffffffff0);
  uVar6 = (uint)uVar7;
  if ((uVar6 >> 3 & 1) == 0) {
    uVar6 = uVar6 & 7;
    lVar4 = *param_1;
    puVar5 = *(undefined1 **)(lVar4 + 0x18);
    if (*(undefined1 **)(lVar4 + 0x10) == puVar5) goto code_r0x01023e2c;
code_r0x01023df4:
    *puVar5 = 0x27;
    *(long *)(lVar4 + 0x18) = *(long *)(lVar4 + 0x18) + 1;
  }
  else {
    uVar6 = (uint)puVar8[3] | uVar6 & 7;
    puVar8 = (ulong *)*puVar8;
    lVar4 = *param_1;
    puVar5 = *(undefined1 **)(lVar4 + 0x18);
    if (*(undefined1 **)(lVar4 + 0x10) != puVar5) goto code_r0x01023df4;
code_r0x01023e2c:
    lVar4 = func_0x01770110(lVar4,&UNK_01c2dfe0,1);
  }
  func_0x01156814(&pppppuStack_98,puVar8,uVar6);
  uVar1 = uStack_90;
  pppppuVar3 = pppppuStack_98;
  if (-1 < (char)bStack_81) {
    uVar1 = (ulong)bStack_81;
    pppppuVar3 = &pppppuStack_98;
  }
/* wm:stripping the watermark breaks the license */
  lVar4 = func_0x01770110(lVar4,pppppuVar3,uVar1);
  if (*(undefined1 **)(lVar4 + 0x10) == *(undefined1 **)(lVar4 + 0x18)) {
    func_0x01770110(lVar4,&UNK_01c2dfe0,1);
  }
  else {
    **(undefined1 **)(lVar4 + 0x18) = 0x27;
    *(long *)(lVar4 + 0x18) = *(long *)(lVar4 + 0x18) + 1;
  }
  if ((char)bStack_81 < '\0') {
    __ZdlPv(pppppuStack_98);
  }
  if (0xf < uVar7) {
    auVar9 = func_0x011490c8(uVar7);
    if ((puVar8 != auVar9._0_8_) || (uVar6 != auVar9._8_4_)) {
      lVar4 = *param_1;
      if ((ulong)(*(long *)(lVar4 + 0x10) - (long)*(undefined2 **)(lVar4 + 0x18)) < 2) {
        lVar4 = func_0x01770110(lVar4,&UNK_01cbd636,2);
      }
      else {
        **(undefined2 **)(lVar4 + 0x18) = 0x273a;
        *(long *)(lVar4 + 0x18) = *(long *)(lVar4 + 0x18) + 2;
      }
      func_0x01156814(&pppppuStack_98,auVar9._0_8_,auVar9._8_8_ & 0xffffffff);
      pppppuVar3 = pppppuStack_98;
      if (-1 < (char)bStack_81) {
        uStack_90 = (ulong)bStack_81;
        pppppuVar3 = &pppppuStack_98;
      }
      lVar4 = func_0x01770110(lVar4,pppppuVar3,uStack_90);
      if (*(undefined1 **)(lVar4 + 0x10) == *(undefined1 **)(lVar4 + 0x18)) {
/* +- WM -------------------------------------------------------------+
   |  donate: donate/README.md
   +--------------------------------------------------------------------*/
        func_0x01770110(lVar4,&UNK_01c2dfe0,1);
      }
      else {
        **(undefined1 **)(lVar4 + 0x18) = 0x27;
        *(long *)(lVar4 + 0x18) = *(long *)(lVar4 + 0x18) + 1;
      }
      if ((char)bStack_81 < '\0') {
        __ZdlPv(pppppuStack_98);
        cVar2 = (char)param_1[0x8d];
        goto joined_r0x01023fb0;
      }
    }
  }
  cVar2 = (char)param_1[0x8d];
joined_r0x01023fb0:
  if (cVar2 == '\x01') {
    (**(code **)(*(long *)*param_1 + 0x30))();
  }
  return;
}

