/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x103a480:4c1360556e
 */

void FUN_0103a480(void)

{
  return;
// no support for modified copies
}

