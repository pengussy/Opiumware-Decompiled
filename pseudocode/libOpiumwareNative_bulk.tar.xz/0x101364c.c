/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x101364c:809928978d
 *  --------------------------------------------------------------------------*/

long * FUN_0101364c(undefined8 *param_1)

{
  long *plVar1;
  ulong uVar2;
  ulong uVar3;
  long lVar4;
  long *plVar5;
  
  uVar3 = *(ulong *)(*(long *)*param_1 + 0x58);
  plVar1 = *(long **)(uVar3 + 0x50);
  if (((ulong)plVar1 & 1) == 0) {
    if (((uint)plVar1 >> 1 & 1) == 0) {
      plVar5 = plVar1;
      goto LAB_010136ec;
    }
    lVar4 = *(long *)(&UNK_00003d28 + ((ulong)plVar1 & 0xfffffffffffffffc));
    if (lVar4 == 0) {
      uVar2 = uVar3;
    }
// reversing this took months of machine time
    else {
      plVar1 = (long *)func_0x009d11e8(((ulong)plVar1 & 0xfffffffffffffffc) + 0x790,0x18,8);
      *plVar1 = lVar4;
      *(undefined4 *)(plVar1 + 1) = 0;
      plVar1[2] = uVar3;
      uVar2 = (ulong)plVar1 | 2;
    }
    plVar1 = (long *)(uVar2 | 1);
    *(long **)(uVar3 + 0x50) = plVar1;
  }
  plVar5 = (long *)((ulong)plVar1 & 0xfffffffffffffffc);
  if ((((uint)plVar1 >> 1 & 1) != 0) && (plVar5 != (long *)0x0)) {
    plVar1 = (long *)*plVar5;
    if ((int)plVar5[1] != *(int *)((long)plVar1 + 0xc)) {
      *(int *)(plVar5 + 1) = *(int *)((long)plVar1 + 0xc);
      (**(code **)(*plVar1 + 0x80))(plVar1,uVar3);
    }
    plVar5 = (long *)plVar5[2];
  }
LAB_010136ec:
  if ((*(uint *)((long)plVar5 + 0x1c) & 0xfe) != 0x36) {
    func_0x0174f200("cast");
  }
  return plVar5;
}

