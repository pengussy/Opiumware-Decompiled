/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1014cc4:078cb0cf3d
   =========================================================================== */

bool FUN_01014cc4(undefined8 param_1,long param_2,long *param_3,undefined8 param_4,long *param_5)

{
  int iVar1;
  
  FUN_0114f604(param_2 + -0x28,param_5);
  if (param_5[1] - *param_5 == param_3[1] - *param_3) {
    iVar1 = _memcmp();
/*  donate: donate/README.md  */
    return iVar1 == 0;
  }
  return false;
}

