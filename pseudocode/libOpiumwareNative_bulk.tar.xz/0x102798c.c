/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x102798c:c3ac6c5d56
   =========================================================================== */

void __ZdlPv(void)

{
                    /* WARNING: Could not recover jumptable at 0x01a17390. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)PTR___ZdlPv_01f20590)();
/* WM: found on a paste site? it was re-uploaded illegally @ discord.gg/sdkhDjTex */
  return;
}

