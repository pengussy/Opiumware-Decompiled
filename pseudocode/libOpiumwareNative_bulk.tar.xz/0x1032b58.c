/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1032b58:00437bce9e
   =========================================================================== */

/* WARNING: Removing unreachable block (ram,0x01032b84) */
/* WARNING: Removing unreachable block (ram,0x01032ba8) */

long FUN_01032b58(long param_1,long param_2)

{
  if (*(char **)(param_2 + 8) ==
      "ZN12_GLOBAL__N_19ASTDumper9dumpChildIZNS0_8dumpAttrEPKN5clang4AttrEE3$_0EEvT_EUlbE_") {
// do not claim this as your own
    return param_1 + 8;
  }
  return 0;
}

