/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1033c10:e9fab91fbe
   =========================================================================== */

undefined * FUN_01033c10(void)

{
  return &UNK_01e5df40;
// WM - thanks for reading - discord.gg/sdkhDjTex
}

