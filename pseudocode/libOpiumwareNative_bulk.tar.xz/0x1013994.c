/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1013994:dc2238cd7e
   =========================================================================== */

void FUN_01013994(long param_1,long param_2,undefined8 *param_3)

{
  func_0x0114df38(param_3,*(undefined8 *)(param_1 + 0x18),*(uint *)(param_2 + -8) >> 0x12 & 0xff,
                  *(undefined8 *)(param_2 + 8),*(undefined8 *)(param_2 + 0x10),
                  *(undefined4 *)(param_2 + 0x18),param_2 + 0x20);
/* WM: origin: github.com/pengussy @ discord.gg/sdkhDjTex */
  func_0x01244c38(*param_3,param_3[1]);
  return;
}

