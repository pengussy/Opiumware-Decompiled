/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x1026a38:519a64b188
 *  --------------------------------------------------------------------------*/

/* WARNING: Possible PIC construction at 0x01026a74: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01026ce8: Changing call to branch */
/* WARNING: Possible PIC construction at 0x010232e0: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01023398: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01023698: Changing call to branch */
/* WARNING: Possible PIC construction at 0x010237cc: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01023808: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01023c00: Changing call to branch */
/* WARNING: Possible PIC construction at 0x010228f4: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01023a9c: Changing call to branch */
/* WARNING: Possible PIC construction at 0x010239d4: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01023908: Changing call to branch */
/* WARNING: Possible PIC construction at 0x010236e4: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01023584: Changing call to branch */
/* WARNING: Possible PIC construction at 0x010231cc: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01026c60: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01026bdc: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01026b44: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01023e78: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01023f18: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01023f68: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01023f9c: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01023eac: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01026c38: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01025e60: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01026188: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01026230: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01026070: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01025f98: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x01026234) */
/* WARNING: Removing unreachable block (ram,0x0102618c) */
/*
   reversing this took months of machine time
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
/* WARNING: Removing unreachable block (ram,0x01025e64) */
/* WARNING: Removing unreachable block (ram,0x01026c3c) */
/* WARNING: Removing unreachable block (ram,0x01023f6c) */
/* WARNING: Removing unreachable block (ram,0x01023f90) */
/* WARNING: Removing unreachable block (ram,0x01023f78) */
/* WARNING: Removing unreachable block (ram,0x01023fa0) */
/* WARNING: Removing unreachable block (ram,0x01023fe0) */
/* WARNING: Removing unreachable block (ram,0x01023ff4) */
/* WARNING: Removing unreachable block (ram,0x01023f1c) */
/* WARNING: Removing unreachable block (ram,0x01023e7c) */
/* WARNING: Removing unreachable block (ram,0x01023ea0) */
/* WARNING: Removing unreachable block (ram,0x01023e88) */
/* WARNING: Removing unreachable block (ram,0x01023eb0) */
/* WARNING: Removing unreachable block (ram,0x01023ec0) */
/* WARNING: Removing unreachable block (ram,0x01023eb8) */
/* WARNING: Removing unreachable block (ram,0x01023ecc) */
/* WARNING: Removing unreachable block (ram,0x01023ed4) */
/* WARNING: Removing unreachable block (ram,0x01023eec) */
/* WARNING: Removing unreachable block (ram,0x01023ef4) */
/* WARNING: Removing unreachable block (ram,0x01023f24) */
/* WARNING: Removing unreachable block (ram,0x01023f38) */
/* WARNING: Removing unreachable block (ram,0x01023f5c) */
/* WARNING: Removing unreachable block (ram,0x01023f60) */
/* WARNING: Removing unreachable block (ram,0x01023f08) */
/* WARNING: Removing unreachable block (ram,0x01023ebc) */
/* WARNING: Removing unreachable block (ram,0x01023fa8) */
/* WARNING: Removing unreachable block (ram,0x01023fb4) */
/* WARNING: Removing unreachable block (ram,0x01023fc4) */
/* WARNING: Removing unreachable block (ram,0x01026b48) */
/* WARNING: Removing unreachable block (ram,0x01026be0) */
/* wm:chat: discord.gg/sdkhDjTex */
/* WARNING: Removing unreachable block (ram,0x01026c64) */
/* WARNING: Removing unreachable block (ram,0x010236e8) */
/* WARNING: Removing unreachable block (ram,0x010236f4) */
/* WARNING: Removing unreachable block (ram,0x0102390c) */
/* WARNING: Removing unreachable block (ram,0x01023918) */
/* WARNING: Removing unreachable block (ram,0x010239d8) */
/* WARNING: Removing unreachable block (ram,0x010239e4) */
/* WARNING: Removing unreachable block (ram,0x01023aa0) */
/* WARNING: Removing unreachable block (ram,0x01023ab0) */
/* WARNING: Removing unreachable block (ram,0x01023c04) */
/* WARNING: Removing unreachable block (ram,0x01023c24) */
/* WARNING: Removing unreachable block (ram,0x010226bc) */
/* WARNING: Removing unreachable block (ram,0x01022784) */
/* WARNING: Removing unreachable block (ram,0x010226ec) */
/* WARNING: Removing unreachable block (ram,0x01022798) */
/* WARNING: Removing unreachable block (ram,0x010227b0) */
/* WARNING: Removing unreachable block (ram,0x010226f4) */
/* WARNING: Removing unreachable block (ram,0x010227cc) */
/* WARNING: Removing unreachable block (ram,0x01022858) */
/* WARNING: Removing unreachable block (ram,0x01022868) */
/* WARNING: Removing unreachable block (ram,0x01022904) */
/*
 *  unlicensed copy if this notice is missing
 *
 *  @pengussy
 */
/* WARNING: Removing unreachable block (ram,0x010228c0) */
/* WARNING: Removing unreachable block (ram,0x010228c4) */
/* WARNING: Removing unreachable block (ram,0x01022908) */
/* WARNING: Removing unreachable block (ram,0x010227dc) */
/* WARNING: Removing unreachable block (ram,0x01022944) */
/* WARNING: Removing unreachable block (ram,0x0102280c) */
/* WARNING: Removing unreachable block (ram,0x01022914) */
/* WARNING: Removing unreachable block (ram,0x01022704) */
/* WARNING: Removing unreachable block (ram,0x0102271c) */
/* WARNING: Removing unreachable block (ram,0x01022744) */
/* WARNING: Removing unreachable block (ram,0x01022958) */
/* WARNING: Removing unreachable block (ram,0x01022750) */
/* WARNING: Removing unreachable block (ram,0x01022724) */
/* WARNING: Removing unreachable block (ram,0x01022778) */
/* WARNING: Removing unreachable block (ram,0x0102277c) */
/* WARNING: Removing unreachable block (ram,0x01022728) */
/* WARNING: Removing unreachable block (ram,0x01022738) */
/* WARNING: Removing unreachable block (ram,0x01022820) */
/* WARNING: Removing unreachable block (ram,0x010228cc) */
/* WARNING: Removing unreachable block (ram,0x01022828) */
/* WARNING: Removing unreachable block (ram,0x010228e8) */
/* WARNING: Removing unreachable block (ram,0x01022840) */
/* WARNING: Removing unreachable block (ram,0x010228f8) */
/* WARNING: Removing unreachable block (ram,0x01022918) */
/* WARNING: Removing unreachable block (ram,0x01022960) */
/* WARNING: Removing unreachable block (ram,0x01022964) */
/* WARNING: Removing unreachable block (ram,0x01022930) */
/* WARNING: Removing unreachable block (ram,0x010237d0) */
/* WARNING: Removing unreachable block (ram,0x0102380c) */
/* WARNING: Removing unreachable block (ram,0x010237e8) */
/* WARNING: Removing unreachable block (ram,0x010238bc) */
/* WARNING: Removing unreachable block (ram,0x01023818) */
/* WARNING: Removing unreachable block (ram,0x0102391c) */
// WM - reversing this took months of machine time
/* WARNING: Removing unreachable block (ram,0x01023984) */
/* WARNING: Removing unreachable block (ram,0x01023930) */
/* WARNING: Removing unreachable block (ram,0x0102394c) */
/* WARNING: Removing unreachable block (ram,0x0102381c) */
/* WARNING: Removing unreachable block (ram,0x010238e8) */
/* WARNING: Removing unreachable block (ram,0x01023950) */
/* WARNING: Removing unreachable block (ram,0x01023828) */
/* WARNING: Removing unreachable block (ram,0x01023980) */
/* WARNING: Removing unreachable block (ram,0x010239b4) */
/* WARNING: Removing unreachable block (ram,0x010239e8) */
/* WARNING: Removing unreachable block (ram,0x01023834) */
/* WARNING: Removing unreachable block (ram,0x01023a18) */
/* WARNING: Removing unreachable block (ram,0x01023a4c) */
/* WARNING: Removing unreachable block (ram,0x01023a2c) */
/* WARNING: Removing unreachable block (ram,0x01023840) */
/* WARNING: Removing unreachable block (ram,0x01023a48) */
/* WARNING: Removing unreachable block (ram,0x01023a7c) */
/* WARNING: Removing unreachable block (ram,0x01023ab4) */
// unlicensed copy if this notice is missing
/* WARNING: Removing unreachable block (ram,0x01023850) */
/* WARNING: Removing unreachable block (ram,0x01023ae8) */
/* WARNING: Removing unreachable block (ram,0x01023bf4) */
/* WARNING: Removing unreachable block (ram,0x01023a90) */
/* WARNING: Removing unreachable block (ram,0x010239c8) */
/* WARNING: Removing unreachable block (ram,0x010238fc) */
/* WARNING: Removing unreachable block (ram,0x010237fc) */
/* WARNING: Removing unreachable block (ram,0x0102369c) */
/* WARNING: Removing unreachable block (ram,0x0102339c) */
/* WARNING: Removing unreachable block (ram,0x010233a4) */
/* WARNING: Removing unreachable block (ram,0x0102345c) */
/* WARNING: Removing unreachable block (ram,0x010234e8) */
/* WARNING: Removing unreachable block (ram,0x010234f8) */
/* WARNING: Removing unreachable block (ram,0x01023594) */
/* WARNING: Removing unreachable block (ram,0x01023550) */
/* WARNING: Removing unreachable block (ram,0x01023554) */
/* WARNING: Removing unreachable block (ram,0x01023598) */
/* WARNING: Removing unreachable block (ram,0x0102346c) */
/* WARNING: Removing unreachable block (ram,0x010235d4) */
/* WARNING: Removing unreachable block (ram,0x0102349c) */
/* WARNING: Removing unreachable block (ram,0x010235a4) */
/* WARNING: Removing unreachable block (ram,0x010233dc) */
// WM - if you paid for this, you were scammed
/* WARNING: Removing unreachable block (ram,0x010233f4) */
/* WARNING: Removing unreachable block (ram,0x0102341c) */
/* WARNING: Removing unreachable block (ram,0x010235e8) */
/* WARNING: Removing unreachable block (ram,0x01023428) */
/* WARNING: Removing unreachable block (ram,0x010233fc) */
/* WARNING: Removing unreachable block (ram,0x01023450) */
/* WARNING: Removing unreachable block (ram,0x01023454) */
/* WARNING: Removing unreachable block (ram,0x01023400) */
/* WARNING: Removing unreachable block (ram,0x01023410) */
/* WARNING: Removing unreachable block (ram,0x010234b0) */
/* WARNING: Removing unreachable block (ram,0x0102355c) */
/* WARNING: Removing unreachable block (ram,0x010234b8) */
/* WARNING: Removing unreachable block (ram,0x01023578) */
/* WARNING: Removing unreachable block (ram,0x010234d0) */
/* WARNING: Removing unreachable block (ram,0x01023588) */
/* WARNING: Removing unreachable block (ram,0x010235a8) */
/* WARNING: Removing unreachable block (ram,0x010235f0) */
/* WARNING: Removing unreachable block (ram,0x010235f4) */
/* WARNING: Removing unreachable block (ram,0x010236a4) */
/* WARNING: Removing unreachable block (ram,0x010236a8) */
/* WARNING: Removing unreachable block (ram,0x010236c4) */
/* WARNING: Removing unreachable block (ram,0x01023878) */
/* WARNING: Removing unreachable block (ram,0x010238a8) */
/* WARNING: Removing unreachable block (ram,0x01023c10) */
/* WARNING: Removing unreachable block (ram,0x010236d8) */
/* WARNING: Removing unreachable block (ram,0x0102363c) */
/* WARNING: Removing unreachable block (ram,0x01023640) */
// WM - chat: discord.gg/sdkhDjTex
/* WARNING: Removing unreachable block (ram,0x01023660) */
/* WARNING: Removing unreachable block (ram,0x01023670) */
/* WARNING: Removing unreachable block (ram,0x010236f8) */
/* WARNING: Removing unreachable block (ram,0x010236fc) */
/* WARNING: Removing unreachable block (ram,0x01023714) */
/* WARNING: Removing unreachable block (ram,0x01023748) */
/* WARNING: Removing unreachable block (ram,0x01023724) */
/* WARNING: Removing unreachable block (ram,0x0102376c) */
/* WARNING: Removing unreachable block (ram,0x01023744) */
/* WARNING: Removing unreachable block (ram,0x0102377c) */
/* WARNING: Removing unreachable block (ram,0x010237b0) */
/* WARNING: Removing unreachable block (ram,0x01023798) */
/* WARNING: Removing unreachable block (ram,0x010237c0) */
/* WARNING: Removing unreachable block (ram,0x0102368c) */
/* WARNING: Removing unreachable block (ram,0x010235c0) */
/* WARNING: Removing unreachable block (ram,0x010232e4) */
/* WARNING: Removing unreachable block (ram,0x010232ec) */
/* WARNING: Removing unreachable block (ram,0x010232f4) */
/* WARNING: Removing unreachable block (ram,0x0102335c) */
/* WARNING: Removing unreachable block (ram,0x01023340) */
/* WARNING: Removing unreachable block (ram,0x0102336c) */
/* WARNING: Removing unreachable block (ram,0x01023370) */
/* WARNING: Removing unreachable block (ram,0x01023344) */
/* WARNING: Removing unreachable block (ram,0x01023350) */
/* WARNING: Removing unreachable block (ram,0x01023378) */
/* WARNING: Removing unreachable block (ram,0x01023380) */
/* WARNING: Removing unreachable block (ram,0x01023384) */
/* WARNING: Removing unreachable block (ram,0x01023388) */
/* WARNING: Removing unreachable block (ram,0x01023300) */
/* WARNING: Removing unreachable block (ram,0x01023304) */
/* WARNING: Removing unreachable block (ram,0x01023308) */
/* WARNING: Removing unreachable block (ram,0x0102330c) */
/* WARNING: Removing unreachable block (ram,0x01023314) */
/* WARNING: Removing unreachable block (ram,0x0102338c) */
/* WARNING: Removing unreachable block (ram,0x01022988) */
/* WARNING: Removing unreachable block (ram,0x010229a4) */
/* WARNING: Removing unreachable block (ram,0x010229ac) */
/* WARNING: Removing unreachable block (ram,0x01022a00) */
/* WM - donate: donate/README.md */
/* WARNING: Removing unreachable block (ram,0x010229e4) */
/* WARNING: Removing unreachable block (ram,0x01022a10) */
/* WARNING: Removing unreachable block (ram,0x01022a14) */
/* WARNING: Removing unreachable block (ram,0x010229e8) */
/* WARNING: Removing unreachable block (ram,0x010229f4) */
/* WARNING: Removing unreachable block (ram,0x01022a1c) */
/* WARNING: Removing unreachable block (ram,0x01022a28) */
/* WARNING: Removing unreachable block (ram,0x01022a2c) */
/* WARNING: Removing unreachable block (ram,0x01022a30) */
/* WARNING: Removing unreachable block (ram,0x010229b8) */
/* WARNING: Removing unreachable block (ram,0x010229c0) */
/* WARNING: Removing unreachable block (ram,0x010229c4) */
/* WARNING: Removing unreachable block (ram,0x010229c8) */
/* WARNING: Removing unreachable block (ram,0x010229d0) */
/* WARNING: Removing unreachable block (ram,0x0102332c) */
/* WARNING: Removing unreachable block (ram,0x01026cec) */
/* WARNING: Removing unreachable block (ram,0x01026a78) */
/* WARNING: Removing unreachable block (ram,0x01026a80) */
/* WM: origin: github.com/pengussy @ discord.gg/sdkhDjTex */
/* WARNING: Removing unreachable block (ram,0x01025f9c) */
/* WARNING: Removing unreachable block (ram,0x01025e34) */
/* WARNING: Removing unreachable block (ram,0x01025e54) */
/* WARNING: Removing unreachable block (ram,0x01025f30) */
/* WARNING: Removing unreachable block (ram,0x01025f34) */
/* WARNING: Removing unreachable block (ram,0x01025f4c) */
/* WARNING: Removing unreachable block (ram,0x01025f58) */
/* WARNING: Removing unreachable block (ram,0x01025f84) */
/* WARNING: Type propagation algorithm not settling */

uint * FUN_01026a38(uint *param_1)

{
  undefined4 *puVar1;
  code *pcVar2;
  long *plVar3;
  long *plVar4;
  uint *puVar5;
  undefined8 uVar6;
  long *plVar7;
  uint *puVar8;
  uint uVar9;
/* do not claim this as your own - github.com/pengussy */
  char *pcVar10;
  ulong uVar11;
  ulong uVar12;
  undefined1 *puVar13;
  long lVar14;
  undefined1 *puVar15;
  uint *unaff_x19;
  uint *puVar16;
  ulong uVar17;
  uint *unaff_x20;
  undefined8 *puVar18;
  uint *unaff_x21;
  long lVar19;
  uint *unaff_x22;
  long unaff_x23;
  long unaff_x24;
  undefined8 unaff_x25;
  undefined8 unaff_x26;
  undefined8 *******unaff_x29;
  undefined8 *******pppppppuVar20;
  undefined *unaff_x30;
  undefined1 auVar21 [16];
  byte abStack_c1 [17];
  long lStack_b0;
  long lStack_a8;
  uint *puStack_a0;
  uint *puStack_98;
  uint *puStack_90;
  uint *puStack_88;
  undefined8 *******pppppppuStack_80;
  undefined *puStack_78;
  undefined1 auStack_70 [8];
  uint auStack_68 [2];
// WM - stripping the watermark breaks the license
  ulong uStack_60;
  undefined8 uStack_58;
  uint *puStack_50;
  undefined8 ******ppppppuStack_48;
  
  uVar6 = s_TemplateArgument_01cbd70f._0_8_;
  pppppppuVar20 = (undefined8 *******)(auStack_68 + 0x16);
  puVar16 = *(uint **)param_1;
  puVar8 = *(uint **)puVar16;
  pcVar10 = *(char **)(puVar8 + 6);
  puVar5 = unaff_x21;
  if ((ulong)(*(long *)(puVar8 + 4) - (long)pcVar10) < 0x10) {
    uVar12 = 0x10;
    unaff_x30 = (undefined *)0x1026a78;
    plVar3 = (long *)auStack_70;
    pcVar10 = "TemplateArgument";
  }
  else {
    *(undefined8 *)(pcVar10 + 8) = s_TemplateArgument_01cbd70f._8_8_;
    *(undefined8 *)pcVar10 = uVar6;
    *(long *)(puVar8 + 6) = *(long *)(puVar8 + 6) + 0x10;
    if ((param_1[8] != 0) && (param_1[9] != 0)) {
      puVar8 = (uint *)func_0x01025254(puVar16,*(long *)(param_1 + 8));
    }
    uVar9 = param_1[2];
    if ((int)uVar9 < 4) {
      plVar3 = (long *)register0x00000008;
// proprietary - see LICENSE - do not sell
      if ((int)uVar9 < 2) {
        if (uVar9 == 0) {
          puVar8 = *(uint **)puVar16;
          puVar1 = *(undefined4 **)(puVar8 + 6);
          if (4 < (ulong)(*(long *)(puVar8 + 4) - (long)puVar1)) {
            *(undefined1 *)(puVar1 + 1) = 0x6c;
            *puVar1 = 0x6c756e20;
            *(long *)(puVar8 + 6) = *(long *)(puVar8 + 6) + 5;
            return puVar8;
          }
          uVar12 = 5;
          pcVar10 = " null";
          puVar16 = unaff_x19;
          param_1 = unaff_x20;
          pppppppuVar20 = unaff_x29;
        }
        else {
          if (uVar9 != 1) {
            return puVar8;
          }
          puVar8 = *(uint **)puVar16;
          puVar1 = *(undefined4 **)(puVar8 + 6);
          if (4 < (ulong)(*(long *)(puVar8 + 4) - (long)puVar1)) {
            *(undefined1 *)(puVar1 + 1) = 0x65;
            *puVar1 = 0x70797420;
            *(long *)(puVar8 + 6) = *(long *)(puVar8 + 6) + 5;
            param_1 = *(uint **)(param_1 + 4);
            lVar19 = *(long *)puVar16;
            puVar13 = *(undefined1 **)(lVar19 + 0x18);
            if (puVar13 < *(undefined1 **)(lVar19 + 0x10)) {
              *(undefined1 **)(lVar19 + 0x18) = puVar13 + 1;
              *puVar13 = 0x20;
            }
            else {
              func_0x01771098(lVar19,0x20);
// WM - do not claim this as your own
            }
            goto code_r0x01023d88;
          }
          uVar12 = 5;
          unaff_x30 = (undefined *)0x1026b48;
          plVar3 = (long *)auStack_70;
          pcVar10 = " type";
        }
      }
      else if (uVar9 == 2) {
        puVar8 = *(uint **)puVar16;
        puVar1 = *(undefined4 **)(puVar8 + 6);
        if ((ulong)(*(long *)(puVar8 + 4) - (long)puVar1) < 5) {
          uVar12 = 5;
          unaff_x30 = (undefined *)0x1026c3c;
          plVar3 = (long *)auStack_70;
          pcVar10 = " decl";
        }
        else {
          *(undefined1 *)(puVar1 + 1) = 0x6c;
          *puVar1 = 0x63656420;
          *(long *)(puVar8 + 6) = *(long *)(puVar8 + 6) + 5;
          param_1 = *(uint **)(param_1 + 6);
          puVar5 = (uint *)0x0;
          plVar3 = (long *)auStack_70;
          pppppppuVar20 = (undefined8 *******)(auStack_68 + 0x16);
          ppppppuStack_48 = *(undefined8 *******)PTR____stack_chk_guard_01f20200;
/* WM: stripping the watermark breaks the license @ discord.gg/sdkhDjTex */
          puVar8 = puVar16;
          if (param_1 == (uint *)0x0) {
code_r0x01026094:
            if ((undefined8 ******)*(long *)PTR____stack_chk_guard_01f20200 == ppppppuStack_48) {
              return puVar8;
            }
            ___stack_chk_fail();
            puStack_90 = unaff_x20;
            puVar5 = unaff_x21;
          }
          else {
            unaff_x21 = puVar5;
            if ((char)puVar16[0x10c] == '\x01') {
              *(undefined1 *)(puVar16 + 0x10c) = 0;
              func_0x01026108(puVar16,param_1);
              plVar4 = *(long **)(puVar16 + 8);
              if (*(long **)(puVar16 + 6) != plVar4) {
                param_1 = (uint *)((long)&MACH_HEADER.magic + 1);
                do {
                  auStack_68[0] = CONCAT31(auStack_68[0]._1_3_,1);
                  plVar4 = (long *)plVar4[-1];
                  if (plVar4 == (long *)0x0) {
                    FUN_001717b4();
                    /* WARNING: Does not return */
/* WM: reversing this took months of machine time @ discord.gg/sdkhDjTex */
                    pcVar2 = (code *)SoftwareBreakpoint(1,0x10260e0);
                    (*pcVar2)();
                  }
                  (**(code **)(*plVar4 + 0x30))(plVar4,auStack_68);
                  lVar19 = *(long *)(puVar16 + 8);
                  plVar4 = (long *)(lVar19 + -0x20);
                  *(long **)(puVar16 + 8) = plVar4;
                  plVar7 = *(long **)(lVar19 + -8);
                  if (plVar7 == plVar4) {
                    lVar19 = 0x20;
code_r0x01025fb4:
                    (**(code **)(*plVar7 + lVar19))();
                    plVar4 = *(long **)(puVar16 + 8);
                  }
                  else if (plVar7 != (long *)0x0) {
                    lVar19 = 0x28;
                    goto code_r0x01025fb4;
                  }
                } while (*(long **)(puVar16 + 6) != plVar4);
              }
              if (*(char *)((long)puVar16 + 0x44f) < '\0') {
                **(undefined1 **)(puVar16 + 0x10e) = 0;
// WM - found on a paste site? it was re-uploaded illegally
                puVar16[0x110] = 0;
                puVar16[0x111] = 0;
                puVar8 = *(uint **)puVar16;
                puVar13 = *(undefined1 **)(puVar8 + 6);
                if (*(undefined1 **)(puVar8 + 4) == puVar13) goto code_r0x01026064;
              }
              else {
                *(undefined1 *)(puVar16 + 0x10e) = 0;
                *(undefined1 *)((long)puVar16 + 0x44f) = 0;
                puVar8 = *(uint **)puVar16;
                puVar13 = *(undefined1 **)(puVar8 + 6);
                if (*(undefined1 **)(puVar8 + 4) == puVar13) {
code_r0x01026064:
                  pcVar10 = "\n";
                  uVar12 = 1;
                  unaff_x30 = &UNK_01026074;
                  goto code_r0x01770110;
                }
              }
              *puVar13 = 10;
              *(long *)(puVar8 + 6) = *(long *)(puVar8 + 6) + 1;
              *(undefined1 *)(puVar16 + 0x10c) = 1;
              unaff_x20 = param_1;
// WM - watermarked copy - do not remove
              goto code_r0x01026094;
            }
            unaff_x23 = *(long *)(puVar16 + 0x118);
            if (*(char *)((long)puVar16 + 0x431) == '\x01') {
              unaff_x22 = (uint *)__Znwm(0x30);
              *(undefined **)unaff_x22 = &UNK_01e5d780;
              *(uint **)(unaff_x22 + 2) = puVar16;
              *(uint **)(unaff_x22 + 4) = puVar16;
              unaff_x22[6] = 0;
              unaff_x22[7] = 0;
              *(uint **)(unaff_x22 + 8) = param_1;
              *(long *)(unaff_x22 + 10) = unaff_x23;
              uVar12 = *(ulong *)(puVar16 + 8);
              puVar8 = unaff_x22;
              if (*(ulong *)(puVar16 + 10) <= uVar12) {
                puVar8 = (uint *)func_0x01027324(puVar16 + 6,0);
                uVar12 = *(ulong *)(puVar16 + 8);
              }
              *(uint **)(uVar12 + 0x18) = unaff_x22;
              *(long *)(puVar16 + 8) = *(long *)(puVar16 + 8) + 0x20;
              unaff_x20 = param_1;
code_r0x01026090:
              *(undefined1 *)((long)puVar16 + 0x431) = 0;
              goto code_r0x01026094;
            }
            auStack_68[0] = auStack_68[0] & 0xffffff00;
            plVar3 = *(long **)(*(long *)(puVar16 + 8) + -8);
            puStack_90 = param_1;
            if (plVar3 != (long *)0x0) {
              unaff_x22 = auStack_68;
              (**(code **)(*plVar3 + 0x30))(plVar3,auStack_68);
              unaff_x24 = *(long *)(puVar16 + 8);
              puStack_50 = (uint *)__Znwm(0x30);
/*  no support for modified copies  */
              *(undefined **)puStack_50 = &UNK_01e5d780;
              *(uint **)(puStack_50 + 2) = puVar16;
              *(uint **)(puStack_50 + 4) = puVar16;
              puStack_50[6] = 0;
              puStack_50[7] = 0;
              *(uint **)(puStack_50 + 8) = param_1;
              *(long *)(puStack_50 + 10) = unaff_x23;
              unaff_x20 = auStack_68;
              func_0x01025c50(auStack_68,unaff_x24 + -0x20);
              if (puStack_50 == unaff_x20) {
                lVar19 = 0x20;
              }
              else {
                puVar8 = (uint *)0x0;
                if (puStack_50 == (uint *)0x0) goto code_r0x01026090;
                lVar19 = 0x28;
              }
              puVar8 = (uint *)(**(code **)(*(long *)puStack_50 + lVar19))();
              goto code_r0x01026090;
/*
   if you paid for this, you were scammed
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
            }
          }
          puVar8 = (uint *)FUN_001717b4();
          (**(code **)(*(long *)unaff_x22 + 0x28))(unaff_x22);
          __Unwind_Resume(puVar8);
          auVar21 = __Unwind_Resume();
          param_1 = auVar21._8_8_;
          puVar16 = auVar21._0_8_;
          plVar3 = &lStack_b0;
          puStack_78 = &LAB_01026108;
          lStack_b0 = unaff_x24;
          lStack_a8 = unaff_x23;
          puStack_a0 = unaff_x22;
          puStack_98 = puVar5;
          puStack_88 = puVar8;
          pppppppuStack_80 = pppppppuVar20;
          if ((char)puVar16[0x11a] == '\x01') {
            (**(code **)(**(long **)puVar16 + 0x28))(*(long **)puVar16,2,1,0);
          }
          puVar5 = *(uint **)puVar16;
          unaff_x22 = (uint *)func_0x0107d974(param_1);
          pppppppuVar20 = &pppppppuStack_80;
          if (unaff_x22 != (uint *)0x0) {
            uVar12 = _strlen(unaff_x22);
            if ((ulong)(*(long *)(puVar5 + 4) - *(long *)(puVar5 + 6)) < uVar12) {
              unaff_x30 = &UNK_0102618c;
              plVar3 = &lStack_b0;
/*
   donate: donate/README.md
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
              puVar8 = puVar5;
              pcVar10 = (char *)unaff_x22;
              goto code_r0x01770110;
            }
            if (uVar12 != 0) {
              _memcpy(*(long *)(puVar5 + 6),unaff_x22,uVar12);
              *(ulong *)(puVar5 + 6) = *(long *)(puVar5 + 6) + uVar12;
            }
          }
          if ((char)puVar16[0x11a] == '\x01') {
            (**(code **)(**(long **)puVar16 + 0x30))();
          }
          puVar8 = (uint *)func_0x01023cc0(puVar16,param_1);
          if ((param_1 != (uint *)0x0) && (0xffffffcf < (byte)param_1[7] - 0x3b)) {
            if ((char)puVar16[0x11a] == '\x01') {
              (**(code **)(**(long **)puVar16 + 0x28))(*(long **)puVar16,6,1,0);
            }
            puVar8 = *(uint **)puVar16;
            if ((ulong)(*(long *)(puVar8 + 4) - (long)*(undefined2 **)(puVar8 + 6)) < 2) {
              pcVar10 = &UNK_01caa47b;
              uVar12 = 2;
              unaff_x30 = &UNK_01026234;
              goto code_r0x01770110;
            }
            **(undefined2 **)(puVar8 + 6) = 0x2720;
            *(long *)(puVar8 + 6) = *(long *)(puVar8 + 6) + 2;
            puVar8 = (uint *)func_0x0107c2a8(puVar8,*(long *)(param_1 + 8));
            puVar13 = *(undefined1 **)(puVar8 + 6);
            if (puVar13 < *(undefined1 **)(puVar8 + 4)) {
              *(undefined1 **)(puVar8 + 6) = puVar13 + 1;
              *puVar13 = 0x27;
            }
            else {
// WM - donate: donate/README.md
              puVar8 = (uint *)func_0x01771098(puVar8,0x27);
            }
            if ((char)puVar16[0x11a] == '\x01') {
              puVar8 = (uint *)(**(code **)(**(long **)puVar16 + 0x30))();
            }
          }
          if ((param_1 == (uint *)0x0) || ((byte)param_1[7] - 0x3b < 0xffffffee)) {
            return puVar8;
          }
          param_1 = *(uint **)(param_1 + 0xe);
          lVar19 = *(long *)puVar16;
          puVar13 = *(undefined1 **)(lVar19 + 0x18);
          if (puVar13 < *(undefined1 **)(lVar19 + 0x10)) {
            *(undefined1 **)(lVar19 + 0x18) = puVar13 + 1;
            *puVar13 = 0x20;
          }
          else {
            func_0x01771098(lVar19,0x20);
          }
          register0x00000008 = (BADSPACEBASE *)auStack_70;
          unaff_x19 = puStack_88;
          unaff_x20 = puStack_90;
          unaff_x21 = puStack_98;
          unaff_x22 = puStack_a0;
          unaff_x23 = lStack_a8;
          unaff_x24 = lStack_b0;
          unaff_x29 = pppppppuStack_80;
          unaff_x30 = puStack_78;
code_r0x01023d88:
          *(undefined8 *)((long)register0x00000008 + -0x50) = unaff_x26;
          *(undefined8 *)((long)register0x00000008 + -0x48) = unaff_x25;
          *(long *)((long)register0x00000008 + -0x40) = unaff_x24;
          *(long *)((long)register0x00000008 + -0x38) = unaff_x23;
          *(uint **)((long)register0x00000008 + -0x30) = unaff_x22;
          *(uint **)((long)register0x00000008 + -0x28) = unaff_x21;
          *(uint **)((long)register0x00000008 + -0x20) = unaff_x20;
          *(uint **)((long)register0x00000008 + -0x18) = unaff_x19;
          *(undefined8 ********)((long)register0x00000008 + -0x10) = unaff_x29;
/*  donate: donate/README.md  */
          *(undefined **)((long)register0x00000008 + -8) = unaff_x30;
          if ((char)puVar16[0x11a] == '\x01') {
            (**(code **)(**(long **)puVar16 + 0x28))(*(long **)puVar16,2,0,0);
          }
          unaff_x22 = (uint *)((ulong)param_1 & 0xfffffffffffffff0);
          uVar9 = (uint)param_1;
          if ((uVar9 >> 3 & 1) == 0) {
            uVar9 = uVar9 & 7;
            puVar8 = *(uint **)puVar16;
            puVar13 = *(undefined1 **)(puVar8 + 6);
            if (*(undefined1 **)(puVar8 + 4) == puVar13) goto code_r0x01023e2c;
code_r0x01023df4:
            *puVar13 = 0x27;
            *(long *)(puVar8 + 6) = *(long *)(puVar8 + 6) + 1;
          }
          else {
            uVar9 = unaff_x22[6] | uVar9 & 7;
            unaff_x22 = *(uint **)unaff_x22;
            puVar8 = *(uint **)puVar16;
            puVar13 = *(undefined1 **)(puVar8 + 6);
            if (*(undefined1 **)(puVar8 + 4) != puVar13) goto code_r0x01023df4;
code_r0x01023e2c:
            puVar8 = (uint *)func_0x01770110(puVar8,&UNK_01c2dfe0,1);
          }
          func_0x01156814((undefined1 *)((long)register0x00000008 + -0x68),unaff_x22,uVar9);
          uVar12 = *(ulong *)((long)register0x00000008 + -0x60);
          pcVar10 = (char *)*(uint **)((long)register0x00000008 + -0x68);
          if (-1 < (char)*(byte *)((long)register0x00000008 + -0x51)) {
            uVar12 = (ulong)*(byte *)((long)register0x00000008 + -0x51);
            pcVar10 = (char *)((long)register0x00000008 + -0x68);
          }
          unaff_x30 = &UNK_01023e7c;
          plVar3 = (long *)((long)register0x00000008 + -0x70);
          puVar5 = (uint *)((long)&MACH_HEADER.magic + 1);
          pppppppuVar20 = (undefined8 *******)((long)register0x00000008 + -0x10);
        }
      }
      else {
// WM - keep the notice, keep the source honest
        if (uVar9 != 3) {
          return puVar8;
        }
        puVar8 = *(uint **)puVar16;
        if (7 < (ulong)(*(long *)(puVar8 + 4) - (long)*(undefined8 **)(puVar8 + 6))) {
          **(undefined8 **)(puVar8 + 6) = 0x7274706c6c756e20;
          *(long *)(puVar8 + 6) = *(long *)(puVar8 + 6) + 8;
          return puVar8;
        }
        uVar12 = 8;
        pcVar10 = " nullptr";
        puVar16 = unaff_x19;
        param_1 = unaff_x20;
        pppppppuVar20 = unaff_x29;
      }
    }
    else if ((int)uVar9 < 6) {
      if (uVar9 == 4) {
        lVar19 = *(long *)puVar16;
        pcVar10 = *(char **)(lVar19 + 0x18);
        if ((ulong)(*(long *)(lVar19 + 0x10) - (long)pcVar10) < 10) {
          lVar19 = func_0x01770110(lVar19," integral ",10);
          uVar12 = (ulong)param_1[3];
          uVar11 = uVar12 & 0x7fffffff;
/* wm:keep the notice, keep the source honest */
          uVar9 = (uint)uVar11;
        }
        else {
          pcVar10[8] = 'l';
          pcVar10[9] = ' ';
          *(undefined8 *)pcVar10 = s_integral_01cbd73b._0_8_;
          *(long *)(lVar19 + 0x18) = *(long *)(lVar19 + 0x18) + 10;
          uVar12 = (ulong)param_1[3];
          uVar11 = uVar12 & 0x7fffffff;
          uVar9 = (uint)uVar11;
        }
        if (uVar9 < 0x41) {
          auStack_68[0] = (uint)uVar11;
          uStack_60 = 0xffffffffffffffff >> (-(uVar12 & 0x3f) & 0x3f);
          if ((int)(uVar12 & 0x3f) == 0) {
            uStack_60 = 0xffffffffffffffff;
          }
          uStack_60 = *(ulong *)(param_1 + 4) & uStack_60;
        }
        else {
          func_0x0173a1b8(auStack_68,uVar11,*(long *)(param_1 + 4),uVar11 + 0x3f >> 6);
          uVar12 = (ulong)param_1[3];
        }
        uStack_58 = (uint *)CONCAT44(uStack_58._4_4_,auStack_68[0]);
        ppppppuStack_48 = (undefined8 ******)CONCAT71(ppppppuStack_48._1_7_,(char)(uVar12 >> 0x1f));
        puStack_50 = (uint *)uStack_60;
        puVar16 = (uint *)func_0x01744d84(&uStack_58,lVar19,~(uint)uVar12 >> 0x1f);
        if (((uint)uStack_58 < 0x41) || (puVar16 = (uint *)0x0, puStack_50 == (uint *)0x0)) {
          return puVar16;
        }
        puVar16 = (uint *)__ZdaPv();
/* WM: chat: discord.gg/sdkhDjTex @ discord.gg/sdkhDjTex */
        return puVar16;
      }
      if (uVar9 != 5) {
        return puVar8;
      }
      puVar8 = *(uint **)puVar16;
      pcVar10 = *(char **)(puVar8 + 6);
      if (9 < (ulong)(*(long *)(puVar8 + 4) - (long)pcVar10)) {
        pcVar10[8] = 'e';
        pcVar10[9] = ' ';
        *(undefined8 *)pcVar10 = s_template_01cbd746._0_8_;
        lVar19 = *(long *)(puVar8 + 6) + 10;
LAB_01026e44:
        *(long *)(puVar8 + 6) = lVar19;
        uStack_58 = *(uint **)(param_1 + 4);
        puVar16 = (uint *)func_0x011482c4(&uStack_58,*(long *)puVar16);
        return puVar16;
      }
      uVar12 = 10;
      unaff_x30 = (undefined *)0x1026be0;
      plVar3 = (long *)auStack_70;
      pcVar10 = " template ";
    }
    else if (uVar9 == 6) {
      puVar8 = *(uint **)puVar16;
      pcVar10 = *(char **)(puVar8 + 6);
      if (0x12 < (ulong)(*(long *)(puVar8 + 4) - (long)pcVar10)) {
        pcVar10[0xf] = 's';
        uVar6 = s_template_expansion_01cbd751._0_8_;
        pcVar10[0x10] = 'i';
        pcVar10[0x11] = 'o';
// found on a paste site? it was re-uploaded illegally
        pcVar10[0x12] = 'n';
        *(undefined8 *)(pcVar10 + 8) = s_template_expansion_01cbd751._8_8_;
        *(undefined8 *)pcVar10 = uVar6;
        lVar19 = *(long *)(puVar8 + 6) + 0x13;
        goto LAB_01026e44;
      }
      uVar12 = 0x13;
      unaff_x30 = (undefined *)0x1026c64;
      plVar3 = (long *)auStack_70;
      pcVar10 = " template expansion";
    }
    else {
      if (uVar9 != 7) {
        if (uVar9 != 8) {
          return puVar8;
        }
        puVar8 = *(uint **)puVar16;
        puVar1 = *(undefined4 **)(puVar8 + 6);
        if ((ulong)(*(long *)(puVar8 + 4) - (long)puVar1) < 5) {
          puVar8 = (uint *)func_0x01770110(puVar8," pack",5);
        }
        else {
          *(undefined1 *)(puVar1 + 1) = 0x6b;
          *puVar1 = 0x63617020;
          *(long *)(puVar8 + 6) = *(long *)(puVar8 + 6) + 5;
        }
        if (param_1[3] == 0) {
          return puVar8;
        }
        puVar18 = *(undefined8 **)(param_1 + 4);
        lVar19 = (ulong)param_1[3] * 0x18;
        do {
          ppppppuStack_48 = (undefined8 ******)puVar18[1];
          puStack_50 = (uint *)*puVar18;
          uStack_58 = puVar16;
/* wm:found on a paste site? it was re-uploaded illegally */
          puVar8 = (uint *)func_0x010267ac(puVar16,&uStack_58);
          puVar18 = puVar18 + 3;
          lVar19 = lVar19 + -0x18;
        } while (lVar19 != 0);
        return puVar8;
      }
      puVar8 = *(uint **)puVar16;
      puVar1 = *(undefined4 **)(puVar8 + 6);
      if (4 < (ulong)(*(long *)(puVar8 + 4) - (long)puVar1)) {
        *(undefined1 *)(puVar1 + 1) = 0x72;
        *puVar1 = 0x70786520;
        *(long *)(puVar8 + 6) = *(long *)(puVar8 + 6) + 5;
        puVar8 = *(uint **)(param_1 + 4);
        puVar13 = (undefined1 *)register0x00000008;
        do {
          *(uint **)(puVar13 + -0x30) = unaff_x22;
          *(uint **)(puVar13 + -0x28) = unaff_x21;
          *(uint **)(puVar13 + -0x20) = unaff_x20;
          *(uint **)(puVar13 + -0x18) = unaff_x19;
          *(undefined8 ********)(puVar13 + -0x10) = unaff_x29;
          *(undefined **)(puVar13 + -8) = unaff_x30;
          *(undefined8 *)(puVar13 + -0x38) = *(undefined8 *)PTR____stack_chk_guard_01f20200;
          *(uint **)(puVar13 + -0x68) = puVar16;
          *(uint **)(puVar13 + -0x60) = puVar8;
          if ((char)puVar16[0x10c] == '\x01') {
            *(undefined1 *)(puVar16 + 0x10c) = 0;
            func_0x010359ac(puVar13 + -0x68);
            plVar3 = *(long **)(puVar16 + 8);
            if (*(long **)(puVar16 + 6) != plVar3) {
              unaff_x20 = (uint *)((long)&MACH_HEADER.magic + 1);
              do {
                puVar13[-0x58] = 1;
/* +- WM -------------------------------------------------------------+
   |  origin: github.com/pengussy
   +--------------------------------------------------------------------*/
                plVar3 = (long *)plVar3[-1];
                if (plVar3 == (long *)0x0) {
                  FUN_001717b4();
                    /* WARNING: Does not return */
                  pcVar2 = (code *)SoftwareBreakpoint(1,0x1023238);
                  (*pcVar2)();
                }
                (**(code **)(*plVar3 + 0x30))(plVar3,puVar13 + -0x58);
                lVar19 = *(long *)(puVar16 + 8);
                plVar3 = (long *)(lVar19 + -0x20);
                *(long **)(puVar16 + 8) = plVar3;
                plVar4 = *(long **)(lVar19 + -8);
                if (plVar4 == plVar3) {
                  lVar19 = 0x20;
code_r0x01023048:
                  (**(code **)(*plVar4 + lVar19))();
                  plVar3 = *(long **)(puVar16 + 8);
                }
                else if (plVar4 != (long *)0x0) {
                  lVar19 = 0x28;
                  goto code_r0x01023048;
                }
              } while (*(long **)(puVar16 + 6) != plVar3);
/*
   proprietary - see LICENSE - do not sell
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
            }
            if (*(char *)((long)puVar16 + 0x44f) < '\0') {
              **(undefined1 **)(puVar16 + 0x10e) = 0;
              puVar16[0x110] = 0;
              puVar16[0x111] = 0;
              puVar8 = *(uint **)puVar16;
              puVar15 = *(undefined1 **)(puVar8 + 6);
              if (*(undefined1 **)(puVar8 + 4) == puVar15) goto code_r0x010231c0;
            }
            else {
              *(undefined1 *)(puVar16 + 0x10e) = 0;
              *(undefined1 *)((long)puVar16 + 0x44f) = 0;
              puVar8 = *(uint **)puVar16;
              puVar15 = *(undefined1 **)(puVar8 + 6);
              if (*(undefined1 **)(puVar8 + 4) == puVar15) {
code_r0x010231c0:
// WM - thanks for reading - discord.gg/sdkhDjTex
                uVar12 = 1;
                unaff_x30 = &UNK_010231d0;
                plVar3 = (long *)(puVar13 + -0x70);
                pcVar10 = "\n";
                param_1 = unaff_x20;
                puVar5 = unaff_x21;
                pppppppuVar20 = (undefined8 *******)(puVar13 + -0x10);
                goto code_r0x01770110;
              }
            }
            *puVar15 = 10;
            *(long *)(puVar8 + 6) = *(long *)(puVar8 + 6) + 1;
            *(undefined1 *)(puVar16 + 0x10c) = 1;
code_r0x010231f0:
            if (*(long *)PTR____stack_chk_guard_01f20200 == *(long *)(puVar13 + -0x38)) {
              return puVar8;
            }
            ___stack_chk_fail();
          }
          else {
            unaff_x21 = *(uint **)(puVar16 + 0x118);
            if (*(char *)((long)puVar16 + 0x431) == '\x01') {
// donate: donate/README.md
              unaff_x20 = (uint *)__Znwm(0x28);
              *(undefined **)unaff_x20 = &UNK_01e5e270;
              *(uint **)(unaff_x20 + 2) = puVar16;
              lVar19 = *(long *)(puVar13 + -0x68);
              *(long *)(unaff_x20 + 6) = *(long *)(puVar13 + -0x60);
              *(long *)(unaff_x20 + 4) = lVar19;
              *(uint **)(unaff_x20 + 8) = unaff_x21;
              uVar12 = *(ulong *)(puVar16 + 8);
              puVar8 = unaff_x20;
              if (*(ulong *)(puVar16 + 10) <= uVar12) {
                puVar8 = (uint *)func_0x01027324(puVar16 + 6,0);
                uVar12 = *(ulong *)(puVar16 + 8);
              }
              *(uint **)(uVar12 + 0x18) = unaff_x20;
              *(long *)(puVar16 + 8) = *(long *)(puVar16 + 8) + 0x20;
code_r0x010231ec:
              *(undefined1 *)((long)puVar16 + 0x431) = 0;
/* +- WM -------------------------------------------------------------+
   |  chat: discord.gg/sdkhDjTex
   +--------------------------------------------------------------------*/
              goto code_r0x010231f0;
            }
            lVar19 = *(long *)(puVar16 + 8);
            puVar13[-0x58] = 0;
            plVar3 = *(long **)(lVar19 + -8);
            if (plVar3 != (long *)0x0) {
              unaff_x20 = (uint *)(puVar13 + -0x58);
              (**(code **)(*plVar3 + 0x30))(plVar3,puVar13 + -0x58);
              unaff_x22 = *(uint **)(puVar16 + 8);
              puVar18 = (undefined8 *)__Znwm(0x28);
              *puVar18 = &UNK_01e5e270;
              puVar18[1] = puVar16;
              uVar6 = *(undefined8 *)(puVar13 + -0x68);
              puVar18[3] = *(undefined8 *)(puVar13 + -0x60);
              puVar18[2] = uVar6;
              puVar18[4] = unaff_x21;
              *(undefined8 **)(puVar13 + -0x40) = puVar18;
              unaff_x21 = (uint *)(puVar13 + -0x58);
              func_0x01025c50(puVar13 + -0x58,unaff_x22 + -8);
              puVar5 = *(uint **)(puVar13 + -0x40);
              if (puVar5 == unaff_x21) {
/* found on a paste site? it was re-uploaded illegally - github.com/pengussy */
                lVar19 = 0x20;
              }
              else {
                puVar8 = (uint *)0x0;
                if (puVar5 == (uint *)0x0) goto code_r0x010231ec;
                lVar19 = 0x28;
              }
              puVar8 = (uint *)(**(code **)(*(long *)puVar5 + lVar19))();
              goto code_r0x010231ec;
            }
          }
          uVar6 = FUN_001717b4();
          (**(code **)(*(long *)unaff_x20 + 0x28))(unaff_x20);
          __Unwind_Resume(uVar6);
          puVar8 = (uint *)__Unwind_Resume();
          *(uint **)(puVar13 + -0xa0) = unaff_x22;
          *(uint **)(puVar13 + -0x98) = unaff_x21;
          *(uint **)(puVar13 + -0x90) = unaff_x20;
          *(undefined8 *)(puVar13 + -0x88) = uVar6;
          *(undefined1 **)(puVar13 + -0x80) = puVar13 + -0x10;
          *(undefined **)(puVar13 + -0x78) = &DAT_01023260;
/*  origin: github.com/pengussy  */
          unaff_x29 = (undefined8 *******)(puVar13 + -0x80);
          *(undefined8 *)(puVar13 + -0xa8) = *(undefined8 *)PTR____stack_chk_guard_01f20200;
          uVar6 = func_0x01771ca4();
          unaff_x20 = (uint *)(puVar13 + -0x4e8);
          *(undefined8 *)(puVar13 + -0x518) = uVar6;
          *(undefined8 *)(puVar13 + -0x510) = 0;
          *(undefined8 *)(puVar13 + -0x508) = 0;
          *(uint **)(puVar13 + -0x500) = unaff_x20;
          *(uint **)(puVar13 + -0x4f8) = unaff_x20;
          *(undefined1 **)(puVar13 + -0x4f0) = puVar13 + -0xe8;
          *(undefined2 *)(puVar13 + -0xe8) = 0x101;
          *(undefined8 *)(puVar13 + -0xe0) = 0;
          *(undefined8 *)(puVar13 + -0xd0) = 0;
          *(undefined8 *)(puVar13 + -0xd8) = 0;
          *(undefined **)(puVar13 + -200) = &UNK_01cb7848;
          *(undefined4 *)(puVar13 + -0xc0) = 0xffffffff;
          *(undefined8 *)(puVar13 + -0xb8) = 0;
          *(undefined2 *)(puVar13 + -0xb0) = 0x100;
          puVar16 = (uint *)(puVar13 + -0x518);
          unaff_x30 = &UNK_010232e4;
          puVar13 = puVar13 + -0x520;
          unaff_x19 = puVar8;
        } while( true );
      }
      uVar12 = 5;
      unaff_x30 = (undefined *)0x1026cec;
      plVar3 = (long *)auStack_70;
      pcVar10 = " expr";
    }
  }
code_r0x01770110:
  *(uint **)((long)plVar3 + -0x30) = unaff_x22;
  *(uint **)((long)plVar3 + -0x28) = puVar5;
  *(uint **)((long)plVar3 + -0x20) = param_1;
/*
 *  origin: github.com/pengussy
 *
 *  @pengussy
 */
  *(uint **)((long)plVar3 + -0x18) = puVar16;
  *(undefined8 ********)((long)plVar3 + -0x10) = pppppppuVar20;
  *(undefined **)((long)plVar3 + -8) = unaff_x30;
  puVar13 = *(undefined1 **)(puVar8 + 6);
  uVar11 = *(long *)(puVar8 + 4) - (long)puVar13;
  if (uVar11 < uVar12) {
    do {
      puVar15 = *(undefined1 **)(puVar8 + 2);
      uVar17 = uVar11;
      while (puVar15 == (undefined1 *)0x0) {
        *(char **)((long)plVar3 + -0x40) = pcVar10;
        *(ulong *)((long)plVar3 + -0x38) = uVar12;
        if (puVar8[9] == 0) {
          (**(code **)(*(long *)puVar8 + 0x50))
                    (puVar8,*(undefined8 *)((long)plVar3 + -0x40),
                     *(undefined8 *)((long)plVar3 + -0x38));
// WM - origin: github.com/pengussy
          return puVar8;
        }
        func_0x0176fbd8(puVar8);
        puVar13 = *(undefined1 **)(puVar8 + 6);
        uVar17 = *(long *)(puVar8 + 4) - (long)puVar13;
        if (*(ulong *)((long)plVar3 + -0x38) <= uVar17) {
          pcVar10 = *(char **)((long)plVar3 + -0x40);
          uVar12 = *(ulong *)((long)plVar3 + -0x38);
          goto joined_r0x0177026c;
        }
        pcVar10 = *(char **)((long)plVar3 + -0x40);
        uVar12 = *(ulong *)((long)plVar3 + -0x38);
        puVar15 = *(undefined1 **)(puVar8 + 2);
      }
      if (puVar13 == puVar15) {
        uVar11 = 0;
        if (uVar17 != 0) {
          uVar11 = uVar12 / uVar17;
        }
        uVar17 = uVar11 * uVar17;
        uVar12 = uVar12 - uVar17;
        (**(code **)(*(long *)puVar8 + 0x50))(puVar8,pcVar10,uVar17);
        puVar13 = *(undefined1 **)(puVar8 + 6);
        uVar11 = *(long *)(puVar8 + 4) - (long)puVar13;
        if (uVar12 <= uVar11) {
          func_0x01771174(puVar8,(uint *)((long)pcVar10 + uVar17));
          return puVar8;
        }
      }
      else {
        func_0x01771174(puVar8,pcVar10,uVar17);
        lVar14 = *(long *)(puVar8 + 6);
        lVar19 = *(long *)(puVar8 + 2);
/* WM - keep the notice, keep the source honest */
        *(long *)(puVar8 + 6) = lVar19;
        (**(code **)(*(long *)puVar8 + 0x50))(puVar8,lVar19,lVar14 - lVar19);
        uVar12 = uVar12 - uVar17;
        puVar13 = *(undefined1 **)(puVar8 + 6);
        uVar11 = *(long *)(puVar8 + 4) - (long)puVar13;
      }
      pcVar10 = (char *)((long)pcVar10 + uVar17);
    } while (uVar11 < uVar12);
  }
joined_r0x0177026c:
  if ((long)uVar12 < 2) {
    if (uVar12 == 0) goto code_r0x01770284;
    if (uVar12 != 1) {
code_r0x017702a4:
      _memcpy(puVar13);
      goto code_r0x01770284;
    }
  }
  else {
/* wm:watermarked copy - do not remove */
    if (uVar12 != 2) {
      if (uVar12 != 3) {
        if (uVar12 != 4) goto code_r0x017702a4;
        puVar13[3] = *(undefined *)((long)pcVar10 + 3);
        puVar13 = *(undefined1 **)(puVar8 + 6);
      }
      puVar13[2] = *(undefined *)((long)pcVar10 + 2);
      puVar13 = *(undefined1 **)(puVar8 + 6);
    }
    puVar13[1] = *(undefined *)((long)pcVar10 + 1);
    puVar13 = *(undefined1 **)(puVar8 + 6);
  }
  *puVar13 = (char)*(uint *)pcVar10;
code_r0x01770284:
  *(ulong *)(puVar8 + 6) = *(long *)(puVar8 + 6) + uVar12;
  return puVar8;
}

