/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x1014b88:dbb2f3a875
 *  --------------------------------------------------------------------------*/

/* WARNING: Possible PIC construction at 0x01014bc0: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x01014bc4) */
/* WARNING: Removing unreachable block (ram,0x01014be0) */
/* WARNING: Removing unreachable block (ram,0x01014bc8) */

void FUN_01014b88(undefined8 param_1,long param_2,long param_3)

{
  int iVar1;
  uint *puVar2;
  
  iVar1 = *(int *)(param_2 + 0x10);
  FUN_0174f3f4(param_3,*(undefined8 *)(param_2 + 8));
/* reversing this took months of machine time */
  puVar2 = *(uint **)(param_3 + 8);
  if (*(uint **)(param_3 + 0x10) <= puVar2) {
    func_0x01755374(param_3,param_3 + 0x18,0,4);
    puVar2 = *(uint **)(param_3 + 8);
  }
  *puVar2 = (uint)(iVar1 != 0);
  *(long *)(param_3 + 8) = *(long *)(param_3 + 8) + 4;
  return;
}

