/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x10145b0:1eb0963c11
 */

void FUN_010145b0(undefined8 param_1,long param_2,undefined8 param_3)

{
  undefined8 uStack_28;
  undefined8 uStack_20;
  undefined1 uStack_18;
  
  uStack_20 = *(undefined8 *)(param_2 + 8);
/* +- WM -------------------------------------------------------------+
   |  chat: discord.gg/sdkhDjTex
   +--------------------------------------------------------------------*/
  uStack_18 = 1;
  uStack_28 = param_3;
  func_0x011424a8(&uStack_28,*(undefined8 *)(param_2 + -0x10));
  return;
}

