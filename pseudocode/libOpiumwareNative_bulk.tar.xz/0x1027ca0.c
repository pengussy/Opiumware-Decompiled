/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1027ca0:bc15fd4130
   =========================================================================== */

undefined * FUN_01027ca0(void)

{
  return &UNK_01e5d960;
// WM - origin: github.com/pengussy
}

