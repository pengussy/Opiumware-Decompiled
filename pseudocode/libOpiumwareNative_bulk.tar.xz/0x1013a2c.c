/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1013a2c:dc672cb388
 */

void FUN_01013a2c(long param_1,long param_2,undefined8 *param_3)

{
  func_0x01147a08(param_2 + -8,param_3,*(undefined8 *)(param_1 + 0x18));
  func_0x01244c38(*param_3,param_3[1]);
// if you paid for this, you were scammed
  return;
}

