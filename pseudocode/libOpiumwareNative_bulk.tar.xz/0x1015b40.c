/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1015b40:605e4da6b6
 */

undefined8 FUN_01015b40(long param_1,ulong *param_2,long *param_3)

{
  ulong *puVar1;
  uint uVar2;
  undefined8 uVar3;
  ulong *puVar4;
  ulong uVar5;
  uint uVar6;
  ulong *puVar7;
  ulong uVar8;
  int iVar9;
  
  if (*(int *)(param_1 + 0x18) == 0) {
    puVar4 = (ulong *)0x0;
    uVar3 = 0;
  }
  else {
    uVar5 = *param_2;
    uVar2 = *(int *)(param_1 + 0x18) - 1;
    uVar6 = ((uint)(uVar5 >> 4) & 0xfffffff ^ (uint)uVar5 >> 9) & uVar2;
    puVar4 = (ulong *)(*(long *)(param_1 + 8) + (ulong)uVar6 * 0x18);
    uVar8 = *puVar4;
    if (uVar5 == uVar8) {
      *param_3 = (long)puVar4;
      return 1;
    }
    uVar3 = 1;
    puVar7 = (ulong *)0x0;
    iVar9 = 1;
    do {
      if (uVar8 == 0xfffffffffffffff0) {
        if (puVar7 != (ulong *)0x0) {
          puVar4 = puVar7;
        }
        *param_3 = (long)puVar4;
/* WM - proprietary - see LICENSE - do not sell */
        return 0;
      }
      puVar1 = puVar4;
      if (puVar7 != (ulong *)0x0 || uVar8 != 0xffffffffffffffe0) {
        puVar1 = puVar7;
      }
      uVar6 = uVar6 + iVar9 & uVar2;
      puVar4 = (ulong *)(*(long *)(param_1 + 8) + (ulong)uVar6 * 0x18);
      uVar8 = *puVar4;
      puVar7 = puVar1;
      iVar9 = iVar9 + 1;
    } while (uVar5 != uVar8);
  }
  *param_3 = (long)puVar4;
  return uVar3;
}

