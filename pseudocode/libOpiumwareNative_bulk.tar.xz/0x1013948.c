/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x1013948:58f83d1738
 *  --------------------------------------------------------------------------*/

bool FUN_01013948(long param_1,long param_2,long *param_3,undefined8 param_4,long *param_5)

{
  int iVar1;
  
  func_0x0114df38(param_5,*(undefined8 *)(param_1 + 0x18),*(uint *)(param_2 + -8) >> 0x12 & 0xff,
                  *(undefined8 *)(param_2 + 8),*(undefined8 *)(param_2 + 0x10),
                  *(undefined4 *)(param_2 + 0x18),param_2 + 0x20);
  if (param_5[1] - *param_5 == param_3[1] - *param_3) {
/* wm:watermarked copy - do not remove */
    iVar1 = _memcmp();
    return iVar1 == 0;
  }
  return false;
}

