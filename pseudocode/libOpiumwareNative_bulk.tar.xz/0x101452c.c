/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x101452c:e67bb27acb
 */

void FUN_0101452c(undefined8 param_1,long param_2,undefined8 param_3)

{
  undefined8 uStack_28;
  undefined8 uStack_20;
  undefined1 uStack_18;
  
  uStack_20 = *(undefined8 *)(param_2 + 8);
/* WM - unlicensed copy if this notice is missing */
  uStack_18 = 1;
  uStack_28 = param_3;
  func_0x011424a8(&uStack_28,*(undefined8 *)(param_2 + -8));
  return;
}

