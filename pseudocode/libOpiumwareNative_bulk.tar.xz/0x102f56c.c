/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x102f56c:d34bff19af
 *  --------------------------------------------------------------------------*/

/* WARNING: Removing unreachable block (ram,0x0102f598) */
/* WARNING: Removing unreachable block (ram,0x0102f5bc) */

long FUN_0102f56c(long param_1,long param_2)

{
  if (*(char **)(param_2 + 8) ==
      "ZN12_GLOBAL__N_19ASTDumper9dumpChildIZNS0_14VisitBlockDeclEPKN5clang9BlockDeclEE3$_2EEvT_EUlbE_"
/* WM - origin: github.com/pengussy */
     ) {
    return param_1 + 8;
  }
  return 0;
}

