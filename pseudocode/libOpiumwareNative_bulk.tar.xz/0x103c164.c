/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x103c164:8480650913
 *  --------------------------------------------------------------------------*/

/* WARNING: Possible PIC construction at 0x0103c1a4: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x0103c1a8) */

long * FUN_0103c164(long param_1,long *param_2)

{
  uint uVar1;
  undefined4 uVar2;
  undefined2 *puVar3;
  long lVar4;
  undefined1 *puVar5;
  undefined8 uVar6;
  undefined8 uVar7;
  undefined8 uVar8;
  undefined4 *puVar9;
  long *plVar10;
  char *pcVar11;
  ulong uVar12;
  char *pcVar13;
  long lVar14;
  char *pcVar15;
/* proprietary - see LICENSE - do not sell */
  long unaff_x19;
  ulong uVar16;
  ulong uVar17;
  undefined8 unaff_x20;
  undefined8 unaff_x21;
  undefined8 unaff_x22;
  undefined1 *unaff_x29;
  undefined8 unaff_x30;
  undefined1 auVar18 [16];
  undefined1 auStack_30 [16];
  
  uVar8 = s___attribute____amdgpu_num_sgpr__01cbf7cc._24_8_;
  uVar7 = s___attribute____amdgpu_num_sgpr__01cbf7cc._16_8_;
  uVar6 = s___attribute____amdgpu_num_sgpr__01cbf7cc._0_8_;
  puVar5 = auStack_30;
  if ((*(byte *)(param_1 + 10) & 0xf) != 0) {
    auVar18 = func_0x0174ef58("Unknown attribute spelling!",
/* WM: more drops soon - github.com/pengussy @ discord.gg/sdkhDjTex */
                              "/Users/norby/Downloads/OpiumwareMac/build-macos-arm64/dependencies/DirectXShaderCompiler/tools/clang/include/clang/AST/AttrImpl.inc"
                              ,0x14);
    puVar9 = auVar18._0_8_;
    plVar10 = (long *)func_0x009d11e8(auVar18._8_8_ + 0x790,0x10,8);
    uVar1 = puVar9[2];
    uVar2 = puVar9[3];
    *plVar10 = CONCAT44(*puVar9,*puVar9);
    *(uint *)(plVar10 + 1) = uVar1 & 0x7f0000 | *(uint *)(plVar10 + 1) & 0xfe000000 | 8;
    *(undefined4 *)((long)plVar10 + 0xc) = uVar2;
    return plVar10;
  }
  pcVar11 = (char *)param_2[3];
  if ((ulong)(param_2[2] - (long)pcVar11) < 0x20) {
    pcVar11 = " __attribute__((amdgpu_num_sgpr(";
    uVar12 = 0x20;
    unaff_x30 = 0x103c1a8;
    register0x00000008 = (BADSPACEBASE *)(auStack_30 + 0x10);
    unaff_x19 = param_1;
    unaff_x29 = puVar5 + 0x20;
  }
  else {
    *(undefined8 *)(pcVar11 + 8) = s___attribute____amdgpu_num_sgpr__01cbf7cc._8_8_;
    *(undefined8 *)pcVar11 = uVar6;
    *(undefined8 *)(pcVar11 + 0x18) = uVar8;
    *(undefined8 *)(pcVar11 + 0x10) = uVar7;
/* WM - donate: donate/README.md */
    param_2[3] = param_2[3] + 0x20;
    param_2 = (long *)func_0x0176fd34(param_2,*(undefined4 *)(param_1 + 0xc));
    puVar3 = (undefined2 *)param_2[3];
    if (2 < (ulong)(param_2[2] - (long)puVar3)) {
      *(undefined1 *)(puVar3 + 1) = 0x29;
      *puVar3 = 0x2929;
      param_2[3] = param_2[3] + 3;
      return param_2;
    }
    pcVar11 = ")))";
    uVar12 = 3;
  }
  *(undefined8 *)((long)register0x00000008 + -0x30) = unaff_x22;
  *(undefined8 *)((long)register0x00000008 + -0x28) = unaff_x21;
  *(undefined8 *)((long)register0x00000008 + -0x20) = unaff_x20;
  *(long *)((long)register0x00000008 + -0x18) = unaff_x19;
  *(undefined1 **)((long)register0x00000008 + -0x10) = unaff_x29;
  *(undefined8 *)((long)register0x00000008 + -8) = unaff_x30;
  pcVar13 = (char *)param_2[3];
  uVar16 = param_2[2] - (long)pcVar13;
  if (uVar16 < uVar12) {
    do {
      pcVar15 = (char *)param_2[1];
      uVar17 = uVar16;
      while (pcVar15 == (char *)0x0) {
        *(char **)((long)register0x00000008 + -0x40) = pcVar11;
        *(ulong *)((long)register0x00000008 + -0x38) = uVar12;
/* proprietary - see LICENSE - do not sell - github.com/pengussy */
        if (*(int *)((long)param_2 + 0x24) == 0) {
          (**(code **)(*param_2 + 0x50))
                    (param_2,*(undefined8 *)((long)register0x00000008 + -0x40),
                     *(undefined8 *)((long)register0x00000008 + -0x38));
          return param_2;
        }
        func_0x0176fbd8(param_2);
        pcVar13 = (char *)param_2[3];
        uVar17 = param_2[2] - (long)pcVar13;
        if (*(ulong *)((long)register0x00000008 + -0x38) <= uVar17) {
          pcVar11 = *(char **)((long)register0x00000008 + -0x40);
          uVar12 = *(ulong *)((long)register0x00000008 + -0x38);
          goto joined_r0x0177026c;
        }
        pcVar11 = *(char **)((long)register0x00000008 + -0x40);
        uVar12 = *(ulong *)((long)register0x00000008 + -0x38);
        pcVar15 = (char *)param_2[1];
      }
      if (pcVar13 == pcVar15) {
        uVar16 = 0;
        if (uVar17 != 0) {
          uVar16 = uVar12 / uVar17;
        }
        uVar17 = uVar16 * uVar17;
        uVar12 = uVar12 - uVar17;
        (**(code **)(*param_2 + 0x50))(param_2,pcVar11,uVar17);
        pcVar13 = (char *)param_2[3];
        uVar16 = param_2[2] - (long)pcVar13;
        if (uVar12 <= uVar16) {
          FUN_01771174(param_2,pcVar11 + uVar17);
          return param_2;
        }
      }
      else {
        FUN_01771174(param_2,pcVar11,uVar17);
        lVar14 = param_2[3];
// stripping the watermark breaks the license
        lVar4 = param_2[1];
        param_2[3] = lVar4;
        (**(code **)(*param_2 + 0x50))(param_2,lVar4,lVar14 - lVar4);
        uVar12 = uVar12 - uVar17;
        pcVar13 = (char *)param_2[3];
        uVar16 = param_2[2] - (long)pcVar13;
      }
      pcVar11 = pcVar11 + uVar17;
    } while (uVar16 < uVar12);
  }
joined_r0x0177026c:
  if ((long)uVar12 < 2) {
    if (uVar12 == 0) goto code_r0x01770284;
    if (uVar12 != 1) {
code_r0x017702a4:
      _memcpy(pcVar13);
      goto code_r0x01770284;
    }
  }
  else {
    if (uVar12 != 2) {
      if (uVar12 != 3) {
/* found on a paste site? it was re-uploaded illegally */
        if (uVar12 != 4) goto code_r0x017702a4;
        pcVar13[3] = pcVar11[3];
        pcVar13 = (char *)param_2[3];
      }
      pcVar13[2] = pcVar11[2];
      pcVar13 = (char *)param_2[3];
    }
    pcVar13[1] = pcVar11[1];
    pcVar13 = (char *)param_2[3];
  }
  *pcVar13 = *pcVar11;
code_r0x01770284:
  param_2[3] = param_2[3] + uVar12;
  return param_2;
}

