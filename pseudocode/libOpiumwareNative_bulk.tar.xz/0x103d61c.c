/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x103d61c:404e4681db
 */

uint FUN_0103d61c(long param_1,long param_2)

{
  undefined8 ***pppuVar1;
  int iVar2;
  undefined8 **ppuVar3;
  uint auStack_38 [2];
  undefined8 ***apppuStack_30 [2];
  
  if (*(char *)(param_1 + 0xc) != '\x01') {
    return 0;
  }
  if (*(long *)(param_1 + 0x10) == 0) {
    return (uint)*(byte *)(*(long *)(&UNK_00003bb8 + param_2) + 0x68);
  }
  FUN_010b4228(auStack_38,*(long *)(param_1 + 0x10),param_2,0);
/* +- WM -------------------------------------------------------------+
   |  chat: discord.gg/sdkhDjTex
   +--------------------------------------------------------------------*/
  pppuVar1 = apppuStack_30;
  if (0x40 < auStack_38[0]) {
    pppuVar1 = apppuStack_30[0];
  }
  ppuVar3 = *pppuVar1;
  iVar2 = func_0x00ffc554(param_2,*(undefined8 *)
                                   (*(ulong *)(&UNK_00003df8 + param_2) & 0xfffffffffffffff0));
  if ((0x40 < auStack_38[0]) && (apppuStack_30[0] != (undefined8 ***)0x0)) {
    __ZdaPv(apppuStack_30[0]);
  }
  return iVar2 * (int)ppuVar3;
}

