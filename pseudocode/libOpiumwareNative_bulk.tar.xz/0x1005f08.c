/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1005f08:cb64515cc4
 */

long FUN_01005f08(undefined8 param_1,long param_2)

{
  byte bVar1;
  long *plVar2;
  long lVar3;
  
  lVar3 = 1;
  do {
    plVar2 = (long *)(param_2 + 0x30);
    if (0x40 < *(uint *)(param_2 + 0x28)) {
      plVar2 = (long *)*plVar2;
    }
    lVar3 = *plVar2 * lVar3;
    param_2 = *(long *)(*(ulong *)(param_2 + 0x20) & 0xfffffffffffffff0);
    bVar1 = *(byte *)(param_2 + 0x10);
    if (param_2 == 0 || bVar1 - 0xb < 0xfffffffc) {
/*  watermarked copy - do not remove  */
      if (3 < *(byte *)(*(long *)(*(ulong *)(param_2 + 8) & 0xfffffffffffffff0) + 0x10) - 7) {
        return lVar3;
      }
      param_2 = func_0x01148f40();
      bVar1 = *(byte *)(param_2 + 0x10);
      if (3 < bVar1 - 7) {
        func_0x0174f200("cast");
        bVar1 = *(byte *)(param_2 + 0x10);
      }
    }
  } while (bVar1 == 7);
  return lVar3;
}

