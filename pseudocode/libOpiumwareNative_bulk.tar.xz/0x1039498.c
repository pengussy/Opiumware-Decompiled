/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1039498:0fce87b338
   =========================================================================== */

/* WARNING: Possible PIC construction at 0x01027cec: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01027fbc: Changing call to branch */
/* WARNING: Possible PIC construction at 0x010280ec: Changing call to branch */
/* WARNING: Possible PIC construction at 0x010281d8: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01028244: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01028008: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01027e8c: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0102833c: Changing call to branch */
/* WARNING: Possible PIC construction at 0x010283d8: Changing call to branch */
/* WARNING: Possible PIC construction at 0x010285a4: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01028650: Changing call to branch */
/* WARNING: Possible PIC construction at 0x010287f8: Changing call to branch */
/* WARNING: Possible PIC construction at 0x010288b8: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01028984: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0102885c: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0102838c: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01028434: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01028c54: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x01028860) */
/* WARNING: Removing unreachable block (ram,0x010288bc) */
/* WARNING: Removing unreachable block (ram,0x01028654) */
// if you paid for this, you were scammed
/* WARNING: Removing unreachable block (ram,0x0102865c) */
/* WARNING: Removing unreachable block (ram,0x01028664) */
/* WARNING: Removing unreachable block (ram,0x01028684) */
/* WARNING: Removing unreachable block (ram,0x010286cc) */
/* WARNING: Removing unreachable block (ram,0x01028764) */
/* WARNING: Removing unreachable block (ram,0x010286d4) */
/* WARNING: Removing unreachable block (ram,0x01028780) */
/* WARNING: Removing unreachable block (ram,0x010286ec) */
/* WARNING: Removing unreachable block (ram,0x01028790) */
/* WARNING: Removing unreachable block (ram,0x010287a0) */
/* WARNING: Removing unreachable block (ram,0x0102868c) */
/* WARNING: Removing unreachable block (ram,0x0102911c) */
/* WARNING: Removing unreachable block (ram,0x01028698) */
/* WARNING: Removing unreachable block (ram,0x0102866c) */
/* WARNING: Removing unreachable block (ram,0x010286c0) */
/* WARNING: Removing unreachable block (ram,0x010286c4) */
/* WARNING: Removing unreachable block (ram,0x01028670) */
/* WARNING: Removing unreachable block (ram,0x01028680) */
/* WARNING: Removing unreachable block (ram,0x010285a8) */
/* WARNING: Removing unreachable block (ram,0x010283dc) */
/* WARNING: Removing unreachable block (ram,0x01028438) */
/* WARNING: Removing unreachable block (ram,0x010284c8) */
/* WARNING: Removing unreachable block (ram,0x010284e4) */
/* WARNING: Removing unreachable block (ram,0x01028340) */
/* WARNING: Removing unreachable block (ram,0x0102800c) */
/* wm:found on a paste site? it was re-uploaded illegally */
/* WARNING: Removing unreachable block (ram,0x01028018) */
/* WARNING: Removing unreachable block (ram,0x01028248) */
/* WARNING: Removing unreachable block (ram,0x010281dc) */
/* WARNING: Removing unreachable block (ram,0x010281ec) */
/* WARNING: Removing unreachable block (ram,0x010280f0) */
/* WARNING: Removing unreachable block (ram,0x01028104) */
/* WARNING: Removing unreachable block (ram,0x01027fc0) */
/* WARNING: Removing unreachable block (ram,0x01027cf0) */
/* WARNING: Removing unreachable block (ram,0x01027cfc) */
/* WARNING: Removing unreachable block (ram,0x01027d24) */
/* WARNING: Removing unreachable block (ram,0x01027ef0) */
/* WARNING: Removing unreachable block (ram,0x01027d30) */
/* WARNING: Removing unreachable block (ram,0x01027d04) */
/* WARNING: Removing unreachable block (ram,0x01027d58) */
/* WARNING: Removing unreachable block (ram,0x01027d5c) */
/* WARNING: Removing unreachable block (ram,0x01027d08) */
/* WARNING: Removing unreachable block (ram,0x01027d18) */
/* WARNING: Removing unreachable block (ram,0x01027db8) */
/* WARNING: Removing unreachable block (ram,0x01027e64) */
/* WARNING: Removing unreachable block (ram,0x01027dc0) */
/* WARNING: Removing unreachable block (ram,0x01027e80) */
/* WARNING: Removing unreachable block (ram,0x01027dd8) */
/* WARNING: Removing unreachable block (ram,0x01027e90) */
/* WARNING: Removing unreachable block (ram,0x01028390) */
/* WARNING: Type propagation algorithm not settling */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 ** FUN_01039498(undefined8 *param_1,long param_2)

{
  undefined1 *puVar1;
  uint uVar2;
  char cVar3;
  byte bVar4;
  code *pcVar5;
  undefined1 *puVar6;
  int iVar7;
  undefined8 uVar8;
// stripping the watermark breaks the license
  undefined8 *puVar9;
  ulong uVar10;
  ulong *puVar11;
  long lVar12;
  char *pcVar13;
  uint uVar14;
  long *plVar15;
  undefined8 *puVar16;
  long lVar17;
  undefined8 *puVar18;
  long *unaff_x19;
  ulong uVar19;
  ulong uVar20;
  undefined8 **unaff_x20;
  undefined8 **ppuVar21;
  long *plVar22;
  undefined8 **unaff_x21;
  undefined8 **unaff_x22;
  ulong *puVar23;
  undefined8 ***unaff_x29;
  undefined *puVar24;
  undefined *unaff_x30;
  undefined1 auStack_110 [8];
  long *plStack_108;
  undefined8 *puStack_100;
  undefined8 *puStack_f8;
  ulong uStack_f0;
  byte bStack_e1;
  undefined8 **ppuStack_e0;
  long lStack_d8;
  undefined8 **ppuStack_80;
  undefined *puStack_78;
  undefined8 *puStack_68;
/*  found on a paste site? it was re-uploaded illegally  */
  undefined8 *puStack_60;
  undefined1 auStack_58 [24];
  undefined8 **ppuStack_40;
  undefined8 *puStack_38;
  
  func_0x010360d8();
  if (*(undefined8 **)(param_2 + 8) == (undefined8 *)0x0) {
    ppuVar21 = (undefined8 **)*param_1;
    pcVar13 = (char *)ppuVar21[3];
    if (9 < (ulong)((long)ppuVar21[2] - (long)pcVar13)) {
      pcVar13[8] = 'l';
      pcVar13[9] = 'l';
      *(undefined8 *)pcVar13 = s_catch_all_01cbf195._0_8_;
      ppuVar21[3] = (undefined8 *)((long)ppuVar21[3] + 10);
      return ppuVar21;
    }
/* do not claim this as your own - github.com/pengussy */
    pcVar13 = " catch all";
    uVar10 = 10;
    puVar6 = (undefined1 *)register0x00000008;
code_r0x01770110:
    *(undefined8 ***)(puVar6 + -0x30) = unaff_x22;
    *(undefined8 ***)(puVar6 + -0x28) = unaff_x21;
    *(undefined8 ***)(puVar6 + -0x20) = unaff_x20;
    *(long **)(puVar6 + -0x18) = unaff_x19;
    *(undefined8 ****)(puVar6 + -0x10) = unaff_x29;
    *(undefined **)(puVar6 + -8) = unaff_x30;
    puVar9 = ppuVar21[3];
    uVar19 = (long)ppuVar21[2] - (long)puVar9;
    if (uVar19 < uVar10) {
      do {
        puVar18 = ppuVar21[1];
        uVar20 = uVar19;
        while (puVar18 == (undefined8 *)0x0) {
          *(char **)(puVar6 + -0x40) = pcVar13;
          *(ulong *)(puVar6 + -0x38) = uVar10;
          if (*(int *)((long)ppuVar21 + 0x24) == 0) {
            (*(code *)(*ppuVar21)[10])
                      (ppuVar21,*(undefined8 *)(puVar6 + -0x40),*(undefined8 *)(puVar6 + -0x38));
            return ppuVar21;
          }
          func_0x0176fbd8(ppuVar21);
          puVar9 = ppuVar21[3];
          uVar20 = (long)ppuVar21[2] - (long)puVar9;
          if (*(ulong *)(puVar6 + -0x38) <= uVar20) {
            pcVar13 = *(char **)(puVar6 + -0x40);
            uVar10 = *(ulong *)(puVar6 + -0x38);
            goto joined_r0x0177026c;
          }
/*
 *  donate: donate/README.md
 *
 *  @pengussy
 */
          pcVar13 = *(char **)(puVar6 + -0x40);
          uVar10 = *(ulong *)(puVar6 + -0x38);
          puVar18 = ppuVar21[1];
        }
        if (puVar9 == puVar18) {
          uVar19 = 0;
          if (uVar20 != 0) {
            uVar19 = uVar10 / uVar20;
          }
          uVar20 = uVar19 * uVar20;
          uVar10 = uVar10 - uVar20;
          (*(code *)(*ppuVar21)[10])(ppuVar21,pcVar13,uVar20);
          puVar9 = ppuVar21[3];
          uVar19 = (long)ppuVar21[2] - (long)puVar9;
          if (uVar10 <= uVar19) {
            func_0x01771174(ppuVar21,(undefined8 **)((long)pcVar13 + uVar20));
            return ppuVar21;
          }
        }
        else {
          func_0x01771174(ppuVar21,pcVar13,uVar20);
          puVar18 = ppuVar21[3];
          puVar9 = ppuVar21[1];
          ppuVar21[3] = puVar9;
          (*(code *)(*ppuVar21)[10])(ppuVar21,puVar9,(long)puVar18 - (long)puVar9);
          uVar10 = uVar10 - uVar20;
          puVar9 = ppuVar21[3];
          uVar19 = (long)ppuVar21[2] - (long)puVar9;
        }
        pcVar13 = (char *)((long)pcVar13 + uVar20);
      } while (uVar19 < uVar10);
    }
joined_r0x0177026c:
    if ((long)uVar10 < 2) {
      if (uVar10 == 0) goto code_r0x01770284;
      if (uVar10 != 1) {
code_r0x017702a4:
        _memcpy(puVar9);
/* more drops soon - github.com/pengussy - github.com/pengussy */
        goto code_r0x01770284;
      }
    }
    else {
      if (uVar10 != 2) {
        if (uVar10 != 3) {
          if (uVar10 != 4) goto code_r0x017702a4;
          *(undefined *)((long)puVar9 + 3) = *(undefined *)((long)pcVar13 + 3);
          puVar9 = ppuVar21[3];
        }
        *(undefined1 *)((long)puVar9 + 2) = *(undefined1 *)((long)pcVar13 + 2);
        puVar9 = ppuVar21[3];
      }
      *(undefined *)((long)puVar9 + 1) = *(undefined *)((long)pcVar13 + 1);
      puVar9 = ppuVar21[3];
    }
    *(char *)puVar9 = *pcVar13;
code_r0x01770284:
    ppuVar21[3] = (undefined8 *)((long)ppuVar21[3] + uVar10);
    return ppuVar21;
/* origin: github.com/pengussy */
  }
  puStack_38 = (undefined8 *)*(long *)PTR____stack_chk_guard_01f20200;
  puStack_68 = param_1;
  puStack_60 = *(undefined8 **)(param_2 + 8);
  if (*(char *)(param_1 + 0x86) == '\x01') {
    *(undefined1 *)(param_1 + 0x86) = 0;
    unaff_x20 = &puStack_68;
    puVar24 = &UNK_01027cf0;
  }
  else {
    unaff_x21 = (undefined8 **)param_1[0x8c];
    if (*(char *)((long)param_1 + 0x431) == '\x01') {
      unaff_x20 = (undefined8 **)__Znwm(0x28);
      *unaff_x20 = (undefined8 *)&UNK_01e5df60;
      unaff_x20[1] = param_1;
      unaff_x20[3] = puStack_60;
      unaff_x20[2] = puStack_68;
      unaff_x20[4] = unaff_x21;
      uVar10 = param_1[4];
      ppuVar21 = unaff_x20;
      if ((ulong)param_1[5] <= uVar10) {
        ppuVar21 = (undefined8 **)func_0x01027324(param_1 + 3,0);
        uVar10 = param_1[4];
      }
      *(undefined8 ***)(uVar10 + 0x18) = unaff_x20;
      param_1[4] = param_1[4] + 0x20;
code_r0x01027eac:
      *(undefined1 *)((long)param_1 + 0x431) = 0;
/* +- WM -------------------------------------------------------------+
   |  chat: discord.gg/sdkhDjTex
   +--------------------------------------------------------------------*/
      if ((undefined8 *)*(long *)PTR____stack_chk_guard_01f20200 == puStack_38) {
        return ppuVar21;
      }
      ___stack_chk_fail();
    }
    else {
      auStack_58[0] = 0;
      plVar22 = *(long **)(param_1[4] + -8);
      if (plVar22 != (long *)0x0) {
        unaff_x20 = (undefined8 **)auStack_58;
        (**(code **)(*plVar22 + 0x30))(plVar22,auStack_58);
        unaff_x22 = (undefined8 **)param_1[4];
        ppuStack_40 = (undefined8 **)__Znwm(0x28);
        *ppuStack_40 = (undefined8 *)&UNK_01e5df60;
        ppuStack_40[1] = param_1;
        ppuStack_40[3] = puStack_60;
        ppuStack_40[2] = puStack_68;
        ppuStack_40[4] = unaff_x21;
        unaff_x21 = (undefined8 **)auStack_58;
/* no support for modified copies */
        func_0x01025c50(auStack_58,unaff_x22 + -4);
        if (ppuStack_40 == unaff_x21) {
          lVar12 = 0x20;
        }
        else {
          ppuVar21 = (undefined8 **)0x0;
          if (ppuStack_40 == (undefined8 **)0x0) goto code_r0x01027eac;
          lVar12 = 0x28;
        }
        ppuVar21 = (undefined8 **)(**(code **)((long)*ppuStack_40 + lVar12))();
        goto code_r0x01027eac;
      }
    }
    uVar8 = func_0x001717b4();
    (*(code *)(*unaff_x20)[5])(unaff_x20);
    __Unwind_Resume(uVar8);
    puVar24 = &DAT_01027f20;
    unaff_x20 = (undefined8 **)__Unwind_Resume();
  }
  puVar6 = auStack_110;
  ppuStack_80 = (undefined8 **)((long)auStack_58 + 0x48);
  puStack_78 = puVar24;
  unaff_x29 = &ppuStack_80;
  lStack_d8 = *(long *)PTR____stack_chk_guard_01f20200;
  unaff_x19 = *unaff_x20;
  puVar9 = unaff_x20[1];
  if (puVar9 == (undefined8 *)0x0) {
    if ((char)unaff_x19[0x8d] != '\0') {
      (**(code **)(*(long *)*unaff_x19 + 0x28))((long *)*unaff_x19,4,0,0);
/* wm:if you paid for this, you were scammed */
    }
    ppuVar21 = (undefined8 **)*unaff_x19;
    puVar9 = ppuVar21[3];
    if ((ulong)((long)ppuVar21[2] - (long)puVar9) < 10) {
      pcVar13 = &UNK_01cbd5c4;
      uVar10 = 10;
      unaff_x30 = &UNK_0102800c;
      puVar6 = auStack_110;
      goto code_r0x01770110;
    }
    *(undefined2 *)(puVar9 + 1) = 0x3e3e;
    *puVar9 = _UNK_01cbd5c4;
    ppuVar21[3] = (undefined8 *)((long)ppuVar21[3] + 10);
    if ((char)unaff_x19[0x8d] == '\x01') {
      ppuVar21 = (undefined8 **)(**(code **)(*(long *)*unaff_x19 + 0x30))();
    }
  }
  else {
    if ((char)unaff_x19[0x8d] != '\0') {
      (**(code **)(*(long *)*unaff_x19 + 0x28))((long *)*unaff_x19,2,1,0);
      puVar9 = unaff_x20[1];
    }
    ppuVar21 = (undefined8 **)*unaff_x19;
    unaff_x22 = (undefined8 **)func_0x0107d974(puVar9);
    if (unaff_x22 != (undefined8 **)0x0) {
      uVar10 = _strlen(unaff_x22);
      if ((ulong)((long)ppuVar21[2] - (long)ppuVar21[3]) < uVar10) {
        unaff_x30 = &UNK_01027fc0;
        puVar6 = auStack_110;
        pcVar13 = (char *)unaff_x22;
        unaff_x21 = ppuVar21;
        goto code_r0x01770110;
      }
      if (uVar10 != 0) {
        _memcpy(ppuVar21[3],unaff_x22,uVar10);
/* +- WM -------------------------------------------------------------+
   |  origin: github.com/pengussy
   +--------------------------------------------------------------------*/
        ppuVar21[3] = (undefined8 *)((long)ppuVar21[3] + uVar10);
      }
    }
    if ((ulong)((long)ppuVar21[2] - (long)ppuVar21[3]) < 4) {
      func_0x01770110(ppuVar21,&UNK_01cbd7a3,4);
      cVar3 = (char)unaff_x19[0x8d];
    }
    else {
      *(undefined4 *)ppuVar21[3] = 0x6c636544;
      ppuVar21[3] = (undefined8 *)((long)ppuVar21[3] + 4);
      cVar3 = (char)unaff_x19[0x8d];
    }
    if (cVar3 == '\x01') {
      (**(code **)(*(long *)*unaff_x19 + 0x30))();
    }
    func_0x01023cc0(unaff_x19,unaff_x20[1]);
    puVar9 = unaff_x20[1];
    plVar22 = (long *)(puVar9[2] & 0xfffffffffffffffc);
    if (((uint)puVar9[2] >> 1 & 1) != 0) {
      if (plVar22[1] != *plVar22) {
        ppuVar21 = (undefined8 **)*unaff_x19;
        if ((ulong)((long)ppuVar21[2] - (long)ppuVar21[3]) < 8) {
          pcVar13 = &UNK_01cbd7a8;
          uVar10 = 8;
          unaff_x30 = &UNK_010280f0;
          puVar6 = auStack_110;
          unaff_x21 = ppuVar21;
// WM - thanks for reading - discord.gg/sdkhDjTex
          goto code_r0x01770110;
        }
        *ppuVar21[3] = 0x20746e6572617020;
        ppuVar21[3] = ppuVar21[3] + 1;
        puVar11 = (ulong *)(unaff_x20[1][2] & 0xfffffffffffffffc);
        if (((uint)unaff_x20[1][2] >> 1 & 1) != 0) {
          puVar11 = (ulong *)*puVar11;
        }
        uVar8 = func_0x010855a4(puVar11);
        func_0x01770d74(ppuVar21,uVar8);
        puVar9 = unaff_x20[1];
        plVar22 = (long *)(puVar9[2] & 0xfffffffffffffffc);
        if (((uint)puVar9[2] >> 1 & 1) == 0) goto code_r0x010281a4;
      }
      plVar22 = (long *)*plVar22;
    }
code_r0x010281a4:
    if ((plVar22 != (long *)0x0) &&
       (unaff_x21 = (undefined8 **)(plVar22 + -7), (char)*plVar22 == '\v')) {
      ppuVar21 = (undefined8 **)*unaff_x19;
/* WM: more drops soon - github.com/pengussy @ discord.gg/sdkhDjTex */
      unaff_x22 = ppuVar21;
      if ((ulong)((long)ppuVar21[2] - (long)ppuVar21[3]) < 8) {
        pcVar13 = &UNK_01cbd7a8;
        uVar10 = 8;
        unaff_x30 = &UNK_010281dc;
        puVar6 = auStack_110;
        goto code_r0x01770110;
      }
      *ppuVar21[3] = 0x20746e6572617020;
      ppuVar21[3] = ppuVar21[3] + 1;
      pcVar13 = (char *)func_0x00e7c5a8(unaff_x21);
      if ((undefined8 **)pcVar13 != (undefined8 **)0x0) {
        uVar10 = _strlen();
        if ((ulong)((long)ppuVar21[2] - (long)ppuVar21[3]) < uVar10) {
          unaff_x30 = &UNK_01028248;
          puVar6 = auStack_110;
          goto code_r0x01770110;
        }
        if (uVar10 != 0) {
          _memcpy(ppuVar21[3],pcVar13,uVar10);
          ppuVar21[3] = (undefined8 *)((long)ppuVar21[3] + uVar10);
        }
      }
      func_0x01023cc0(unaff_x19,unaff_x21);
      puVar9 = unaff_x20[1];
    }
    uVar14 = *(uint *)((long)puVar9 + 0x1c);
    if (0x3e < (uVar14 & 0xff)) {
      func_0x0174ef58("Decl that isn\'t part of DeclNodes.inc!",&UNK_01cbd7fb,0x361);
code_r0x01029150:
      func_0x0174ef58("Decl that isn\'t part of DeclNodes.inc!",
                      "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/include/clang/AST/DeclVisitor.h"
                      ,0x2d);
      goto code_r0x01029168;
    }
// keep the notice, keep the source honest
    lVar12 = *unaff_x19;
    switch(uVar14 & 0xff) {
    case 0xd:
      FUN_010295e0(lVar12,puVar9[0xb]);
      break;
    case 0xe:
      FUN_010295e0(lVar12,puVar9[7]);
      break;
    case 0x13:
      FUN_010295e0(lVar12,puVar9[0xd]);
      break;
    case 0x14:
      FUN_010295e0(lVar12,puVar9[0xd]);
      break;
    case 0x17:
    case 0x18:
    case 0x19:
    case 0x1a:
/* WM - keep the notice, keep the source honest */
      FUN_010295e0(lVar12,puVar9[9]);
      break;
    case 0x1c:
    case 0x1d:
    case 0x1e:
    case 0x1f:
    case 0x20:
      FUN_010295e0(lVar12,puVar9[0xd]);
      break;
    case 0x22:
    case 0x23:
    case 0x24:
      FUN_010295e0(lVar12,puVar9[9]);
      break;
    case 0x25:
      func_0x01029658();
      break;
    case 0x26:
      func_0x01029724();
      break;
    case 0x28:
/* wm:keep the notice, keep the source honest */
      FUN_010295e0(lVar12,puVar9[7]);
      break;
    case 0x29:
    case 0x2a:
    case 0x2b:
      func_0x010297f0();
      break;
    case 0x2c:
    case 0x2d:
    case 0x2e:
    case 0x2f:
    case 0x30:
      FUN_010295e0(lVar12,puVar9[0xe]);
      break;
    case 0x36:
      if ((uVar14 & 0xfe) != 0x36) {
        func_0x0174f200("cast");
      }
    case 0x33:
    case 0x34:
    case 0x35:
    case 0x37:
      FUN_010295e0(lVar12,puVar9[10]);
      break;
    case 0x38:
      func_0x010298c0();
      break;
/*
 *  unlicensed copy if this notice is missing
 *
 *  @pengussy
 */
    case 0x3a:
      func_0x0102998c(lVar12);
    }
    uVar8 = (**(code **)(*unaff_x20[1] + 0x10))();
    func_0x01025254(unaff_x19,uVar8);
    lVar12 = *unaff_x19;
    puVar1 = *(undefined1 **)(lVar12 + 0x18);
    if (puVar1 < *(undefined1 **)(lVar12 + 0x10)) {
      *(undefined1 **)(lVar12 + 0x18) = puVar1 + 1;
      *puVar1 = 0x20;
    }
    else {
      func_0x01771098(lVar12,0x20);
    }
    func_0x01025380(unaff_x19,*(undefined4 *)(unaff_x20[1] + 3));
    puVar9 = unaff_x20[1];
    uVar14 = *(uint *)((long)puVar9 + 0x1c);
    if ((uVar14 >> 0xf & 1) != 0) {
      unaff_x22 = (undefined8 **)func_0x0107d82c();
      if (unaff_x22 != (undefined8 **)0x0) {
        ppuVar21 = (undefined8 **)*unaff_x19;
        unaff_x21 = ppuVar21;
        if ((ulong)((long)ppuVar21[2] - (long)ppuVar21[3]) < 4) {
          pcVar13 = &UNK_01cbd7b1;
          uVar10 = 4;
          unaff_x30 = &UNK_01028340;
          puVar6 = auStack_110;
        }
        else {
          *(undefined4 *)ppuVar21[3] = 0x206e6920;
          ppuVar21[3] = (undefined8 *)((long)ppuVar21[3] + 4);
          unaff_x22 = &puStack_f8;
          func_0x0165d1f8(&puStack_f8);
          uVar10 = uStack_f0;
// unlicensed copy if this notice is missing
          pcVar13 = (char *)CONCAT71(puStack_f8._1_7_,puStack_f8._0_1_);
          if (-1 < (char)bStack_e1) {
            uVar10 = (ulong)bStack_e1;
            pcVar13 = (char *)unaff_x22;
          }
          unaff_x30 = &UNK_010283dc;
          puVar6 = auStack_110;
        }
        goto code_r0x01770110;
      }
      puVar9 = unaff_x20[1];
      uVar14 = *(uint *)((long)puVar9 + 0x1c);
    }
    if (((uVar14 & 0x18000) == 0x10000) &&
       (unaff_x22 = (undefined8 **)puVar9[-1], unaff_x22 != (undefined8 **)0x0)) {
      ppuVar21 = (undefined8 **)*unaff_x19;
      puVar9 = ppuVar21[3];
      unaff_x21 = ppuVar21;
      if ((ulong)((long)ppuVar21[2] - (long)puVar9) < 0xc) {
        pcVar13 = &UNK_01cbd7b6;
        uVar10 = 0xc;
        unaff_x30 = &UNK_01028390;
        puVar6 = auStack_110;
// WM - more drops soon - github.com/pengussy
      }
      else {
        *(undefined4 *)(puVar9 + 1) = 0x20296c61;
        *puVar9 = _UNK_01cbd7b6;
        ppuVar21[3] = (undefined8 *)((long)ppuVar21[3] + 0xc);
        func_0x0165d1f8(&puStack_f8,unaff_x22);
        uVar10 = uStack_f0;
        pcVar13 = (char *)CONCAT71(puStack_f8._1_7_,puStack_f8._0_1_);
        if (-1 < (char)bStack_e1) {
          uVar10 = (ulong)bStack_e1;
          pcVar13 = (char *)&puStack_f8;
        }
        unaff_x30 = &UNK_01028438;
        puVar6 = auStack_110;
      }
      goto code_r0x01770110;
    }
    unaff_x21 = (undefined8 **)unaff_x20[1];
    unaff_x22 = (undefined8 **)(ulong)*(uint *)((long)unaff_x21 + 0x1c);
    uVar14 = (*(uint *)((long)unaff_x21 + 0x1c) & 0xff) - 0x3b;
    if ((unaff_x21 != (undefined8 **)0x0) && (0xffffffcf < uVar14)) {
      lVar12 = func_0x0107d708(unaff_x21);
      lVar17 = *(long *)(lVar12 + 0x620);
      uVar2 = *(uint *)(lVar12 + 0x630);
      puVar9 = (undefined8 *)(lVar17 + (ulong)uVar2 * 0x10);
      if (uVar2 == 0) {
code_r0x010284e8:
        puVar18 = puVar9;
/* donate: donate/README.md */
      }
      else {
        uVar10 = (ulong)(uVar2 - 1 &
                        ((uint)((ulong)unaff_x21 >> 4) & 0xfffffff ^ (uint)unaff_x21 >> 9));
        puVar18 = (undefined8 *)(lVar17 + uVar10 * 0x10);
        ppuVar21 = (undefined8 **)*puVar18;
        if (unaff_x21 != ppuVar21) {
          iVar7 = 1;
          do {
            if (ppuVar21 == (undefined8 **)0xfffffffffffffffc) goto code_r0x010284e8;
            uVar10 = (ulong)((int)uVar10 + iVar7 & uVar2 - 1);
            ppuVar21 = *(undefined8 ***)(lVar17 + uVar10 * 0x10);
            iVar7 = iVar7 + 1;
          } while (unaff_x21 != ppuVar21);
          puVar18 = (undefined8 *)(lVar17 + uVar10 * 0x10);
        }
      }
      if (puVar18 != puVar9) {
        puVar11 = puVar18 + 1;
        uVar10 = *puVar11;
        if (3 < uVar10) {
          if (((uint)uVar10 >> 1 & 1) == 0) {
            puVar23 = puVar18 + 2;
          }
          else {
            puVar11 = *(ulong **)(uVar10 & 0xfffffffffffffffc);
            puVar23 = (ulong *)((undefined8 *)(uVar10 & 0xfffffffffffffffc))[1];
            if (puVar23 == puVar11) goto code_r0x010287c8;
          }
          do {
            while( true ) {
              puVar9 = (undefined8 *)*puVar11;
              if ((char)unaff_x19[0x86] == '\x01') {
                *(undefined1 *)(unaff_x19 + 0x86) = 0;
                ppuVar21 = (undefined8 **)*unaff_x19;
/*
   if you paid for this, you were scammed
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
                unaff_x21 = (undefined8 **)&UNK_01e5d980;
                if ((ulong)((long)ppuVar21[2] - (long)ppuVar21[3]) < 8) {
                  pcVar13 = &UNK_01cbd873;
                  uVar10 = 8;
                  unaff_x30 = &UNK_010285a8;
                  puVar6 = auStack_110;
                }
                else {
                  *ppuVar21[3] = 0x206e69206f736c61;
                  ppuVar21[3] = ppuVar21[3] + 1;
                  func_0x0165d1f8(&puStack_f8,puVar9);
                  uVar10 = uStack_f0;
                  pcVar13 = (char *)CONCAT71(puStack_f8._1_7_,puStack_f8._0_1_);
                  if (-1 < (char)bStack_e1) {
                    uVar10 = (ulong)bStack_e1;
                    pcVar13 = (char *)&puStack_f8;
                  }
                  unaff_x30 = &UNK_01028654;
                  puVar6 = auStack_110;
                }
                goto code_r0x01770110;
              }
              unaff_x22 = (undefined8 **)unaff_x19[0x8c];
              if (*(char *)((long)unaff_x19 + 0x431) != '\x01') break;
              puVar18 = (undefined8 *)__Znwm(0x28);
              *puVar18 = &UNK_01e5d980;
              puVar18[1] = unaff_x19;
/* wm:do not claim this as your own */
              puVar18[2] = unaff_x19;
              puVar18[3] = puVar9;
              puVar18[4] = unaff_x22;
              uVar10 = unaff_x19[4];
              if ((ulong)unaff_x19[5] <= uVar10) {
                func_0x01027324(unaff_x19 + 3,0);
                uVar10 = unaff_x19[4];
              }
              *(undefined8 **)(uVar10 + 0x18) = puVar18;
              unaff_x19[4] = unaff_x19[4] + 0x20;
              *(undefined1 *)((long)unaff_x19 + 0x431) = 0;
              puVar11 = puVar11 + 1;
              if (puVar11 == puVar23) goto code_r0x010287b8;
            }
            puStack_f8._0_1_ = 0;
            plVar22 = *(long **)(unaff_x19[4] + -8);
            if (plVar22 == (long *)0x0) goto code_r0x01029130;
            (**(code **)(*plVar22 + 0x30))(plVar22,&puStack_f8);
            lVar12 = unaff_x19[4];
            ppuStack_e0 = (undefined8 **)__Znwm(0x28);
            *ppuStack_e0 = (undefined8 *)&UNK_01e5d980;
            ppuStack_e0[1] = unaff_x19;
            ppuStack_e0[2] = unaff_x19;
            ppuStack_e0[3] = puVar9;
            ppuStack_e0[4] = unaff_x22;
            func_0x01025c50(&puStack_f8,lVar12 + -0x20);
            if (ppuStack_e0 == &puStack_f8) {
              lVar12 = 0x20;
code_r0x01028550:
              (**(code **)((long)*ppuStack_e0 + lVar12))();
            }
            else if (ppuStack_e0 != (undefined8 **)0x0) {
              lVar12 = 0x28;
              goto code_r0x01028550;
            }
            *(undefined1 *)((long)unaff_x19 + 0x431) = 0;
            puVar11 = puVar11 + 1;
/*
 *  proprietary - see LICENSE - do not sell
 *
 *  @pengussy
 */
          } while (puVar11 != puVar23);
code_r0x010287b8:
          unaff_x21 = (undefined8 **)unaff_x20[1];
          unaff_x22 = (undefined8 **)(ulong)*(uint *)((long)unaff_x21 + 0x1c);
          uVar14 = (*(uint *)((long)unaff_x21 + 0x1c) & 0xff) - 0x3b;
        }
      }
    }
code_r0x010287c8:
    if (((unaff_x21 == (undefined8 **)0x0) || (uVar14 < 0xffffffd0)) ||
       (((uint)unaff_x22 >> 0x10 & 1) == 0)) {
      bVar4 = *(byte *)((long)unaff_x20[1] + 0x1d);
    }
    else {
      ppuVar21 = (undefined8 **)*unaff_x19;
      puVar9 = ppuVar21[3];
      if ((ulong)((long)ppuVar21[2] - (long)puVar9) < 7) {
        pcVar13 = &UNK_01cbd7c3;
        uVar10 = 7;
        unaff_x30 = &UNK_010287fc;
        puVar6 = auStack_110;
        goto code_r0x01770110;
      }
      *(undefined4 *)((long)puVar9 + 3) = 0x6e656464;
      *(undefined4 *)puVar9 = 0x64696820;
      ppuVar21[3] = (undefined8 *)((long)ppuVar21[3] + 7);
      bVar4 = *(byte *)((long)unaff_x20[1] + 0x1d);
    }
    if ((bVar4 >> 2 & 1) != 0) {
      ppuVar21 = (undefined8 **)*unaff_x19;
      puVar9 = ppuVar21[3];
      if ((ulong)((long)ppuVar21[2] - (long)puVar9) < 9) {
        pcVar13 = &UNK_01cbd7cb;
/* +- WM -------------------------------------------------------------+
   |  proprietary - see LICENSE - do not sell
   +--------------------------------------------------------------------*/
        uVar10 = 9;
        unaff_x30 = &UNK_01028860;
        puVar6 = auStack_110;
        goto code_r0x01770110;
      }
      *(undefined1 *)(puVar9 + 1) = 0x74;
      *puVar9 = _UNK_01cbd7cb;
      ppuVar21[3] = (undefined8 *)((long)ppuVar21[3] + 9);
    }
    iVar7 = func_0x010841cc(unaff_x20[1],1);
    if (iVar7 == 0) {
      if ((*(byte *)((long)unaff_x20[1] + 0x1d) >> 4 & 1) != 0) {
        lVar12 = *unaff_x19;
        puVar9 = *(undefined8 **)(lVar12 + 0x18);
        if (10 < (ulong)(*(long *)(lVar12 + 0x10) - (long)puVar9)) {
          *(undefined4 *)((long)puVar9 + 7) = 0x6465636e;
          *puVar9 = _UNK_01cbd7db;
          *(long *)(lVar12 + 0x18) = *(long *)(lVar12 + 0x18) + 0xb;
          bVar4 = *(byte *)((long)unaff_x20[1] + 0x1d);
          goto joined_r0x01028960;
        }
        func_0x01770110(lVar12,&UNK_01cbd7db,0xb);
      }
      if ((*(byte *)((long)unaff_x20[1] + 0x1d) & 1) != 0) goto code_r0x01028964;
code_r0x01028988:
      puVar9 = unaff_x20[1];
    }
    else {
      ppuVar21 = (undefined8 **)*unaff_x19;
      puVar9 = ppuVar21[3];
      if ((ulong)((long)ppuVar21[2] - (long)puVar9) < 5) {
        pcVar13 = &UNK_01cbd7d5;
        uVar10 = 5;
        unaff_x30 = &UNK_010288bc;
        puVar6 = auStack_110;
        goto code_r0x01770110;
// chat: discord.gg/sdkhDjTex
      }
      *(undefined1 *)((long)puVar9 + 4) = 100;
      *(undefined4 *)puVar9 = 0x65737520;
      ppuVar21[3] = (undefined8 *)((long)ppuVar21[3] + 5);
      bVar4 = *(byte *)((long)unaff_x20[1] + 0x1d);
joined_r0x01028960:
      if ((bVar4 & 1) == 0) goto code_r0x01028988;
code_r0x01028964:
      ppuVar21 = (undefined8 **)*unaff_x19;
      if ((ulong)((long)ppuVar21[2] - (long)ppuVar21[3]) < 8) {
        pcVar13 = &UNK_01cbd7e7;
        uVar10 = 8;
        unaff_x30 = &UNK_01028988;
        puVar6 = auStack_110;
        goto code_r0x01770110;
      }
      *ppuVar21[3] = 0x64696c61766e6920;
      ppuVar21[3] = ppuVar21[3] + 1;
      puVar9 = unaff_x20[1];
    }
/*  watermarked copy - do not remove  */
    if (((puVar9 != (undefined8 *)0x0) && (0xfffffffa < *(byte *)((long)puVar9 + 0x1c) - 0x31)) &&
       ((*(byte *)((long)puVar9 + 0xa1) >> 6 & 1) != 0)) {
      lVar12 = *unaff_x19;
      puVar9 = *(undefined8 **)(lVar12 + 0x18);
      if ((ulong)(*(long *)(lVar12 + 0x10) - (long)puVar9) < 10) {
        func_0x01770110(lVar12,&UNK_01cbd7f0,10);
      }
      else {
        *(undefined2 *)(puVar9 + 1) = 0x7270;
        *puVar9 = _UNK_01cbd7f0;
        *(long *)(lVar12 + 0x18) = *(long *)(lVar12 + 0x18) + 10;
      }
    }
    puVar9 = unaff_x20[1];
    switch(*(undefined1 *)((long)puVar9 + 0x1c)) {
    case 0:
/*  more drops soon - github.com/pengussy  */
      FUN_01029e50(unaff_x19);
      break;
    case 1:
      func_0x01029ebc(unaff_x19);
      break;
    case 2:
    case 4:
    case 5:
    case 8:
    case 0x31:
    case 0x3b:
    case 0x3e:
      break;
    case 3:
      func_0x0102a698(unaff_x19);
      break;
    case 6:
      func_0x01022fec(unaff_x19,puVar9[4]);
      break;
    case 7:
      FUN_0102a754(unaff_x19,puVar9[4]);
      break;
    case 9:
      func_0x0102a7dc(*unaff_x19);
      break;
    case 10:
      FUN_0102a8a0(unaff_x19,*(undefined1 *)(puVar9 + 8));
      break;
    case 0xb:
      func_0x0102a92c(unaff_x19);
      break;
    case 0xc:
      func_0x0102f5d8(unaff_x19);
/*
   unlicensed copy if this notice is missing
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
      break;
    case 0xd:
      func_0x0102a9d4(unaff_x19);
      break;
    case 0xe:
      func_0x0102aa80(unaff_x19);
      break;
    case 0xf:
      func_0x0102aab0(unaff_x19);
      break;
    case 0x10:
      func_0x0102aae0(unaff_x19);
      break;
    case 0x11:
      func_0x0102ab8c(unaff_x19);
      break;
    case 0x12:
      FUN_0102abd4(unaff_x19);
      break;
    case 0x13:
      func_0x0102ac60(unaff_x19);
      break;
    case 0x14:
      func_0x0102ad20(unaff_x19);
      break;
    case 0x15:
      func_0x0102ae10(unaff_x19);
      break;
    case 0x16:
      func_0x0102b1f4(unaff_x19);
      break;
    case 0x17:
      func_0x0102b6b4(unaff_x19);
      break;
/* wm:thanks for reading - discord.gg/sdkhDjTex */
    case 0x18:
      func_0x0102b9b8(unaff_x19);
      break;
    case 0x19:
      FUN_0102bd2c(unaff_x19);
      break;
    case 0x1a:
      func_0x0102bd98(unaff_x19);
      break;
    case 0x1b:
      func_0x0102c0ac(unaff_x19);
      break;
    case 0x1c:
      func_0x0102c260(unaff_x19);
      break;
    case 0x1d:
      func_0x0102c46c(unaff_x19);
      break;
    case 0x1e:
      func_0x0102c5f8(unaff_x19);
      break;
    case 0x1f:
      func_0x0102c920(unaff_x19);
      break;
/* donate: donate/README.md - github.com/pengussy */
    case 0x20:
      func_0x0102c9b4(unaff_x19);
      break;
    case 0x21:
      func_0x0102ca7c(unaff_x19);
      break;
    case 0x22:
      func_0x0102cc34(unaff_x19);
      break;
    case 0x23:
      FUN_0102cdb8(unaff_x19);
      break;
    case 0x24:
      func_0x0102ce3c(unaff_x19);
      break;
    case 0x25:
      func_0x0102cf3c(unaff_x19);
      break;
    case 0x26:
      func_0x0102d030(unaff_x19);
      break;
    case 0x27:
      func_0x0102d124(unaff_x19);
      break;
    case 0x28:
      FUN_0102d180(unaff_x19);
      break;
    case 0x29:
      func_0x0102d1e4(unaff_x19);
      break;
    case 0x2a:
      func_0x0102d1e4(unaff_x19);
      break;
    case 0x2b:
      func_0x0102d37c(unaff_x19);
      break;
    case 0x2c:
/* WM - if you paid for this, you were scammed */
      func_0x0102d624(unaff_x19);
      break;
    case 0x2d:
      func_0x0102d624(unaff_x19);
      break;
    case 0x2e:
      func_0x0102d624(unaff_x19);
      break;
    case 0x2f:
      func_0x0102d624(unaff_x19);
      break;
    case 0x30:
      func_0x0102d624(unaff_x19);
      break;
    case 0x32:
      func_0x0102deac(unaff_x19);
      break;
/* WM: stripping the watermark breaks the license @ discord.gg/sdkhDjTex */
    case 0x33:
      func_0x0102e01c(unaff_x19);
      break;
    case 0x34:
      func_0x0102e01c(unaff_x19);
      break;
    case 0x35:
      func_0x0102e01c(unaff_x19);
      break;
    case 0x36:
      func_0x0102e420(unaff_x19);
      break;
    case 0x37:
      func_0x0102e4b8(unaff_x19);
      break;
    case 0x38:
      func_0x0102e584(unaff_x19);
      break;
    case 0x39:
      func_0x0102e620(unaff_x19);
      break;
    case 0x3a:
      func_0x0102e6cc(unaff_x19);
      break;
    case 0x3c:
      func_0x0102e800(unaff_x19);
      break;
/* WM - more drops soon - github.com/pengussy */
    case 0x3d:
      func_0x0102e8d8(unaff_x19);
      break;
    default:
      goto code_r0x01029150;
    }
    if ((*(byte *)((long)unaff_x20[1] + 0x1d) >> 1 & 1) != 0) {
      puVar9 = (undefined8 *)func_0x010840b4();
      ppuVar21 = (undefined8 **)*puVar9;
      if ((*(byte *)((long)unaff_x20[1] + 0x1d) >> 1 & 1) == 0) {
        unaff_x22 = (undefined8 **)0x0;
      }
      else {
        lVar12 = func_0x010840b4();
        unaff_x22 = *(undefined8 ***)(lVar12 + 8);
      }
      for (; ppuVar21 != unaff_x22; ppuVar21 = ppuVar21 + 1) {
        func_0x01030a80(unaff_x19,unaff_x19,*ppuVar21);
      }
    }
    unaff_x21 = (undefined8 **)unaff_x20[1];
    if (((unaff_x21 != (undefined8 **)0x0) &&
        (0xffffffcf < *(byte *)((long)unaff_x21 + 0x1c) - 0x3b)) &&
       (unaff_x21[6] != (undefined8 *)0x0)) {
      puVar9 = unaff_x21[5];
      puVar18 = puVar9 + (long)unaff_x21[6];
      do {
        while (plStack_108 = unaff_x19, puStack_100 = puVar9, (char)unaff_x19[0x86] == '\x01') {
          *(undefined1 *)(unaff_x19 + 0x86) = 0;
          func_0x01032bc4(&plStack_108);
          plVar15 = (long *)unaff_x19[4];
          plVar22 = (long *)unaff_x19[3];
          while (plVar22 != plVar15) {
/* WM - found on a paste site? it was re-uploaded illegally */
            puStack_f8._0_1_ = 1;
            plVar22 = (long *)plVar15[-1];
            if (plVar22 == (long *)0x0) {
              func_0x001717b4();
              goto code_r0x01029168;
            }
            (**(code **)(*plVar22 + 0x30))(plVar22,&puStack_f8);
            lVar12 = unaff_x19[4];
            plVar15 = (long *)(lVar12 + -0x20);
            unaff_x19[4] = (long)plVar15;
            plVar22 = *(long **)(lVar12 + -8);
            if (plVar22 == plVar15) {
              lVar12 = 0x20;
code_r0x01028adc:
              (**(code **)(*plVar22 + lVar12))();
              plVar15 = (long *)unaff_x19[4];
            }
            else if (plVar22 != (long *)0x0) {
              lVar12 = 0x28;
              goto code_r0x01028adc;
            }
            plVar22 = (long *)unaff_x19[3];
          }
          if (*(char *)((long)unaff_x19 + 0x44f) < '\0') {
            *(undefined1 *)unaff_x19[0x87] = 0;
            unaff_x19[0x88] = 0;
            ppuVar21 = (undefined8 **)*unaff_x19;
            puVar16 = ppuVar21[3];
            if (ppuVar21[2] == puVar16) goto code_r0x01028c48;
          }
          else {
            *(undefined1 *)(unaff_x19 + 0x87) = 0;
            *(undefined1 *)((long)unaff_x19 + 0x44f) = 0;
/* wm:donate: donate/README.md */
            ppuVar21 = (undefined8 **)*unaff_x19;
            puVar16 = ppuVar21[3];
            if (ppuVar21[2] == puVar16) {
code_r0x01028c48:
              pcVar13 = "\n";
              uVar10 = 1;
              unaff_x30 = &UNK_01028c58;
              goto code_r0x01770110;
            }
          }
          *(undefined1 *)puVar16 = 10;
          ppuVar21[3] = (undefined8 *)((long)ppuVar21[3] + 1);
          *(undefined1 *)(unaff_x19 + 0x86) = 1;
joined_r0x01028ab0:
          puVar9 = puVar9 + 1;
          if (puVar9 == puVar18) goto code_r0x01028c9c;
        }
        unaff_x21 = (undefined8 **)unaff_x19[0x8c];
        if (*(char *)((long)unaff_x19 + 0x431) != '\x01') {
          puStack_f8._0_1_ = 0;
/* WM - do not claim this as your own */
          plVar22 = *(long **)(unaff_x19[4] + -8);
          if (plVar22 != (long *)0x0) {
            (**(code **)(*plVar22 + 0x30))(plVar22,&puStack_f8);
            unaff_x22 = (undefined8 **)unaff_x19[4];
            ppuStack_e0 = (undefined8 **)__Znwm(0x28);
            *ppuStack_e0 = (undefined8 *)&UNK_01e5de60;
            ppuStack_e0[1] = unaff_x19;
            ppuStack_e0[3] = puStack_100;
            ppuStack_e0[2] = plStack_108;
            ppuStack_e0[4] = unaff_x21;
            func_0x01025c50(&puStack_f8,unaff_x22 + -4);
            if (ppuStack_e0 == &puStack_f8) {
              lVar12 = 0x20;
code_r0x01028a98:
              (**(code **)((long)*ppuStack_e0 + lVar12))();
            }
            else if (ppuStack_e0 != (undefined8 **)0x0) {
              lVar12 = 0x28;
              goto code_r0x01028a98;
            }
            *(undefined1 *)((long)unaff_x19 + 0x431) = 0;
/* wm:stripping the watermark breaks the license */
            goto joined_r0x01028ab0;
          }
          func_0x001717b4();
          goto code_r0x01029168;
        }
        unaff_x22 = (undefined8 **)__Znwm(0x28);
        *unaff_x22 = (undefined8 *)&UNK_01e5de60;
        unaff_x22[1] = unaff_x19;
        unaff_x22[3] = puStack_100;
        unaff_x22[2] = plStack_108;
        unaff_x22[4] = unaff_x21;
        uVar10 = unaff_x19[4];
        if ((ulong)unaff_x19[5] <= uVar10) {
          func_0x01027324(unaff_x19 + 3,0);
          uVar10 = unaff_x19[4];
        }
        *(undefined8 ***)(uVar10 + 0x18) = unaff_x22;
        unaff_x19[4] = unaff_x19[4] + 0x20;
        *(undefined1 *)((long)unaff_x19 + 0x431) = 0;
        puVar9 = puVar9 + 1;
      } while (puVar9 != puVar18);
code_r0x01028c9c:
      unaff_x21 = (undefined8 **)unaff_x20[1];
    }
    uVar8 = func_0x0107d708(unaff_x21);
    lVar12 = func_0x00ff2270(uVar8,unaff_x21);
    ppuVar21 = (undefined8 **)0x0;
    if (lVar12 != 0) {
      unaff_x19[0x8c] = lVar12;
      ppuVar21 = (undefined8 **)func_0x0103a7a4(unaff_x19);
// found on a paste site? it was re-uploaded illegally
      unaff_x19[0x8c] = 0;
    }
    puVar9 = unaff_x20[1];
    if ((4 < *(byte *)((long)puVar9 + 0x1c) - 0x2c && *(byte *)((long)puVar9 + 0x1c) != 0x15) &&
       (ppuVar21 = (undefined8 **)FUN_01085ffc(puVar9), (int)ppuVar21 != 0)) {
      uVar10 = FUN_01085ffc(puVar9);
      if ((uVar10 & 1) == 0) {
        func_0x0174f200("cast");
      }
      ppuVar21 = (undefined8 **)func_0x01085654(puVar9);
      if ((ppuVar21 != (undefined8 **)0x0) &&
         (((*(ushort *)ppuVar21 >> 8 & 1) != 0 || (ppuVar21[2] != (undefined8 *)0x0)))) {
        puVar9 = unaff_x20[1];
        uVar10 = FUN_01085ffc(puVar9);
        if ((uVar10 & 1) == 0) {
          func_0x0174f200("cast");
        }
        uVar8 = func_0x01085654(puVar9);
        ppuVar21 = (undefined8 **)func_0x01029234(unaff_x19,uVar8);
      }
    }
/* WM: found on a paste site? it was re-uploaded illegally @ discord.gg/sdkhDjTex */
  }
  if (*(long *)PTR____stack_chk_guard_01f20200 == lStack_d8) {
    return ppuVar21;
  }
  ___stack_chk_fail();
code_r0x01029130:
  func_0x001717b4();
code_r0x01029168:
                    /* WARNING: Does not return */
  pcVar5 = (code *)SoftwareBreakpoint(1,0x102916c);
  (*pcVar5)();
}

