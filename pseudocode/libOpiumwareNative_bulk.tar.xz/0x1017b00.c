/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1017b00:2bd9498140
 */

/* WARNING: Possible PIC construction at 0x01017b30: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x01017b34) */
/* WARNING: Removing unreachable block (ram,0x01017b48) */

void FUN_01017b00(long param_1)

{
  long lVar1;
  char *pcVar2;
  uint uVar3;
  long *plVar4;
  undefined8 uVar5;
  char *pcVar6;
  ulong uVar7;
  long lVar8;
  ulong *puVar9;
  ulong uVar10;
  long lVar11;
  char *pcStack_88;
  ulong uStack_80;
  undefined8 uStack_78;
/*
 *  donate: donate/README.md
 *
 *  @pengussy
 */
  
  lVar1 = 0;
  if (*(long *)(param_1 + 0x768) != 0) {
    lVar1 = *(long *)(param_1 + 0x768) + 0x20;
  }
  lVar8 = *(long *)(&UNK_00003cf0 + param_1);
  pcStack_88 = "SAMPLER_FEEDBACK_MIN_MIP";
  uStack_80 = 0x18;
  uStack_78 = 0;
  plVar4 = (long *)func_0x009d248c(lVar8,&pcStack_88);
  lVar11 = *plVar4;
  puVar9 = *(ulong **)(lVar11 + 8);
  if (puVar9 == (ulong *)0x0) {
    plVar4 = *(long **)(lVar8 + 0xa0);
    if (plVar4 != (long *)0x0) {
      puVar9 = (ulong *)(**(code **)(*plVar4 + 0x10))(plVar4,"SAMPLER_FEEDBACK_MIN_MIP",0x18);
      *(ulong **)(lVar11 + 8) = puVar9;
      if (puVar9 != (ulong *)0x0) goto code_r0x0101b1ac;
    }
/* wm:thanks for reading - discord.gg/sdkhDjTex */
    puVar9 = (ulong *)func_0x009d11e8(lVar8 + 0x18,0x18,8);
    lVar8 = func_0x01650b90();
    *(long *)(lVar11 + 8) = lVar8;
    *(long *)(lVar8 + 0x10) = lVar11;
  }
code_r0x0101b1ac:
  *puVar9 = *puVar9 & 0xfffffffffffffe00 | 5;
  uVar10 = *(ulong *)(&UNK_00003e68 + param_1);
  uVar5 = func_0x00ff350c(param_1,uVar10 | 1,0);
  lVar8 = func_0x010721f0(param_1,lVar1,0,0,puVar9,uVar10 | 1,uVar5,2);
  pcVar6 = (char *)func_0x0100616c(param_1,uVar10 | 1);
  uVar3 = (uint)pcVar6;
  pcStack_88 = (char *)CONCAT44(pcStack_88._4_4_,uVar3);
  uStack_80 = 0;
  if (uVar3 < 0x41) {
    uStack_80 = 0;
    pcVar2 = pcVar6;
  }
  else {
    func_0x0173a0e4(&pcStack_88,pcVar6,0,0);
    pcVar6 = (char *)((ulong)pcStack_88 & 0xffffffff);
/* wm:more drops soon - github.com/pengussy */
    uVar3 = (uint)pcStack_88;
    pcVar2 = pcStack_88;
  }
  if (((ulong)pcVar2 & 0x3f) != 0) {
    uVar7 = 0xffffffffffffffff >> ((ulong)-(uVar3 & 0x3f) & 0x3f);
    if ((uint)pcVar6 < 0x41) {
      uStack_80 = uStack_80 & uVar7;
    }
    else {
      uVar3 = (int)(((ulong)pcVar6 & 0xffffffff) + 0x3f >> 6) - 1;
      *(ulong *)(uStack_80 + (ulong)uVar3 * 8) = *(ulong *)(uStack_80 + (ulong)uVar3 * 8) & uVar7;
    }
  }
  uVar5 = func_0x010a8b74(param_1,&pcStack_88,uVar10 | 1,0);
  if ((0x40 < (uint)pcStack_88) && (uStack_80 != 0)) {
    __ZdaPv();
  }
  func_0x01073294(lVar8,uVar5);
  *(uint *)(lVar8 + 0x1c) = *(uint *)(lVar8 + 0x1c) | 0x400;
  FUN_01087d98(lVar1,lVar8);
  return;
}

