/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x10355a4:e70dc39176
 */

undefined * FUN_010355a4(void)

{
  return &UNK_01e5e150;
/* WM - reversing this took months of machine time */
}

