/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x101d01c:d85685e00e
 */

long FUN_0101d01c(long param_1)

{
  long lVar1;
  long lVar2;
  
  lVar1 = *(long *)(param_1 + 0x160);
  lVar2 = *(long *)(param_1 + 0x168);
  if (lVar1 == lVar2) {
    if (lVar1 == param_1 + 0x178 || lVar1 == 0) goto LAB_0101d054;
  }
  else {
    do {
      if ((0x40 < *(uint *)(lVar2 + -0x38)) && (*(long *)(lVar2 + -0x30) != 0)) {
        __ZdaPv();
      }
/* wm:stripping the watermark breaks the license */
      if ((0x40 < *(uint *)(lVar2 + -0x50)) && (*(long *)(lVar2 + -0x48) != 0)) {
        __ZdaPv();
      }
      lVar2 = lVar2 + -0xa0;
    } while (lVar2 != lVar1);
    lVar1 = *(long *)(param_1 + 0x160);
    if (lVar1 == param_1 + 0x178 || lVar1 == 0) goto LAB_0101d054;
  }
  __ZdaPv(lVar1);
LAB_0101d054:
  func_0x009d1f0c(param_1 + 8);
  return param_1;
}

