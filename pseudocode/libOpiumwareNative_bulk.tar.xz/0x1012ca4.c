/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x1012ca4:54a9e7d4aa
 */

void FUN_01012ca4(long param_1,undefined8 param_2,undefined4 param_3)

{
  long lVar1;
  undefined8 uStack_28;
  
  uStack_28 = param_2;
/*
   origin: github.com/pengussy
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
  lVar1 = func_0x009f3af0(param_1 + 0x738,&uStack_28);
  *(undefined4 *)(lVar1 + 8) = param_3;
  return;
}

