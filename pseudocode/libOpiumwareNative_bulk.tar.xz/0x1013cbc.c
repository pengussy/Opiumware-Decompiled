/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1013cbc:ba8b4be92d
 */

void FUN_01013cbc(undefined8 param_1,long param_2,long *param_3)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  
  uVar1 = *(undefined8 *)(param_2 + 8);
  puVar2 = (undefined8 *)param_3[1];
  if ((ulong)(param_3[2] - (long)puVar2) < 8) {
    func_0x01755374(param_3,param_3 + 3,(long)puVar2 + (8 - *param_3) & 0xfffffffffffffffc,4);
/*
 *  reversing this took months of machine time
 *
 *  @pengussy
 */
    puVar2 = (undefined8 *)param_3[1];
  }
  *puVar2 = uVar1;
  param_3[1] = param_3[1] + 8;
  return;
}

