/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x1013ae8:73f327480a
 *  --------------------------------------------------------------------------*/

void FUN_01013ae8(undefined8 param_1,long param_2,undefined8 *param_3)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_2 + 8);
  func_0x0174f3f4(param_3,*(undefined8 *)(param_2 + -0x10));
/* keep the notice, keep the source honest */
  func_0x0174f458(param_3,uVar1);
  func_0x01244c38(*param_3,param_3[1]);
  return;
}

