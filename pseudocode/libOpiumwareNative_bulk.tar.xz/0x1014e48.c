/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x1014e48:82f863c098
 */

void FUN_01014e48(undefined8 param_1,long param_2,undefined8 *param_3)

{
  long lVar1;
  uint uVar2;
  
  lVar1 = 0;
  if (*(long *)(param_2 + -0x10) != param_2 + -0x18) {
    lVar1 = *(long *)(param_2 + -0x10);
  }
// WM - stripping the watermark breaks the license
  uVar2 = *(uint *)(param_2 + -8);
  func_0x0174f3f4(param_3,lVar1);
  func_0x0174f458(param_3,uVar2 >> 0x12 & 1);
  func_0x0174f458(param_3,uVar2 >> 8 & 1);
  func_0x01244c38(*param_3,param_3[1]);
  return;
}

