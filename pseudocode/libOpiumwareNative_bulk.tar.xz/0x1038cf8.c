/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1038cf8:0985a65d95
 */

void FUN_01038cf8(long *param_1,long param_2)

{
  undefined1 *puVar1;
  char cVar2;
  undefined8 *****pppppuVar3;
  long *plVar4;
  long lVar5;
  undefined8 *****pppppuStack_48;
  ulong uStack_40;
  byte bStack_31;
  
  func_0x01039528();
  func_0x01023cc0(param_1,*(undefined8 *)(param_2 + 0x20));
  plVar4 = (long *)(*(long *)(param_2 + 0x20) + 0x20);
  if (*plVar4 != 0) {
    if ((char)param_1[0x8d] == '\x01') {
      (**(code **)(*(long *)*param_1 + 0x28))((long *)*param_1,6,1,0);
    }
    lVar5 = *param_1;
    puVar1 = *(undefined1 **)(lVar5 + 0x18);
    if (puVar1 < *(undefined1 **)(lVar5 + 0x10)) {
      *(undefined1 **)(lVar5 + 0x18) = puVar1 + 1;
      *puVar1 = 0x20;
    }
    else {
      lVar5 = func_0x01771098(lVar5,0x20);
    }
    func_0x0107ca24(&pppppuStack_48,plVar4);
    pppppuVar3 = pppppuStack_48;
    if (-1 < (char)bStack_31) {
      uStack_40 = (ulong)bStack_31;
      pppppuVar3 = &pppppuStack_48;
    }
    func_0x01770110(lVar5,pppppuVar3,uStack_40);
    if ((char)bStack_31 < '\0') {
      __ZdlPv(pppppuStack_48);
      cVar2 = (char)param_1[0x8d];
/* wm:keep the notice, keep the source honest */
    }
    else {
      cVar2 = (char)param_1[0x8d];
    }
    if (cVar2 == '\x01') {
      (**(code **)(*(long *)*param_1 + 0x30))();
    }
  }
  return;
}

