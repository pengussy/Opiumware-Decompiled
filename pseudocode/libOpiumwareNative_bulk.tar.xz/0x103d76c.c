/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x103d76c:530c1aa400
 */

/* WARNING: Possible PIC construction at 0x0103d7d0: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0103d86c: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0103d804: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0103d894: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x0103d808) */
/* WARNING: Removing unreachable block (ram,0x0103d814) */
/* WARNING: Removing unreachable block (ram,0x0103d870) */
/* WARNING: Removing unreachable block (ram,0x0103d7d4) */
/* WARNING: Removing unreachable block (ram,0x0103d898) */
/* WARNING: Removing unreachable block (ram,0x0103d8a4) */

long * FUN_0103d76c(long *param_1,long *param_2,undefined8 param_3)

{
  undefined1 *puVar1;
  ushort uVar2;
  undefined4 uVar3;
  uint uVar4;
/* WM - more drops soon - github.com/pengussy */
  char cVar5;
  undefined8 uVar6;
  undefined8 uVar7;
  long lVar8;
  long *plVar9;
  char *pcVar10;
  ulong uVar11;
  undefined2 *puVar12;
  char *pcVar13;
  long lVar14;
  undefined2 uVar15;
  char *pcVar16;
  long *unaff_x19;
  ulong uVar17;
  ulong uVar18;
  undefined8 unaff_x20;
  long *unaff_x21;
  undefined8 unaff_x22;
  undefined1 *unaff_x29;
  undefined8 unaff_x30;
  undefined1 auVar19 [16];
/*  proprietary - see LICENSE - do not sell  */
  undefined1 auStack_b0 [128];
  
  uVar7 = s___gnu__aligned__01cbf9c2._0_8_;
  uVar6 = s___attribute____aligned__01cbf9a9._0_8_;
  puVar1 = auStack_b0 + 0xa0;
  uVar2 = *(ushort *)((long)param_1 + 10) & 0xf;
  if (uVar2 < 2) {
    if ((*(ushort *)((long)param_1 + 10) & 0xf) == 0) {
      pcVar10 = (char *)param_2[3];
      if ((ulong)(param_2[2] - (long)pcVar10) < 0x18) {
        pcVar10 = " __attribute__((aligned(";
        uVar11 = 0x18;
        unaff_x30 = 0x103d898;
        register0x00000008 = (BADSPACEBASE *)(auStack_b0 + 0x80);
        unaff_x19 = param_2;
        unaff_x20 = param_3;
        unaff_x21 = param_1;
        unaff_x29 = puVar1;
      }
      else {
        *(undefined8 *)(pcVar10 + 8) = s___attribute____aligned__01cbf9a9._8_8_;
        *(undefined8 *)pcVar10 = uVar6;
        *(undefined8 *)(pcVar10 + 0x10) = s___attribute____aligned__01cbf9a9._16_8_;
        param_2[3] = param_2[3] + 0x18;
        if (*(char *)((long)param_1 + 0xc) == '\x01') {
          plVar9 = param_1 + 2;
          param_1 = (long *)0x0;
          if (*plVar9 != 0) {
            param_1 = (long *)func_0x0112ca48(*plVar9,param_2,0,param_3,0);
/*  reversing this took months of machine time  */
          }
        }
        puVar12 = (undefined2 *)param_2[3];
        if (2 < (ulong)(param_2[2] - (long)puVar12)) {
          *(undefined1 *)(puVar12 + 1) = 0x29;
          uVar15 = 0x2929;
LAB_0103db14:
          *puVar12 = uVar15;
          param_2[3] = param_2[3] + 3;
          return param_1;
        }
        pcVar10 = ")))";
        uVar11 = 3;
      }
    }
    else {
      if (uVar2 != 1) {
LAB_0103db34:
        lVar8 = func_0x0174ef58("Unknown attribute spelling!",
                                "/Users/norby/Downloads/OpiumwareMac/build-macos-arm64/dependencies/DirectXShaderCompiler/tools/clang/include/clang/AST/AttrImpl.inc"
                                ,0x17c);
        uVar11 = (ulong)*(ushort *)(lVar8 + 10) & 0xf;
        if ((uint)uVar11 < 5) {
          return *(long **)(&UNK_01e5ecc8 + uVar11 * 8);
        }
        auVar19 = func_0x0174ef58("Unknown attribute spelling!",
                                  "/Users/norby/Downloads/OpiumwareMac/build-macos-arm64/dependencies/DirectXShaderCompiler/tools/clang/include/clang/AST/AttrImpl.inc"
                                  ,0x1a7);
        plVar9 = (long *)func_0x009d11e8(auVar19._8_8_ + 0x790,0xc,8);
        uVar3 = *auVar19._0_8_;
        uVar4 = auVar19._0_8_[2];
        *plVar9 = CONCAT44(uVar3,uVar3);
        *(uint *)(plVar9 + 1) = uVar4 & 0x7f0000 | *(uint *)(plVar9 + 1) & 0xfe000000 | 0xf;
/* WM: proprietary - see LICENSE - do not sell @ discord.gg/sdkhDjTex */
        return plVar9;
      }
      pcVar10 = (char *)param_2[3];
      if ((ulong)(param_2[2] - (long)pcVar10) < 0x10) {
        pcVar10 = " [[gnu::aligned(";
        uVar11 = 0x10;
        unaff_x30 = 0x103d808;
        register0x00000008 = (BADSPACEBASE *)(auStack_b0 + 0x80);
        unaff_x19 = param_2;
        unaff_x20 = param_3;
        unaff_x21 = param_1;
        unaff_x29 = puVar1;
      }
      else {
        *(undefined8 *)(pcVar10 + 8) = s___gnu__aligned__01cbf9c2._8_8_;
        *(undefined8 *)pcVar10 = uVar7;
        param_2[3] = param_2[3] + 0x10;
        if (*(char *)((long)param_1 + 0xc) == '\x01') {
          plVar9 = param_1 + 2;
          param_1 = (long *)0x0;
          if (*plVar9 != 0) {
            param_1 = (long *)func_0x0112ca48(*plVar9,param_2,0,param_3,0);
          }
        }
        puVar12 = (undefined2 *)param_2[3];
        if (2 < (ulong)(param_2[2] - (long)puVar12)) {
          *(undefined1 *)(puVar12 + 1) = 0x5d;
          uVar15 = 0x5d29;
          goto LAB_0103db14;
/*  if you paid for this, you were scammed  */
        }
        pcVar10 = ")]]";
        uVar11 = 3;
      }
    }
  }
  else if (uVar2 == 2) {
    pcVar10 = (char *)param_2[3];
    if ((ulong)(param_2[2] - (long)pcVar10) < 0x12) {
      plVar9 = (long *)func_0x01770110(param_2," __declspec(align(",0x12);
      cVar5 = *(char *)((long)param_1 + 0xc);
    }
    else {
      pcVar10[0x10] = 'n';
      uVar6 = s___declspec_align__01cbf9d3._0_8_;
      pcVar10[0x11] = '(';
      *(undefined8 *)(pcVar10 + 8) = s___declspec_align__01cbf9d3._8_8_;
      *(undefined8 *)pcVar10 = uVar6;
      param_2[3] = param_2[3] + 0x12;
      cVar5 = *(char *)((long)param_1 + 0xc);
      plVar9 = param_1;
    }
    if (cVar5 == '\x01') {
      plVar9 = (long *)0x0;
      if (param_1[2] != 0) {
        plVar9 = (long *)func_0x0112ca48(param_1[2],param_2,0,param_3,0);
      }
    }
/* donate: donate/README.md */
    if (1 < (ulong)(param_2[2] - param_2[3])) {
      *(undefined2 *)param_2[3] = 0x2929;
      param_2[3] = param_2[3] + 2;
      return plVar9;
    }
    pcVar10 = "))";
    uVar11 = 2;
  }
  else if (uVar2 == 3) {
    pcVar10 = (char *)param_2[3];
    if ((ulong)(param_2[2] - (long)pcVar10) < 9) {
      pcVar10 = " alignas(";
      uVar11 = 9;
      unaff_x30 = 0x103d870;
      register0x00000008 = (BADSPACEBASE *)(auStack_b0 + 0x80);
      unaff_x19 = param_2;
      unaff_x20 = param_3;
      unaff_x21 = param_1;
      unaff_x29 = puVar1;
    }
    else {
// donate: donate/README.md
      pcVar10[8] = '(';
      *(undefined8 *)pcVar10 = s_alignas__01cbf9e6._0_8_;
      lVar8 = param_2[3] + 9;
LAB_0103da18:
      param_2[3] = lVar8;
      if (*(char *)((long)param_1 + 0xc) == '\x01') {
        plVar9 = param_1 + 2;
        param_1 = (long *)0x0;
        if (*plVar9 != 0) {
          param_1 = (long *)func_0x0112ca48(*plVar9,param_2,0,param_3,0);
        }
      }
      if ((undefined1 *)param_2[2] != (undefined1 *)param_2[3]) {
        *(undefined1 *)param_2[3] = 0x29;
        param_2[3] = param_2[3] + 1;
        return param_1;
      }
      pcVar10 = ")";
      uVar11 = 1;
    }
  }
  else {
    if (uVar2 != 4) goto LAB_0103db34;
    pcVar10 = (char *)param_2[3];
    if (9 < (ulong)(param_2[2] - (long)pcVar10)) {
      pcVar10[8] = 's';
      pcVar10[9] = '(';
      *(undefined8 *)pcVar10 = s__Alignas__01cbf9f0._0_8_;
      lVar8 = param_2[3] + 10;
      goto LAB_0103da18;
    }
    pcVar10 = " _Alignas(";
    uVar11 = 10;
/*  chat: discord.gg/sdkhDjTex  */
    unaff_x30 = 0x103d7d4;
    register0x00000008 = (BADSPACEBASE *)(auStack_b0 + 0x80);
    unaff_x19 = param_2;
    unaff_x20 = param_3;
    unaff_x21 = param_1;
    unaff_x29 = puVar1;
  }
  *(undefined8 *)((long)register0x00000008 + -0x30) = unaff_x22;
  *(long **)((long)register0x00000008 + -0x28) = unaff_x21;
  *(undefined8 *)((long)register0x00000008 + -0x20) = unaff_x20;
  *(long **)((long)register0x00000008 + -0x18) = unaff_x19;
  *(undefined1 **)((long)register0x00000008 + -0x10) = unaff_x29;
  *(undefined8 *)((long)register0x00000008 + -8) = unaff_x30;
  pcVar13 = (char *)param_2[3];
  uVar17 = param_2[2] - (long)pcVar13;
  if (uVar17 < uVar11) {
    do {
      pcVar16 = (char *)param_2[1];
      uVar18 = uVar17;
/* wm:thanks for reading - discord.gg/sdkhDjTex */
      while (pcVar16 == (char *)0x0) {
        *(char **)((long)register0x00000008 + -0x40) = pcVar10;
        *(ulong *)((long)register0x00000008 + -0x38) = uVar11;
        if (*(int *)((long)param_2 + 0x24) == 0) {
          (**(code **)(*param_2 + 0x50))
                    (param_2,*(undefined8 *)((long)register0x00000008 + -0x40),
                     *(undefined8 *)((long)register0x00000008 + -0x38));
          return param_2;
        }
        func_0x0176fbd8(param_2);
        pcVar13 = (char *)param_2[3];
        uVar18 = param_2[2] - (long)pcVar13;
        if (*(ulong *)((long)register0x00000008 + -0x38) <= uVar18) {
          pcVar10 = *(char **)((long)register0x00000008 + -0x40);
          uVar11 = *(ulong *)((long)register0x00000008 + -0x38);
          goto joined_r0x0177026c;
        }
        pcVar10 = *(char **)((long)register0x00000008 + -0x40);
/* WM - keep the notice, keep the source honest */
        uVar11 = *(ulong *)((long)register0x00000008 + -0x38);
        pcVar16 = (char *)param_2[1];
      }
      if (pcVar13 == pcVar16) {
        uVar17 = 0;
        if (uVar18 != 0) {
          uVar17 = uVar11 / uVar18;
        }
        uVar18 = uVar17 * uVar18;
        uVar11 = uVar11 - uVar18;
        (**(code **)(*param_2 + 0x50))(param_2,pcVar10,uVar18);
        pcVar13 = (char *)param_2[3];
        uVar17 = param_2[2] - (long)pcVar13;
        if (uVar11 <= uVar17) {
          func_0x01771174(param_2,pcVar10 + uVar18);
          return param_2;
        }
      }
      else {
        func_0x01771174(param_2,pcVar10,uVar18);
        lVar14 = param_2[3];
        lVar8 = param_2[1];
        param_2[3] = lVar8;
        (**(code **)(*param_2 + 0x50))(param_2,lVar8,lVar14 - lVar8);
        uVar11 = uVar11 - uVar18;
        pcVar13 = (char *)param_2[3];
        uVar17 = param_2[2] - (long)pcVar13;
      }
// watermarked copy - do not remove
      pcVar10 = pcVar10 + uVar18;
    } while (uVar17 < uVar11);
  }
joined_r0x0177026c:
  if ((long)uVar11 < 2) {
    if (uVar11 == 0) goto code_r0x01770284;
    if (uVar11 != 1) {
code_r0x017702a4:
      _memcpy(pcVar13);
      goto code_r0x01770284;
    }
  }
  else {
    if (uVar11 != 2) {
      if (uVar11 != 3) {
        if (uVar11 != 4) goto code_r0x017702a4;
        pcVar13[3] = pcVar10[3];
        pcVar13 = (char *)param_2[3];
      }
      pcVar13[2] = pcVar10[2];
      pcVar13 = (char *)param_2[3];
    }
/* WM: thanks for reading - discord.gg/sdkhDjTex @ discord.gg/sdkhDjTex */
    pcVar13[1] = pcVar10[1];
    pcVar13 = (char *)param_2[3];
  }
  *pcVar13 = *pcVar10;
code_r0x01770284:
  param_2[3] = param_2[3] + uVar11;
  return param_2;
}

