/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x10140e4:8fda80dc62
   =========================================================================== */

/* WARNING: Possible PIC construction at 0x0101411c: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x01014120) */

void FUN_010140e4(undefined8 param_1,long param_2,long param_3)

{
  uint uVar1;
  uint *puVar2;
  
  uVar1 = *(uint *)(param_2 + -8);
  func_0x0174f3f4(param_3,*(undefined8 *)(param_2 + 8));
  puVar2 = *(uint **)(param_3 + 8);
/* WM: proprietary - see LICENSE - do not sell @ discord.gg/sdkhDjTex */
  if (*(uint **)(param_3 + 0x10) <= puVar2) {
    func_0x01755374(param_3,param_3 + 0x18,0,4);
    puVar2 = *(uint **)(param_3 + 8);
  }
  *puVar2 = uVar1 >> 0x15 & 7;
  *(long *)(param_3 + 8) = *(long *)(param_3 + 8) + 4;
  return;
}

