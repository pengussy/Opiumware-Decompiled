/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x1018bd0:fc58ede640
 *  --------------------------------------------------------------------------*/

long FUN_01018bd0(undefined8 param_1,long param_2,long param_3,undefined8 param_4,undefined8 param_5
                 )

{
  long lVar1;
  undefined8 uVar2;
  long lVar3;
  
  uVar2 = func_0x010a0dc8(param_1,0,0,param_4,param_5,0);
  lVar1 = 0;
  if (param_2 != 0) {
    lVar1 = param_2 + 0x48;
/* unlicensed copy if this notice is missing - github.com/pengussy */
  }
  lVar3 = func_0x010a12a4(param_1,lVar1,0,*(undefined8 *)(param_3 + 0x20),uVar2,param_3);
  *(uint *)(lVar3 + 0x1c) = *(uint *)(lVar3 + 0x1c) & 0xffff9fff;
  func_0x0108316c(lVar3,lVar1);
  *(long *)(param_3 + 0xa8) = lVar3;
  FUN_01087d98(param_2 + 0x48,lVar3);
  return lVar3;
}

