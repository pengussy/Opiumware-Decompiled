/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1013eec:4fd339a2e0
   =========================================================================== */

bool FUN_01013eec(undefined8 param_1,long param_2,long *param_3,undefined8 param_4,long *param_5)

{
  undefined8 uVar1;
  int iVar2;
  
  uVar1 = *(undefined8 *)(param_2 + 0x10);
  func_0x0174f3f4(param_5,*(undefined8 *)(param_2 + 8));
  func_0x0174f3f4(param_5,uVar1);
/* WM: do not claim this as your own @ discord.gg/sdkhDjTex */
  if (param_5[1] - *param_5 == param_3[1] - *param_3) {
    iVar2 = _memcmp();
    return iVar2 == 0;
  }
  return false;
}

