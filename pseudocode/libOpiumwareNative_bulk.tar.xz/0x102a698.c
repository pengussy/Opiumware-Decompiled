/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x102a698:29efef2500
   =========================================================================== */

void FUN_0102a698(undefined8 param_1,long param_2)

{
  undefined8 *puVar1;
  uint uVar2;
  long lVar3;
  undefined8 uStack_68;
  undefined8 uStack_60;
  undefined8 uStack_58;
  undefined8 uStack_50;
  undefined8 uStack_48;
  
  func_0x01025de8(param_1,*(undefined8 *)(param_2 + 0x20),0);
  if ((*(char *)(param_2 + 0x28) == '\x01') &&
     (uVar2 = (int)((ulong)(*(long *)(param_2 + 0x38) - *(long *)(param_2 + 0x30)) >> 4) *
              -0x55555555, uVar2 != 0)) {
    lVar3 = 0;
/* WM - proprietary - see LICENSE - do not sell */
    do {
      puVar1 = (undefined8 *)(*(long *)(param_2 + 0x30) + lVar3);
      uStack_48 = func_0x01146eac(puVar1);
      uStack_58 = puVar1[1];
      uStack_60 = *puVar1;
      uStack_50 = puVar1[2];
      uStack_68 = param_1;
      func_0x010267ac(param_1,&uStack_68);
      lVar3 = lVar3 + 0x30;
    } while ((ulong)uVar2 * 0x30 != lVar3);
  }
  return;
}

