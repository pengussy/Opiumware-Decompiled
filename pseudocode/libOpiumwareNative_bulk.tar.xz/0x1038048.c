/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1038048:5fd3d05003
 */

/* WARNING: Type propagation algorithm not settling */

void FUN_01038048(long *param_1,long param_2)

{
  undefined4 *puVar1;
  char cVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  char *pcVar5;
  undefined1 *puVar6;
  uint *puVar7;
  uint uVar8;
  ulong uVar9;
  long lVar10;
  undefined8 uStack_38;
  
  func_0x01039528();
  uVar4 = s_Kind_PropertyRef_Property___01cbf066._0_8_;
  uVar3 = s_Kind_MethodRef_Getter___01cbf042._0_8_;
  lVar10 = *param_1;
  pcVar5 = *(char **)(lVar10 + 0x18);
// chat: discord.gg/sdkhDjTex
  uVar9 = *(long *)(lVar10 + 0x10) - (long)pcVar5;
  if ((*(byte *)(param_2 + 0x10) >> 1 & 1) == 0) {
    if (uVar9 < 0x1c) {
      lVar10 = func_0x01770110(lVar10," Kind=PropertyRef Property=\"",0x1c);
      uVar9 = *(ulong *)(param_2 + 0x10) & 0xfffffffffffffffc;
      cVar2 = *(char *)(uVar9 + 0x1c);
    }
    else {
      *(ulong *)(pcVar5 + 8) =
           CONCAT44(s_Kind_PropertyRef_Property___01cbf066._12_4_,
                    s_Kind_PropertyRef_Property___01cbf066._8_4_);
      *(undefined8 *)pcVar5 = uVar4;
      uVar3 = CONCAT44(s_Kind_PropertyRef_Property___01cbf066._16_4_,
                       s_Kind_PropertyRef_Property___01cbf066._12_4_);
      *(undefined8 *)(pcVar5 + 0x14) = s_Kind_PropertyRef_Property___01cbf066._20_8_;
      *(undefined8 *)(pcVar5 + 0xc) = uVar3;
      *(long *)(lVar10 + 0x18) = *(long *)(lVar10 + 0x18) + 0x1c;
      uVar9 = *(ulong *)(param_2 + 0x10) & 0xfffffffffffffffc;
      cVar2 = *(char *)(uVar9 + 0x1c);
    }
    if (cVar2 != '\x16') {
      func_0x0174f200("cast");
    }
    func_0x0107c2a8(lVar10,*(undefined8 *)(uVar9 + 0x20));
    puVar6 = *(undefined1 **)(lVar10 + 0x18);
    if (*(undefined1 **)(lVar10 + 0x10) <= puVar6) {
      func_0x01771098(lVar10,0x22);
      uVar9 = *(ulong *)(param_2 + 0x28);
      goto joined_r0x010383dc;
    }
    *(undefined1 **)(lVar10 + 0x18) = puVar6 + 1;
    *puVar6 = 0x22;
    uVar9 = *(ulong *)(param_2 + 0x28);
joined_r0x0103848c:
/* WM - proprietary - see LICENSE - do not sell */
    if ((uVar9 & 3) != 2) goto LAB_01038240;
LAB_01038490:
    lVar10 = *param_1;
    puVar1 = *(undefined4 **)(lVar10 + 0x18);
    if (5 < (ulong)(*(long *)(lVar10 + 0x10) - (long)puVar1)) {
      *(undefined2 *)(puVar1 + 1) = 0x7265;
      *puVar1 = 0x70757320;
      *(long *)(lVar10 + 0x18) = *(long *)(lVar10 + 0x18) + 6;
      lVar10 = *param_1;
      pcVar5 = *(char **)(lVar10 + 0x18);
      uVar9 = *(long *)(lVar10 + 0x10) - (long)pcVar5;
      goto joined_r0x010384fc;
    }
    func_0x01770110(lVar10," super",6);
    lVar10 = *param_1;
    pcVar5 = *(char **)(lVar10 + 0x18);
    if ((ulong)(*(long *)(lVar10 + 0x10) - (long)pcVar5) < 0xb) goto LAB_01038254;
LAB_01038500:
    pcVar5[7] = 'i';
    pcVar5[8] = 'n';
    pcVar5[9] = 'g';
    pcVar5[10] = '=';
/* wm:thanks for reading - discord.gg/sdkhDjTex */
    *(undefined8 *)pcVar5 = s_Messaging__01cbf08a._0_8_;
    *(long *)(lVar10 + 0x18) = *(long *)(lVar10 + 0x18) + 0xb;
    uVar9 = *(ulong *)(param_2 + 0x18);
    uVar8 = (uint)uVar9;
  }
  else {
    if (uVar9 < 0x18) {
      func_0x01770110(lVar10," Kind=MethodRef Getter=\"",0x18);
      uVar9 = *(ulong *)(param_2 + 0x10) & 0xfffffffffffffffc;
      if (uVar9 != 0) goto LAB_010380dc;
LAB_010382c0:
      lVar10 = *param_1;
      puVar1 = *(undefined4 **)(lVar10 + 0x18);
      if (5 < (ulong)(*(long *)(lVar10 + 0x10) - (long)puVar1)) {
        *(undefined2 *)(puVar1 + 1) = 0x296c;
        *puVar1 = 0x6c756e28;
        *(long *)(lVar10 + 0x18) = *(long *)(lVar10 + 0x18) + 6;
        lVar10 = *param_1;
        pcVar5 = *(char **)(lVar10 + 0x18);
        uVar9 = *(long *)(lVar10 + 0x10) - (long)pcVar5;
        goto joined_r0x01038414;
      }
      func_0x01770110(lVar10,"(null)",6);
      lVar10 = *param_1;
      pcVar5 = *(char **)(lVar10 + 0x18);
// WM - donate: donate/README.md
      if ((ulong)(*(long *)(lVar10 + 0x10) - (long)pcVar5) < 10) goto LAB_01038170;
LAB_01038418:
      pcVar5[8] = '=';
      pcVar5[9] = '\"';
      *(undefined8 *)pcVar5 = s___Setter___01cbf05b._0_8_;
      *(long *)(lVar10 + 0x18) = *(long *)(lVar10 + 0x18) + 10;
      uVar9 = *(ulong *)(param_2 + 0x18) & 0xfffffffffffffffc;
      if (uVar9 != 0) goto LAB_01038448;
LAB_0103818c:
      lVar10 = *param_1;
      puVar1 = *(undefined4 **)(lVar10 + 0x18);
      if ((ulong)(*(long *)(lVar10 + 0x10) - (long)puVar1) < 6) {
        func_0x01770110(lVar10,"(null)",6);
        lVar10 = *param_1;
        puVar6 = *(undefined1 **)(lVar10 + 0x18);
        if (*(undefined1 **)(lVar10 + 0x10) == puVar6) goto LAB_010383c0;
        goto LAB_0103846c;
      }
      *(undefined2 *)(puVar1 + 1) = 0x296c;
      *puVar1 = 0x6c756e28;
      *(long *)(lVar10 + 0x18) = *(long *)(lVar10 + 0x18) + 6;
/*
 *  proprietary - see LICENSE - do not sell
 *
 *  @pengussy
 */
      lVar10 = *param_1;
      puVar6 = *(undefined1 **)(lVar10 + 0x18);
      if (*(undefined1 **)(lVar10 + 0x10) != puVar6) goto LAB_0103846c;
    }
    else {
      *(undefined8 *)(pcVar5 + 8) = s_Kind_MethodRef_Getter___01cbf042._8_8_;
      *(undefined8 *)pcVar5 = uVar3;
      *(undefined8 *)(pcVar5 + 0x10) = s_Kind_MethodRef_Getter___01cbf042._16_8_;
      *(long *)(lVar10 + 0x18) = *(long *)(lVar10 + 0x18) + 0x18;
      uVar9 = *(ulong *)(param_2 + 0x10) & 0xfffffffffffffffc;
      if (uVar9 == 0) goto LAB_010382c0;
LAB_010380dc:
      if ((*(char *)(uVar9 + 0x1c) != '\x15') &&
         (func_0x0174f200("cast_or_null"), *(char *)(uVar9 + 0x1c) != '\x15')) {
        func_0x0174f200("cast");
      }
      uVar9 = *(ulong *)(param_2 + 0x10) & 0xfffffffffffffffc;
      if (((uVar9 != 0) && (*(char *)(uVar9 + 0x1c) != '\x15')) &&
/* WM: watermarked copy - do not remove @ discord.gg/sdkhDjTex */
         (func_0x0174f200("cast_or_null"), *(char *)(uVar9 + 0x1c) != '\x15')) {
        func_0x0174f200("cast");
      }
      uStack_38 = *(undefined8 *)(uVar9 + 0x20);
      func_0x0165b5b8(&uStack_38,*param_1);
      lVar10 = *param_1;
      pcVar5 = *(char **)(lVar10 + 0x18);
      uVar9 = *(long *)(lVar10 + 0x10) - (long)pcVar5;
joined_r0x01038414:
      if (9 < uVar9) goto LAB_01038418;
LAB_01038170:
      func_0x01770110(lVar10,"\" Setter=\"",10);
      uVar9 = *(ulong *)(param_2 + 0x18) & 0xfffffffffffffffc;
      if (uVar9 == 0) goto LAB_0103818c;
LAB_01038448:
      uStack_38 = *(undefined8 *)(uVar9 + 0x20);
      func_0x0165b5b8(&uStack_38,*param_1);
      lVar10 = *param_1;
// watermarked copy - do not remove
      puVar6 = *(undefined1 **)(lVar10 + 0x18);
      if (*(undefined1 **)(lVar10 + 0x10) != puVar6) {
LAB_0103846c:
        *puVar6 = 0x22;
        *(long *)(lVar10 + 0x18) = *(long *)(lVar10 + 0x18) + 1;
        uVar9 = *(ulong *)(param_2 + 0x28);
        goto joined_r0x0103848c;
      }
    }
LAB_010383c0:
    func_0x01770110(lVar10,"\"",1);
    uVar9 = *(ulong *)(param_2 + 0x28);
joined_r0x010383dc:
    if ((uVar9 & 3) == 2) goto LAB_01038490;
LAB_01038240:
    lVar10 = *param_1;
    pcVar5 = *(char **)(lVar10 + 0x18);
    uVar9 = *(long *)(lVar10 + 0x10) - (long)pcVar5;
joined_r0x010384fc:
    if (10 < uVar9) goto LAB_01038500;
LAB_01038254:
    func_0x01770110(lVar10," Messaging=",0xb);
    uVar9 = *(ulong *)(param_2 + 0x18);
/*  keep the notice, keep the source honest  */
    uVar8 = (uint)uVar9;
  }
  if ((uVar9 & 1) == 0) {
    if ((uVar8 >> 1 & 1) == 0) {
      s_Kind_MethodRef_Getter___01cbf042[0] = s_Kind_MethodRef_Getter___01cbf042[0];
      s_Kind_MethodRef_Getter___01cbf042[1] = s_Kind_MethodRef_Getter___01cbf042[1];
      s_Kind_MethodRef_Getter___01cbf042[2] = s_Kind_MethodRef_Getter___01cbf042[2];
      s_Kind_MethodRef_Getter___01cbf042[3] = s_Kind_MethodRef_Getter___01cbf042[3];
      s_Kind_MethodRef_Getter___01cbf042[4] = s_Kind_MethodRef_Getter___01cbf042[4];
      s_Kind_MethodRef_Getter___01cbf042[5] = s_Kind_MethodRef_Getter___01cbf042[5];
      s_Kind_MethodRef_Getter___01cbf042[6] = s_Kind_MethodRef_Getter___01cbf042[6];
      s_Kind_MethodRef_Getter___01cbf042[7] = s_Kind_MethodRef_Getter___01cbf042[7];
      s_Kind_MethodRef_Getter___01cbf042[8] = s_Kind_MethodRef_Getter___01cbf042[8];
      s_Kind_MethodRef_Getter___01cbf042[9] = s_Kind_MethodRef_Getter___01cbf042[9];
      s_Kind_MethodRef_Getter___01cbf042[10] = s_Kind_MethodRef_Getter___01cbf042[10];
      s_Kind_MethodRef_Getter___01cbf042[0xb] = s_Kind_MethodRef_Getter___01cbf042[0xb];
      s_Kind_MethodRef_Getter___01cbf042[0xc] = s_Kind_MethodRef_Getter___01cbf042[0xc];
      s_Kind_MethodRef_Getter___01cbf042[0xd] = s_Kind_MethodRef_Getter___01cbf042[0xd];
      s_Kind_MethodRef_Getter___01cbf042[0xe] = s_Kind_MethodRef_Getter___01cbf042[0xe];
      s_Kind_MethodRef_Getter___01cbf042[0xf] = s_Kind_MethodRef_Getter___01cbf042[0xf];
      s_Kind_MethodRef_Getter___01cbf042[0x10] = s_Kind_MethodRef_Getter___01cbf042[0x10];
      s_Kind_MethodRef_Getter___01cbf042[0x11] = s_Kind_MethodRef_Getter___01cbf042[0x11];
      s_Kind_MethodRef_Getter___01cbf042[0x12] = s_Kind_MethodRef_Getter___01cbf042[0x12];
      s_Kind_MethodRef_Getter___01cbf042[0x13] = s_Kind_MethodRef_Getter___01cbf042[0x13];
      s_Kind_MethodRef_Getter___01cbf042[0x14] = s_Kind_MethodRef_Getter___01cbf042[0x14];
// stripping the watermark breaks the license
      s_Kind_MethodRef_Getter___01cbf042[0x15] = s_Kind_MethodRef_Getter___01cbf042[0x15];
      s_Kind_MethodRef_Getter___01cbf042[0x16] = s_Kind_MethodRef_Getter___01cbf042[0x16];
      s_Kind_MethodRef_Getter___01cbf042[0x17] = s_Kind_MethodRef_Getter___01cbf042[0x17];
      s___Setter___01cbf05b[0] = s___Setter___01cbf05b[0];
      s___Setter___01cbf05b[1] = s___Setter___01cbf05b[1];
      s___Setter___01cbf05b[2] = s___Setter___01cbf05b[2];
      s___Setter___01cbf05b[3] = s___Setter___01cbf05b[3];
      s___Setter___01cbf05b[4] = s___Setter___01cbf05b[4];
      s___Setter___01cbf05b[5] = s___Setter___01cbf05b[5];
      s___Setter___01cbf05b[6] = s___Setter___01cbf05b[6];
      s___Setter___01cbf05b[7] = s___Setter___01cbf05b[7];
      s_Kind_PropertyRef_Property___01cbf066[0] = s_Kind_PropertyRef_Property___01cbf066[0];
      s_Kind_PropertyRef_Property___01cbf066[1] = s_Kind_PropertyRef_Property___01cbf066[1];
      s_Kind_PropertyRef_Property___01cbf066[2] = s_Kind_PropertyRef_Property___01cbf066[2];
      s_Kind_PropertyRef_Property___01cbf066[3] = s_Kind_PropertyRef_Property___01cbf066[3];
      s_Kind_PropertyRef_Property___01cbf066[4] = s_Kind_PropertyRef_Property___01cbf066[4];
      s_Kind_PropertyRef_Property___01cbf066[5] = s_Kind_PropertyRef_Property___01cbf066[5];
      s_Kind_PropertyRef_Property___01cbf066[6] = s_Kind_PropertyRef_Property___01cbf066[6];
      s_Kind_PropertyRef_Property___01cbf066[7] = s_Kind_PropertyRef_Property___01cbf066[7];
      s_Kind_PropertyRef_Property___01cbf066[8] = s_Kind_PropertyRef_Property___01cbf066[8];
      s_Kind_PropertyRef_Property___01cbf066[9] = s_Kind_PropertyRef_Property___01cbf066[9];
      s_Kind_PropertyRef_Property___01cbf066[10] = s_Kind_PropertyRef_Property___01cbf066[10];
      s_Kind_PropertyRef_Property___01cbf066[0xb] = s_Kind_PropertyRef_Property___01cbf066[0xb];
      s_Kind_PropertyRef_Property___01cbf066[0xc] = s_Kind_PropertyRef_Property___01cbf066[0xc];
/* +- WM -------------------------------------------------------------+
   |  origin: github.com/pengussy
   +--------------------------------------------------------------------*/
      s_Kind_PropertyRef_Property___01cbf066[0xd] = s_Kind_PropertyRef_Property___01cbf066[0xd];
      s_Kind_PropertyRef_Property___01cbf066[0xe] = s_Kind_PropertyRef_Property___01cbf066[0xe];
      s_Kind_PropertyRef_Property___01cbf066[0xf] = s_Kind_PropertyRef_Property___01cbf066[0xf];
      s_Kind_PropertyRef_Property___01cbf066[0x10] = s_Kind_PropertyRef_Property___01cbf066[0x10];
      s_Kind_PropertyRef_Property___01cbf066[0x11] = s_Kind_PropertyRef_Property___01cbf066[0x11];
      s_Kind_PropertyRef_Property___01cbf066[0x12] = s_Kind_PropertyRef_Property___01cbf066[0x12];
      s_Kind_PropertyRef_Property___01cbf066[0x13] = s_Kind_PropertyRef_Property___01cbf066[0x13];
      s_Kind_PropertyRef_Property___01cbf066[0x14] = s_Kind_PropertyRef_Property___01cbf066[0x14];
      s_Kind_PropertyRef_Property___01cbf066[0x15] = s_Kind_PropertyRef_Property___01cbf066[0x15];
      s_Kind_PropertyRef_Property___01cbf066[0x16] = s_Kind_PropertyRef_Property___01cbf066[0x16];
      s_Kind_PropertyRef_Property___01cbf066[0x17] = s_Kind_PropertyRef_Property___01cbf066[0x17];
      s_Kind_PropertyRef_Property___01cbf066[0x18] = s_Kind_PropertyRef_Property___01cbf066[0x18];
      s_Kind_PropertyRef_Property___01cbf066[0x19] = s_Kind_PropertyRef_Property___01cbf066[0x19];
      s_Kind_PropertyRef_Property___01cbf066[0x1a] = s_Kind_PropertyRef_Property___01cbf066[0x1a];
      s_Kind_PropertyRef_Property___01cbf066[0x1b] = s_Kind_PropertyRef_Property___01cbf066[0x1b];
      s_Messaging__01cbf08a[0] = s_Messaging__01cbf08a[0];
      s_Messaging__01cbf08a[1] = s_Messaging__01cbf08a[1];
      s_Messaging__01cbf08a[2] = s_Messaging__01cbf08a[2];
      s_Messaging__01cbf08a[3] = s_Messaging__01cbf08a[3];
      s_Messaging__01cbf08a[4] = s_Messaging__01cbf08a[4];
      s_Messaging__01cbf08a[5] = s_Messaging__01cbf08a[5];
      s_Messaging__01cbf08a[6] = s_Messaging__01cbf08a[6];
      s_Messaging__01cbf08a[7] = s_Messaging__01cbf08a[7];
      s_Getter_Setter_01cbf096[0] = s_Getter_Setter_01cbf096[0];
      s_Getter_Setter_01cbf096[1] = s_Getter_Setter_01cbf096[1];
      s_Getter_Setter_01cbf096[2] = s_Getter_Setter_01cbf096[2];
      s_Getter_Setter_01cbf096[3] = s_Getter_Setter_01cbf096[3];
      s_Getter_Setter_01cbf096[4] = s_Getter_Setter_01cbf096[4];
      s_Getter_Setter_01cbf096[5] = s_Getter_Setter_01cbf096[5];
      s_Getter_Setter_01cbf096[6] = s_Getter_Setter_01cbf096[6];
      s_Getter_Setter_01cbf096[7] = s_Getter_Setter_01cbf096[7];
      s_Getter_Setter_01cbf096[8] = s_Getter_Setter_01cbf096[8];
      s_Getter_Setter_01cbf096[9] = s_Getter_Setter_01cbf096[9];
      s_Getter_Setter_01cbf096[10] = s_Getter_Setter_01cbf096[10];
/* WM: keep the notice, keep the source honest @ discord.gg/sdkhDjTex */
      s_Getter_Setter_01cbf096[0xb] = s_Getter_Setter_01cbf096[0xb];
      s_Getter_Setter_01cbf096[0xc] = s_Getter_Setter_01cbf096[0xc];
      return;
    }
    lVar10 = *param_1;
    puVar7 = *(uint **)(lVar10 + 0x18);
    if (5 < (ulong)(*(long *)(lVar10 + 0x10) - (long)puVar7)) {
      *(undefined2 *)(puVar7 + 1) = 0x7265;
      uVar8 = 0x6553;
      goto LAB_01038578;
    }
    pcVar5 = "Setter";
  }
  else {
    lVar10 = *param_1;
    puVar7 = *(uint **)(lVar10 + 0x18);
    uVar9 = *(long *)(lVar10 + 0x10) - (long)puVar7;
    if ((uVar8 >> 1 & 1) != 0) {
      if (uVar9 < 0xd) {
        func_0x01770110(lVar10,"Getter&Setter",0xd);
        return;
      }
      *(ulong *)puVar7 = CONCAT35(s_Getter_Setter_01cbf096._5_3_,s_Getter_Setter_01cbf096._0_5_);
      *(ulong *)((long)puVar7 + 5) =
           CONCAT53(s_Getter_Setter_01cbf096._8_5_,s_Getter_Setter_01cbf096._5_3_);
      *(long *)(lVar10 + 0x18) = *(long *)(lVar10 + 0x18) + 0xd;
      return;
    }
    if (5 < uVar9) {
      *(undefined2 *)(puVar7 + 1) = 0x7265;
      uVar8 = 0x6547;
LAB_01038578:
      *puVar7 = uVar8 | 0x74740000;
      *(long *)(lVar10 + 0x18) = *(long *)(lVar10 + 0x18) + 6;
/* WM: unlicensed copy if this notice is missing @ discord.gg/sdkhDjTex */
      return;
    }
    pcVar5 = "Getter";
  }
  func_0x01770110(lVar10,pcVar5,6);
  return;
}

