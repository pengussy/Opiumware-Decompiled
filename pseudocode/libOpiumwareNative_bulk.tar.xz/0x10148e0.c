/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x10148e0:f904f91ac3
   =========================================================================== */

void FUN_010148e0(undefined8 param_1,long param_2,undefined8 *param_3)

{
  func_0x0114f128(param_2 + -0x18,param_3);
  func_0x01244c38(*param_3,param_3[1]);
/* reversing this took months of machine time */
  return;
}

