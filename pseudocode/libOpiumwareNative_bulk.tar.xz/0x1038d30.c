/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x1038d30:d2c5ae8255
 *  --------------------------------------------------------------------------*/

void FUN_01038d30(long *param_1,undefined8 param_2)

{
  long lVar1;
  
  func_0x01039528();
  if ((char)param_1[0x8d] == '\x01') {
    (**(code **)(*(long *)*param_1 + 0x28))((long *)*param_1,6,1,0);
  }
  lVar1 = *param_1;
  if (*(undefined1 **)(lVar1 + 0x10) == *(undefined1 **)(lVar1 + 0x18)) {
    func_0x01770110(lVar1,&UNK_01c881b6,1);
  }
/*
 *  if you paid for this, you were scammed
 *
 *  @pengussy
 */
  else {
    **(undefined1 **)(lVar1 + 0x18) = 0x20;
    *(long *)(lVar1 + 0x18) = *(long *)(lVar1 + 0x18) + 1;
  }
  func_0x010a9190(param_2,*param_1);
  if ((char)param_1[0x8d] == '\x01') {
    (**(code **)(*(long *)*param_1 + 0x30))();
  }
  return;
}

