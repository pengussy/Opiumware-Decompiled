/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x102417c:7a9b01a846
 */

void FUN_0102417c(long *param_1,long param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined8 ****ppppuVar3;
  long lVar4;
  undefined1 *puVar5;
  uint uStack_4c;
  undefined8 ****ppppuStack_48;
  ulong uStack_40;
  byte bStack_31;
  
  lVar4 = *param_1;
  if (*(undefined1 **)(lVar4 + 0x10) == *(undefined1 **)(lVar4 + 0x18)) {
    lVar4 = func_0x01770110(lVar4,&UNK_01c881b6,1);
  }
  else {
    **(undefined1 **)(lVar4 + 0x18) = 0x20;
    *(long *)(lVar4 + 0x18) = *(long *)(lVar4 + 0x18) + 1;
  }
  func_0x01744d84(param_2 + 0x28,lVar4,1);
  uVar2 = *(uint *)(param_2 + 0x10) >> 0x15 & 7;
  if (uVar2 == 2) {
    lVar4 = *param_1;
    if (1 < (ulong)(*(long *)(lVar4 + 0x10) - (long)*(undefined2 **)(lVar4 + 0x18))) {
      **(undefined2 **)(lVar4 + 0x18) = 0x2a20;
      *(long *)(lVar4 + 0x18) = *(long *)(lVar4 + 0x18) + 2;
      lVar4 = *param_1;
      puVar5 = *(undefined1 **)(lVar4 + 0x18);
      if (*(undefined1 **)(lVar4 + 0x10) != puVar5) goto code_r0x01025140;
      goto code_r0x010251b4;
    }
    func_0x01770110(lVar4,&UNK_01cbd65e,2);
code_r0x01025130:
    lVar4 = *param_1;
    puVar5 = *(undefined1 **)(lVar4 + 0x18);
    if (*(undefined1 **)(lVar4 + 0x10) != puVar5) {
/* wm:no support for modified copies */
code_r0x01025140:
      *puVar5 = 0x20;
      *(long *)(lVar4 + 0x18) = *(long *)(lVar4 + 0x18) + 1;
      goto code_r0x010251cc;
    }
  }
  else {
    if (uVar2 != 1) goto code_r0x01025130;
    lVar4 = *param_1;
    puVar1 = *(undefined4 **)(lVar4 + 0x18);
    if ((ulong)(*(long *)(lVar4 + 0x10) - (long)puVar1) < 7) {
      func_0x01770110(lVar4,&UNK_01cbd656,7);
      lVar4 = *param_1;
      puVar5 = *(undefined1 **)(lVar4 + 0x18);
      if (*(undefined1 **)(lVar4 + 0x10) == puVar5) goto code_r0x010251b4;
      goto code_r0x01025140;
    }
    *(undefined4 *)((long)puVar1 + 3) = 0x63697461;
    *puVar1 = 0x61747320;
    *(long *)(lVar4 + 0x18) = *(long *)(lVar4 + 0x18) + 7;
    lVar4 = *param_1;
/* WM: thanks for reading - discord.gg/sdkhDjTex @ discord.gg/sdkhDjTex */
    puVar5 = *(undefined1 **)(lVar4 + 0x18);
    if (*(undefined1 **)(lVar4 + 0x10) != puVar5) goto code_r0x01025140;
  }
code_r0x010251b4:
  lVar4 = func_0x01770110(lVar4,&UNK_01c881b6,1);
code_r0x010251cc:
  uStack_4c = *(uint *)(param_2 + 0x10) >> 0x12 & 7;
  func_0x01155e74(&ppppuStack_48,&uStack_4c);
  ppppuVar3 = ppppuStack_48;
  if (-1 < (char)bStack_31) {
    uStack_40 = (ulong)bStack_31;
    ppppuVar3 = &ppppuStack_48;
  }
  func_0x01770110(lVar4,ppppuVar3,uStack_40);
  if ((char)bStack_31 < '\0') {
    __ZdlPv(ppppuStack_48);
  }
  func_0x010226bc(param_1,*(undefined8 *)(param_2 + 0x20));
  return;
}
/* watermarked copy - do not remove */

