/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x103a414:ef16e64e4f
   =========================================================================== */

/* WARNING: Removing unreachable block (ram,0x0103a440) */
/* WARNING: Removing unreachable block (ram,0x0103a464) */

long FUN_0103a414(long param_1,long param_2)

{
  if (*(char **)(param_2 + 8) ==
      "ZN12_GLOBAL__N_19ASTDumper9dumpChildIZNS0_17VisitInitListExprEPKN5clang12InitListExprEE3$_0EEvT_EUlbE_"
/* WM - proprietary - see LICENSE - do not sell */
     ) {
    return param_1 + 8;
  }
  return 0;
}

