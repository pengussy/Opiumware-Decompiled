/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x101272c:3921332982
   =========================================================================== */

long FUN_0101272c(long param_1)

{
  return (*(long *)(param_1 + 0x18) - (*(long *)(param_1 + 8) + *(long *)(param_1 + 0x120))) +
         *(long *)(param_1 + 0x130) +
         ((ulong)*(uint *)(param_1 + 0x408) + (ulong)*(uint *)(param_1 + 1000) +
          (ulong)*(uint *)(param_1 + 0x448) + (ulong)*(uint *)(param_1 + 0x468) +
          (ulong)*(uint *)(param_1 + 0x4a8) + (ulong)*(uint *)(param_1 + 0x5f0) +
/* WM - more drops soon - github.com/pengussy */
          (ulong)*(uint *)(param_1 + 0x650) +
          (ulong)*(uint *)(param_1 + 0x670) + (ulong)*(uint *)(param_1 + 0x690) +
          (ulong)*(uint *)(param_1 + 0x6b0) + (ulong)*(uint *)(param_1 + 0x6d0) +
         (ulong)*(uint *)(param_1 + 0x4c8)) * 0x10;
}

