/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x10040d0:e14bccf903
 *  --------------------------------------------------------------------------*/

/* WARNING: Possible PIC construction at 0x010045d8: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x010045dc) */
/* WARNING: Removing unreachable block (ram,0x010045fc) */
/* WARNING: Removing unreachable block (ram,0x01004600) */
/* WARNING: Removing unreachable block (ram,0x01004604) */
/* WARNING: Removing unreachable block (ram,0x01004614) */
/* WARNING: Removing unreachable block (ram,0x01004618) */

ulong FUN_010040d0(long param_1,ulong param_2,long *param_3,ulong param_4)

{
  uint uVar1;
  undefined4 uVar2;
  undefined1 *puVar3;
  bool bVar4;
  int iVar5;
  long lVar6;
  undefined8 uVar7;
  ulong uVar8;
  ulong *puVar9;
  long lVar10;
  long *plVar11;
  ulong uVar12;
  ulong uVar13;
  ulong *puVar14;
  long lVar15;
  ulong *puVar16;
  long lVar17;
  long *plVar18;
  long lVar19;
  long *plVar20;
  long *plVar21;
  long *plVar22;
  long unaff_x19;
  ulong unaff_x20;
  ulong uVar23;
/* wm:watermarked copy - do not remove */
  undefined8 unaff_x21;
  undefined1 *puVar24;
  uint uVar25;
  ulong unaff_x22;
  long *unaff_x23;
  long unaff_x24;
  ulong unaff_x25;
  ulong *unaff_x26;
  ulong *puVar26;
  undefined8 *unaff_x27;
  undefined8 *puVar27;
  undefined1 *unaff_x28;
  ulong uVar28;
  long *plVar29;
  undefined1 *unaff_x29;
  undefined *unaff_x30;
  undefined1 auVar30 [16];
  
  puVar9 = (ulong *)0x0;
  uVar13 = 0;
  puVar3 = (undefined1 *)register0x00000008;
/* unlicensed copy if this notice is missing */
  lVar6 = 0;
  uVar23 = param_4 & 0xffffffff;
  while( true ) {
    uVar12 = uVar23;
    plVar11 = param_3;
    lVar10 = lVar6;
    uVar8 = param_2;
    auVar30._8_8_ = lVar10;
    auVar30._0_8_ = puVar9;
    *(undefined1 **)(puVar3 + -0x60) = unaff_x28;
    *(undefined8 **)(puVar3 + -0x58) = unaff_x27;
    *(ulong **)(puVar3 + -0x50) = unaff_x26;
    *(ulong *)(puVar3 + -0x48) = unaff_x25;
    *(long *)(puVar3 + -0x40) = unaff_x24;
    *(long **)(puVar3 + -0x38) = unaff_x23;
    *(ulong *)(puVar3 + -0x30) = unaff_x22;
    *(undefined8 *)(puVar3 + -0x28) = unaff_x21;
    *(ulong *)(puVar3 + -0x20) = unaff_x20;
    *(long *)(puVar3 + -0x18) = unaff_x19;
/*
   proprietary - see LICENSE - do not sell
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
    *(undefined1 **)(puVar3 + -0x10) = unaff_x29;
    *(undefined **)(puVar3 + -8) = unaff_x30;
    unaff_x29 = puVar3 + -0x10;
    *(undefined8 *)(puVar3 + -0x70) = *(undefined8 *)PTR____stack_chk_guard_01f20200;
    if ((((lVar10 == 0) && ((uVar13 & 1) == 0)) && (uVar12 == 0)) &&
       (uVar23 = uVar8, *(char *)(*(long *)(uVar8 & 0xfffffffffffffff0) + 0x10) == '\''))
    goto code_r0x010046a4;
    puVar24 = puVar3 + -0x180;
    *(undefined1 **)(puVar3 + -0x198) = puVar24;
    *(undefined1 **)(puVar3 + -400) = puVar24;
    *(undefined1 **)(puVar3 + -0x188) = puVar3 + -0x100;
    func_0x0114f568(puVar3 + -0x198,uVar8,puVar9,lVar10,plVar11,uVar12,uVar13);
    *(undefined8 *)(puVar3 + -0x1a0) = 0;
    lVar6 = func_0x0174fdd0(param_1 + 0x2d0,puVar3 + -0x198,puVar3 + -0x1a0);
    if (lVar6 != 0) break;
    *(undefined1 **)(puVar3 + -0x1b0) = puVar24;
    *(int *)(puVar3 + -0x1b4) = (int)uVar13;
    *(ulong **)(puVar3 + -0x1c0) = puVar9;
    uVar25 = (uint)uVar12;
/*  do not claim this as your own  */
    param_3 = plVar11;
    uVar23 = uVar12;
    if (lVar10 == 0) {
      lVar6 = *(long *)(uVar8 & 0xfffffffffffffff0);
      if ((lVar6 == 0) || ((*(uint *)(lVar6 + 0x10) & 0xfe) != 0x26)) {
        if ((*(uint *)(*(long *)(*(ulong *)(lVar6 + 8) & 0xfffffffffffffff0) + 0x10) & 0xfe) == 0x26
           ) {
          lVar6 = func_0x01148f40(lVar6);
          if ((*(uint *)(lVar6 + 0x10) & 0xfe) != 0x26) {
            func_0x0174f200(&UNK_01c88bc8);
          }
          goto code_r0x010041e8;
        }
        *(undefined8 *)(puVar3 + -0x1a8) = 0;
        *(undefined4 *)(puVar3 + -0x1d0) = 1;
        puVar26 = puVar9;
      }
      else {
code_r0x010041e8:
        auVar30 = func_0x0114a2a4(lVar6);
        lVar17 = auVar30._8_8_;
        puVar16 = auVar30._0_8_;
        lVar6 = lVar17 * 8;
        puVar9 = puVar16 + lVar17;
        if (lVar17 != 0) goto code_r0x01004204;
        *(undefined8 *)(puVar3 + -0x1a8) = 0;
        *(undefined4 *)(puVar3 + -0x1d0) = 1;
        puVar26 = puVar16;
      }
      lVar6 = 0;
      unaff_x27 = (undefined8 *)((long)&MACH_HEADER.magic + 1);
      if (uVar25 != 0) goto code_r0x01004234;
/* more drops soon - github.com/pengussy */
code_r0x01004350:
      if ((int)unaff_x27 == 0) {
        *(undefined1 **)(puVar3 + -0xa8) = puVar3 + -0x90;
        *(undefined1 **)(puVar3 + -0xa0) = puVar3 + -0x90;
        *(undefined1 **)(puVar3 + -0x98) = puVar3 + -0x70;
        unaff_x27 = (undefined8 *)((long)&MACH_HEADER.magic + 1);
code_r0x01004390:
        puVar16 = (ulong *)(puVar3 + -0x90);
        *(ulong **)(puVar3 + -0x1c8) = puVar16;
        if (4 < *(ulong *)(puVar3 + -0x1a8)) {
          func_0x01755374(puVar3 + -0xa8,puVar16,lVar6,8);
          puVar16 = *(ulong **)(puVar3 + -0xa0);
        }
        if ((*(uint *)(puVar3 + -0x1d0) & 1) == 0) {
          do {
            uVar13 = *puVar26;
            uVar28 = *(ulong *)((uVar13 & 0xfffffffffffffff0) + 8);
            if (*(ulong **)(puVar3 + -0x98) <= puVar16) {
              func_0x01755374(puVar3 + -0xa8,*(undefined8 *)(puVar3 + -0x1c8),0,8);
              puVar16 = *(ulong **)(puVar3 + -0xa0);
            }
/* stripping the watermark breaks the license - github.com/pengussy */
            *puVar16 = uVar28 | uVar13 & 7;
            puVar16 = (ulong *)(*(long *)(puVar3 + -0xa0) + 8);
            *(ulong **)(puVar3 + -0xa0) = puVar16;
            puVar26 = puVar26 + 1;
          } while (puVar26 != puVar9);
        }
        puVar26 = *(ulong **)(puVar3 + -0xa8);
        *(long *)(puVar3 + -0x1a8) = (long)puVar16 - (long)puVar26 >> 3;
        unaff_x28 = puVar3 + -0xe8;
        *(undefined1 **)(puVar3 + -0x100) = unaff_x28;
        *(undefined1 **)(puVar3 + -0xf8) = unaff_x28;
        *(undefined1 **)(puVar3 + -0xf0) = puVar3 + -0xa8;
        unaff_x21 = *(undefined8 *)(puVar3 + -0x1b0);
        uVar13 = (ulong)*(uint *)(puVar3 + -0x1b4);
        puVar9 = puVar26;
        if ((int)unaff_x27 == 0) goto code_r0x010043fc;
      }
      else {
        if (*(long *)(*(long *)(uVar8 & 0xfffffffffffffff0) + 8) ==
            *(long *)(uVar8 & 0xfffffffffffffff0)) {
          puVar24 = *(undefined1 **)(puVar3 + -0x1b0);
          uVar2 = *(undefined4 *)(puVar3 + -0x1b4);
          uVar23 = func_0x009d11e8(param_1 + 0x790,(uVar25 + (int)lVar10) * 8 + 0x30,0x10);
/* no support for modified copies */
          func_0x0114a09c(uVar23,0,uVar8,*(undefined8 *)(puVar3 + -0x1c0),lVar10,plVar11,uVar12,
                          uVar2);
          *(undefined8 *)(uVar23 + 0x28) = 0;
          puVar9 = *(ulong **)(param_1 + 0x10);
          if (*(ulong **)(param_1 + 0x18) <= puVar9) {
            func_0x01755374(param_1 + 8,param_1 + 0x20,0,8);
            puVar9 = *(ulong **)(param_1 + 0x10);
          }
          *puVar9 = uVar23;
          *(long *)(param_1 + 0x10) = *(long *)(param_1 + 0x10) + 8;
          func_0x0174fce8(param_1 + 0x2d0,(undefined8 *)(uVar23 + 0x28),
                          *(undefined8 *)(puVar3 + -0x1a0));
code_r0x01004690:
          if ((*(undefined1 **)(puVar3 + -0x198) != puVar24) &&
             (*(undefined1 **)(puVar3 + -0x198) != (undefined1 *)0x0)) {
            __ZdaPv();
          }
code_r0x010046a4:
          if (*(long *)PTR____stack_chk_guard_01f20200 == *(long *)(puVar3 + -0x70)) {
            return uVar23;
          }
          uVar7 = ___stack_chk_fail();
          if (*(long *)(puVar3 + -0x198) == *(long *)(puVar3 + -0x1b0) ||
              *(long *)(puVar3 + -0x198) == 0) goto code_r0x010047d0;
code_r0x01004784:
          do {
            __ZdaPv();
            uVar7 = __Unwind_Resume(uVar7);
            if (*(long *)(puVar3 + -0x100) != *(long *)(puVar3 + -0x1d0) &&
                *(long *)(puVar3 + -0x100) != 0) goto code_r0x010047d8;
            if (*(long *)(puVar3 + -0xa8) != *(long *)(puVar3 + -0x1c8) &&
                *(long *)(puVar3 + -0xa8) != 0) goto code_r0x010047f0;
            while (*(long *)(puVar3 + -0x198) == *(long *)(puVar3 + -0x1b0) ||
                   *(long *)(puVar3 + -0x198) == 0) {
code_r0x010047d0:
              while( true ) {
                __Unwind_Resume(uVar7);
/* wm:proprietary - see LICENSE - do not sell */
code_r0x010047d8:
                __ZdaPv();
                if (*(long *)(puVar3 + -0xa8) == *(long *)(puVar3 + -0x1c8) ||
                    *(long *)(puVar3 + -0xa8) == 0) break;
code_r0x010047f0:
                __ZdaPv();
                if (*(long *)(puVar3 + -0x198) != *(long *)(puVar3 + -0x1b0) &&
                    *(long *)(puVar3 + -0x198) != 0) goto code_r0x01004784;
              }
            }
          } while( true );
        }
        puVar24 = puVar3 + -0x90;
        *(undefined1 **)(puVar3 + -0xa8) = puVar24;
        *(undefined1 **)(puVar3 + -0xa0) = puVar24;
        *(undefined1 **)(puVar3 + -0x1c8) = puVar24;
        *(undefined1 **)(puVar3 + -0x98) = puVar3 + -0x70;
        unaff_x28 = puVar3 + -0xe8;
        *(undefined1 **)(puVar3 + -0x100) = unaff_x28;
        *(undefined1 **)(puVar3 + -0xf8) = unaff_x28;
        *(undefined1 **)(puVar3 + -0xf0) = puVar3 + -0xa8;
        unaff_x21 = *(undefined8 *)(puVar3 + -0x1b0);
        uVar13 = (ulong)*(uint *)(puVar3 + -0x1b4);
        puVar9 = puVar26;
      }
    }
/*  watermarked copy - do not remove  */
    else {
      lVar6 = lVar10 * 8;
      puVar16 = puVar9;
      puVar9 = puVar9 + lVar10;
code_r0x01004204:
      do {
        puVar26 = auVar30._0_8_;
        puVar14 = puVar16 + 1;
        lVar17 = *(long *)(*puVar16 & 0xfffffffffffffff0);
        bVar4 = *(long *)(lVar17 + 8) == lVar17;
        unaff_x27 = (undefined8 *)(ulong)bVar4;
        puVar16 = puVar14;
      } while (bVar4 && puVar14 != puVar9);
      *(long *)(puVar3 + -0x1a8) = auVar30._8_8_;
      *(undefined4 *)(puVar3 + -0x1d0) = 0;
      if (uVar25 == 0) goto code_r0x01004350;
code_r0x01004234:
      lVar17 = (**(code **)(*(long *)*plVar11 + 0x20))();
      lVar15 = *plVar11;
      if (lVar17 == lVar15) {
        if (uVar25 != 1) {
          uVar13 = 1;
          do {
            iVar5 = func_0x0107bb90(*(undefined8 *)(lVar15 + 0x20),
                                    *(undefined8 *)(plVar11[uVar13] + 0x20));
            if (-1 < iVar5) goto code_r0x01004250;
            lVar17 = (**(code **)(*(long *)plVar11[uVar13] + 0x20))();
            lVar15 = plVar11[uVar13];
            if (lVar17 != lVar15) goto code_r0x01004250;
            uVar1 = (int)uVar13 + 1;
            uVar13 = (ulong)uVar1;
          } while (uVar25 != uVar1);
        }
        goto code_r0x01004350;
      }
/* WM: watermarked copy - do not remove @ discord.gg/sdkhDjTex */
code_r0x01004250:
      puVar24 = puVar3 + -0x90;
      *(undefined1 **)(puVar3 + -0xa8) = puVar24;
      *(undefined1 **)(puVar3 + -0xa0) = puVar24;
      *(undefined1 **)(puVar3 + -0x98) = puVar3 + -0x70;
      if ((int)unaff_x27 == 0) goto code_r0x01004390;
      *(undefined1 **)(puVar3 + -0x1c8) = puVar24;
      *(undefined1 **)(puVar3 + -0x100) = puVar3 + -0xe8;
      *(undefined1 **)(puVar3 + -0xf8) = puVar3 + -0xe8;
      *(undefined1 **)(puVar3 + -0xf0) = puVar3 + -0xa8;
code_r0x010043fc:
      func_0x00c69c80(puVar3 + -0x100,puVar3 + -0xe8,plVar11,plVar11 + uVar12);
      *(undefined1 **)(puVar3 + -0x1d0) = puVar3 + -0xe8;
      puVar27 = *(undefined8 **)(puVar3 + -0x100);
      plVar29 = puVar27 + uVar12;
      *(ulong *)(puVar3 + -0x1e0) = uVar12 * 8;
      *(undefined8 **)(puVar3 + -0x1d8) = puVar27;
      if (uVar25 < 2) {
        if (uVar25 != 0) goto code_r0x010044b4;
code_r0x01004514:
        plVar22 = *(long **)(puVar3 + -0x1d8);
        unaff_x27 = puVar27;
      }
      else {
        _qsort(puVar27,uVar12,8,FUN_010130a4);
code_r0x010044b4:
        do {
          uVar7 = (**(code **)(*(long *)*puVar27 + 0x20))();
          unaff_x27 = puVar27 + 1;
          *puVar27 = uVar7;
          uVar23 = uVar23 - 1;
// WM - stripping the watermark breaks the license
          puVar27 = unaff_x27;
        } while (uVar23 != 0);
        if (uVar25 == 0) goto code_r0x01004514;
        plVar22 = *(long **)(puVar3 + -0x1d8);
        if (uVar12 != 1) {
          lVar6 = *(long *)(puVar3 + -0x1e0) + -0x10;
          plVar18 = plVar22;
          plVar20 = plVar22 + 1;
code_r0x010044f0:
          plVar21 = plVar20 + 1;
          if (*plVar18 != *plVar20) goto code_r0x01004500;
          plVar20 = plVar18;
          if (plVar18 + 2 != plVar29) {
            lVar17 = 0x10;
            lVar15 = *plVar18;
            do {
              lVar19 = *(long *)((long)plVar18 + lVar17);
              if (lVar15 != lVar19) {
                plVar20 = plVar20 + 1;
                *plVar20 = lVar19;
              }
              lVar17 = lVar17 + 8;
/*
 *  watermarked copy - do not remove
 *
 *  @pengussy
 */
              lVar6 = lVar6 + -8;
              lVar15 = lVar19;
            } while (lVar6 != 0);
          }
          plVar29 = plVar20 + 1;
        }
      }
code_r0x010045a0:
      unaff_x21 = *(undefined8 *)(puVar3 + -0x1b0);
      uVar13 = (ulong)*(uint *)(puVar3 + -0x1b4);
      unaff_x28 = *(undefined1 **)(puVar3 + -0x1d0);
      param_3 = *(long **)(puVar3 + -0x100);
      uVar23 = (ulong)((long)plVar29 - (long)plVar22) >> 3 & 0xffffffff;
      puVar9 = puVar26;
    }
    plVar29 = (long *)(puVar3 + -0x1a8);
    unaff_x30 = &UNK_010045dc;
    puVar3 = puVar3 + -0x1e0;
    param_2 = *(ulong *)((uVar8 & 0xfffffffffffffff0) + 8) | uVar8 & 7;
    lVar6 = *plVar29;
    unaff_x19 = param_1;
    unaff_x20 = uVar8;
    unaff_x22 = uVar12;
    unaff_x23 = plVar11;
    unaff_x24 = lVar10;
    unaff_x25 = uVar13;
    unaff_x26 = puVar9;
  }
  uVar23 = lVar6 - 0x28;
  goto code_r0x01004690;
code_r0x01004500:
// unlicensed copy if this notice is missing
  lVar6 = lVar6 + -8;
  plVar18 = plVar18 + 1;
  plVar20 = plVar21;
  if (plVar21 == plVar29) goto code_r0x010045a0;
  goto code_r0x010044f0;
}

