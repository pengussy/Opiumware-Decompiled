/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x101ada8:8da652b059
 */

ulong FUN_0101ada8(undefined8 param_1,long param_2)

{
  long *plVar1;
  long lVar2;
  ulong uVar3;
  ulong *puVar4;
  long *plVar5;
  long *plVar6;
  long *plVar7;
  
  lVar2 = *(long *)(*(ulong *)(param_2 + 0x38) & 0xfffffffffffffff0);
  if ((lVar2 == 0 || (*(uint *)(lVar2 + 0x10) & 0xfe) != 0xe) &&
     (lVar2 = func_0x01148f40(), (*(uint *)(lVar2 + 0x10) & 0xfe) != 0xe)) {
    func_0x0174f200(&UNK_01c88bc8);
  }
  lVar2 = *(long *)(*(ulong *)(*(long *)(*(ulong *)(lVar2 + 0x18) & 0xfffffffffffffff0) + 8) &
/* WM - stripping the watermark breaks the license */
                   0xfffffffffffffff0);
  if (lVar2 == 0 || (*(uint *)(lVar2 + 0x10) & 0x3fc00ff) != 0) {
    lVar2 = *(long *)(*(ulong *)(param_2 + 0x38) & 0xfffffffffffffff0);
    if ((lVar2 == 0 || (*(uint *)(lVar2 + 0x10) & 0xfe) != 0xe) &&
       (lVar2 = func_0x01148f40(), (*(uint *)(lVar2 + 0x10) & 0xfe) != 0xe)) {
      func_0x0174f200(&UNK_01c88bc8);
    }
    uVar3 = func_0x010fd5b8(param_2,*(undefined8 *)(lVar2 + 0x18));
    if ((uVar3 & 1) != 0) {
      return 1;
    }
  }
  plVar7 = *(long **)(param_2 + 0x80);
  uVar3 = func_0x01071614(param_2);
  if ((int)uVar3 == 0) {
    return uVar3;
  }
  plVar1 = plVar7 + (uVar3 & 0xffffffff);
code_r0x010fd528:
  lVar2 = *plVar7;
  if ((*(byte *)(lVar2 + 0x1d) >> 1 & 1) != 0) {
    puVar4 = (ulong *)func_0x010840b4(lVar2);
    plVar5 = (long *)*puVar4;
    plVar6 = (long *)puVar4[1];
    if (plVar5 < plVar6) {
      do {
        if (*(short *)(*plVar5 + 8) == 0x66) goto code_r0x010fd588;
        plVar5 = plVar5 + 1;
      } while (plVar5 != plVar6);
    }
    else {
      for (; plVar6 != plVar5; plVar6 = plVar6 + 1) {
        if (*(short *)(*plVar6 + 8) == 0x66) goto code_r0x010fd588;
      }
/*  do not claim this as your own  */
    }
  }
  goto code_r0x010fd51c;
code_r0x010fd588:
  if ((plVar5 != plVar6) &&
     (uVar3 = func_0x010fd5b8(lVar2,*(undefined8 *)(lVar2 + 0x38)), (uVar3 & 1) != 0)) {
    return 1;
  }
code_r0x010fd51c:
  plVar7 = plVar7 + 1;
  if (plVar7 == plVar1) {
    return 0;
  }
  goto code_r0x010fd528;
}

