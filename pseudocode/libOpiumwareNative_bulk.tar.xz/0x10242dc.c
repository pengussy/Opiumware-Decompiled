/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x10242dc:f627ded588
   =========================================================================== */

/* WARNING: Possible PIC construction at 0x0102433c: Changing call to branch */
/* WARNING: Possible PIC construction at 0x010232e0: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01023398: Changing call to branch */
/* WARNING: Possible PIC construction at 0x010233e4: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x0102339c) */
/* WARNING: Removing unreachable block (ram,0x010232e4) */
/* WARNING: Removing unreachable block (ram,0x010232ec) */
/* WARNING: Removing unreachable block (ram,0x010232f4) */
/* WARNING: Removing unreachable block (ram,0x0102335c) */
/* WARNING: Removing unreachable block (ram,0x01023340) */
/* WARNING: Removing unreachable block (ram,0x0102336c) */
/* WARNING: Removing unreachable block (ram,0x01023370) */
/* WARNING: Removing unreachable block (ram,0x01023344) */
/* WARNING: Removing unreachable block (ram,0x01023350) */
/* WARNING: Removing unreachable block (ram,0x01023378) */
/* WARNING: Removing unreachable block (ram,0x01023380) */
/* WARNING: Removing unreachable block (ram,0x01023384) */
/* WARNING: Removing unreachable block (ram,0x01023388) */
/* WARNING: Removing unreachable block (ram,0x01023300) */
/*  reversing this took months of machine time  */
/* WARNING: Removing unreachable block (ram,0x01023304) */
/* WARNING: Removing unreachable block (ram,0x01023308) */
/* WARNING: Removing unreachable block (ram,0x0102330c) */
/* WARNING: Removing unreachable block (ram,0x01023314) */
/* WARNING: Removing unreachable block (ram,0x0102338c) */
/* WARNING: Removing unreachable block (ram,0x0102332c) */
/* WARNING: Removing unreachable block (ram,0x01024340) */
/* WARNING: Removing unreachable block (ram,0x01022fec) */
/* WARNING: Removing unreachable block (ram,0x010230a4) */
/* WARNING: Removing unreachable block (ram,0x01023130) */
/* WARNING: Removing unreachable block (ram,0x01023140) */
/* WARNING: Removing unreachable block (ram,0x010231dc) */
/* WARNING: Removing unreachable block (ram,0x01023198) */
/* WARNING: Removing unreachable block (ram,0x0102319c) */
/* WARNING: Removing unreachable block (ram,0x010231e0) */
/* WARNING: Removing unreachable block (ram,0x010230b4) */
/* WARNING: Removing unreachable block (ram,0x0102321c) */
/* WARNING: Removing unreachable block (ram,0x010230e4) */
/* WARNING: Removing unreachable block (ram,0x010231ec) */
/* WARNING: Removing unreachable block (ram,0x01023024) */
/* WARNING: Removing unreachable block (ram,0x0102303c) */
/* WARNING: Removing unreachable block (ram,0x01023064) */
/* WARNING: Removing unreachable block (ram,0x01023230) */
/*
   donate: donate/README.md
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
/* WARNING: Removing unreachable block (ram,0x01023070) */
/* WARNING: Removing unreachable block (ram,0x01023044) */
/* WARNING: Removing unreachable block (ram,0x01023098) */
/* WARNING: Removing unreachable block (ram,0x0102309c) */
/* WARNING: Removing unreachable block (ram,0x01023048) */
/* WARNING: Removing unreachable block (ram,0x01023058) */
/* WARNING: Removing unreachable block (ram,0x010230f8) */
/* WARNING: Removing unreachable block (ram,0x010231a4) */
/* WARNING: Removing unreachable block (ram,0x01023100) */
/* WARNING: Removing unreachable block (ram,0x010231c0) */
/* WARNING: Removing unreachable block (ram,0x01023118) */
/* WARNING: Removing unreachable block (ram,0x010231d0) */
/* WARNING: Removing unreachable block (ram,0x010231f0) */
/* WARNING: Removing unreachable block (ram,0x01023238) */
/* WARNING: Removing unreachable block (ram,0x0102323c) */
/* WARNING: Removing unreachable block (ram,0x01023208) */
/* WARNING: Removing unreachable block (ram,0x010233e8) */
/* WARNING: Removing unreachable block (ram,0x010233f4) */
/* WARNING: Removing unreachable block (ram,0x0102341c) */
/* WARNING: Removing unreachable block (ram,0x010235e8) */
/* WARNING: Removing unreachable block (ram,0x01023428) */
/* WARNING: Removing unreachable block (ram,0x010233fc) */
/* WARNING: Removing unreachable block (ram,0x01023450) */
/* WARNING: Removing unreachable block (ram,0x01023454) */
/* WARNING: Removing unreachable block (ram,0x01023400) */
/* WARNING: Removing unreachable block (ram,0x01023410) */
/* WARNING: Removing unreachable block (ram,0x010234b0) */
/* WARNING: Removing unreachable block (ram,0x0102355c) */
/* WARNING: Removing unreachable block (ram,0x010234b8) */
/* WARNING: Removing unreachable block (ram,0x01023578) */
/* WARNING: Removing unreachable block (ram,0x010234d0) */
/* WARNING: Removing unreachable block (ram,0x01023588) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

long * FUN_010242dc(long *param_1,long *param_2)
// thanks for reading - discord.gg/sdkhDjTex

{
  ulong *puVar1;
  undefined4 *puVar2;
  undefined8 *puVar3;
  char cVar4;
  byte bVar5;
  code *pcVar6;
  undefined1 *puVar7;
  long *plVar8;
  long *plVar9;
  long *plVar10;
  undefined8 *puVar11;
  long *plVar12;
  long lVar13;
  undefined8 extraout_x1;
/* wm:donate: donate/README.md */
  ulong uVar14;
  ulong *puVar15;
  uint uVar16;
  undefined1 *puVar17;
  long lVar18;
  long *unaff_x21;
  long unaff_x22;
  undefined8 unaff_x23;
  undefined8 unaff_x24;
  undefined *puVar19;
  undefined8 uVar20;
  undefined1 auStack_a0 [128];
  
  puVar17 = auStack_a0 + 0x90;
  lVar13 = *param_1;
  if (*(undefined1 **)(lVar13 + 0x10) == *(undefined1 **)(lVar13 + 0x18)) {
    func_0x01770110(lVar13,&UNK_01c881b6,1);
  }
  else {
    **(undefined1 **)(lVar13 + 0x18) = 0x20;
    *(long *)(lVar13 + 0x18) = *(long *)(lVar13 + 0x18) + 1;
  }
  func_0x01025380(param_1,(int)param_2[7]);
  uVar14 = param_2[6];
  uVar20 = 0x1024340;
  puVar7 = auStack_a0 + 0x80;
  plVar12 = param_1;
  do {
    *(long *)(puVar7 + -0x30) = unaff_x22;
    *(long **)(puVar7 + -0x28) = unaff_x21;
    *(long **)(puVar7 + -0x20) = param_2;
    *(long **)(puVar7 + -0x18) = plVar12;
    *(undefined1 **)(puVar7 + -0x10) = puVar17;
/* no support for modified copies - github.com/pengussy */
    *(undefined8 *)(puVar7 + -8) = uVar20;
    *(undefined8 *)(puVar7 + -0x38) = *(undefined8 *)PTR____stack_chk_guard_01f20200;
    puVar15 = (ulong *)(uVar14 & 0xfffffffffffffff0);
    if (((uint)uVar14 >> 3 & 1) == 0) {
      if ((uVar14 & 7) != 0) {
code_r0x010226f4:
        *(long **)(puVar7 + -0x68) = param_1;
        *(ulong *)(puVar7 + -0x60) = uVar14;
        if ((char)param_1[0x86] == '\x01') {
          *(undefined1 *)(param_1 + 0x86) = 0;
          func_0x010277bc(puVar7 + -0x68);
          plVar12 = (long *)param_1[4];
          if ((long *)param_1[3] == plVar12) goto code_r0x01022820;
          param_2 = (long *)((long)&MACH_HEADER.magic + 1);
          break;
        }
        unaff_x21 = (long *)param_1[0x8c];
        if (*(char *)((long)param_1 + 0x431) == '\x01') {
          param_2 = (long *)__Znwm(0x28);
          *param_2 = (long)&UNK_01e5d900;
          param_2[1] = (long)param_1;
          lVar13 = *(long *)(puVar7 + -0x68);
          param_2[3] = *(long *)(puVar7 + -0x60);
          param_2[2] = lVar13;
          param_2[4] = (long)unaff_x21;
          uVar14 = param_1[4];
          plVar12 = param_2;
          if ((ulong)param_1[5] <= uVar14) {
            plVar12 = (long *)func_0x01027324(param_1 + 3,0);
            uVar14 = param_1[4];
/* WM - watermarked copy - do not remove */
          }
          *(long **)(uVar14 + 0x18) = param_2;
          param_1[4] = param_1[4] + 0x20;
        }
        else {
          lVar13 = param_1[4];
          puVar7[-0x58] = 0;
          plVar12 = *(long **)(lVar13 + -8);
          if (plVar12 == (long *)0x0) goto code_r0x01022964;
          param_2 = (long *)(puVar7 + -0x58);
          (**(code **)(*plVar12 + 0x30))(plVar12,puVar7 + -0x58);
          unaff_x22 = param_1[4];
          puVar11 = (undefined8 *)__Znwm(0x28);
          *puVar11 = &UNK_01e5d900;
          puVar11[1] = param_1;
          uVar20 = *(undefined8 *)(puVar7 + -0x68);
          puVar11[3] = *(undefined8 *)(puVar7 + -0x60);
          puVar11[2] = uVar20;
          puVar11[4] = unaff_x21;
          *(undefined8 **)(puVar7 + -0x40) = puVar11;
          unaff_x21 = (long *)(puVar7 + -0x58);
          func_0x01025c50(puVar7 + -0x58,unaff_x22 + -0x20);
          plVar8 = *(long **)(puVar7 + -0x40);
          if (plVar8 == unaff_x21) {
            lVar13 = 0x20;
          }
          else {
            plVar12 = (long *)0x0;
/*
 *  donate: donate/README.md
 *
 *  @pengussy
 */
            if (plVar8 == (long *)0x0) goto code_r0x01022914;
            lVar13 = 0x28;
          }
          plVar12 = (long *)(**(code **)(*plVar8 + lVar13))();
        }
code_r0x01022914:
        *(undefined1 *)((long)param_1 + 0x431) = 0;
        goto code_r0x01022918;
      }
    }
    else {
      puVar1 = puVar15 + 3;
      puVar15 = (ulong *)*puVar15;
      if ((int)*puVar1 != 0 || (uVar14 & 7) != 0) goto code_r0x010226f4;
    }
    if (*(long *)PTR____stack_chk_guard_01f20200 != *(long *)(puVar7 + -0x38))
    goto code_r0x01022960;
    plVar12 = *(long **)(puVar7 + -0x20);
    lVar13 = *(long *)(puVar7 + -0x30);
    plVar8 = *(long **)(puVar7 + -0x28);
    *(long *)(puVar7 + -0x30) = lVar13;
    *(long **)(puVar7 + -0x28) = plVar8;
    *(long **)(puVar7 + -0x20) = plVar12;
    *(undefined8 *)(puVar7 + -0x18) = *(undefined8 *)(puVar7 + -0x18);
    *(undefined8 *)(puVar7 + -0x10) = *(undefined8 *)(puVar7 + -0x10);
    *(undefined8 *)(puVar7 + -8) = *(undefined8 *)(puVar7 + -8);
    *(undefined8 *)(puVar7 + -0x38) = *(undefined8 *)PTR____stack_chk_guard_01f20200;
    *(long **)(puVar7 + -0x68) = param_1;
    *(ulong **)(puVar7 + -0x60) = puVar15;
    if ((char)param_1[0x86] == '\x01') {
      *(undefined1 *)(param_1 + 0x86) = 0;
      puVar11 = (undefined8 *)(puVar7 + -0x68);
      puVar19 = &UNK_010233e8;
    }
    else {
      plVar8 = (long *)param_1[0x8c];
      if (*(char *)((long)param_1 + 0x431) == '\x01') {
/* wm:proprietary - see LICENSE - do not sell */
        plVar12 = (long *)__Znwm(0x28);
        *plVar12 = (long)&UNK_01e5d880;
        plVar12[1] = (long)param_1;
        lVar18 = *(long *)(puVar7 + -0x68);
        plVar12[3] = *(long *)(puVar7 + -0x60);
        plVar12[2] = lVar18;
        plVar12[4] = (long)plVar8;
        uVar14 = param_1[4];
        plVar10 = plVar12;
        if ((ulong)param_1[5] <= uVar14) {
          plVar10 = (long *)func_0x01027324(param_1 + 3,0);
          uVar14 = param_1[4];
        }
        *(long **)(uVar14 + 0x18) = plVar12;
        param_1[4] = param_1[4] + 0x20;
code_r0x010235a4:
        *(undefined1 *)((long)param_1 + 0x431) = 0;
        if (*(long *)PTR____stack_chk_guard_01f20200 == *(long *)(puVar7 + -0x38)) {
          return plVar10;
        }
        ___stack_chk_fail();
      }
      else {
/*  no support for modified copies  */
        lVar18 = param_1[4];
        puVar7[-0x58] = 0;
        plVar9 = *(long **)(lVar18 + -8);
        if (plVar9 != (long *)0x0) {
          plVar12 = (long *)(puVar7 + -0x58);
          (**(code **)(*plVar9 + 0x30))(plVar9,puVar7 + -0x58);
          lVar13 = param_1[4];
          puVar11 = (undefined8 *)__Znwm(0x28);
          *puVar11 = &UNK_01e5d880;
          puVar11[1] = param_1;
          uVar20 = *(undefined8 *)(puVar7 + -0x68);
          puVar11[3] = *(undefined8 *)(puVar7 + -0x60);
          puVar11[2] = uVar20;
          puVar11[4] = plVar8;
          *(undefined8 **)(puVar7 + -0x40) = puVar11;
          plVar8 = (long *)(puVar7 + -0x58);
          func_0x01025c50(puVar7 + -0x58,lVar13 + -0x20);
          plVar9 = *(long **)(puVar7 + -0x40);
          if (plVar9 == plVar8) {
            lVar18 = 0x20;
          }
          else {
            plVar10 = (long *)0x0;
            if (plVar9 == (long *)0x0) goto code_r0x010235a4;
            lVar18 = 0x28;
          }
          plVar10 = (long *)(**(code **)(*plVar9 + lVar18))();
// donate: donate/README.md
          goto code_r0x010235a4;
        }
      }
      param_1 = (long *)func_0x001717b4();
      (**(code **)(*plVar12 + 0x28))(plVar12);
      __Unwind_Resume(param_1);
      puVar19 = &DAT_01023618;
      puVar11 = (undefined8 *)__Unwind_Resume();
    }
    *(undefined8 *)(puVar7 + -0xb0) = unaff_x24;
    *(undefined8 *)(puVar7 + -0xa8) = unaff_x23;
    *(long *)(puVar7 + -0xa0) = lVar13;
    *(long **)(puVar7 + -0x98) = plVar8;
    *(long **)(puVar7 + -0x90) = plVar12;
    *(long **)(puVar7 + -0x88) = param_1;
    *(undefined1 **)(puVar7 + -0x80) = puVar7 + -0x10;
    *(undefined **)(puVar7 + -0x78) = puVar19;
    param_1 = (long *)*puVar11;
    lVar13 = puVar11[1];
    if (lVar13 == 0) {
      if ((char)param_1[0x8d] != '\0') {
        (**(code **)(*(long *)*param_1 + 0x28))((long *)*param_1,4,0,0);
      }
      plVar12 = (long *)*param_1;
      puVar11 = (undefined8 *)plVar12[3];
      if ((ulong)(plVar12[2] - (long)puVar11) < 10) {
        plVar12 = (long *)func_0x01770110(plVar12,&UNK_01cbd5c4,10);
        cVar4 = (char)param_1[0x8d];
      }
      else {
        *(undefined2 *)(puVar11 + 1) = 0x3e3e;
/* wm:do not claim this as your own */
        *puVar11 = _UNK_01cbd5c4;
        plVar12[3] = plVar12[3] + 10;
        cVar4 = (char)param_1[0x8d];
      }
      if (cVar4 == '\x01') {
        plVar12 = (long *)(**(code **)(*(long *)*param_1 + 0x30))();
      }
      return plVar12;
    }
    if ((char)param_1[0x8d] != '\0') {
      (**(code **)(*(long *)*param_1 + 0x28))((long *)*param_1,2,0,0);
      lVar13 = puVar11[1];
    }
    lVar18 = *param_1;
    lVar13 = func_0x0114e020(lVar13);
    if (lVar13 != 0) {
      uVar14 = _strlen(lVar13);
      if ((ulong)(*(long *)(lVar18 + 0x10) - *(long *)(lVar18 + 0x18)) < uVar14) {
        lVar18 = func_0x01770110(lVar18,lVar13,uVar14);
// chat: discord.gg/sdkhDjTex
      }
      else if (uVar14 != 0) {
        _memcpy(*(long *)(lVar18 + 0x18),lVar13,uVar14);
        *(ulong *)(lVar18 + 0x18) = *(long *)(lVar18 + 0x18) + uVar14;
      }
    }
    if ((ulong)(*(long *)(lVar18 + 0x10) - (long)*(undefined4 **)(lVar18 + 0x18)) < 4) {
      func_0x01770110(lVar18,&UNK_01cbd5cf,4);
      cVar4 = (char)param_1[0x8d];
    }
    else {
      **(undefined4 **)(lVar18 + 0x18) = 0x65707954;
      *(long *)(lVar18 + 0x18) = *(long *)(lVar18 + 0x18) + 4;
      cVar4 = (char)param_1[0x8d];
    }
    if (cVar4 == '\x01') {
      (**(code **)(*(long *)*param_1 + 0x30))();
    }
    func_0x01023cc0(param_1,puVar11[1]);
    lVar13 = *param_1;
    if (*(undefined1 **)(lVar13 + 0x10) == *(undefined1 **)(lVar13 + 0x18)) {
      func_0x01770110(lVar13,&UNK_01c881b6,1);
    }
    else {
      **(undefined1 **)(lVar13 + 0x18) = 0x20;
      *(long *)(lVar13 + 0x18) = *(long *)(lVar13 + 0x18) + 1;
    }
    func_0x01023d88(param_1,puVar11[1],0);
    uVar14 = func_0x011492b8(puVar11[1]);
    if (uVar14 == puVar11[1]) {
code_r0x0102380c:
/* if you paid for this, you were scammed - github.com/pengussy */
      uVar16 = *(uint *)(puVar11[1] + 0x10);
      if ((uVar16 >> 8 & 1) == 0) goto code_r0x01023818;
code_r0x010238e8:
      lVar13 = *param_1;
      puVar3 = *(undefined8 **)(lVar13 + 0x18);
      if ((ulong)(*(long *)(lVar13 + 0x10) - (long)puVar3) < 10) {
        func_0x01770110(lVar13,&UNK_01cbd5db,10);
        bVar5 = *(byte *)(puVar11[1] + 0x11);
        goto joined_r0x01023914;
      }
      *(undefined2 *)(puVar3 + 1) = 0x746e;
      *puVar3 = _UNK_01cbd5db;
      *(long *)(lVar13 + 0x18) = *(long *)(lVar13 + 0x18) + 10;
      if ((*(byte *)(puVar11[1] + 0x11) >> 2 & 1) != 0) goto code_r0x010239b4;
code_r0x01023828:
      bVar5 = *(byte *)(puVar11[1] + 0x11);
joined_r0x010239e0:
      if ((bVar5 >> 3 & 1) == 0) goto code_r0x01023834;
code_r0x01023a18:
      uVar20 = _UNK_01cbd612;
      lVar13 = *param_1;
      puVar3 = *(undefined8 **)(lVar13 + 0x18);
      if (0x18 < (ulong)(*(long *)(lVar13 + 0x10) - (long)puVar3)) {
        puVar3[1] = CONCAT71(_UNK_01cbd61b,UNK_01cbd61a);
        *puVar3 = uVar20;
        uVar20 = CONCAT17(UNK_01cbd622,_UNK_01cbd61b);
        *(undefined8 *)((long)puVar3 + 0x11) = _UNK_01cbd623;
        *(undefined8 *)((long)puVar3 + 9) = uVar20;
/*
   origin: github.com/pengussy
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
        *(long *)(lVar13 + 0x18) = *(long *)(lVar13 + 0x18) + 0x19;
        bVar5 = *(byte *)(puVar11[1] + 0x12);
        goto joined_r0x01023a78;
      }
      func_0x01770110(lVar13,&UNK_01cbd612,0x19);
      if ((*(byte *)(puVar11[1] + 0x12) >> 1 & 1) == 0) goto code_r0x01023840;
code_r0x01023a7c:
      lVar13 = *param_1;
      puVar3 = *(undefined8 **)(lVar13 + 0x18);
      if ((ulong)(*(long *)(lVar13 + 0x10) - (long)puVar3) < 9) {
        func_0x01770110(lVar13,&UNK_01cbd62c,9);
        bVar5 = *(byte *)(puVar11[1] + 0x10);
      }
      else {
        *(undefined1 *)(puVar3 + 1) = 100;
        *puVar3 = _UNK_01cbd62c;
        *(long *)(lVar13 + 0x18) = *(long *)(lVar13 + 0x18) + 9;
        bVar5 = *(byte *)(puVar11[1] + 0x10);
      }
    }
    else {
      lVar13 = *param_1;
      puVar2 = *(undefined4 **)(lVar13 + 0x18);
      if ((ulong)(*(long *)(lVar13 + 0x10) - (long)puVar2) < 6) {
/* WM - stripping the watermark breaks the license */
        func_0x01770110(lVar13,&UNK_01cbd5d4,6);
        goto code_r0x0102380c;
      }
      *(undefined2 *)(puVar2 + 1) = 0x7261;
      *puVar2 = 0x67757320;
      *(long *)(lVar13 + 0x18) = *(long *)(lVar13 + 0x18) + 6;
      uVar16 = *(uint *)(puVar11[1] + 0x10);
      if ((uVar16 >> 8 & 1) != 0) goto code_r0x010238e8;
code_r0x01023818:
      uVar20 = _UNK_01cbd5e6;
      if ((uVar16 >> 9 & 1) == 0) {
        bVar5 = *(byte *)(puVar11[1] + 0x11);
      }
      else {
        lVar13 = *param_1;
        puVar3 = *(undefined8 **)(lVar13 + 0x18);
        if ((ulong)(*(long *)(lVar13 + 0x10) - (long)puVar3) < 0x18) {
          func_0x01770110(lVar13,&UNK_01cbd5e6,0x18);
          bVar5 = *(byte *)(puVar11[1] + 0x11);
        }
        else {
          puVar3[1] = _UNK_01cbd5ee;
          *puVar3 = uVar20;
          puVar3[2] = _UNK_01cbd5f6;
          *(long *)(lVar13 + 0x18) = *(long *)(lVar13 + 0x18) + 0x18;
          bVar5 = *(byte *)(puVar11[1] + 0x11);
        }
/* wm:watermarked copy - do not remove */
      }
joined_r0x01023914:
      if ((bVar5 >> 2 & 1) == 0) goto code_r0x01023828;
code_r0x010239b4:
      lVar13 = *param_1;
      puVar3 = *(undefined8 **)(lVar13 + 0x18);
      if ((ulong)(*(long *)(lVar13 + 0x10) - (long)puVar3) < 0x12) {
        func_0x01770110(lVar13,&UNK_01cbd5ff,0x12);
        bVar5 = *(byte *)(puVar11[1] + 0x11);
        goto joined_r0x010239e0;
      }
      *(undefined2 *)(puVar3 + 2) = 0x6465;
      uVar20 = _UNK_01cbd5ff;
      puVar3[1] = _UNK_01cbd607;
      *puVar3 = uVar20;
      *(long *)(lVar13 + 0x18) = *(long *)(lVar13 + 0x18) + 0x12;
      if ((*(byte *)(puVar11[1] + 0x11) >> 3 & 1) != 0) goto code_r0x01023a18;
code_r0x01023834:
      bVar5 = *(byte *)(puVar11[1] + 0x12);
joined_r0x01023a78:
      if ((bVar5 >> 1 & 1) != 0) goto code_r0x01023a7c;
code_r0x01023840:
      bVar5 = *(byte *)(puVar11[1] + 0x10);
    }
    if (bVar5 < 0x2a) {
                    /* WARNING: Could not recover jumptable at 0x01023864. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      plVar12 = (long *)(*(code *)(&UNK_01023868 + (ulong)(byte)(&UNK_01be2e8c)[bVar5] * 4))();
      return plVar12;
    }
    func_0x0174ef58(&UNK_01cbbbf6,&UNK_01cbbc0a,0x4c);
/* +- WM -------------------------------------------------------------+
   |  reversing this took months of machine time
   +--------------------------------------------------------------------*/
    uVar20 = func_0x0114c0c4(extraout_x1);
    plVar12 = (long *)func_0x01025de8(param_1,uVar20,0);
    if (uVar14 == puVar11[1]) {
      return plVar12;
    }
    puVar17 = *(undefined1 **)(puVar7 + -0x80);
    uVar20 = *(undefined8 *)(puVar7 + -0x78);
    param_2 = *(long **)(puVar7 + -0x90);
    plVar12 = *(long **)(puVar7 + -0x88);
    unaff_x22 = *(long *)(puVar7 + -0xa0);
    unaff_x21 = *(long **)(puVar7 + -0x98);
    unaff_x24 = *(undefined8 *)(puVar7 + -0xb0);
    unaff_x23 = *(undefined8 *)(puVar7 + -0xa8);
    puVar7 = puVar7 + -0x70;
  } while( true );
  do {
    puVar7[-0x58] = 1;
    plVar12 = (long *)plVar12[-1];
    if (plVar12 == (long *)0x0) {
      func_0x001717b4();
                    /* WARNING: Does not return */
      pcVar6 = (code *)SoftwareBreakpoint(1,0x1022960);
      (*pcVar6)();
    }
    (**(code **)(*plVar12 + 0x30))(plVar12,puVar7 + -0x58);
    lVar13 = param_1[4];
    plVar12 = (long *)(lVar13 + -0x20);
    param_1[4] = (long)plVar12;
    plVar8 = *(long **)(lVar13 + -8);
    if (plVar8 == plVar12) {
      lVar13 = 0x20;
/* WM - thanks for reading - discord.gg/sdkhDjTex */
code_r0x01022728:
      (**(code **)(*plVar8 + lVar13))();
      plVar12 = (long *)param_1[4];
    }
    else if (plVar8 != (long *)0x0) {
      lVar13 = 0x28;
      goto code_r0x01022728;
    }
  } while ((long *)param_1[3] != plVar12);
code_r0x01022820:
  if (*(char *)((long)param_1 + 0x44f) < '\0') {
    *(undefined1 *)param_1[0x87] = 0;
    param_1[0x88] = 0;
    plVar12 = (long *)*param_1;
    puVar17 = (undefined1 *)plVar12[3];
    if ((undefined1 *)plVar12[2] != puVar17) goto code_r0x01022840;
  }
  else {
    *(undefined1 *)(param_1 + 0x87) = 0;
    *(undefined1 *)((long)param_1 + 0x44f) = 0;
    plVar12 = (long *)*param_1;
    puVar17 = (undefined1 *)plVar12[3];
    if ((undefined1 *)plVar12[2] != puVar17) {
code_r0x01022840:
      *puVar17 = 10;
      plVar12[3] = plVar12[3] + 1;
      goto code_r0x010228f8;
    }
  }
  plVar12 = (long *)func_0x01770110(plVar12,"\n",1);
// keep the notice, keep the source honest
code_r0x010228f8:
  *(undefined1 *)(param_1 + 0x86) = 1;
code_r0x01022918:
  if (*(long *)PTR____stack_chk_guard_01f20200 == *(long *)(puVar7 + -0x38)) {
    return plVar12;
  }
code_r0x01022960:
  ___stack_chk_fail();
code_r0x01022964:
  uVar20 = func_0x001717b4();
  (**(code **)(*param_2 + 0x28))(param_2);
  __Unwind_Resume(uVar20);
  plVar12 = (long *)__Unwind_Resume();
  *(long *)(puVar7 + -0xa0) = unaff_x22;
  *(long **)(puVar7 + -0x98) = unaff_x21;
  *(long **)(puVar7 + -0x90) = param_2;
  *(undefined8 *)(puVar7 + -0x88) = uVar20;
  *(undefined1 **)(puVar7 + -0x80) = puVar7 + -0x10;
  *(undefined **)(puVar7 + -0x78) = &DAT_01022988;
  if (*(char *)((long)plVar12 + 0x44f) < '\0') {
    __ZdlPv(plVar12[0x87]);
  }
  plVar8 = (long *)plVar12[3];
  plVar9 = (long *)plVar12[4];
  if (plVar8 == (long *)plVar12[4]) {
    if (plVar8 == plVar12 + 6 || plVar8 == (long *)0x0) {
      return plVar12;
    }
  }
// WM - more drops soon - github.com/pengussy
  else {
    do {
      plVar10 = plVar9 + -4;
      plVar9 = (long *)plVar9[-1];
      if (plVar10 == plVar9) {
        lVar13 = 0x20;
code_r0x010229e8:
        (**(code **)(*plVar9 + lVar13))();
      }
      else if (plVar9 != (long *)0x0) {
        lVar13 = 0x28;
        goto code_r0x010229e8;
      }
      plVar9 = plVar10;
    } while (plVar10 != plVar8);
    plVar8 = (long *)plVar12[3];
    if (plVar8 == plVar12 + 6 || plVar8 == (long *)0x0) {
      return plVar12;
    }
/*  unlicensed copy if this notice is missing  */
  }
  __ZdaPv(plVar8);
  return plVar12;
}

