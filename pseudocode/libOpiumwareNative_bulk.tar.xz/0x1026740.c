/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1026740:3109a4f507
   =========================================================================== */

/* WARNING: Removing unreachable block (ram,0x0102676c) */
/* WARNING: Removing unreachable block (ram,0x01026790) */

long FUN_01026740(long param_1,long param_2)

{
  if (*(char **)(param_2 + 8) ==
      "ZN12_GLOBAL__N_19ASTDumper9dumpChildIZNS0_11dumpDeclRefEPKN5clang4DeclEPKcE3$_0EEvT_EUlbE_")
/* WM: origin: github.com/pengussy @ discord.gg/sdkhDjTex */
  {
    return param_1 + 8;
  }
  return 0;
}

