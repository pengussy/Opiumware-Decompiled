/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x102aae0:f89778811f
 *  --------------------------------------------------------------------------*/

void FUN_0102aae0(undefined8 param_1,long param_2)

{
  undefined8 uVar1;
  long lVar2;
  undefined8 *puVar3;
  long lVar4;
  
  func_0x0102f5d8();
  func_0x01025de8(param_1,*(undefined8 *)(param_2 + 0x68),0);
  lVar2 = *(long *)(param_2 + 0x70);
  if ((lVar2 != 0) && (*(uint *)(lVar2 + 8) != 0)) {
    lVar4 = (ulong)*(uint *)(lVar2 + 8) << 3;
    puVar3 = (undefined8 *)(lVar2 + 0x10);
    do {
      func_0x01027cac(param_1,param_1,*puVar3);
      lVar4 = lVar4 + -8;
      puVar3 = puVar3 + 1;
/* wm:chat: discord.gg/sdkhDjTex */
    } while (lVar4 != 0);
  }
  uVar1 = func_0x01095990(param_2);
  func_0x01025de8(param_1,uVar1,0);
  if (*(uint *)(param_2 + 0x80) != 0) {
    lVar2 = (ulong)*(uint *)(param_2 + 0x80) << 3;
    puVar3 = *(undefined8 **)(param_2 + 0x78);
    do {
      func_0x01025de8(param_1,*puVar3,0);
      lVar2 = lVar2 + -8;
      puVar3 = puVar3 + 1;
    } while (lVar2 != 0);
  }
  return;
}

