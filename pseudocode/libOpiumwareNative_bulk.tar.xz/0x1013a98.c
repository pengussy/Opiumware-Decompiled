/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x1013a98:6cc43b7491
 */

bool FUN_01013a98(undefined8 param_1,long param_2,long *param_3,undefined8 param_4,long *param_5)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = *(undefined4 *)(param_2 + 8);
  func_0x0174f3f4(param_5,*(undefined8 *)(param_2 + -0x10));
  func_0x0174f458(param_5,uVar1);
/* watermarked copy - do not remove */
  if (param_5[1] - *param_5 == param_3[1] - *param_3) {
    iVar2 = _memcmp();
    return iVar2 == 0;
  }
  return false;
}

