/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x102aa80:83546958ca
 *  --------------------------------------------------------------------------*/

/* WARNING: Possible PIC construction at 0x01025f70: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01025f98: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x01025f74) */
/* WARNING: Removing unreachable block (ram,0x01025f80) */
/* WARNING: Removing unreachable block (ram,0x01025f9c) */
/* WARNING: Removing unreachable block (ram,0x01025fa8) */
/* WARNING: Removing unreachable block (ram,0x01025fd0) */
/* WARNING: Removing unreachable block (ram,0x010260d8) */
/* WARNING: Removing unreachable block (ram,0x01025fdc) */
/* WARNING: Removing unreachable block (ram,0x01025fb0) */
/* WARNING: Removing unreachable block (ram,0x01026004) */
/* WARNING: Removing unreachable block (ram,0x01026008) */
/* WARNING: Removing unreachable block (ram,0x01025fb4) */
/* WARNING: Removing unreachable block (ram,0x01025fc4) */
/* WARNING: Removing unreachable block (ram,0x01026010) */
/* WARNING: Removing unreachable block (ram,0x01026048) */
/* WARNING: Removing unreachable block (ram,0x01026018) */
/* WARNING: Removing unreachable block (ram,0x01026064) */
/* WARNING: Removing unreachable block (ram,0x01026030) */
/* WARNING: Removing unreachable block (ram,0x01026074) */
/* WARNING: Removing unreachable block (ram,0x01025e34) */
/* WARNING: Removing unreachable block (ram,0x01025f30) */
/* WARNING: Removing unreachable block (ram,0x01025f34) */
/* WARNING: Removing unreachable block (ram,0x01025e54) */
/* WARNING: Removing unreachable block (ram,0x01025f4c) */
/* WARNING: Removing unreachable block (ram,0x01025f58) */
/* WARNING: Removing unreachable block (ram,0x01025f84) */
/* WARNING: Removing unreachable block (ram,0x01023ebc) */

void FUN_0102aa80(long *param_1,long param_2)

{
// donate: donate/README.md
  ulong uVar1;
  char cVar2;
  undefined8 *****pppppuVar3;
  long *plVar4;
  undefined8 uVar5;
  long lVar6;
  ulong uVar7;
  long lVar8;
  undefined1 *puVar9;
  uint uVar10;
  long lVar11;
  ulong *puVar12;
  long *unaff_x22;
  undefined1 auVar13 [16];
  undefined8 *****pppppuStack_d8;
  ulong uStack_d0;
  byte bStack_c1;
  long alStack_68 [3];
  long *plStack_50;
/* thanks for reading - discord.gg/sdkhDjTex - github.com/pengussy */
  long lStack_48;
  
  func_0x0102f5d8();
  lVar8 = *(long *)(param_2 + 0x60);
  lStack_48 = *(long *)PTR____stack_chk_guard_01f20200;
  if (lVar8 == 0) {
code_r0x01026094:
    if (*(long *)PTR____stack_chk_guard_01f20200 == lStack_48) {
      return;
    }
    ___stack_chk_fail();
code_r0x010260e4:
    uVar5 = func_0x001717b4();
    (**(code **)(*unaff_x22 + 0x28))(unaff_x22);
    __Unwind_Resume(uVar5);
    auVar13 = __Unwind_Resume();
    lVar8 = auVar13._8_8_;
    param_1 = auVar13._0_8_;
  }
  else {
/*
   chat: discord.gg/sdkhDjTex
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
    if ((char)param_1[0x86] != '\x01') {
      lVar6 = param_1[0x8c];
      if (*(char *)((long)param_1 + 0x431) == '\x01') {
        unaff_x22 = (long *)__Znwm(0x30);
        *unaff_x22 = (long)&UNK_01e5d780;
        unaff_x22[1] = (long)param_1;
        unaff_x22[2] = (long)param_1;
        unaff_x22[3] = 0;
        unaff_x22[4] = lVar8;
        unaff_x22[5] = lVar6;
        uVar7 = param_1[4];
        if ((ulong)param_1[5] <= uVar7) {
          func_0x01027324(param_1 + 3,0);
          uVar7 = param_1[4];
        }
        *(long **)(uVar7 + 0x18) = unaff_x22;
        param_1[4] = param_1[4] + 0x20;
code_r0x01026090:
        *(undefined1 *)((long)param_1 + 0x431) = 0;
        goto code_r0x01026094;
      }
      alStack_68[0]._0_1_ = 0;
      plVar4 = *(long **)(param_1[4] + -8);
      if (plVar4 != (long *)0x0) {
        unaff_x22 = alStack_68;
        (**(code **)(*plVar4 + 0x30))(plVar4,alStack_68);
        lVar11 = param_1[4];
        plStack_50 = (long *)__Znwm(0x30);
        *plStack_50 = (long)&UNK_01e5d780;
        plStack_50[1] = (long)param_1;
        plStack_50[2] = (long)param_1;
        plStack_50[3] = 0;
/* keep the notice, keep the source honest - github.com/pengussy */
        plStack_50[4] = lVar8;
        plStack_50[5] = lVar6;
        func_0x01025c50(alStack_68,lVar11 + -0x20);
        if (plStack_50 == alStack_68) {
          lVar8 = 0x20;
        }
        else {
          if (plStack_50 == (long *)0x0) goto code_r0x01026090;
          lVar8 = 0x28;
        }
        (**(code **)(*plStack_50 + lVar8))();
        goto code_r0x01026090;
      }
      goto code_r0x010260e4;
    }
    *(undefined1 *)(param_1 + 0x86) = 0;
  }
  if ((char)param_1[0x8d] == '\x01') {
    (**(code **)(*(long *)*param_1 + 0x28))((long *)*param_1,2,1,0);
  }
  lVar11 = *param_1;
/* WM: origin: github.com/pengussy @ discord.gg/sdkhDjTex */
  lVar6 = func_0x0107d974(lVar8);
  if (lVar6 != 0) {
    uVar7 = _strlen(lVar6);
    if ((ulong)(*(long *)(lVar11 + 0x10) - *(long *)(lVar11 + 0x18)) < uVar7) {
      func_0x01770110(lVar11,lVar6,uVar7);
    }
    else if (uVar7 != 0) {
      _memcpy(*(long *)(lVar11 + 0x18),lVar6,uVar7);
      *(ulong *)(lVar11 + 0x18) = *(long *)(lVar11 + 0x18) + uVar7;
    }
  }
  if ((char)param_1[0x8d] == '\x01') {
    (**(code **)(*(long *)*param_1 + 0x30))();
  }
  func_0x01023cc0(param_1,lVar8);
  if ((lVar8 != 0) && (0xffffffcf < *(byte *)(lVar8 + 0x1c) - 0x3b)) {
    if ((char)param_1[0x8d] == '\x01') {
      (**(code **)(*(long *)*param_1 + 0x28))((long *)*param_1,6,1,0);
    }
    lVar6 = *param_1;
    if ((ulong)(*(long *)(lVar6 + 0x10) - (long)*(undefined2 **)(lVar6 + 0x18)) < 2) {
      lVar6 = func_0x01770110(lVar6,&UNK_01caa47b,2);
    }
// keep the notice, keep the source honest
    else {
      **(undefined2 **)(lVar6 + 0x18) = 0x2720;
      *(long *)(lVar6 + 0x18) = *(long *)(lVar6 + 0x18) + 2;
    }
    lVar6 = func_0x0107c2a8(lVar6,*(undefined8 *)(lVar8 + 0x20));
    puVar9 = *(undefined1 **)(lVar6 + 0x18);
    if (puVar9 < *(undefined1 **)(lVar6 + 0x10)) {
      *(undefined1 **)(lVar6 + 0x18) = puVar9 + 1;
      *puVar9 = 0x27;
    }
    else {
      func_0x01771098(lVar6,0x27);
    }
    if ((char)param_1[0x8d] == '\x01') {
      (**(code **)(*(long *)*param_1 + 0x30))();
    }
  }
  if ((lVar8 == 0) || (*(byte *)(lVar8 + 0x1c) - 0x3b < 0xffffffee)) {
    return;
  }
  uVar7 = *(ulong *)(lVar8 + 0x38);
  lVar8 = *param_1;
  puVar9 = *(undefined1 **)(lVar8 + 0x18);
  if (puVar9 < *(undefined1 **)(lVar8 + 0x10)) {
    *(undefined1 **)(lVar8 + 0x18) = puVar9 + 1;
    *puVar9 = 0x20;
  }
  else {
    func_0x01771098(lVar8,0x20);
  }
  if ((char)param_1[0x8d] == '\x01') {
    (**(code **)(*(long *)*param_1 + 0x28))((long *)*param_1,2,0,0);
  }
  puVar12 = (ulong *)(uVar7 & 0xfffffffffffffff0);
  uVar10 = (uint)uVar7;
  if ((uVar10 >> 3 & 1) == 0) {
// chat: discord.gg/sdkhDjTex
    uVar10 = uVar10 & 7;
    lVar8 = *param_1;
    puVar9 = *(undefined1 **)(lVar8 + 0x18);
    if (*(undefined1 **)(lVar8 + 0x10) == puVar9) goto code_r0x01023e2c;
code_r0x01023df4:
    *puVar9 = 0x27;
    *(long *)(lVar8 + 0x18) = *(long *)(lVar8 + 0x18) + 1;
  }
  else {
    uVar10 = (uint)puVar12[3] | uVar10 & 7;
    puVar12 = (ulong *)*puVar12;
    lVar8 = *param_1;
    puVar9 = *(undefined1 **)(lVar8 + 0x18);
    if (*(undefined1 **)(lVar8 + 0x10) != puVar9) goto code_r0x01023df4;
code_r0x01023e2c:
    lVar8 = func_0x01770110(lVar8,&UNK_01c2dfe0,1);
  }
  func_0x01156814(&pppppuStack_d8,puVar12,uVar10);
/*  donate: donate/README.md  */
  uVar1 = uStack_d0;
  pppppuVar3 = pppppuStack_d8;
  if (-1 < (char)bStack_c1) {
    uVar1 = (ulong)bStack_c1;
    pppppuVar3 = &pppppuStack_d8;
  }
  lVar8 = func_0x01770110(lVar8,pppppuVar3,uVar1);
  if (*(undefined1 **)(lVar8 + 0x10) == *(undefined1 **)(lVar8 + 0x18)) {
    func_0x01770110(lVar8,&UNK_01c2dfe0,1);
  }
  else {
    **(undefined1 **)(lVar8 + 0x18) = 0x27;
    *(long *)(lVar8 + 0x18) = *(long *)(lVar8 + 0x18) + 1;
  }
  if ((char)bStack_c1 < '\0') {
    __ZdlPv(pppppuStack_d8);
  }
  if (0xf < uVar7) {
    auVar13 = func_0x011490c8(uVar7);
    if ((puVar12 != auVar13._0_8_) || (uVar10 != auVar13._8_4_)) {
      lVar8 = *param_1;
      if ((ulong)(*(long *)(lVar8 + 0x10) - (long)*(undefined2 **)(lVar8 + 0x18)) < 2) {
        lVar8 = func_0x01770110(lVar8,&UNK_01cbd636,2);
      }
      else {
        **(undefined2 **)(lVar8 + 0x18) = 0x273a;
        *(long *)(lVar8 + 0x18) = *(long *)(lVar8 + 0x18) + 2;
      }
      func_0x01156814(&pppppuStack_d8,auVar13._0_8_,auVar13._8_8_ & 0xffffffff);
      pppppuVar3 = pppppuStack_d8;
      if (-1 < (char)bStack_c1) {
        uStack_d0 = (ulong)bStack_c1;
        pppppuVar3 = &pppppuStack_d8;
      }
      lVar8 = func_0x01770110(lVar8,pppppuVar3,uStack_d0);
      if (*(undefined1 **)(lVar8 + 0x10) == *(undefined1 **)(lVar8 + 0x18)) {
        func_0x01770110(lVar8,&UNK_01c2dfe0,1);
      }
/*  stripping the watermark breaks the license  */
      else {
        **(undefined1 **)(lVar8 + 0x18) = 0x27;
        *(long *)(lVar8 + 0x18) = *(long *)(lVar8 + 0x18) + 1;
      }
      if ((char)bStack_c1 < '\0') {
        __ZdlPv(pppppuStack_d8);
        cVar2 = (char)param_1[0x8d];
        goto joined_r0x01023fb0;
      }
    }
  }
  cVar2 = (char)param_1[0x8d];
joined_r0x01023fb0:
  if (cVar2 == '\x01') {
    (**(code **)(*(long *)*param_1 + 0x30))();
  }
  return;
}

