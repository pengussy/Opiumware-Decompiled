/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x102e01c:05f1422275
 */

/* WARNING: Possible PIC construction at 0x010232e0: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01023398: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x010232e4) */
/* WARNING: Removing unreachable block (ram,0x010232ec) */
/* WARNING: Removing unreachable block (ram,0x010232f4) */
/* WARNING: Removing unreachable block (ram,0x0102335c) */
/* WARNING: Removing unreachable block (ram,0x01023340) */
/* WARNING: Removing unreachable block (ram,0x0102336c) */
/* WARNING: Removing unreachable block (ram,0x01023370) */
/* WARNING: Removing unreachable block (ram,0x01023344) */
/* WARNING: Removing unreachable block (ram,0x01023350) */
/* WARNING: Removing unreachable block (ram,0x01023378) */
/* WARNING: Removing unreachable block (ram,0x01023380) */
/* WARNING: Removing unreachable block (ram,0x01023384) */
/* WARNING: Removing unreachable block (ram,0x01023388) */
/* WARNING: Removing unreachable block (ram,0x01023300) */
/* WARNING: Removing unreachable block (ram,0x01023304) */
/* WARNING: Removing unreachable block (ram,0x01023308) */
/* WARNING: Removing unreachable block (ram,0x0102330c) */
/* WARNING: Removing unreachable block (ram,0x01023314) */
/* WARNING: Removing unreachable block (ram,0x0102338c) */
/* WARNING: Removing unreachable block (ram,0x0102332c) */
/* WARNING: Removing unreachable block (ram,0x0102339c) */
/* WARNING: Removing unreachable block (ram,0x010233a4) */
/* WARNING: Removing unreachable block (ram,0x0102345c) */
/* WARNING: Removing unreachable block (ram,0x010234e8) */
/* WARNING: Removing unreachable block (ram,0x010234f8) */
/* WARNING: Removing unreachable block (ram,0x01023594) */
/* WARNING: Removing unreachable block (ram,0x01023550) */
/* WARNING: Removing unreachable block (ram,0x01023554) */
/* WARNING: Removing unreachable block (ram,0x01023598) */
/* WARNING: Removing unreachable block (ram,0x0102346c) */
/* WARNING: Removing unreachable block (ram,0x010235d4) */
/* WARNING: Removing unreachable block (ram,0x0102349c) */
/* WARNING: Removing unreachable block (ram,0x010235a4) */
/* WARNING: Removing unreachable block (ram,0x010233dc) */
/* WARNING: Removing unreachable block (ram,0x010233f4) */
/* WARNING: Removing unreachable block (ram,0x0102341c) */
/* WM - chat: discord.gg/sdkhDjTex */
/* WARNING: Removing unreachable block (ram,0x010235e8) */
/* WARNING: Removing unreachable block (ram,0x01023428) */
/* WARNING: Removing unreachable block (ram,0x010233fc) */
/* WARNING: Removing unreachable block (ram,0x01023450) */
/* WARNING: Removing unreachable block (ram,0x01023454) */
/* WARNING: Removing unreachable block (ram,0x01023400) */
/* WARNING: Removing unreachable block (ram,0x01023410) */
/* WARNING: Removing unreachable block (ram,0x010234b0) */
/* WARNING: Removing unreachable block (ram,0x0102355c) */
/* WARNING: Removing unreachable block (ram,0x010234b8) */
/* WARNING: Removing unreachable block (ram,0x01023578) */
/* WARNING: Removing unreachable block (ram,0x010234d0) */
/* WARNING: Removing unreachable block (ram,0x01023588) */
/* WARNING: Removing unreachable block (ram,0x010235a8) */
/* WARNING: Removing unreachable block (ram,0x010235f0) */
/* WARNING: Removing unreachable block (ram,0x010235f4) */
/* WARNING: Removing unreachable block (ram,0x010236a4) */
/* WARNING: Removing unreachable block (ram,0x010236a8) */
/* WARNING: Removing unreachable block (ram,0x010236c4) */
/* WARNING: Removing unreachable block (ram,0x01023878) */
/* WARNING: Removing unreachable block (ram,0x010236d8) */
/* WARNING: Removing unreachable block (ram,0x010238a8) */
/* WARNING: Removing unreachable block (ram,0x010236f4) */
/* WARNING: Removing unreachable block (ram,0x0102363c) */
/* WARNING: Removing unreachable block (ram,0x01023640) */
/* WARNING: Removing unreachable block (ram,0x01023660) */
/* WARNING: Removing unreachable block (ram,0x01023670) */
/* WARNING: Removing unreachable block (ram,0x010236f8) */
/* WARNING: Removing unreachable block (ram,0x010236fc) */
// WM - origin: github.com/pengussy
/* WARNING: Removing unreachable block (ram,0x0102368c) */
/* WARNING: Removing unreachable block (ram,0x01023714) */
/* WARNING: Removing unreachable block (ram,0x01023748) */
/* WARNING: Removing unreachable block (ram,0x01023724) */
/* WARNING: Removing unreachable block (ram,0x0102376c) */
/* WARNING: Removing unreachable block (ram,0x01023744) */
/* WARNING: Removing unreachable block (ram,0x0102377c) */
/* WARNING: Removing unreachable block (ram,0x010237b0) */
/* WARNING: Removing unreachable block (ram,0x01023798) */
/* WARNING: Removing unreachable block (ram,0x010237c0) */
/* WARNING: Removing unreachable block (ram,0x010237e8) */
/* WARNING: Removing unreachable block (ram,0x010238bc) */
/* WARNING: Removing unreachable block (ram,0x010237fc) */
/* WARNING: Removing unreachable block (ram,0x0102380c) */
/* WARNING: Removing unreachable block (ram,0x010238e8) */
/* WARNING: Removing unreachable block (ram,0x01023950) */
/*  thanks for reading - discord.gg/sdkhDjTex  */
/* WARNING: Removing unreachable block (ram,0x01023980) */
/* WARNING: Removing unreachable block (ram,0x010238fc) */
/* WARNING: Removing unreachable block (ram,0x01023918) */
/* WARNING: Removing unreachable block (ram,0x01023818) */
/* WARNING: Removing unreachable block (ram,0x0102391c) */
/* WARNING: Removing unreachable block (ram,0x01023984) */
/* WARNING: Removing unreachable block (ram,0x01023930) */
/* WARNING: Removing unreachable block (ram,0x0102394c) */
/* WARNING: Removing unreachable block (ram,0x0102381c) */
/* WARNING: Removing unreachable block (ram,0x010239b4) */
/* WARNING: Removing unreachable block (ram,0x010239e8) */
/* WARNING: Removing unreachable block (ram,0x010239c8) */
/* WARNING: Removing unreachable block (ram,0x010239e4) */
/* WARNING: Removing unreachable block (ram,0x01023828) */
/* WARNING: Removing unreachable block (ram,0x01023a18) */
/* WARNING: Removing unreachable block (ram,0x01023a4c) */
/* WARNING: Removing unreachable block (ram,0x01023a2c) */
/* WARNING: Removing unreachable block (ram,0x01023a48) */
/* WARNING: Removing unreachable block (ram,0x01023834) */
/* WARNING: Removing unreachable block (ram,0x01023a7c) */
/* WARNING: Removing unreachable block (ram,0x01023ab4) */
/* WARNING: Removing unreachable block (ram,0x01023a90) */
/* WARNING: Removing unreachable block (ram,0x01023ab0) */
/* WARNING: Removing unreachable block (ram,0x01023840) */
/* WARNING: Removing unreachable block (ram,0x01023ae8) */
/* WARNING: Removing unreachable block (ram,0x01023bf4) */
/* WARNING: Removing unreachable block (ram,0x01023c24) */
/* WARNING: Removing unreachable block (ram,0x010226bc) */
/* WARNING: Removing unreachable block (ram,0x01022784) */
/* WARNING: Removing unreachable block (ram,0x010226ec) */
/* WM - origin: github.com/pengussy */
/* WARNING: Removing unreachable block (ram,0x01022798) */
/* WARNING: Removing unreachable block (ram,0x010227b0) */
/* WARNING: Removing unreachable block (ram,0x010226f4) */
/* WARNING: Removing unreachable block (ram,0x010227cc) */
/* WARNING: Removing unreachable block (ram,0x01022858) */
/* WARNING: Removing unreachable block (ram,0x01022868) */
/* WARNING: Removing unreachable block (ram,0x01022904) */
/* WARNING: Removing unreachable block (ram,0x010228c0) */
/* WARNING: Removing unreachable block (ram,0x010228c4) */
/* WARNING: Removing unreachable block (ram,0x01022908) */
/* WARNING: Removing unreachable block (ram,0x010227dc) */
/* WARNING: Removing unreachable block (ram,0x01022944) */
/* WARNING: Removing unreachable block (ram,0x0102280c) */
/* WARNING: Removing unreachable block (ram,0x01022914) */
/* WARNING: Removing unreachable block (ram,0x01022704) */
/* WARNING: Removing unreachable block (ram,0x0102271c) */
/* WARNING: Removing unreachable block (ram,0x01022744) */
/* WARNING: Removing unreachable block (ram,0x01022958) */
/* WARNING: Removing unreachable block (ram,0x01022750) */
/* WARNING: Removing unreachable block (ram,0x01022724) */
/* WARNING: Removing unreachable block (ram,0x01022778) */
/* WARNING: Removing unreachable block (ram,0x0102277c) */
/* WARNING: Removing unreachable block (ram,0x01022728) */
/* WARNING: Removing unreachable block (ram,0x01022738) */
/* WARNING: Removing unreachable block (ram,0x01022820) */
/* WARNING: Removing unreachable block (ram,0x010228cc) */
/* found on a paste site? it was re-uploaded illegally */
/* WARNING: Removing unreachable block (ram,0x01022828) */
/* WARNING: Removing unreachable block (ram,0x010228e8) */
/* WARNING: Removing unreachable block (ram,0x01022840) */
/* WARNING: Removing unreachable block (ram,0x010228f8) */
/* WARNING: Removing unreachable block (ram,0x01022918) */
/* WARNING: Removing unreachable block (ram,0x01022960) */
/* WARNING: Removing unreachable block (ram,0x01022964) */
/* WARNING: Removing unreachable block (ram,0x01022988) */
/* WARNING: Removing unreachable block (ram,0x010229a4) */
/* WARNING: Removing unreachable block (ram,0x010229ac) */
/* WARNING: Removing unreachable block (ram,0x01022a00) */
/* WARNING: Removing unreachable block (ram,0x010229e4) */
/* WARNING: Removing unreachable block (ram,0x01022a10) */
/* WARNING: Removing unreachable block (ram,0x01022a14) */
/* WARNING: Removing unreachable block (ram,0x010229e8) */
/* WARNING: Removing unreachable block (ram,0x010229f4) */
/* WARNING: Removing unreachable block (ram,0x01022a1c) */
/* WARNING: Removing unreachable block (ram,0x01022a28) */
/* WARNING: Removing unreachable block (ram,0x01022a2c) */
/* WARNING: Removing unreachable block (ram,0x01022a30) */
/* WARNING: Removing unreachable block (ram,0x010229b8) */
// chat: discord.gg/sdkhDjTex
/* WARNING: Removing unreachable block (ram,0x010229c0) */
/* WARNING: Removing unreachable block (ram,0x010229c4) */
/* WARNING: Removing unreachable block (ram,0x010229c8) */
/* WARNING: Removing unreachable block (ram,0x010229d0) */
/* WARNING: Removing unreachable block (ram,0x01022930) */
/* WARNING: Removing unreachable block (ram,0x01023c10) */
/* WARNING: Removing unreachable block (ram,0x01023850) */
/* WARNING: Removing unreachable block (ram,0x010235c0) */

void FUN_0102e01c(long *param_1,long param_2)

{
  undefined4 *puVar1;
  byte bVar2;
  code *pcVar3;
  int iVar4;
  long *plVar5;
  long *plVar6;
  undefined8 *puVar7;
  long lVar8;
  long lVar9;
  char *pcVar10;
  ulong uVar11;
  undefined1 *puVar12;
  ulong uVar13;
  ulong unaff_x19;
  long *unaff_x20;
  long *unaff_x21;
  undefined8 uVar14;
  long unaff_x22;
  undefined1 *unaff_x29;
  undefined *unaff_x30;
  
  func_0x0102f5d8();
// do not claim this as your own
  uVar14 = *(undefined8 *)(param_2 + 0x38);
  lVar8 = *param_1;
  puVar12 = *(undefined1 **)(lVar8 + 0x18);
  if (puVar12 < *(undefined1 **)(lVar8 + 0x10)) {
    *(undefined1 **)(lVar8 + 0x18) = puVar12 + 1;
    *puVar12 = 0x20;
  }
  else {
    func_0x01771098(lVar8,0x20);
  }
  func_0x01023d88(param_1,uVar14,1);
  bVar2 = *(byte *)(param_2 + 0x68) & 7;
  if ((*(byte *)(param_2 + 0x68) & 7) != 0) {
    lVar8 = *param_1;
    puVar12 = *(undefined1 **)(lVar8 + 0x18);
    if (puVar12 < *(undefined1 **)(lVar8 + 0x10)) {
      *(undefined1 **)(lVar8 + 0x18) = puVar12 + 1;
      *puVar12 = 0x20;
      lVar9 = func_0x010720a4(bVar2);
    }
    else {
      lVar8 = func_0x01771098(lVar8,0x20);
      lVar9 = func_0x010720a4(bVar2);
    }
    if (lVar9 != 0) {
      uVar13 = _strlen();
      if ((ulong)(*(long *)(lVar8 + 0x10) - *(long *)(lVar8 + 0x18)) < uVar13) {
        func_0x01770110(lVar8,lVar9,uVar13);
      }
      else if (uVar13 != 0) {
        _memcpy(*(long *)(lVar8 + 0x18),lVar9,uVar13);
        *(ulong *)(lVar8 + 0x18) = *(long *)(lVar8 + 0x18) + uVar13;
      }
    }
  }
/* wm:more drops soon - github.com/pengussy */
  iVar4 = func_0x0107232c(param_2);
  if (iVar4 == 2) {
    lVar8 = *param_1;
    pcVar10 = *(char **)(lVar8 + 0x18);
    if ((ulong)(*(long *)(lVar8 + 0x10) - (long)pcVar10) < 0xc) {
      func_0x01770110(lVar8," tls_dynamic",0xc);
    }
    else {
      pcVar10[8] = 'a';
      pcVar10[9] = 'm';
      pcVar10[10] = 'i';
      pcVar10[0xb] = 'c';
      *(undefined8 *)pcVar10 = s_tls_dynamic_01cbda62._0_8_;
      lVar9 = *(long *)(lVar8 + 0x18) + 0xc;
LAB_0102e1c4:
      *(long *)(lVar8 + 0x18) = lVar9;
    }
  }
  else if (iVar4 == 1) {
    lVar8 = *param_1;
    if (3 < (ulong)(*(long *)(lVar8 + 0x10) - (long)*(undefined4 **)(lVar8 + 0x18))) {
      **(undefined4 **)(lVar8 + 0x18) = 0x736c7420;
/*
   origin: github.com/pengussy
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
      lVar9 = *(long *)(lVar8 + 0x18) + 4;
      goto LAB_0102e1c4;
    }
    func_0x01770110(lVar8," tls",4);
  }
  if ((*(byte *)(param_2 + 8) >> 1 & 1) == 0) {
LAB_0102e1f4:
    if (*(char *)(param_2 + 0x1c) == '5') goto LAB_0102e270;
LAB_0102e200:
    if ((*(ushort *)(param_2 + 0x68) >> 8 & 1) == 0) goto LAB_0102e270;
    lVar8 = *param_1;
    puVar1 = *(undefined4 **)(lVar8 + 0x18);
    if ((ulong)(*(long *)(lVar8 + 0x10) - (long)puVar1) < 5) {
      func_0x01770110(lVar8," nrvo",5);
      uVar13 = *(ulong *)(param_2 + 0x60);
    }
    else {
      *(undefined1 *)(puVar1 + 1) = 0x6f;
      *puVar1 = 0x76726e20;
      *(long *)(lVar8 + 0x18) = *(long *)(lVar8 + 0x18) + 5;
      uVar13 = *(ulong *)(param_2 + 0x60);
    }
  }
  else {
    lVar8 = *param_1;
    pcVar10 = *(char **)(lVar8 + 0x18);
    if ((ulong)(*(long *)(lVar8 + 0x10) - (long)pcVar10) < 0x13) {
      func_0x01770110(lVar8," __module_private__",0x13);
// reversing this took months of machine time
      goto LAB_0102e1f4;
    }
    pcVar10[0xf] = 't';
    uVar14 = s___module_private___01cbd96e._0_8_;
    pcVar10[0x10] = 'e';
    pcVar10[0x11] = '_';
    pcVar10[0x12] = '_';
    *(undefined8 *)(pcVar10 + 8) = s___module_private___01cbd96e._8_8_;
    *(undefined8 *)pcVar10 = uVar14;
    *(long *)(lVar8 + 0x18) = *(long *)(lVar8 + 0x18) + 0x13;
    if (*(char *)(param_2 + 0x1c) != '5') goto LAB_0102e200;
LAB_0102e270:
    uVar13 = *(ulong *)(param_2 + 0x60);
  }
  if ((uVar13 < 4) || ((uVar13 & 1) != 0)) {
    s___module_private___01cbd96e[0] = s___module_private___01cbd96e[0];
    s___module_private___01cbd96e[1] = s___module_private___01cbd96e[1];
    s___module_private___01cbd96e[2] = s___module_private___01cbd96e[2];
    s___module_private___01cbd96e[3] = s___module_private___01cbd96e[3];
    s___module_private___01cbd96e[4] = s___module_private___01cbd96e[4];
    s___module_private___01cbd96e[5] = s___module_private___01cbd96e[5];
    s___module_private___01cbd96e[6] = s___module_private___01cbd96e[6];
    s___module_private___01cbd96e[7] = s___module_private___01cbd96e[7];
    s___module_private___01cbd96e[8] = s___module_private___01cbd96e[8];
    s___module_private___01cbd96e[9] = s___module_private___01cbd96e[9];
    s___module_private___01cbd96e[10] = s___module_private___01cbd96e[10];
    s___module_private___01cbd96e[0xb] = s___module_private___01cbd96e[0xb];
    s___module_private___01cbd96e[0xc] = s___module_private___01cbd96e[0xc];
    s___module_private___01cbd96e[0xd] = s___module_private___01cbd96e[0xd];
    s___module_private___01cbd96e[0xe] = s___module_private___01cbd96e[0xe];
    s___module_private___01cbd96e[0xf] = s___module_private___01cbd96e[0xf];
    s_tls_dynamic_01cbda62[0] = s_tls_dynamic_01cbda62[0];
    s_tls_dynamic_01cbda62[1] = s_tls_dynamic_01cbda62[1];
    s_tls_dynamic_01cbda62[2] = s_tls_dynamic_01cbda62[2];
/* wm:donate: donate/README.md */
    s_tls_dynamic_01cbda62[3] = s_tls_dynamic_01cbda62[3];
    s_tls_dynamic_01cbda62[4] = s_tls_dynamic_01cbda62[4];
    s_tls_dynamic_01cbda62[5] = s_tls_dynamic_01cbda62[5];
    s_tls_dynamic_01cbda62[6] = s_tls_dynamic_01cbda62[6];
    s_tls_dynamic_01cbda62[7] = s_tls_dynamic_01cbda62[7];
    return;
  }
  bVar2 = *(byte *)(param_2 + 0x68) >> 5 & 3;
  if (bVar2 < 2) {
    if (bVar2 == 0) {
      lVar8 = *param_1;
      puVar1 = *(undefined4 **)(lVar8 + 0x18);
      if ((ulong)(*(long *)(lVar8 + 0x10) - (long)puVar1) < 6) {
        func_0x01770110(lVar8," cinit",6);
        uVar13 = *(ulong *)(param_2 + 0x60);
      }
// WM - proprietary - see LICENSE - do not sell
      else {
        *(undefined2 *)(puVar1 + 1) = 0x7469;
        *puVar1 = 0x6e696320;
        *(long *)(lVar8 + 0x18) = *(long *)(lVar8 + 0x18) + 6;
        uVar13 = *(ulong *)(param_2 + 0x60);
      }
    }
    else {
      lVar8 = *param_1;
      puVar7 = *(undefined8 **)(lVar8 + 0x18);
      if ((ulong)(*(long *)(lVar8 + 0x10) - (long)puVar7) < 9) {
        pcVar10 = " callinit";
        goto LAB_0102e34c;
      }
      pcVar10 = " callinit";
LAB_0102e3b0:
      *(undefined1 *)(puVar7 + 1) = 0x74;
      *puVar7 = *(undefined8 *)pcVar10;
      *(long *)(lVar8 + 0x18) = *(long *)(lVar8 + 0x18) + 9;
      uVar13 = *(ulong *)(param_2 + 0x60);
    }
  }
  else {
    if (bVar2 == 2) {
      lVar8 = *param_1;
      puVar7 = *(undefined8 **)(lVar8 + 0x18);
      if (8 < (ulong)(*(long *)(lVar8 + 0x10) - (long)puVar7)) {
/* proprietary - see LICENSE - do not sell */
        pcVar10 = " listinit";
        goto LAB_0102e3b0;
      }
      pcVar10 = " listinit";
LAB_0102e34c:
      func_0x01770110(lVar8,pcVar10,9);
    }
    uVar13 = *(ulong *)(param_2 + 0x60);
  }
  if (3 < uVar13) {
    uVar11 = uVar13 & 0xfffffffffffffffc;
    if ((uVar13 & 3) == 0) goto code_r0x01022fec;
    if ((uVar13 & 3) == 2) {
      uVar11 = *(ulong *)(uVar11 + 8);
      goto code_r0x01022fec;
    }
  }
  uVar11 = 0;
code_r0x01022fec:
  do {
    *(long *)((long)register0x00000008 + -0x30) = unaff_x22;
    *(long **)((long)register0x00000008 + -0x28) = unaff_x21;
/* wm:reversing this took months of machine time */
    *(long **)((long)register0x00000008 + -0x20) = unaff_x20;
    *(ulong *)((long)register0x00000008 + -0x18) = unaff_x19;
    *(undefined1 **)((long)register0x00000008 + -0x10) = unaff_x29;
    *(undefined **)((long)register0x00000008 + -8) = unaff_x30;
    *(undefined8 *)((long)register0x00000008 + -0x38) =
         *(undefined8 *)PTR____stack_chk_guard_01f20200;
    *(long **)((long)register0x00000008 + -0x68) = param_1;
    *(ulong *)((long)register0x00000008 + -0x60) = uVar11;
    if ((char)param_1[0x86] == '\x01') {
      *(undefined1 *)(param_1 + 0x86) = 0;
      func_0x010359ac((undefined1 *)((long)register0x00000008 + -0x68));
      plVar5 = (long *)param_1[4];
      if ((long *)param_1[3] != plVar5) {
        unaff_x20 = (long *)((long)&MACH_HEADER.magic + 1);
        do {
          *(undefined1 *)((long)register0x00000008 + -0x58) = 1;
/* +- WM -------------------------------------------------------------+
   |  reversing this took months of machine time
   +--------------------------------------------------------------------*/
          plVar5 = (long *)plVar5[-1];
          if (plVar5 == (long *)0x0) {
            FUN_001717b4();
                    /* WARNING: Does not return */
            pcVar3 = (code *)SoftwareBreakpoint(1,0x1023238);
            (*pcVar3)();
          }
          (**(code **)(*plVar5 + 0x30))(plVar5,(undefined1 *)((long)register0x00000008 + -0x58));
          lVar8 = param_1[4];
          plVar5 = (long *)(lVar8 + -0x20);
          param_1[4] = (long)plVar5;
          plVar6 = *(long **)(lVar8 + -8);
          if (plVar6 == plVar5) {
            lVar8 = 0x20;
code_r0x01023048:
            (**(code **)(*plVar6 + lVar8))();
            plVar5 = (long *)param_1[4];
          }
          else if (plVar6 != (long *)0x0) {
            lVar8 = 0x28;
            goto code_r0x01023048;
          }
        } while ((long *)param_1[3] != plVar5);
      }
      if (*(char *)((long)param_1 + 0x44f) < '\0') {
        *(undefined1 *)param_1[0x87] = 0;
/* +- WM -------------------------------------------------------------+
   |  watermarked copy - do not remove
   +--------------------------------------------------------------------*/
        param_1[0x88] = 0;
        lVar8 = *param_1;
        puVar12 = *(undefined1 **)(lVar8 + 0x18);
        if (*(undefined1 **)(lVar8 + 0x10) != puVar12) goto code_r0x01023118;
code_r0x010231c0:
        func_0x01770110(lVar8,"\n",1);
      }
      else {
        *(undefined1 *)(param_1 + 0x87) = 0;
        *(undefined1 *)((long)param_1 + 0x44f) = 0;
        lVar8 = *param_1;
        puVar12 = *(undefined1 **)(lVar8 + 0x18);
        if (*(undefined1 **)(lVar8 + 0x10) == puVar12) goto code_r0x010231c0;
code_r0x01023118:
        *puVar12 = 10;
        *(long *)(lVar8 + 0x18) = *(long *)(lVar8 + 0x18) + 1;
      }
      *(undefined1 *)(param_1 + 0x86) = 1;
code_r0x010231f0:
      if (*(long *)PTR____stack_chk_guard_01f20200 == *(long *)((long)register0x00000008 + -0x38)) {
        return;
      }
      ___stack_chk_fail();
/* WM: origin: github.com/pengussy @ discord.gg/sdkhDjTex */
    }
    else {
      unaff_x21 = (long *)param_1[0x8c];
      if (*(char *)((long)param_1 + 0x431) == '\x01') {
        unaff_x20 = (long *)__Znwm(0x28);
        *unaff_x20 = (long)&UNK_01e5e270;
        unaff_x20[1] = (long)param_1;
        lVar8 = *(long *)((long)register0x00000008 + -0x68);
        unaff_x20[3] = *(long *)((long)register0x00000008 + -0x60);
        unaff_x20[2] = lVar8;
        unaff_x20[4] = (long)unaff_x21;
        uVar13 = param_1[4];
        if ((ulong)param_1[5] <= uVar13) {
          func_0x01027324(param_1 + 3,0);
          uVar13 = param_1[4];
        }
        *(long **)(uVar13 + 0x18) = unaff_x20;
        param_1[4] = param_1[4] + 0x20;
code_r0x010231ec:
        *(undefined1 *)((long)param_1 + 0x431) = 0;
        goto code_r0x010231f0;
      }
      lVar8 = param_1[4];
      *(undefined1 *)((long)register0x00000008 + -0x58) = 0;
      plVar5 = *(long **)(lVar8 + -8);
      if (plVar5 != (long *)0x0) {
        unaff_x20 = (long *)((long)register0x00000008 + -0x58);
        (**(code **)(*plVar5 + 0x30))(plVar5,(undefined1 *)((long)register0x00000008 + -0x58));
/* +- WM -------------------------------------------------------------+
   |  unlicensed copy if this notice is missing
   +--------------------------------------------------------------------*/
        unaff_x22 = param_1[4];
        puVar7 = (undefined8 *)__Znwm(0x28);
        *puVar7 = &UNK_01e5e270;
        puVar7[1] = param_1;
        uVar14 = *(undefined8 *)((long)register0x00000008 + -0x68);
        puVar7[3] = *(undefined8 *)((long)register0x00000008 + -0x60);
        puVar7[2] = uVar14;
        puVar7[4] = unaff_x21;
        *(undefined8 **)((long)register0x00000008 + -0x40) = puVar7;
        unaff_x21 = (long *)((long)register0x00000008 + -0x58);
        func_0x01025c50((undefined1 *)((long)register0x00000008 + -0x58),unaff_x22 + -0x20);
        plVar5 = *(long **)((long)register0x00000008 + -0x40);
        if (plVar5 == unaff_x21) {
          lVar8 = 0x20;
        }
        else {
          if (plVar5 == (long *)0x0) goto code_r0x010231ec;
          lVar8 = 0x28;
        }
        (**(code **)(*plVar5 + lVar8))();
        goto code_r0x010231ec;
      }
    }
    uVar14 = FUN_001717b4();
    (**(code **)(*unaff_x20 + 0x28))(unaff_x20);
    __Unwind_Resume(uVar14);
// thanks for reading - discord.gg/sdkhDjTex
    uVar11 = __Unwind_Resume();
    *(long *)((long)register0x00000008 + -0xa0) = unaff_x22;
    *(long **)((long)register0x00000008 + -0x98) = unaff_x21;
    *(long **)((long)register0x00000008 + -0x90) = unaff_x20;
    *(undefined8 *)((long)register0x00000008 + -0x88) = uVar14;
    *(undefined1 **)((long)register0x00000008 + -0x80) =
         (undefined1 *)((long)register0x00000008 + -0x10);
    *(undefined **)((long)register0x00000008 + -0x78) = &DAT_01023260;
    unaff_x29 = (undefined1 *)((long)register0x00000008 + -0x80);
    *(undefined8 *)((long)register0x00000008 + -0xa8) =
         *(undefined8 *)PTR____stack_chk_guard_01f20200;
    uVar14 = func_0x01771ca4();
    unaff_x20 = (long *)((long)register0x00000008 + -0x4e8);
    *(undefined8 *)((long)register0x00000008 + -0x518) = uVar14;
    *(undefined8 *)((long)register0x00000008 + -0x510) = 0;
    *(undefined8 *)((long)register0x00000008 + -0x508) = 0;
    *(long **)((long)register0x00000008 + -0x500) = unaff_x20;
    *(long **)((long)register0x00000008 + -0x4f8) = unaff_x20;
    *(undefined1 **)((long)register0x00000008 + -0x4f0) =
         (undefined1 *)((long)register0x00000008 + -0xe8);
    *(undefined2 *)((long)register0x00000008 + -0xe8) = 0x101;
    *(undefined8 *)((long)register0x00000008 + -0xe0) = 0;
    *(undefined8 *)((long)register0x00000008 + -0xd0) = 0;
    *(undefined8 *)((long)register0x00000008 + -0xd8) = 0;
    *(undefined **)((long)register0x00000008 + -200) = &UNK_01cb7848;
    *(undefined4 *)((long)register0x00000008 + -0xc0) = 0xffffffff;
    *(undefined8 *)((long)register0x00000008 + -0xb8) = 0;
    *(undefined2 *)((long)register0x00000008 + -0xb0) = 0x100;
/* WM: thanks for reading - discord.gg/sdkhDjTex @ discord.gg/sdkhDjTex */
    param_1 = (long *)((long)register0x00000008 + -0x518);
    unaff_x30 = &UNK_010232e4;
    register0x00000008 = (BADSPACEBASE *)((long)register0x00000008 + -0x520);
    unaff_x19 = uVar11;
  } while( true );
}

