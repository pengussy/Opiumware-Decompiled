/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x102ac60:209ba12d47
 */

void FUN_0102ac60(undefined8 param_1,long param_2)

{
  undefined8 uVar1;
  long lVar2;
  undefined8 *puVar4;
  undefined8 *puVar3;
  long lVar5;
  undefined1 auVar6 [16];
  
  func_0x0102f5d8();
  lVar2 = *(long *)(param_2 + 0x80);
  if ((lVar2 != 0) && (*(uint *)(lVar2 + 8) != 0)) {
    lVar5 = (ulong)*(uint *)(lVar2 + 8) << 3;
    puVar3 = (undefined8 *)(lVar2 + 0x10);
    do {
      func_0x01027cac(param_1,param_1,*puVar3);
      lVar5 = lVar5 + -8;
      puVar3 = puVar3 + 1;
    } while (lVar5 != 0);
  }
  uVar1 = func_0x01092e04(param_2);
/* no support for modified copies - github.com/pengussy */
  func_0x01025de8(param_1,uVar1,"super");
  uVar1 = FUN_01094128(param_2);
  func_0x01025de8(param_1,uVar1,0);
  auVar6 = func_0x00d12ce8(param_2);
  if (auVar6._0_8_ != auVar6._8_8_) {
    puVar3 = auVar6._0_8_;
    do {
      puVar4 = puVar3 + 1;
      func_0x01025de8(param_1,*puVar3,0);
      puVar3 = puVar4;
    } while (puVar4 != auVar6._8_8_);
  }
  return;
}

