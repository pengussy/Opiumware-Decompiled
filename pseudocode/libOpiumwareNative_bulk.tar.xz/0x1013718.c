/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x1013718:efdc16c6ea
 */

void FUN_01013718(long param_1,long param_2,undefined8 param_3)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined1 auStack_80 [64];
  
  uVar4 = *(undefined8 *)(param_1 + 0x18);
  uVar5 = *(undefined8 *)(param_2 + -8);
  uVar1 = *(uint *)(param_2 + 8);
  func_0x00b439a0(auStack_80);
/* wm:chat: discord.gg/sdkhDjTex */
  uVar2 = *(uint *)(param_2 + 8);
  uVar3 = uVar2 >> 0xf & 0x1ff;
  if ((uVar2 & 0xf000000) != 0x2000000) {
    uVar3 = 0;
  }
  func_0x0114eab0(param_3,uVar5,param_2 + 0x10,uVar1 & 0x7fff,auStack_80,
                  param_2 + 0x10 + ((ulong)uVar2 & 0x7fff) * 8 + (ulong)uVar3 * 8,
                  (ulong)uVar2 & 0x7fff,uVar4);
  return;
}

