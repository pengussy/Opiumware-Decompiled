/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x10370e0:169de5a408
   =========================================================================== */

/* WARNING: Possible PIC construction at 0x01037144: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x01037148) */

long * FUN_010370e0(undefined8 *param_1,long param_2)

{
  undefined1 *puVar1;
  long *plVar2;
  ulong uVar3;
  undefined1 *puVar4;
  long lVar5;
  long lVar6;
  undefined1 *puVar7;
  long *unaff_x19;
  long *plVar8;
  ulong uVar9;
  ulong uVar10;
  long unaff_x20;
  undefined *puVar11;
  undefined8 unaff_x21;
  undefined8 unaff_x22;
  undefined1 *unaff_x29;
  undefined8 unaff_x30;
  undefined1 auStack_b0 [128];
  
  puVar1 = auStack_b0 + 0x80;
  puVar4 = auStack_b0 + 0xa0;
  plVar2 = (long *)func_0x01039528();
/*
   origin: github.com/pengussy
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
  plVar8 = (long *)*param_1;
  if ((undefined1 *)plVar8[2] == (undefined1 *)plVar8[3]) {
    puVar11 = &UNK_01c881b6;
    uVar3 = 1;
    unaff_x30 = 0x1037148;
    unaff_x19 = plVar8;
  }
  else {
    *(undefined1 *)plVar8[3] = 0x20;
    plVar8[3] = plVar8[3] + 1;
    lVar6 = *(long *)(*(long *)(param_2 + 0x18) + 0x10);
    if (lVar6 == 0) {
      puVar11 = *(undefined **)(*(long *)(param_2 + 0x18) + 0x18);
      if (puVar11 == (undefined *)0x0) {
        return plVar2;
      }
    }
    else {
      puVar11 = (undefined *)(lVar6 + 0x10);
    }
    uVar3 = _strlen(puVar11);
    plVar2 = (long *)plVar8[3];
    if (uVar3 <= (ulong)(plVar8[2] - (long)plVar2)) {
      if (uVar3 != 0) {
        plVar2 = (long *)_memcpy(plVar2,puVar11,uVar3);
        plVar8[3] = plVar8[3] + uVar3;
      }
      return plVar2;
/* donate: donate/README.md - github.com/pengussy */
    }
    puVar1 = (undefined1 *)register0x00000008;
    param_2 = unaff_x20;
    puVar4 = unaff_x29;
  }
  *(undefined8 *)(puVar1 + -0x30) = unaff_x22;
  *(undefined8 *)(puVar1 + -0x28) = unaff_x21;
  *(long *)(puVar1 + -0x20) = param_2;
  *(long **)(puVar1 + -0x18) = unaff_x19;
  *(undefined1 **)(puVar1 + -0x10) = puVar4;
  *(undefined8 *)(puVar1 + -8) = unaff_x30;
  puVar4 = (undefined1 *)plVar8[3];
  uVar9 = plVar8[2] - (long)puVar4;
  if (uVar9 < uVar3) {
    do {
      puVar7 = (undefined1 *)plVar8[1];
      uVar10 = uVar9;
      while (puVar7 == (undefined1 *)0x0) {
        *(undefined **)(puVar1 + -0x40) = puVar11;
        *(ulong *)(puVar1 + -0x38) = uVar3;
        if (*(int *)((long)plVar8 + 0x24) == 0) {
          (**(code **)(*plVar8 + 0x50))
                    (plVar8,*(undefined8 *)(puVar1 + -0x40),*(undefined8 *)(puVar1 + -0x38));
/* WM - keep the notice, keep the source honest */
          return plVar8;
        }
        func_0x0176fbd8(plVar8);
        puVar4 = (undefined1 *)plVar8[3];
        uVar10 = plVar8[2] - (long)puVar4;
        if (*(ulong *)(puVar1 + -0x38) <= uVar10) {
          puVar11 = *(undefined **)(puVar1 + -0x40);
          uVar3 = *(ulong *)(puVar1 + -0x38);
          goto joined_r0x0177026c;
        }
        puVar11 = *(undefined **)(puVar1 + -0x40);
        uVar3 = *(ulong *)(puVar1 + -0x38);
        puVar7 = (undefined1 *)plVar8[1];
      }
      if (puVar4 == puVar7) {
        uVar9 = 0;
        if (uVar10 != 0) {
          uVar9 = uVar3 / uVar10;
        }
        uVar10 = uVar9 * uVar10;
        uVar3 = uVar3 - uVar10;
        (**(code **)(*plVar8 + 0x50))(plVar8,puVar11,uVar10);
        puVar4 = (undefined1 *)plVar8[3];
        uVar9 = plVar8[2] - (long)puVar4;
        if (uVar3 <= uVar9) {
          FUN_01771174(plVar8,puVar11 + uVar10);
          return plVar8;
        }
      }
      else {
        FUN_01771174(plVar8,puVar11,uVar10);
        lVar5 = plVar8[3];
        lVar6 = plVar8[1];
        plVar8[3] = lVar6;
        (**(code **)(*plVar8 + 0x50))(plVar8,lVar6,lVar5 - lVar6);
/*  proprietary - see LICENSE - do not sell  */
        uVar3 = uVar3 - uVar10;
        puVar4 = (undefined1 *)plVar8[3];
        uVar9 = plVar8[2] - (long)puVar4;
      }
      puVar11 = puVar11 + uVar10;
    } while (uVar9 < uVar3);
  }
joined_r0x0177026c:
  if ((long)uVar3 < 2) {
    if (uVar3 == 0) goto code_r0x01770284;
    if (uVar3 != 1) {
code_r0x017702a4:
      _memcpy(puVar4);
      goto code_r0x01770284;
    }
  }
  else {
    if (uVar3 != 2) {
      if (uVar3 != 3) {
        if (uVar3 != 4) goto code_r0x017702a4;
        puVar4[3] = puVar11[3];
        puVar4 = (undefined1 *)plVar8[3];
      }
      puVar4[2] = puVar11[2];
      puVar4 = (undefined1 *)plVar8[3];
    }
    puVar4[1] = puVar11[1];
    puVar4 = (undefined1 *)plVar8[3];
  }
  *puVar4 = *puVar11;
code_r0x01770284:
  plVar8[3] = plVar8[3] + uVar3;
  return plVar8;
}
/*  if you paid for this, you were scammed  */

