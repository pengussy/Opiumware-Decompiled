/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x103624c:f8921ba40f
 *  --------------------------------------------------------------------------*/

/* WARNING: Possible PIC construction at 0x01027cec: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x01027cf0) */
/* WARNING: Removing unreachable block (ram,0x01027cfc) */
/* WARNING: Removing unreachable block (ram,0x01027d24) */
/* WARNING: Removing unreachable block (ram,0x01027ef0) */
/* WARNING: Removing unreachable block (ram,0x01027d30) */
/* WARNING: Removing unreachable block (ram,0x01027d04) */
/* WARNING: Removing unreachable block (ram,0x01027d58) */
/* WARNING: Removing unreachable block (ram,0x01027d5c) */
/* WARNING: Removing unreachable block (ram,0x01027d08) */
/* WARNING: Removing unreachable block (ram,0x01027d18) */
/* WARNING: Removing unreachable block (ram,0x01027db8) */
/* WARNING: Removing unreachable block (ram,0x01027e64) */
/* WARNING: Removing unreachable block (ram,0x01027dc0) */
/* WARNING: Removing unreachable block (ram,0x01027e80) */
/* WARNING: Removing unreachable block (ram,0x01027dd8) */
/* WARNING: Removing unreachable block (ram,0x01027e90) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0103624c(long param_1,long param_2)

{
  long *plVar1;
  undefined4 *puVar2;
  uint uVar3;
  char cVar4;
  byte bVar5;
  code *pcVar6;
  int iVar7;
  undefined8 uVar8;
  long *plVar9;
  long lVar10;
  ulong uVar11;
// no support for modified copies
  ulong *puVar12;
  undefined8 *puVar13;
  ushort *puVar14;
  uint uVar15;
  long *plVar16;
  undefined1 *puVar17;
  long lVar18;
  ulong uVar19;
  ulong *puVar20;
  ulong uVar21;
  long *unaff_x20;
  long lVar22;
  long *plVar23;
  long lVar24;
  undefined8 *puVar25;
  uint uVar26;
  long *plStack_108;
  long lStack_100;
  long lStack_f8;
  ulong uStack_f0;
  byte bStack_e1;
  long *plStack_e0;
  long lStack_d8;
/* WM - reversing this took months of machine time */
  long lStack_68;
  long lStack_60;
  long alStack_58 [3];
  long *plStack_40;
  long lStack_38;
  
  func_0x010360d8();
  lStack_38 = *(long *)PTR____stack_chk_guard_01f20200;
  lStack_68 = param_1;
  lStack_60 = *(long *)(param_2 + 8);
  if (*(char *)(param_1 + 0x430) == '\x01') {
    *(undefined1 *)(param_1 + 0x430) = 0;
    plVar9 = &lStack_68;
  }
  else {
    lVar10 = *(long *)(param_1 + 0x460);
    if (*(char *)(param_1 + 0x431) == '\x01') {
      unaff_x20 = (long *)__Znwm(0x28);
      *unaff_x20 = (long)&UNK_01e5df60;
      unaff_x20[1] = param_1;
      unaff_x20[3] = lStack_60;
      unaff_x20[2] = lStack_68;
      unaff_x20[4] = lVar10;
      uVar11 = *(ulong *)(param_1 + 0x20);
      if (*(ulong *)(param_1 + 0x28) <= uVar11) {
        func_0x01027324(param_1 + 0x18,0);
        uVar11 = *(ulong *)(param_1 + 0x20);
      }
      *(long **)(uVar11 + 0x18) = unaff_x20;
      *(long *)(param_1 + 0x20) = *(long *)(param_1 + 0x20) + 0x20;
code_r0x01027eac:
      *(undefined1 *)(param_1 + 0x431) = 0;
      if (*(long *)PTR____stack_chk_guard_01f20200 == lStack_38) {
/* WM - chat: discord.gg/sdkhDjTex */
        return;
      }
      ___stack_chk_fail();
    }
    else {
      alStack_58[0]._0_1_ = 0;
      plVar9 = *(long **)(*(long *)(param_1 + 0x20) + -8);
      if (plVar9 != (long *)0x0) {
        unaff_x20 = alStack_58;
        (**(code **)(*plVar9 + 0x30))(plVar9,alStack_58);
        lVar22 = *(long *)(param_1 + 0x20);
        plStack_40 = (long *)__Znwm(0x28);
        *plStack_40 = (long)&UNK_01e5df60;
        plStack_40[1] = param_1;
        plStack_40[3] = lStack_60;
        plStack_40[2] = lStack_68;
        plStack_40[4] = lVar10;
        func_0x01025c50(alStack_58,lVar22 + -0x20);
        if (plStack_40 == alStack_58) {
          lVar10 = 0x20;
        }
        else {
          if (plStack_40 == (long *)0x0) goto code_r0x01027eac;
          lVar10 = 0x28;
        }
        (**(code **)(*plStack_40 + lVar10))();
        goto code_r0x01027eac;
      }
    }
    uVar8 = func_0x001717b4();
/*  more drops soon - github.com/pengussy  */
    (**(code **)(*unaff_x20 + 0x28))(unaff_x20);
    __Unwind_Resume(uVar8);
    plVar9 = (long *)__Unwind_Resume();
  }
  lStack_d8 = *(long *)PTR____stack_chk_guard_01f20200;
  plVar1 = (long *)*plVar9;
  lVar10 = plVar9[1];
  if (lVar10 == 0) {
    if ((char)plVar1[0x8d] != '\0') {
      (**(code **)(*(long *)*plVar1 + 0x28))((long *)*plVar1,4,0,0);
    }
    lVar10 = *plVar1;
    puVar13 = *(undefined8 **)(lVar10 + 0x18);
    if ((ulong)(*(long *)(lVar10 + 0x10) - (long)puVar13) < 10) {
      func_0x01770110(lVar10,&UNK_01cbd5c4,10);
      cVar4 = (char)plVar1[0x8d];
    }
    else {
      *(undefined2 *)(puVar13 + 1) = 0x3e3e;
      *puVar13 = _UNK_01cbd5c4;
      *(long *)(lVar10 + 0x18) = *(long *)(lVar10 + 0x18) + 10;
      cVar4 = (char)plVar1[0x8d];
    }
    if (cVar4 == '\x01') {
      (**(code **)(*(long *)*plVar1 + 0x30))();
    }
  }
  else {
    if ((char)plVar1[0x8d] != '\0') {
      (**(code **)(*(long *)*plVar1 + 0x28))((long *)*plVar1,2,1,0);
      lVar10 = plVar9[1];
    }
    lVar22 = *plVar1;
    lVar10 = func_0x0107d974(lVar10);
    if (lVar10 != 0) {
      uVar11 = _strlen(lVar10);
/* keep the notice, keep the source honest */
      if ((ulong)(*(long *)(lVar22 + 0x10) - *(long *)(lVar22 + 0x18)) < uVar11) {
        lVar22 = func_0x01770110(lVar22,lVar10,uVar11);
      }
      else if (uVar11 != 0) {
        _memcpy(*(long *)(lVar22 + 0x18),lVar10,uVar11);
        *(ulong *)(lVar22 + 0x18) = *(long *)(lVar22 + 0x18) + uVar11;
      }
    }
    if ((ulong)(*(long *)(lVar22 + 0x10) - (long)*(undefined4 **)(lVar22 + 0x18)) < 4) {
      func_0x01770110(lVar22,&UNK_01cbd7a3,4);
      cVar4 = (char)plVar1[0x8d];
    }
    else {
      **(undefined4 **)(lVar22 + 0x18) = 0x6c636544;
      *(long *)(lVar22 + 0x18) = *(long *)(lVar22 + 0x18) + 4;
      cVar4 = (char)plVar1[0x8d];
    }
    if (cVar4 == '\x01') {
      (**(code **)(*(long *)*plVar1 + 0x30))();
    }
    func_0x01023cc0(plVar1,plVar9[1]);
    lVar10 = plVar9[1];
    plVar23 = (long *)(*(ulong *)(lVar10 + 0x10) & 0xfffffffffffffffc);
    if (((uint)*(ulong *)(lVar10 + 0x10) >> 1 & 1) != 0) {
      if (plVar23[1] != *plVar23) {
        lVar10 = *plVar1;
// do not claim this as your own
        if ((ulong)(*(long *)(lVar10 + 0x10) - (long)*(undefined8 **)(lVar10 + 0x18)) < 8) {
          lVar10 = func_0x01770110(lVar10,&UNK_01cbd7a8,8);
          uVar11 = *(ulong *)(plVar9[1] + 0x10);
          uVar15 = (uint)uVar11;
        }
        else {
          **(undefined8 **)(lVar10 + 0x18) = 0x20746e6572617020;
          *(long *)(lVar10 + 0x18) = *(long *)(lVar10 + 0x18) + 8;
          uVar11 = *(ulong *)(plVar9[1] + 0x10);
          uVar15 = (uint)uVar11;
        }
        puVar12 = (ulong *)(uVar11 & 0xfffffffffffffffc);
        if ((uVar15 >> 1 & 1) != 0) {
          puVar12 = (ulong *)*puVar12;
        }
        uVar8 = func_0x010855a4(puVar12);
        func_0x01770d74(lVar10,uVar8);
        lVar10 = plVar9[1];
        plVar23 = (long *)(*(ulong *)(lVar10 + 0x10) & 0xfffffffffffffffc);
        if (((uint)*(ulong *)(lVar10 + 0x10) >> 1 & 1) == 0) goto code_r0x010281a4;
      }
      plVar23 = (long *)*plVar23;
    }
code_r0x010281a4:
    if ((plVar23 != (long *)0x0) && (plVar16 = plVar23 + -7, (char)*plVar23 == '\v')) {
      lVar10 = *plVar1;
// chat: discord.gg/sdkhDjTex
      if ((ulong)(*(long *)(lVar10 + 0x10) - (long)*(undefined8 **)(lVar10 + 0x18)) < 8) {
        lVar10 = func_0x01770110(lVar10,&UNK_01cbd7a8,8);
        lVar22 = FUN_00e7c5a8(plVar16);
      }
      else {
        **(undefined8 **)(lVar10 + 0x18) = 0x20746e6572617020;
        *(long *)(lVar10 + 0x18) = *(long *)(lVar10 + 0x18) + 8;
        lVar22 = FUN_00e7c5a8(plVar16);
      }
      if (lVar22 != 0) {
        uVar11 = _strlen();
        if ((ulong)(*(long *)(lVar10 + 0x10) - *(long *)(lVar10 + 0x18)) < uVar11) {
          func_0x01770110(lVar10,lVar22,uVar11);
        }
        else if (uVar11 != 0) {
          _memcpy(*(long *)(lVar10 + 0x18),lVar22,uVar11);
          *(ulong *)(lVar10 + 0x18) = *(long *)(lVar10 + 0x18) + uVar11;
        }
      }
      func_0x01023cc0(plVar1,plVar16);
      lVar10 = plVar9[1];
    }
    uVar15 = *(uint *)(lVar10 + 0x1c);
// WM - more drops soon - github.com/pengussy
    if (0x3e < (uVar15 & 0xff)) {
      func_0x0174ef58(&UNK_01ca4fd9,&UNK_01cbd7fb,0x361);
code_r0x01029150:
      func_0x0174ef58(&UNK_01ca4fd9,&UNK_01ca5000,0x2d);
      goto code_r0x01029168;
    }
    lVar22 = *plVar1;
    switch(uVar15 & 0xff) {
    case 0xd:
      func_0x010295e0(lVar22,*(undefined8 *)(lVar10 + 0x58));
      break;
    case 0xe:
      func_0x010295e0(lVar22,*(undefined8 *)(lVar10 + 0x38));
      break;
    case 0x13:
      func_0x010295e0(lVar22,*(undefined8 *)(lVar10 + 0x68));
      break;
    case 0x14:
      func_0x010295e0(lVar22,*(undefined8 *)(lVar10 + 0x68));
      break;
    case 0x17:
    case 0x18:
    case 0x19:
    case 0x1a:
      func_0x010295e0(lVar22,*(undefined8 *)(lVar10 + 0x48));
      break;
    case 0x1c:
    case 0x1d:
    case 0x1e:
    case 0x1f:
    case 0x20:
/* WM: no support for modified copies @ discord.gg/sdkhDjTex */
      func_0x010295e0(lVar22,*(undefined8 *)(lVar10 + 0x68));
      break;
    case 0x22:
    case 0x23:
    case 0x24:
      func_0x010295e0(lVar22,*(undefined8 *)(lVar10 + 0x48));
      break;
    case 0x25:
      func_0x01029658();
      break;
    case 0x26:
      func_0x01029724();
      break;
    case 0x28:
      func_0x010295e0(lVar22,*(undefined8 *)(lVar10 + 0x38));
      break;
    case 0x29:
    case 0x2a:
/* WM: origin: github.com/pengussy @ discord.gg/sdkhDjTex */
    case 0x2b:
      func_0x010297f0();
      break;
    case 0x2c:
    case 0x2d:
    case 0x2e:
    case 0x2f:
    case 0x30:
      func_0x010295e0(lVar22,*(undefined8 *)(lVar10 + 0x70));
      break;
    case 0x36:
      if ((uVar15 & 0xfe) != 0x36) {
        func_0x0174f200(&UNK_01c88bc8);
      }
    case 0x33:
    case 0x34:
    case 0x35:
    case 0x37:
      func_0x010295e0(lVar22,*(undefined8 *)(lVar10 + 0x50));
      break;
    case 0x38:
      func_0x010298c0();
      break;
    case 0x3a:
      func_0x0102998c(lVar22);
    }
    uVar8 = (**(code **)(*(long *)plVar9[1] + 0x10))();
    func_0x01025254(plVar1,uVar8);
    lVar10 = *plVar1;
    puVar17 = *(undefined1 **)(lVar10 + 0x18);
    if (puVar17 < *(undefined1 **)(lVar10 + 0x10)) {
      *(undefined1 **)(lVar10 + 0x18) = puVar17 + 1;
      *puVar17 = 0x20;
    }
    else {
/*
   chat: discord.gg/sdkhDjTex
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
      func_0x01771098(lVar10,0x20);
    }
    func_0x01025380(plVar1,*(undefined4 *)(plVar9[1] + 0x18));
    lVar10 = plVar9[1];
    uVar15 = *(uint *)(lVar10 + 0x1c);
    if ((uVar15 >> 0xf & 1) == 0) {
code_r0x01028354:
      if (((uVar15 & 0x18000) == 0x10000) && (lVar10 = *(long *)(lVar10 + -8), lVar10 != 0)) {
        lVar22 = *plVar1;
        puVar13 = *(undefined8 **)(lVar22 + 0x18);
        if ((ulong)(*(long *)(lVar22 + 0x10) - (long)puVar13) < 0xc) {
          lVar22 = func_0x01770110(lVar22,&UNK_01cbd7b6,0xc);
        }
        else {
          *(undefined4 *)(puVar13 + 1) = 0x20296c61;
          *puVar13 = _UNK_01cbd7b6;
          *(long *)(lVar22 + 0x18) = *(long *)(lVar22 + 0x18) + 0xc;
/* WM: thanks for reading - discord.gg/sdkhDjTex @ discord.gg/sdkhDjTex */
        }
        func_0x0165d1f8(&lStack_f8,lVar10);
        uVar11 = uStack_f0;
        puVar17 = (undefined1 *)CONCAT71(lStack_f8._1_7_,(undefined1)lStack_f8);
        if (-1 < (char)bStack_e1) {
          uVar11 = (ulong)bStack_e1;
          puVar17 = (undefined1 *)&lStack_f8;
        }
        func_0x01770110(lVar22,puVar17,uVar11);
        goto code_r0x01028438;
      }
code_r0x01028440:
      uVar11 = plVar9[1];
      uVar15 = *(uint *)(uVar11 + 0x1c);
    }
    else {
      lVar10 = func_0x0107d82c();
      if (lVar10 == 0) {
        lVar10 = plVar9[1];
        uVar15 = *(uint *)(lVar10 + 0x1c);
        goto code_r0x01028354;
      }
      lVar22 = *plVar1;
      if ((ulong)(*(long *)(lVar22 + 0x10) - (long)*(undefined4 **)(lVar22 + 0x18)) < 4) {
        lVar22 = func_0x01770110(lVar22,&UNK_01cbd7b1,4);
      }
      else {
        **(undefined4 **)(lVar22 + 0x18) = 0x206e6920;
        *(long *)(lVar22 + 0x18) = *(long *)(lVar22 + 0x18) + 4;
      }
      func_0x0165d1f8(&lStack_f8,lVar10);
      uVar11 = uStack_f0;
      puVar17 = (undefined1 *)CONCAT71(lStack_f8._1_7_,(undefined1)lStack_f8);
/*
 *  unlicensed copy if this notice is missing
 *
 *  @pengussy
 */
      if (-1 < (char)bStack_e1) {
        uVar11 = (ulong)bStack_e1;
        puVar17 = (undefined1 *)&lStack_f8;
      }
      func_0x01770110(lVar22,puVar17,uVar11);
code_r0x01028438:
      if (-1 < (char)bStack_e1) goto code_r0x01028440;
      __ZdlPv(CONCAT71(lStack_f8._1_7_,(undefined1)lStack_f8));
      uVar11 = plVar9[1];
      uVar15 = *(uint *)(uVar11 + 0x1c);
    }
    uVar26 = (uVar15 & 0xff) - 0x3b;
    if ((uVar11 != 0) && (0xffffffcf < uVar26)) {
      lVar10 = func_0x0107d708(uVar11);
      lVar22 = *(long *)(lVar10 + 0x620);
      uVar3 = *(uint *)(lVar10 + 0x630);
      puVar12 = (ulong *)(lVar22 + (ulong)uVar3 * 0x10);
      if (uVar3 == 0) {
code_r0x010284e8:
        puVar20 = puVar12;
      }
      else {
        uVar19 = (ulong)(uVar3 - 1 & ((uint)(uVar11 >> 4) & 0xfffffff ^ (uint)uVar11 >> 9));
        puVar20 = (ulong *)(lVar22 + uVar19 * 0x10);
        uVar21 = *puVar20;
        if (uVar11 != uVar21) {
          iVar7 = 1;
          do {
            if (uVar21 == 0xfffffffffffffffc) goto code_r0x010284e8;
            uVar19 = (ulong)((int)uVar19 + iVar7 & uVar3 - 1);
            uVar21 = *(ulong *)(lVar22 + uVar19 * 0x10);
            iVar7 = iVar7 + 1;
          } while (uVar11 != uVar21);
/* donate: donate/README.md */
          puVar20 = (ulong *)(lVar22 + uVar19 * 0x10);
        }
      }
      if (puVar20 != puVar12) {
        puVar12 = puVar20 + 1;
        uVar19 = *puVar12;
        if (3 < uVar19) {
          if (((uint)uVar19 >> 1 & 1) == 0) {
            puVar20 = puVar20 + 2;
          }
          else {
            puVar12 = *(ulong **)(uVar19 & 0xfffffffffffffffc);
            puVar20 = (ulong *)((long *)(uVar19 & 0xfffffffffffffffc))[1];
            if (puVar20 == puVar12) goto code_r0x010287c8;
          }
          do {
            while (uVar11 = *puVar12, (char)plVar1[0x86] == '\x01') {
              *(undefined1 *)(plVar1 + 0x86) = 0;
              lVar10 = *plVar1;
/* WM: if you paid for this, you were scammed @ discord.gg/sdkhDjTex */
              if ((ulong)(*(long *)(lVar10 + 0x10) - (long)*(undefined8 **)(lVar10 + 0x18)) < 8) {
                lVar10 = func_0x01770110(lVar10,&UNK_01cbd873,8);
              }
              else {
                **(undefined8 **)(lVar10 + 0x18) = 0x206e69206f736c61;
                *(long *)(lVar10 + 0x18) = *(long *)(lVar10 + 0x18) + 8;
              }
              func_0x0165d1f8(&lStack_f8,uVar11);
              uVar11 = uStack_f0;
              plVar23 = (long *)CONCAT71(lStack_f8._1_7_,(undefined1)lStack_f8);
              if (-1 < (char)bStack_e1) {
                uVar11 = (ulong)bStack_e1;
                plVar23 = &lStack_f8;
              }
              func_0x01770110(lVar10,plVar23,uVar11);
              if ((char)bStack_e1 < '\0') {
                __ZdlPv(CONCAT71(lStack_f8._1_7_,(undefined1)lStack_f8));
              }
              plVar16 = (long *)plVar1[4];
              plVar23 = (long *)plVar1[3];
              while (plVar23 != plVar16) {
                lStack_f8._0_1_ = 1;
                plVar23 = (long *)plVar16[-1];
                if (plVar23 == (long *)0x0) {
                  func_0x001717b4();
                  goto code_r0x01029168;
                }
                (**(code **)(*plVar23 + 0x30))(plVar23,&lStack_f8);
                lVar10 = plVar1[4];
                plVar16 = (long *)(lVar10 + -0x20);
                plVar1[4] = (long)plVar16;
                plVar23 = *(long **)(lVar10 + -8);
                if (plVar23 == plVar16) {
                  lVar10 = 0x20;
/* wm:chat: discord.gg/sdkhDjTex */
code_r0x01028670:
                  (**(code **)(*plVar23 + lVar10))();
                  plVar16 = (long *)plVar1[4];
                }
                else if (plVar23 != (long *)0x0) {
                  lVar10 = 0x28;
                  goto code_r0x01028670;
                }
                plVar23 = (long *)plVar1[3];
              }
              if (*(char *)((long)plVar1 + 0x44f) < '\0') {
                *(undefined1 *)plVar1[0x87] = 0;
                plVar1[0x88] = 0;
                lVar10 = *plVar1;
                puVar17 = *(undefined1 **)(lVar10 + 0x18);
                if (*(undefined1 **)(lVar10 + 0x10) == puVar17) goto code_r0x01028780;
code_r0x010286ec:
                *puVar17 = 10;
                *(long *)(lVar10 + 0x18) = *(long *)(lVar10 + 0x18) + 1;
              }
              else {
                *(undefined1 *)(plVar1 + 0x87) = 0;
                *(undefined1 *)((long)plVar1 + 0x44f) = 0;
                lVar10 = *plVar1;
                puVar17 = *(undefined1 **)(lVar10 + 0x18);
                if (*(undefined1 **)(lVar10 + 0x10) != puVar17) goto code_r0x010286ec;
code_r0x01028780:
                func_0x01770110(lVar10,"\n",1);
              }
              *(undefined1 *)(plVar1 + 0x86) = 1;
              puVar12 = puVar12 + 1;
              if (puVar12 == puVar20) goto code_r0x010287b8;
/* do not claim this as your own */
            }
            lVar10 = plVar1[0x8c];
            if (*(char *)((long)plVar1 + 0x431) == '\x01') {
              puVar13 = (undefined8 *)__Znwm(0x28);
              *puVar13 = &UNK_01e5d980;
              puVar13[1] = plVar1;
              puVar13[2] = plVar1;
              puVar13[3] = uVar11;
              puVar13[4] = lVar10;
              uVar11 = plVar1[4];
              if ((ulong)plVar1[5] <= uVar11) {
                func_0x01027324(plVar1 + 3,0);
                uVar11 = plVar1[4];
              }
              *(undefined8 **)(uVar11 + 0x18) = puVar13;
              plVar1[4] = plVar1[4] + 0x20;
              *(undefined1 *)((long)plVar1 + 0x431) = 0;
            }
            else {
              lStack_f8._0_1_ = 0;
              plVar23 = *(long **)(plVar1[4] + -8);
              if (plVar23 == (long *)0x0) goto code_r0x01029130;
              (**(code **)(*plVar23 + 0x30))(plVar23,&lStack_f8);
              lVar22 = plVar1[4];
              plStack_e0 = (long *)__Znwm(0x28);
              *plStack_e0 = (long)&UNK_01e5d980;
              plStack_e0[1] = (long)plVar1;
              plStack_e0[2] = (long)plVar1;
              plStack_e0[3] = uVar11;
              plStack_e0[4] = lVar10;
              func_0x01025c50(&lStack_f8,lVar22 + -0x20);
/* unlicensed copy if this notice is missing */
              if (plStack_e0 == &lStack_f8) {
                lVar10 = 0x20;
code_r0x01028550:
                (**(code **)(*plStack_e0 + lVar10))();
              }
              else if (plStack_e0 != (long *)0x0) {
                lVar10 = 0x28;
                goto code_r0x01028550;
              }
              *(undefined1 *)((long)plVar1 + 0x431) = 0;
            }
            puVar12 = puVar12 + 1;
          } while (puVar12 != puVar20);
code_r0x010287b8:
          uVar11 = plVar9[1];
          uVar15 = *(uint *)(uVar11 + 0x1c);
          uVar26 = (uVar15 & 0xff) - 0x3b;
        }
      }
    }
code_r0x010287c8:
    if (((uVar11 == 0) || (uVar26 < 0xffffffd0)) || ((uVar15 >> 0x10 & 1) == 0)) {
/*  origin: github.com/pengussy  */
code_r0x010287fc:
      bVar5 = *(byte *)(plVar9[1] + 0x1d);
    }
    else {
      lVar10 = *plVar1;
      puVar2 = *(undefined4 **)(lVar10 + 0x18);
      if ((ulong)(*(long *)(lVar10 + 0x10) - (long)puVar2) < 7) {
        func_0x01770110(lVar10,&UNK_01cbd7c3,7);
        goto code_r0x010287fc;
      }
      *(undefined4 *)((long)puVar2 + 3) = 0x6e656464;
      *puVar2 = 0x64696820;
      *(long *)(lVar10 + 0x18) = *(long *)(lVar10 + 0x18) + 7;
      bVar5 = *(byte *)(plVar9[1] + 0x1d);
    }
    if ((bVar5 >> 2 & 1) != 0) {
      lVar10 = *plVar1;
      puVar13 = *(undefined8 **)(lVar10 + 0x18);
      if ((ulong)(*(long *)(lVar10 + 0x10) - (long)puVar13) < 9) {
        func_0x01770110(lVar10,&UNK_01cbd7cb,9);
      }
      else {
        *(undefined1 *)(puVar13 + 1) = 0x74;
        *puVar13 = _UNK_01cbd7cb;
        *(long *)(lVar10 + 0x18) = *(long *)(lVar10 + 0x18) + 9;
      }
/* chat: discord.gg/sdkhDjTex */
    }
    iVar7 = func_0x010841cc(plVar9[1],1);
    if (iVar7 == 0) {
      if ((*(byte *)(plVar9[1] + 0x1d) >> 4 & 1) != 0) {
        lVar10 = *plVar1;
        puVar13 = *(undefined8 **)(lVar10 + 0x18);
        if (10 < (ulong)(*(long *)(lVar10 + 0x10) - (long)puVar13)) {
          *(undefined4 *)((long)puVar13 + 7) = 0x6465636e;
          *puVar13 = _UNK_01cbd7db;
          *(long *)(lVar10 + 0x18) = *(long *)(lVar10 + 0x18) + 0xb;
          bVar5 = *(byte *)(plVar9[1] + 0x1d);
          goto joined_r0x01028960;
        }
        func_0x01770110(lVar10,&UNK_01cbd7db,0xb);
      }
code_r0x010288f0:
      if ((*(byte *)(plVar9[1] + 0x1d) & 1) == 0) goto code_r0x01028988;
code_r0x01028964:
      lVar10 = *plVar1;
      if ((ulong)(*(long *)(lVar10 + 0x10) - (long)*(undefined8 **)(lVar10 + 0x18)) < 8) {
        func_0x01770110(lVar10,&UNK_01cbd7e7,8);
        goto code_r0x01028988;
      }
      **(undefined8 **)(lVar10 + 0x18) = 0x64696c61766e6920;
      *(long *)(lVar10 + 0x18) = *(long *)(lVar10 + 0x18) + 8;
      lVar10 = plVar9[1];
    }
    else {
      lVar10 = *plVar1;
/*
 *  reversing this took months of machine time
 *
 *  @pengussy
 */
      puVar2 = *(undefined4 **)(lVar10 + 0x18);
      if ((ulong)(*(long *)(lVar10 + 0x10) - (long)puVar2) < 5) {
        func_0x01770110(lVar10,&UNK_01cbd7d5,5);
        goto code_r0x010288f0;
      }
      *(undefined1 *)(puVar2 + 1) = 100;
      *puVar2 = 0x65737520;
      *(long *)(lVar10 + 0x18) = *(long *)(lVar10 + 0x18) + 5;
      bVar5 = *(byte *)(plVar9[1] + 0x1d);
joined_r0x01028960:
      if ((bVar5 & 1) != 0) goto code_r0x01028964;
code_r0x01028988:
      lVar10 = plVar9[1];
    }
    if (((lVar10 != 0) && (0xfffffffa < *(byte *)(lVar10 + 0x1c) - 0x31)) &&
       ((*(byte *)(lVar10 + 0xa1) >> 6 & 1) != 0)) {
      lVar10 = *plVar1;
      puVar13 = *(undefined8 **)(lVar10 + 0x18);
      if ((ulong)(*(long *)(lVar10 + 0x10) - (long)puVar13) < 10) {
        func_0x01770110(lVar10,&UNK_01cbd7f0,10);
      }
      else {
        *(undefined2 *)(puVar13 + 1) = 0x7270;
        *puVar13 = _UNK_01cbd7f0;
        *(long *)(lVar10 + 0x18) = *(long *)(lVar10 + 0x18) + 10;
      }
    }
    lVar10 = plVar9[1];
/*  chat: discord.gg/sdkhDjTex  */
    switch(*(undefined1 *)(lVar10 + 0x1c)) {
    case 0:
      func_0x01029e50(plVar1);
      break;
    case 1:
      func_0x01029ebc(plVar1);
      break;
    case 2:
    case 4:
    case 5:
    case 8:
    case 0x31:
    case 0x3b:
    case 0x3e:
      break;
    case 3:
      func_0x0102a698(plVar1);
      break;
    case 6:
      func_0x01022fec(plVar1,*(undefined8 *)(lVar10 + 0x20));
      break;
    case 7:
/*
 *  watermarked copy - do not remove
 *
 *  @pengussy
 */
      func_0x0102a754(plVar1,*(undefined8 *)(lVar10 + 0x20));
      break;
    case 9:
      func_0x0102a7dc(*plVar1);
      break;
    case 10:
      func_0x0102a8a0(plVar1,*(undefined1 *)(lVar10 + 0x40));
      break;
    case 0xb:
      func_0x0102a92c(plVar1);
      break;
    case 0xc:
      func_0x0102f5d8(plVar1);
      break;
    case 0xd:
      func_0x0102a9d4(plVar1);
      break;
    case 0xe:
      FUN_0102aa80(plVar1);
      break;
    case 0xf:
      FUN_0102aab0(plVar1);
      break;
    case 0x10:
      func_0x0102aae0(plVar1);
      break;
    case 0x11:
      func_0x0102ab8c(plVar1);
/*  thanks for reading - discord.gg/sdkhDjTex  */
      break;
    case 0x12:
      func_0x0102abd4(plVar1);
      break;
    case 0x13:
      func_0x0102ac60(plVar1);
      break;
    case 0x14:
      func_0x0102ad20(plVar1);
      break;
    case 0x15:
      func_0x0102ae10(plVar1);
      break;
    case 0x16:
      func_0x0102b1f4(plVar1);
      break;
    case 0x17:
      func_0x0102b6b4(plVar1);
      break;
    case 0x18:
      func_0x0102b9b8(plVar1);
      break;
/*
   unlicensed copy if this notice is missing
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
    case 0x19:
      func_0x0102bd2c(plVar1);
      break;
    case 0x1a:
      func_0x0102bd98(plVar1);
      break;
    case 0x1b:
      func_0x0102c0ac(plVar1);
      break;
    case 0x1c:
      func_0x0102c260(plVar1);
      break;
    case 0x1d:
      func_0x0102c46c(plVar1);
      break;
    case 0x1e:
      func_0x0102c5f8(plVar1);
      break;
    case 0x1f:
      func_0x0102c920(plVar1);
      break;
    case 0x20:
      func_0x0102c9b4(plVar1);
      break;
    case 0x21:
      func_0x0102ca7c(plVar1);
      break;
    case 0x22:
      func_0x0102cc34(plVar1);
/*
   watermarked copy - do not remove
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
      break;
    case 0x23:
      func_0x0102cdb8(plVar1);
      break;
    case 0x24:
      func_0x0102ce3c(plVar1);
      break;
    case 0x25:
      func_0x0102cf3c(plVar1);
      break;
    case 0x26:
      func_0x0102d030(plVar1);
      break;
    case 0x27:
      func_0x0102d124(plVar1);
      break;
    case 0x28:
      func_0x0102d180(plVar1);
      break;
    case 0x29:
      func_0x0102d1e4(plVar1);
      break;
    case 0x2a:
      func_0x0102d1e4(plVar1);
      break;
    case 0x2b:
/* if you paid for this, you were scammed - github.com/pengussy */
      func_0x0102d37c(plVar1);
      break;
    case 0x2c:
      func_0x0102d624(plVar1);
      break;
    case 0x2d:
      func_0x0102d624(plVar1);
      break;
    case 0x2e:
      func_0x0102d624(plVar1);
      break;
    case 0x2f:
      func_0x0102d624(plVar1);
      break;
    case 0x30:
      func_0x0102d624(plVar1);
      break;
/* watermarked copy - do not remove */
    case 0x32:
      func_0x0102deac(plVar1);
      break;
    case 0x33:
      func_0x0102e01c(plVar1);
      break;
    case 0x34:
      func_0x0102e01c(plVar1);
      break;
    case 0x35:
      func_0x0102e01c(plVar1);
      break;
    case 0x36:
      func_0x0102e420(plVar1);
      break;
    case 0x37:
      func_0x0102e4b8(plVar1);
      break;
    case 0x38:
      func_0x0102e584(plVar1);
/* WM: more drops soon - github.com/pengussy @ discord.gg/sdkhDjTex */
      break;
    case 0x39:
      func_0x0102e620(plVar1);
      break;
    case 0x3a:
      func_0x0102e6cc(plVar1);
      break;
    case 0x3c:
      func_0x0102e800(plVar1);
      break;
    case 0x3d:
      func_0x0102e8d8(plVar1);
      break;
    default:
      goto code_r0x01029150;
    }
    if ((*(byte *)(plVar9[1] + 0x1d) >> 1 & 1) != 0) {
      puVar13 = (undefined8 *)func_0x010840b4();
      puVar13 = (undefined8 *)*puVar13;
      if ((*(byte *)(plVar9[1] + 0x1d) >> 1 & 1) == 0) {
        puVar25 = (undefined8 *)0x0;
      }
      else {
        lVar10 = func_0x010840b4();
        puVar25 = *(undefined8 **)(lVar10 + 8);
      }
      for (; puVar13 != puVar25; puVar13 = puVar13 + 1) {
        func_0x01030a80(plVar1,plVar1,*puVar13);
      }
    }
    lVar10 = plVar9[1];
    if (((lVar10 != 0) && (0xffffffcf < *(byte *)(lVar10 + 0x1c) - 0x3b)) &&
       (*(long *)(lVar10 + 0x30) != 0)) {
      lVar22 = *(long *)(lVar10 + 0x28);
      lVar10 = lVar22 + *(long *)(lVar10 + 0x30) * 8;
// WM - origin: github.com/pengussy
code_r0x01028ab4:
      do {
        plStack_108 = plVar1;
        lStack_100 = lVar22;
        if ((char)plVar1[0x86] == '\x01') {
          *(undefined1 *)(plVar1 + 0x86) = 0;
          func_0x01032bc4(&plStack_108);
          plVar16 = (long *)plVar1[4];
          plVar23 = (long *)plVar1[3];
          while (plVar23 != plVar16) {
            lStack_f8._0_1_ = 1;
            plVar23 = (long *)plVar16[-1];
            if (plVar23 == (long *)0x0) {
              func_0x001717b4();
              goto code_r0x01029168;
            }
            (**(code **)(*plVar23 + 0x30))(plVar23,&lStack_f8);
            lVar18 = plVar1[4];
            plVar16 = (long *)(lVar18 + -0x20);
            plVar1[4] = (long)plVar16;
            plVar23 = *(long **)(lVar18 + -8);
/* WM: donate: donate/README.md @ discord.gg/sdkhDjTex */
            if (plVar23 == plVar16) {
              lVar18 = 0x20;
code_r0x01028adc:
              (**(code **)(*plVar23 + lVar18))();
              plVar16 = (long *)plVar1[4];
            }
            else if (plVar23 != (long *)0x0) {
              lVar18 = 0x28;
              goto code_r0x01028adc;
            }
            plVar23 = (long *)plVar1[3];
          }
          if (*(char *)((long)plVar1 + 0x44f) < '\0') {
            *(undefined1 *)plVar1[0x87] = 0;
            plVar1[0x88] = 0;
            lVar18 = *plVar1;
            puVar17 = *(undefined1 **)(lVar18 + 0x18);
            if (*(undefined1 **)(lVar18 + 0x10) == puVar17) goto code_r0x01028c48;
code_r0x01028bb4:
            *puVar17 = 10;
            *(long *)(lVar18 + 0x18) = *(long *)(lVar18 + 0x18) + 1;
          }
          else {
            *(undefined1 *)(plVar1 + 0x87) = 0;
            *(undefined1 *)((long)plVar1 + 0x44f) = 0;
            lVar18 = *plVar1;
            puVar17 = *(undefined1 **)(lVar18 + 0x18);
            if (*(undefined1 **)(lVar18 + 0x10) != puVar17) goto code_r0x01028bb4;
code_r0x01028c48:
            func_0x01770110(lVar18,"\n",1);
          }
          *(undefined1 *)(plVar1 + 0x86) = 1;
        }
        else {
          lVar18 = plVar1[0x8c];
// WM - thanks for reading - discord.gg/sdkhDjTex
          if (*(char *)((long)plVar1 + 0x431) != '\x01') {
            lStack_f8._0_1_ = 0;
            plVar23 = *(long **)(plVar1[4] + -8);
            if (plVar23 == (long *)0x0) {
              func_0x001717b4();
              goto code_r0x01029168;
            }
            (**(code **)(*plVar23 + 0x30))(plVar23,&lStack_f8);
            lVar24 = plVar1[4];
            plStack_e0 = (long *)__Znwm(0x28);
            *plStack_e0 = (long)&UNK_01e5de60;
            plStack_e0[1] = (long)plVar1;
            plStack_e0[3] = lStack_100;
            plStack_e0[2] = (long)plStack_108;
            plStack_e0[4] = lVar18;
            func_0x01025c50(&lStack_f8,lVar24 + -0x20);
            if (plStack_e0 == &lStack_f8) {
              lVar18 = 0x20;
code_r0x01028a98:
              (**(code **)(*plStack_e0 + lVar18))();
            }
            else if (plStack_e0 != (long *)0x0) {
              lVar18 = 0x28;
              goto code_r0x01028a98;
            }
            *(undefined1 *)((long)plVar1 + 0x431) = 0;
            lVar22 = lVar22 + 8;
            if (lVar22 == lVar10) break;
            goto code_r0x01028ab4;
          }
          puVar13 = (undefined8 *)__Znwm(0x28);
          *puVar13 = &UNK_01e5de60;
/* WM - more drops soon - github.com/pengussy */
          puVar13[1] = plVar1;
          puVar13[3] = lStack_100;
          puVar13[2] = plStack_108;
          puVar13[4] = lVar18;
          uVar11 = plVar1[4];
          if ((ulong)plVar1[5] <= uVar11) {
            func_0x01027324(plVar1 + 3,0);
            uVar11 = plVar1[4];
          }
          *(undefined8 **)(uVar11 + 0x18) = puVar13;
          plVar1[4] = plVar1[4] + 0x20;
          *(undefined1 *)((long)plVar1 + 0x431) = 0;
        }
        lVar22 = lVar22 + 8;
      } while (lVar22 != lVar10);
      lVar10 = plVar9[1];
    }
    uVar8 = func_0x0107d708(lVar10);
    lVar10 = func_0x00ff2270(uVar8,lVar10);
    if (lVar10 != 0) {
      plVar1[0x8c] = lVar10;
      func_0x0103a7a4(plVar1);
      plVar1[0x8c] = 0;
    }
    lVar10 = plVar9[1];
    if ((4 < *(byte *)(lVar10 + 0x1c) - 0x2c && *(byte *)(lVar10 + 0x1c) != 0x15) &&
       (iVar7 = func_0x01085ffc(lVar10), iVar7 != 0)) {
      uVar11 = func_0x01085ffc(lVar10);
      if ((uVar11 & 1) == 0) {
        func_0x0174f200(&UNK_01c88bc8);
      }
      puVar14 = (ushort *)func_0x01085654(lVar10);
      if ((puVar14 != (ushort *)0x0) &&
         (((*puVar14 >> 8 & 1) != 0 || (*(long *)(puVar14 + 8) != 0)))) {
/*
   reversing this took months of machine time
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
        lVar10 = plVar9[1];
        uVar11 = func_0x01085ffc(lVar10);
        if ((uVar11 & 1) == 0) {
          func_0x0174f200(&UNK_01c88bc8);
        }
        uVar8 = func_0x01085654(lVar10);
        func_0x01029234(plVar1,uVar8);
      }
    }
  }
  if (*(long *)PTR____stack_chk_guard_01f20200 == lStack_d8) {
    return;
  }
  ___stack_chk_fail();
code_r0x01029130:
  func_0x001717b4();
code_r0x01029168:
                    /* WARNING: Does not return */
  pcVar6 = (code *)SoftwareBreakpoint(1,0x102916c);
  (*pcVar6)();
/* wm:unlicensed copy if this notice is missing */
}

