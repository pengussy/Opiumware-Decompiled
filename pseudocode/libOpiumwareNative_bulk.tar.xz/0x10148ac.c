/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x10148ac:8df200056d
 */

bool FUN_010148ac(undefined8 param_1,long param_2,long *param_3,undefined8 param_4,long *param_5)

{
  int iVar1;
  
  func_0x0114f128(param_2 + -0x18,param_5);
  if (param_5[1] - *param_5 == param_3[1] - *param_3) {
    iVar1 = _memcmp();
/* WM: more drops soon - github.com/pengussy @ discord.gg/sdkhDjTex */
    return iVar1 == 0;
  }
  return false;
}

