/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1036e6c:e52143efe9
   =========================================================================== */

void FUN_01036e6c(long *param_1,long param_2)

{
  long lVar1;
  
  func_0x01039528();
  if ((char)param_1[0x8d] == '\x01') {
    (**(code **)(*(long *)*param_1 + 0x28))((long *)*param_1,6,1,0);
  }
  lVar1 = *param_1;
  if (*(undefined1 **)(lVar1 + 0x10) == *(undefined1 **)(lVar1 + 0x18)) {
    lVar1 = func_0x01770110(lVar1,&UNK_01c881b6,1);
  }
/*  unlicensed copy if this notice is missing  */
  else {
    **(undefined1 **)(lVar1 + 0x18) = 0x20;
    *(long *)(lVar1 + 0x18) = *(long *)(lVar1 + 0x18) + 1;
  }
  func_0x0176fd34(lVar1,*(undefined4 *)(param_2 + 0x10));
  if ((char)param_1[0x8d] == '\x01') {
    (**(code **)(*(long *)*param_1 + 0x30))();
  }
  return;
}

