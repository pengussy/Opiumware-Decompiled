/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1017704:82a50b6bc3
   =========================================================================== */

/* WARNING: Possible PIC construction at 0x01017754: Changing call to branch */
/* WARNING: Possible PIC construction at 0x010177c4: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x01017758) */
/* WARNING: Removing unreachable block (ram,0x010177c8) */
/* WARNING: Removing unreachable block (ram,0x010177d4) */
/* WARNING: Removing unreachable block (ram,0x010177fc) */
/* WARNING: Removing unreachable block (ram,0x01017824) */
/* WARNING: Removing unreachable block (ram,0x0101784c) */
/* WARNING: Removing unreachable block (ram,0x01017874) */
/* WARNING: Removing unreachable block (ram,0x0101789c) */
/* WARNING: Removing unreachable block (ram,0x010178c4) */
/* WARNING: Removing unreachable block (ram,0x010178ec) */
/* WARNING: Removing unreachable block (ram,0x01017914) */
/* WARNING: Removing unreachable block (ram,0x0101793c) */
/* WARNING: Removing unreachable block (ram,0x01017964) */
/* WARNING: Removing unreachable block (ram,0x010179a8) */
/* WARNING: Removing unreachable block (ram,0x01017998) */

void FUN_01017704(long param_1)

{
  long lVar1;
/*  thanks for reading - discord.gg/sdkhDjTex  */
  long *plVar2;
  undefined8 uVar3;
  undefined8 *puVar4;
  long lVar5;
  ulong *puVar6;
  long lVar7;
  char *pcStack_1a8;
  undefined8 uStack_1a0;
  undefined8 uStack_198;
  undefined8 auStack_130 [33];
  undefined8 uStack_28;
  
  puVar4 = auStack_130;
  uStack_28 = *(undefined8 *)PTR____stack_chk_guard_01f20200;
  _memcpy(auStack_130,&UNK_01e5d438,0x108);
  lVar5 = *(long *)(&UNK_00003cf0 + param_1);
  lVar1 = 0;
  if (*(long *)(param_1 + 0x768) != 0) {
    lVar1 = *(long *)(param_1 + 0x768) + 0x20;
  }
  pcStack_1a8 = "RAY_FLAG";
  uStack_1a0 = 8;
  uStack_198 = 0;
  plVar2 = (long *)func_0x009d248c(lVar5,&pcStack_1a8);
  lVar7 = *plVar2;
  puVar6 = *(ulong **)(lVar7 + 8);
  if (puVar6 == (ulong *)0x0) {
    plVar2 = *(long **)(lVar5 + 0xa0);
    if (plVar2 != (long *)0x0) {
      puVar6 = (ulong *)(**(code **)(*plVar2 + 0x10))(plVar2,"RAY_FLAG",8);
      *(ulong **)(lVar7 + 8) = puVar6;
      if (puVar6 != (ulong *)0x0) goto code_r0x01017a5c;
    }
/* wm:watermarked copy - do not remove */
    puVar6 = (ulong *)func_0x009d11e8(lVar5 + 0x18,0x18,8);
    lVar5 = func_0x01650b90();
    *(long *)(lVar7 + 8) = lVar5;
    *(long *)(lVar5 + 0x10) = lVar7;
  }
code_r0x01017a5c:
  *puVar6 = *puVar6 & 0xfffffffffffffe00 | 5;
  uVar3 = func_0x00ff350c(param_1,*(undefined8 *)(&UNK_00003e68 + param_1),0);
  lVar5 = func_0x01078178(param_1,lVar1,0,0,puVar6,uVar3);
  func_0x01087d98(lVar1,lVar5);
  *(uint *)(lVar5 + 0x1c) = *(uint *)(lVar5 + 0x1c) | 0x400;
  do {
    func_0x0101b110(param_1,lVar1,*puVar4,puVar4[1],*(undefined4 *)(puVar4 + 2));
    puVar4 = puVar4 + 3;
  } while (puVar4 != &uStack_28);
  return;
}

