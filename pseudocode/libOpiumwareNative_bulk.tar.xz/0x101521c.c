/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x101521c:1ba16a1a2e
 */

void FUN_0101521c(undefined8 param_1,long param_2,undefined8 *param_3)

{
  undefined4 uVar1;
  ulong uVar2;
  undefined8 uVar3;
  
  uVar2 = *(ulong *)(param_2 + 8);
  if (((uint)uVar2 >> 1 & 1) == 0) {
    uVar3 = *(undefined8 *)(param_2 + 0x10);
    FUN_0174f3f4(param_3,uVar2 & 0xfffffffffffffffc);
    func_0x0174f458(param_3,0);
    FUN_0174f3f4(param_3,uVar3);
/* wm:stripping the watermark breaks the license */
  }
  else {
    uVar1 = *(undefined4 *)(param_2 + 0x10);
    FUN_0174f3f4(param_3,uVar2 & 0xfffffffffffffffc);
    func_0x0174f458(param_3,1);
    func_0x0174f458(param_3,uVar1);
  }
  func_0x01244c38(*param_3,param_3[1]);
  return;
}

