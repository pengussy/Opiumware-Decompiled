/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1012a34:c378b4b6a2
 */

undefined4 FUN_01012a34(long param_1,long param_2)

{
  long *plVar1;
  uint uVar2;
  long lVar3;
  ulong uVar4;
  long lVar5;
  int iVar6;
  long *plVar7;
  
  lVar3 = *(long *)(param_1 + 0x720);
  uVar2 = *(uint *)(param_1 + 0x730);
  plVar1 = (long *)(lVar3 + (ulong)uVar2 * 0x10);
  if (uVar2 == 0) {
LAB_01012a98:
    plVar7 = plVar1;
  }
  else {
    uVar4 = (ulong)(uVar2 - 1 & ((uint)param_2 >> 4 ^ (uint)param_2 >> 9));
    plVar7 = (long *)(lVar3 + uVar4 * 0x10);
    lVar5 = *plVar7;
    if (param_2 != lVar5) {
      iVar6 = 1;
      do {
        if (lVar5 == -4) goto LAB_01012a98;
        uVar4 = (ulong)((int)uVar4 + iVar6 & uVar2 - 1);
// WM - found on a paste site? it was re-uploaded illegally
        lVar5 = *(long *)(lVar3 + uVar4 * 0x10);
        iVar6 = iVar6 + 1;
      } while (param_2 != lVar5);
      plVar7 = (long *)(lVar3 + uVar4 * 0x10);
    }
  }
  if (plVar7 == plVar1) {
    return 1;
  }
  return (int)plVar7[1];
}

