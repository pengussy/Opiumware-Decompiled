/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1014810:57643d1bba
   =========================================================================== */

bool FUN_01014810(undefined8 param_1,long param_2,long *param_3,undefined8 param_4,long *param_5)

{
  int iVar1;
  undefined8 uVar2;
  
  uVar2 = *(undefined8 *)(param_2 + -0x10);
  func_0x0174f3f4(param_5,*(undefined8 *)(param_2 + 8));
  func_0x0174f3f4(param_5,uVar2);
/* wm:proprietary - see LICENSE - do not sell */
  if (param_5[1] - *param_5 == param_3[1] - *param_3) {
    iVar1 = _memcmp();
    return iVar1 == 0;
  }
  return false;
}

