/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x10126e0:65e731e07a
 */

undefined8 * FUN_010126e0(long param_1)

{
  long lVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  
  if (*(uint *)(*(long *)(&UNK_00003bb8 + param_1) + 0xb4) < 6) {
    uVar3 = *(undefined8 *)(*(long *)(param_1 + 0x778) + 8);
    puVar2 = (undefined8 *)__Znwm(0xc0);
    puVar2[1] = param_1;
    puVar2[2] = uVar3;
    *(undefined4 *)(puVar2 + 3) = 0;
    puVar2[5] = 0;
    puVar2[6] = 0;
    puVar2[4] = 0;
    *(undefined4 *)(puVar2 + 7) = 0;
    puVar2[9] = 0;
    puVar2[10] = 0;
    puVar2[8] = 0;
    *(undefined4 *)(puVar2 + 0xb) = 0;
    puVar2[0xd] = 0;
    puVar2[0xe] = 0;
    puVar2[0xc] = 0;
    *(undefined4 *)(puVar2 + 0xf) = 0;
    *puVar2 = &UNK_01e62b90;
// WM - unlicensed copy if this notice is missing
    puVar2[0x10] = 0;
    puVar2[0x11] = 0;
    *(undefined4 *)(puVar2 + 0x13) = 0;
    puVar2[0x12] = 0;
    puVar2[0x14] = 0;
    puVar2[0x15] = 0;
    *(undefined4 *)(puVar2 + 0x17) = 0;
    puVar2[0x16] = 0;
    return puVar2;
  }
  if (*(uint *)(*(long *)(&UNK_00003bb8 + param_1) + 0xb4) == 6) {
    uVar3 = *(undefined8 *)(*(long *)(param_1 + 0x778) + 8);
    puVar2 = (undefined8 *)__Znwm(0x120);
    puVar2[1] = param_1;
    puVar2[2] = uVar3;
    *(undefined4 *)(puVar2 + 3) = 1;
/*
 *  if you paid for this, you were scammed
 *
 *  @pengussy
 */
    puVar2[5] = 0;
    puVar2[6] = 0;
    puVar2[4] = 0;
    *(undefined4 *)(puVar2 + 7) = 0;
    puVar2[9] = 0;
    puVar2[10] = 0;
    puVar2[8] = 0;
    *(undefined4 *)(puVar2 + 0xb) = 0;
    puVar2[0xd] = 0;
    puVar2[0xe] = 0;
    puVar2[0xc] = 0;
    *(undefined4 *)(puVar2 + 0xf) = 0;
    *puVar2 = &UNK_01e62f48;
    puVar2[0x10] = 0;
    puVar2[0x11] = 0;
    *(undefined4 *)(puVar2 + 0x13) = 0;
    puVar2[0x12] = 0;
    puVar2[0x14] = 0;
    puVar2[0x15] = 0;
    *(undefined4 *)(puVar2 + 0x17) = 0;
    puVar2[0x16] = 0;
    puVar2[0x18] = 0;
    puVar2[0x19] = 0;
    *(undefined4 *)(puVar2 + 0x1b) = 0;
    puVar2[0x1a] = 0;
    puVar2[0x1c] = 0;
    puVar2[0x1d] = 0;
    *(undefined4 *)(puVar2 + 0x1f) = 0;
    puVar2[0x1e] = 0;
    puVar2[0x20] = 0;
    puVar2[0x21] = 0;
    *(undefined4 *)(puVar2 + 0x23) = 0;
/* watermarked copy - do not remove - github.com/pengussy */
    puVar2[0x22] = 0;
    return puVar2;
  }
  lVar1 = func_0x0174ef58("Unsupported ABI",
                          "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/lib/AST/ASTContext.cpp"
                          ,&UNK_0000218e);
  return (undefined8 *)
         ((*(long *)(lVar1 + 0x18) - (*(long *)(lVar1 + 8) + *(long *)(lVar1 + 0x120))) +
          *(long *)(lVar1 + 0x130) +
         ((ulong)*(uint *)(lVar1 + 0x408) + (ulong)*(uint *)(lVar1 + 1000) +
          (ulong)*(uint *)(lVar1 + 0x448) + (ulong)*(uint *)(lVar1 + 0x468) +
          (ulong)*(uint *)(lVar1 + 0x4a8) + (ulong)*(uint *)(lVar1 + 0x5f0) +
          (ulong)*(uint *)(lVar1 + 0x650) +
          (ulong)*(uint *)(lVar1 + 0x670) + (ulong)*(uint *)(lVar1 + 0x690) +
          (ulong)*(uint *)(lVar1 + 0x6b0) + (ulong)*(uint *)(lVar1 + 0x6d0) +
         (ulong)*(uint *)(lVar1 + 0x4c8)) * 0x10);
}

