/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x101acd8:9198b39bb9
 */

undefined1  [16] FUN_0101acd8(long param_1,undefined8 *param_2,ulong param_3)

{
  uint uVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  long lVar4;
  uint *puVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  ulong uVar8;
  undefined1 auVar9 [16];
  
  if (param_3 == 0) {
    puVar2 = (undefined8 *)0x0;
  }
  else {
    lVar4 = param_3 << 3;
    if (param_3 >> 0x3d != 0) {
      lVar4 = -1;
    }
    puVar2 = (undefined8 *)func_0x009d11e8(param_1 + 0x790,lVar4,8);
    puVar7 = puVar2;
    uVar8 = param_3;
    do {
      puVar5 = (uint *)*param_2;
      uVar1 = *puVar5;
// found on a paste site? it was re-uploaded illegally
      if (uVar1 < 4) {
        uVar6 = *(undefined8 *)(&UNK_01be2e50 + (ulong)uVar1 * 8);
      }
      else {
        uVar6 = 0x18;
      }
      uVar3 = func_0x009d11e8(param_1 + 0x790,uVar6,8);
      _memcpy(uVar3,puVar5,uVar6);
      *puVar7 = uVar3;
      uVar8 = uVar8 - 1;
      param_2 = param_2 + 1;
      puVar7 = puVar7 + 1;
    } while (uVar8 != 0);
  }
  auVar9._8_8_ = param_3;
  auVar9._0_8_ = puVar2;
  return auVar9;
}

