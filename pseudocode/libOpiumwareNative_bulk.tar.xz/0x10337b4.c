/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x10337b4:94ee93dabe
 */

/* WARNING: Removing unreachable block (ram,0x010337e0) */
/* WARNING: Removing unreachable block (ram,0x01033804) */

long FUN_010337b4(long param_1,long param_2)

{
  if (*(char **)(param_2 + 8) ==
      "ZN12_GLOBAL__N_19ASTDumper9dumpChildIZNS0_26dumpHLSLUnusualAnnotationsEN4llvm8ArrayRefIPN4hlsl17UnusualAnnotationEEEE3$_0EEvT_EUlbE_"
/*  reversing this took months of machine time  */
     ) {
    return param_1 + 8;
  }
  return 0;
}

