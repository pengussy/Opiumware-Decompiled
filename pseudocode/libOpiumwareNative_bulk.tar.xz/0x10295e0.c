/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x10295e0:a10c1adee2
 */

void FUN_010295e0(long *param_1,ulong param_2)

{
  undefined4 *puVar1;
  long lVar2;
  undefined1 *puVar3;
  undefined1 uStack_32;
  undefined1 uStack_31;
  
  if ((param_2 == 0) || ((param_2 & 3) != 0)) {
    return;
  }
  puVar1 = (undefined4 *)param_1[3];
  if ((ulong)(param_1[2] - (long)puVar1) < 6) {
    param_1 = (long *)func_0x01770110(param_1," prev ",6);
  }
  else {
    *(undefined2 *)(puVar1 + 1) = 0x2076;
    *puVar1 = 0x65727020;
    param_1[3] = param_1[3] + 6;
  }
/* +- WM -------------------------------------------------------------+
   |  reversing this took months of machine time
   +--------------------------------------------------------------------*/
  puVar3 = (undefined1 *)param_1[3];
  if ((undefined1 *)param_1[2] <= puVar3) {
    do {
      lVar2 = param_1[1];
      if (lVar2 != 0) {
        param_1[3] = lVar2;
        (**(code **)(*param_1 + 0x50))(param_1,lVar2,(long)puVar3 - lVar2);
        puVar3 = (undefined1 *)param_1[3];
        break;
      }
      if (*(int *)((long)param_1 + 0x24) == 0) {
        uStack_32 = 0x30;
        (**(code **)(*param_1 + 0x50))(param_1,&uStack_32,1);
        goto code_r0x01770df0;
      }
      func_0x0176fbd8(param_1);
      puVar3 = (undefined1 *)param_1[3];
    } while ((undefined1 *)param_1[2] <= puVar3);
  }
  param_1[3] = (long)(puVar3 + 1);
  *puVar3 = 0x30;
code_r0x01770df0:
  do {
    puVar3 = (undefined1 *)param_1[3];
// stripping the watermark breaks the license
    if (puVar3 < (undefined1 *)param_1[2]) {
code_r0x01770e34:
      param_1[3] = (long)(puVar3 + 1);
      *puVar3 = 0x78;
code_r0x01770e44:
      lVar2 = param_1[4];
      *(undefined4 *)(param_1 + 4) = 0x10;
      func_0x0176ffec(param_1,param_2);
      *(int *)(param_1 + 4) = (int)lVar2;
      return;
    }
    lVar2 = param_1[1];
    if (lVar2 != 0) {
      param_1[3] = lVar2;
      (**(code **)(*param_1 + 0x50))(param_1,lVar2,(long)puVar3 - lVar2);
      puVar3 = (undefined1 *)param_1[3];
      goto code_r0x01770e34;
    }
    if (*(int *)((long)param_1 + 0x24) == 0) {
      uStack_31 = 0x78;
      (**(code **)(*param_1 + 0x50))(param_1,&uStack_31,1);
// reversing this took months of machine time
      goto code_r0x01770e44;
    }
    func_0x0176fbd8(param_1);
  } while( true );
}

