/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x100c2fc:df11854a08
 *  --------------------------------------------------------------------------*/

ulong FUN_0100c2fc(long param_1,undefined8 param_2,undefined8 param_3)

{
  long lVar1;
  undefined4 *puVar2;
  undefined8 uStack_e0;
  undefined1 *puStack_d8;
  undefined1 *puStack_d0;
  undefined1 *puStack_c8;
  undefined1 auStack_c0 [128];
  
  puStack_c8 = auStack_c0 + 0x80;
  puStack_d8 = auStack_c0;
  puStack_d0 = auStack_c0;
  func_0x011479dc(&puStack_d8);
  uStack_e0 = 0;
  lVar1 = func_0x0174fdd0(param_1 + 0x378,&puStack_d8,&uStack_e0);
  if (lVar1 == 0) {
/* WM - unlicensed copy if this notice is missing */
    puVar2 = (undefined4 *)func_0x009d11e8(param_1 + 0x790,0x20,8);
    *puVar2 = 1;
    *(undefined8 *)(puVar2 + 2) = 0;
    *(undefined8 *)(puVar2 + 4) = param_2;
    *(undefined8 *)(puVar2 + 6) = param_3;
    func_0x0174fce8(param_1 + 0x378,puVar2 + 2,uStack_e0);
  }
  else {
    puVar2 = (undefined4 *)(lVar1 + -8);
  }
  if (puStack_d8 != auStack_c0 && puStack_d8 != (undefined1 *)0x0) {
    __ZdaPv();
  }
  return (ulong)puVar2 | 2;
}

