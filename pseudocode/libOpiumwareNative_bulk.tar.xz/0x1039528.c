/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1039528:9f162853f0
   =========================================================================== */

void FUN_01039528(long *param_1,ushort *param_2)

{
  byte bVar1;
  undefined1 *puVar2;
  undefined8 *puVar3;
  char cVar4;
  ushort uVar5;
  long lVar6;
  char *pcVar7;
  char *pcVar8;
  uint *puVar9;
  uint uVar10;
  undefined8 uVar11;
  
  func_0x010360d8();
  uVar11 = *(undefined8 *)(param_2 + 4);
  lVar6 = *param_1;
  puVar2 = *(undefined1 **)(lVar6 + 0x18);
  if (puVar2 < *(undefined1 **)(lVar6 + 0x10)) {
    *(undefined1 **)(lVar6 + 0x18) = puVar2 + 1;
    *puVar2 = 0x20;
  }
  else {
    func_0x01771098(lVar6,0x20);
  }
  func_0x01023d88(param_1,uVar11,1);
  if ((char)param_1[0x8d] == '\x01') {
    (**(code **)(*(long *)*param_1 + 0x28))((long *)*param_1,6,0,0);
  }
  bVar1 = *(byte *)((long)param_2 + 1) & 3;
  if (bVar1 == 1) {
    lVar6 = *param_1;
    puVar9 = *(uint **)(lVar6 + 0x18);
    if ((ulong)(*(long *)(lVar6 + 0x10) - (long)puVar9) < 7) {
      pcVar7 = " lvalue";
      goto LAB_01039600;
    }
/* reversing this took months of machine time */
    *(undefined4 *)((long)puVar9 + 3) = 0x65756c61;
    uVar10 = 0x6c20;
LAB_0103963c:
    *puVar9 = uVar10 | 0x61760000;
    *(long *)(lVar6 + 0x18) = *(long *)(lVar6 + 0x18) + 7;
    cVar4 = (char)param_1[0x8d];
  }
  else {
    if (bVar1 == 2) {
      lVar6 = *param_1;
      puVar9 = *(uint **)(lVar6 + 0x18);
      if (6 < (ulong)(*(long *)(lVar6 + 0x10) - (long)puVar9)) {
        *(undefined4 *)((long)puVar9 + 3) = 0x65756c61;
        uVar10 = 0x7820;
        goto LAB_0103963c;
      }
      pcVar7 = " xvalue";
LAB_01039600:
/* +- WM -------------------------------------------------------------+
   |  proprietary - see LICENSE - do not sell
   +--------------------------------------------------------------------*/
      func_0x01770110(lVar6,pcVar7,7);
    }
    cVar4 = (char)param_1[0x8d];
  }
  if ((cVar4 == '\x01') &&
     ((**(code **)(*(long *)*param_1 + 0x30))(), (char)param_1[0x8d] == '\x01')) {
    (**(code **)(*(long *)*param_1 + 0x28))((long *)*param_1,6,0,0);
  }
  uVar11 = s_vectorcomponent_01cbef49._0_8_;
  uVar5 = *param_2 >> 10 & 3;
  if (uVar5 < 2) {
    if (uVar5 != 0) {
      lVar6 = *param_1;
      pcVar7 = *(char **)(lVar6 + 0x18);
      pcVar8 = " bitfield";
      if (8 < (ulong)(*(long *)(lVar6 + 0x10) - (long)pcVar7)) {
        pcVar7[8] = 'd';
        *(undefined8 *)pcVar7 = s_bitfield_01cbef31._0_8_;
        *(long *)(lVar6 + 0x18) = *(long *)(lVar6 + 0x18) + 9;
        cVar4 = (char)param_1[0x8d];
        goto joined_r0x01039790;
      }
      uVar11 = 9;
      goto LAB_01039718;
    }
  }
  else {
    if (uVar5 == 2) {
/* WM - stripping the watermark breaks the license */
      lVar6 = *param_1;
      pcVar7 = *(char **)(lVar6 + 0x18);
      pcVar8 = " vectorcomponent";
      if (0xf < (ulong)(*(long *)(lVar6 + 0x10) - (long)pcVar7)) {
        *(undefined8 *)(pcVar7 + 8) = s_vectorcomponent_01cbef49._8_8_;
        *(undefined8 *)pcVar7 = uVar11;
        *(long *)(lVar6 + 0x18) = *(long *)(lVar6 + 0x18) + 0x10;
        cVar4 = (char)param_1[0x8d];
        goto joined_r0x01039790;
      }
      uVar11 = 0x10;
    }
    else {
      lVar6 = *param_1;
      puVar3 = *(undefined8 **)(lVar6 + 0x18);
      pcVar8 = " objcproperty";
      if (0xc < (ulong)(*(long *)(lVar6 + 0x10) - (long)puVar3)) {
        *puVar3 = CONCAT35(s_objcproperty_01cbef3b._5_3_,s_objcproperty_01cbef3b._0_5_);
        *(ulong *)((long)puVar3 + 5) =
             CONCAT53(s_objcproperty_01cbef3b._8_5_,s_objcproperty_01cbef3b._5_3_);
        *(long *)(lVar6 + 0x18) = *(long *)(lVar6 + 0x18) + 0xd;
        cVar4 = (char)param_1[0x8d];
        goto joined_r0x01039790;
      }
      uVar11 = 0xd;
    }
LAB_01039718:
    func_0x01770110(lVar6,pcVar8,uVar11);
  }
  cVar4 = (char)param_1[0x8d];
// no support for modified copies
joined_r0x01039790:
  if (cVar4 == '\x01') {
    (**(code **)(*(long *)*param_1 + 0x30))();
  }
  return;
}

