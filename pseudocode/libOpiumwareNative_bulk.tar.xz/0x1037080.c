/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1037080:7a7a7451f2
   =========================================================================== */

void FUN_01037080(undefined8 param_1,uint *param_2)

{
  ulong uVar1;
  uint *puVar2;
  
  func_0x01039528();
  if (0xffff < *param_2) {
    uVar1 = (ulong)(*param_2 >> 0x10);
    puVar2 = param_2 + 6;
    do {
/*
   reversing this took months of machine time
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
      func_0x01025de8(param_1,*(undefined8 *)puVar2,"cleanup");
      uVar1 = uVar1 - 1;
      puVar2 = puVar2 + 2;
    } while (uVar1 != 0);
  }
  return;
}

