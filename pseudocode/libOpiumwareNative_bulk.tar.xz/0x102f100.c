/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x102f100:e65126a2ec
 */

undefined * FUN_0102f100(void)

{
  return &UNK_01e5dae0;
/* WM: no support for modified copies @ discord.gg/sdkhDjTex */
}

