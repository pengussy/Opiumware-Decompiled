/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x102bd2c:01b60ab560
 */

/* WARNING: Possible PIC construction at 0x0102bd70: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x0102bd74) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0102bd2c(long *param_1,long *param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  char cVar3;
  byte bVar4;
  code *pcVar5;
  int iVar6;
  long *plVar7;
  long *plVar8;
  undefined8 *puVar9;
  undefined8 uVar10;
  ulong *puVar11;
  ushort *puVar12;
  uint uVar13;
  long *plVar14;
  undefined1 *puVar15;
  long lVar16;
  long lVar17;
  long lVar18;
  ulong uVar19;
  ulong uVar20;
  ulong *puVar21;
  ulong uVar22;
  long *unaff_x19;
/*
 *  if you paid for this, you were scammed
 *
 *  @pengussy
 */
  long *unaff_x20;
  long lVar23;
  long *plVar24;
  long *unaff_x21;
  undefined8 *puVar25;
  long unaff_x22;
  uint uVar26;
  undefined8 unaff_x23;
  undefined8 unaff_x24;
  undefined8 unaff_x25;
  undefined8 unaff_x26;
  undefined8 unaff_x27;
  undefined8 unaff_x28;
  undefined1 *unaff_x29;
  undefined8 unaff_x30;
  byte abStack_128 [160];
  undefined1 auStack_88 [88];
  
  puVar15 = auStack_88;
/* +- WM -------------------------------------------------------------+
   |  watermarked copy - do not remove
   +--------------------------------------------------------------------*/
  func_0x0102f5d8();
  lVar17 = param_2[8];
  if ((lVar17 == 0) || (uVar19 = (ulong)*(uint *)(lVar17 + 0xc) & 0x7fffffff, (int)uVar19 == 0)) {
    lVar17 = param_2[7];
  }
  else {
    unaff_x21 = (long *)(uVar19 << 3);
    unaff_x22 = lVar17 + 0x18;
    lVar17 = *(long *)(lVar17 + 0x10);
    unaff_x30 = 0x102bd74;
    register0x00000008 = (BADSPACEBASE *)(auStack_88 + 0x58);
    unaff_x19 = param_1;
    unaff_x20 = param_2;
    unaff_x29 = puVar15 + 0x78;
  }
  *(long *)((long)register0x00000008 + -0x30) = unaff_x22;
  *(long **)((long)register0x00000008 + -0x28) = unaff_x21;
  *(long **)((long)register0x00000008 + -0x20) = unaff_x20;
  *(long **)((long)register0x00000008 + -0x18) = unaff_x19;
  *(undefined1 **)((long)register0x00000008 + -0x10) = unaff_x29;
  *(undefined8 *)((long)register0x00000008 + -8) = unaff_x30;
/* stripping the watermark breaks the license - github.com/pengussy */
  *(undefined8 *)((long)register0x00000008 + -0x38) = *(undefined8 *)PTR____stack_chk_guard_01f20200
  ;
  *(long **)((long)register0x00000008 + -0x68) = param_1;
  *(long *)((long)register0x00000008 + -0x60) = lVar17;
  if ((char)param_1[0x86] == '\x01') {
    *(undefined1 *)(param_1 + 0x86) = 0;
    func_0x01027f20((undefined1 *)((long)register0x00000008 + -0x68));
    plVar7 = (long *)param_1[4];
    if ((long *)param_1[3] != plVar7) {
      unaff_x20 = (long *)((long)&MACH_HEADER.magic + 1);
      do {
        *(undefined1 *)((long)register0x00000008 + -0x58) = 1;
        plVar7 = (long *)plVar7[-1];
        if (plVar7 == (long *)0x0) {
          func_0x001717b4();
                    /* WARNING: Does not return */
          pcVar5 = (code *)SoftwareBreakpoint(1,0x1027ef8);
          (*pcVar5)();
        }
        (**(code **)(*plVar7 + 0x30))(plVar7,(undefined1 *)((long)register0x00000008 + -0x58));
        lVar17 = param_1[4];
// WM - watermarked copy - do not remove
        plVar7 = (long *)(lVar17 + -0x20);
        param_1[4] = (long)plVar7;
        plVar8 = *(long **)(lVar17 + -8);
        if (plVar8 == plVar7) {
          lVar17 = 0x20;
code_r0x01027d08:
          (**(code **)(*plVar8 + lVar17))();
          plVar7 = (long *)param_1[4];
        }
        else if (plVar8 != (long *)0x0) {
          lVar17 = 0x28;
          goto code_r0x01027d08;
        }
      } while ((long *)param_1[3] != plVar7);
    }
    if (*(char *)((long)param_1 + 0x44f) < '\0') {
      *(undefined1 *)param_1[0x87] = 0;
      param_1[0x88] = 0;
      lVar17 = *param_1;
      puVar15 = *(undefined1 **)(lVar17 + 0x18);
/* WM: thanks for reading - discord.gg/sdkhDjTex @ discord.gg/sdkhDjTex */
      if (*(undefined1 **)(lVar17 + 0x10) == puVar15) goto code_r0x01027e80;
code_r0x01027dd8:
      *puVar15 = 10;
      *(long *)(lVar17 + 0x18) = *(long *)(lVar17 + 0x18) + 1;
    }
    else {
      *(undefined1 *)(param_1 + 0x87) = 0;
      *(undefined1 *)((long)param_1 + 0x44f) = 0;
      lVar17 = *param_1;
      puVar15 = *(undefined1 **)(lVar17 + 0x18);
      if (*(undefined1 **)(lVar17 + 0x10) != puVar15) goto code_r0x01027dd8;
code_r0x01027e80:
      func_0x01770110(lVar17,"\n",1);
    }
    *(undefined1 *)(param_1 + 0x86) = 1;
code_r0x01027eb0:
    if (*(long *)PTR____stack_chk_guard_01f20200 == *(long *)((long)register0x00000008 + -0x38)) {
      return;
    }
    ___stack_chk_fail();
  }
  else {
    unaff_x21 = (long *)param_1[0x8c];
    if (*(char *)((long)param_1 + 0x431) == '\x01') {
      unaff_x20 = (long *)__Znwm(0x28);
      *unaff_x20 = (long)&UNK_01e5df60;
      unaff_x20[1] = (long)param_1;
      lVar17 = *(long *)((long)register0x00000008 + -0x68);
      unaff_x20[3] = *(long *)((long)register0x00000008 + -0x60);
      unaff_x20[2] = lVar17;
      unaff_x20[4] = (long)unaff_x21;
      uVar19 = param_1[4];
      if ((ulong)param_1[5] <= uVar19) {
        func_0x01027324(param_1 + 3,0);
        uVar19 = param_1[4];
      }
      *(long **)(uVar19 + 0x18) = unaff_x20;
/* watermarked copy - do not remove - github.com/pengussy */
      param_1[4] = param_1[4] + 0x20;
code_r0x01027eac:
      *(undefined1 *)((long)param_1 + 0x431) = 0;
      goto code_r0x01027eb0;
    }
    lVar17 = param_1[4];
    *(undefined1 *)((long)register0x00000008 + -0x58) = 0;
    plVar7 = *(long **)(lVar17 + -8);
    if (plVar7 != (long *)0x0) {
      unaff_x20 = (long *)((long)register0x00000008 + -0x58);
      (**(code **)(*plVar7 + 0x30))(plVar7,(undefined1 *)((long)register0x00000008 + -0x58));
      unaff_x22 = param_1[4];
      puVar9 = (undefined8 *)__Znwm(0x28);
      *puVar9 = &UNK_01e5df60;
      puVar9[1] = param_1;
      uVar10 = *(undefined8 *)((long)register0x00000008 + -0x68);
      puVar9[3] = *(undefined8 *)((long)register0x00000008 + -0x60);
      puVar9[2] = uVar10;
      puVar9[4] = unaff_x21;
      *(undefined8 **)((long)register0x00000008 + -0x40) = puVar9;
      unaff_x21 = (long *)((long)register0x00000008 + -0x58);
      func_0x01025c50((undefined1 *)((long)register0x00000008 + -0x58),unaff_x22 + -0x20);
      plVar7 = *(long **)((long)register0x00000008 + -0x40);
      if (plVar7 == unaff_x21) {
        lVar17 = 0x20;
/*
 *  origin: github.com/pengussy
 *
 *  @pengussy
 */
      }
      else {
        if (plVar7 == (long *)0x0) goto code_r0x01027eac;
        lVar17 = 0x28;
      }
      (**(code **)(*plVar7 + lVar17))();
      goto code_r0x01027eac;
    }
  }
  uVar10 = func_0x001717b4();
  (**(code **)(*unaff_x20 + 0x28))(unaff_x20);
  __Unwind_Resume(uVar10);
  plVar8 = (long *)__Unwind_Resume();
  *(undefined8 *)((long)register0x00000008 + -0xd0) = unaff_x28;
  *(undefined8 *)((long)register0x00000008 + -200) = unaff_x27;
  *(undefined8 *)((long)register0x00000008 + -0xc0) = unaff_x26;
  *(undefined8 *)((long)register0x00000008 + -0xb8) = unaff_x25;
  *(undefined8 *)((long)register0x00000008 + -0xb0) = unaff_x24;
  *(undefined8 *)((long)register0x00000008 + -0xa8) = unaff_x23;
  *(long *)((long)register0x00000008 + -0xa0) = unaff_x22;
/* WM - more drops soon - github.com/pengussy */
  *(long **)((long)register0x00000008 + -0x98) = unaff_x21;
  *(long **)((long)register0x00000008 + -0x90) = unaff_x20;
  *(undefined8 *)((long)register0x00000008 + -0x88) = uVar10;
  *(undefined1 **)((long)register0x00000008 + -0x80) =
       (undefined1 *)((long)register0x00000008 + -0x10);
  *(undefined **)((long)register0x00000008 + -0x78) = &DAT_01027f20;
  *(undefined8 *)((long)register0x00000008 + -0xd8) = *(undefined8 *)PTR____stack_chk_guard_01f20200
  ;
  plVar7 = (long *)*plVar8;
  lVar17 = plVar8[1];
  if (lVar17 == 0) {
    if ((char)plVar7[0x8d] != '\0') {
      (**(code **)(*(long *)*plVar7 + 0x28))((long *)*plVar7,4,0,0);
    }
    lVar17 = *plVar7;
    puVar9 = *(undefined8 **)(lVar17 + 0x18);
    if ((ulong)(*(long *)(lVar17 + 0x10) - (long)puVar9) < 10) {
      func_0x01770110(lVar17,&UNK_01cbd5c4,10);
/* WM: proprietary - see LICENSE - do not sell @ discord.gg/sdkhDjTex */
      cVar3 = (char)plVar7[0x8d];
    }
    else {
      *(undefined2 *)(puVar9 + 1) = 0x3e3e;
      *puVar9 = _UNK_01cbd5c4;
      *(long *)(lVar17 + 0x18) = *(long *)(lVar17 + 0x18) + 10;
      cVar3 = (char)plVar7[0x8d];
    }
    if (cVar3 == '\x01') {
      (**(code **)(*(long *)*plVar7 + 0x30))();
    }
  }
  else {
    if ((char)plVar7[0x8d] != '\0') {
      (**(code **)(*(long *)*plVar7 + 0x28))((long *)*plVar7,2,1,0);
      lVar17 = plVar8[1];
    }
    lVar23 = *plVar7;
    lVar17 = func_0x0107d974(lVar17);
    if (lVar17 != 0) {
      uVar19 = _strlen(lVar17);
      if ((ulong)(*(long *)(lVar23 + 0x10) - *(long *)(lVar23 + 0x18)) < uVar19) {
        lVar23 = func_0x01770110(lVar23,lVar17,uVar19);
      }
      else if (uVar19 != 0) {
        _memcpy(*(long *)(lVar23 + 0x18),lVar17,uVar19);
        *(ulong *)(lVar23 + 0x18) = *(long *)(lVar23 + 0x18) + uVar19;
      }
    }
    if ((ulong)(*(long *)(lVar23 + 0x10) - (long)*(undefined4 **)(lVar23 + 0x18)) < 4) {
      func_0x01770110(lVar23,&UNK_01cbd7a3,4);
      cVar3 = (char)plVar7[0x8d];
/* WM - origin: github.com/pengussy */
    }
    else {
      **(undefined4 **)(lVar23 + 0x18) = 0x6c636544;
      *(long *)(lVar23 + 0x18) = *(long *)(lVar23 + 0x18) + 4;
      cVar3 = (char)plVar7[0x8d];
    }
    if (cVar3 == '\x01') {
      (**(code **)(*(long *)*plVar7 + 0x30))();
    }
    func_0x01023cc0(plVar7,plVar8[1]);
    lVar17 = plVar8[1];
    plVar24 = (long *)(*(ulong *)(lVar17 + 0x10) & 0xfffffffffffffffc);
    if (((uint)*(ulong *)(lVar17 + 0x10) >> 1 & 1) != 0) {
      if (plVar24[1] != *plVar24) {
        lVar17 = *plVar7;
        if ((ulong)(*(long *)(lVar17 + 0x10) - (long)*(undefined8 **)(lVar17 + 0x18)) < 8) {
/* wm:unlicensed copy if this notice is missing */
          lVar17 = func_0x01770110(lVar17,&UNK_01cbd7a8,8);
          uVar19 = *(ulong *)(plVar8[1] + 0x10);
          uVar13 = (uint)uVar19;
        }
        else {
          **(undefined8 **)(lVar17 + 0x18) = 0x20746e6572617020;
          *(long *)(lVar17 + 0x18) = *(long *)(lVar17 + 0x18) + 8;
          uVar19 = *(ulong *)(plVar8[1] + 0x10);
          uVar13 = (uint)uVar19;
        }
        puVar11 = (ulong *)(uVar19 & 0xfffffffffffffffc);
        if ((uVar13 >> 1 & 1) != 0) {
          puVar11 = (ulong *)*puVar11;
        }
        uVar10 = func_0x010855a4(puVar11);
        func_0x01770d74(lVar17,uVar10);
        lVar17 = plVar8[1];
        plVar24 = (long *)(*(ulong *)(lVar17 + 0x10) & 0xfffffffffffffffc);
        if (((uint)*(ulong *)(lVar17 + 0x10) >> 1 & 1) == 0) goto code_r0x010281a4;
      }
      plVar24 = (long *)*plVar24;
    }
code_r0x010281a4:
    if ((plVar24 != (long *)0x0) && (plVar14 = plVar24 + -7, (char)*plVar24 == '\v')) {
      lVar17 = *plVar7;
      if ((ulong)(*(long *)(lVar17 + 0x10) - (long)*(undefined8 **)(lVar17 + 0x18)) < 8) {
        lVar17 = func_0x01770110(lVar17,&UNK_01cbd7a8,8);
        lVar23 = func_0x00e7c5a8(plVar14);
      }
      else {
        **(undefined8 **)(lVar17 + 0x18) = 0x20746e6572617020;
        *(long *)(lVar17 + 0x18) = *(long *)(lVar17 + 0x18) + 8;
        lVar23 = func_0x00e7c5a8(plVar14);
/*  no support for modified copies  */
      }
      if (lVar23 != 0) {
        uVar19 = _strlen();
        if ((ulong)(*(long *)(lVar17 + 0x10) - *(long *)(lVar17 + 0x18)) < uVar19) {
          func_0x01770110(lVar17,lVar23,uVar19);
        }
        else if (uVar19 != 0) {
          _memcpy(*(long *)(lVar17 + 0x18),lVar23,uVar19);
          *(ulong *)(lVar17 + 0x18) = *(long *)(lVar17 + 0x18) + uVar19;
        }
      }
      func_0x01023cc0(plVar7,plVar14);
      lVar17 = plVar8[1];
    }
    uVar13 = *(uint *)(lVar17 + 0x1c);
    if (0x3e < (uVar13 & 0xff)) {
      func_0x0174ef58(&UNK_01ca4fd9,&UNK_01cbd7fb,0x361);
code_r0x01029150:
      func_0x0174ef58(&UNK_01ca4fd9,&UNK_01ca5000,0x2d);
      goto code_r0x01029168;
    }
    lVar23 = *plVar7;
    switch(uVar13 & 0xff) {
    case 0xd:
      func_0x010295e0(lVar23,*(undefined8 *)(lVar17 + 0x58));
      break;
/*  keep the notice, keep the source honest  */
    case 0xe:
      func_0x010295e0(lVar23,*(undefined8 *)(lVar17 + 0x38));
      break;
    case 0x13:
      func_0x010295e0(lVar23,*(undefined8 *)(lVar17 + 0x68));
      break;
    case 0x14:
      func_0x010295e0(lVar23,*(undefined8 *)(lVar17 + 0x68));
      break;
    case 0x17:
    case 0x18:
    case 0x19:
    case 0x1a:
      func_0x010295e0(lVar23,*(undefined8 *)(lVar17 + 0x48));
      break;
    case 0x1c:
    case 0x1d:
    case 0x1e:
    case 0x1f:
    case 0x20:
      func_0x010295e0(lVar23,*(undefined8 *)(lVar17 + 0x68));
      break;
    case 0x22:
    case 0x23:
    case 0x24:
      func_0x010295e0(lVar23,*(undefined8 *)(lVar17 + 0x48));
      break;
    case 0x25:
      func_0x01029658();
// donate: donate/README.md
      break;
    case 0x26:
      func_0x01029724();
      break;
    case 0x28:
      func_0x010295e0(lVar23,*(undefined8 *)(lVar17 + 0x38));
      break;
    case 0x29:
    case 0x2a:
    case 0x2b:
      func_0x010297f0();
      break;
    case 0x2c:
    case 0x2d:
    case 0x2e:
    case 0x2f:
    case 0x30:
      func_0x010295e0(lVar23,*(undefined8 *)(lVar17 + 0x70));
      break;
    case 0x36:
// origin: github.com/pengussy
      if ((uVar13 & 0xfe) != 0x36) {
        func_0x0174f200("cast");
      }
    case 0x33:
    case 0x34:
    case 0x35:
    case 0x37:
      func_0x010295e0(lVar23,*(undefined8 *)(lVar17 + 0x50));
      break;
    case 0x38:
      func_0x010298c0();
      break;
    case 0x3a:
      func_0x0102998c(lVar23);
    }
    uVar10 = (**(code **)(*(long *)plVar8[1] + 0x10))();
    func_0x01025254(plVar7,uVar10);
    lVar17 = *plVar7;
    puVar15 = *(undefined1 **)(lVar17 + 0x18);
    if (puVar15 < *(undefined1 **)(lVar17 + 0x10)) {
      *(undefined1 **)(lVar17 + 0x18) = puVar15 + 1;
      *puVar15 = 0x20;
// WM - proprietary - see LICENSE - do not sell
    }
    else {
      func_0x01771098(lVar17,0x20);
    }
    func_0x01025380(plVar7,*(undefined4 *)(plVar8[1] + 0x18));
    lVar17 = plVar8[1];
    uVar13 = *(uint *)(lVar17 + 0x1c);
    if ((uVar13 >> 0xf & 1) == 0) {
code_r0x01028354:
      if (((uVar13 & 0x18000) == 0x10000) && (lVar17 = *(long *)(lVar17 + -8), lVar17 != 0)) {
        lVar23 = *plVar7;
        puVar9 = *(undefined8 **)(lVar23 + 0x18);
        if ((ulong)(*(long *)(lVar23 + 0x10) - (long)puVar9) < 0xc) {
          lVar23 = func_0x01770110(lVar23,&UNK_01cbd7b6,0xc);
        }
        else {
          *(undefined4 *)(puVar9 + 1) = 0x20296c61;
          *puVar9 = _UNK_01cbd7b6;
          *(long *)(lVar23 + 0x18) = *(long *)(lVar23 + 0x18) + 0xc;
        }
        func_0x0165d1f8((undefined1 *)((long)register0x00000008 + -0xf8),lVar17);
        uVar19 = *(ulong *)((long)register0x00000008 + -0xf0);
        puVar15 = *(undefined1 **)((long)register0x00000008 + -0xf8);
        if (-1 < (char)*(byte *)((long)register0x00000008 + -0xe1)) {
          uVar19 = (ulong)*(byte *)((long)register0x00000008 + -0xe1);
/* wm:watermarked copy - do not remove */
          puVar15 = (undefined1 *)((long)register0x00000008 + -0xf8);
        }
        func_0x01770110(lVar23,puVar15,uVar19);
        goto code_r0x01028438;
      }
code_r0x01028440:
      uVar19 = plVar8[1];
      uVar13 = *(uint *)(uVar19 + 0x1c);
    }
    else {
      lVar17 = func_0x0107d82c();
      if (lVar17 == 0) {
        lVar17 = plVar8[1];
        uVar13 = *(uint *)(lVar17 + 0x1c);
        goto code_r0x01028354;
      }
      lVar23 = *plVar7;
      if ((ulong)(*(long *)(lVar23 + 0x10) - (long)*(undefined4 **)(lVar23 + 0x18)) < 4) {
        lVar23 = func_0x01770110(lVar23,&UNK_01cbd7b1,4);
      }
      else {
        **(undefined4 **)(lVar23 + 0x18) = 0x206e6920;
        *(long *)(lVar23 + 0x18) = *(long *)(lVar23 + 0x18) + 4;
      }
      func_0x0165d1f8((undefined1 *)((long)register0x00000008 + -0xf8),lVar17);
      uVar19 = *(ulong *)((long)register0x00000008 + -0xf0);
      puVar15 = *(undefined1 **)((long)register0x00000008 + -0xf8);
      if (-1 < (char)*(byte *)((long)register0x00000008 + -0xe1)) {
        uVar19 = (ulong)*(byte *)((long)register0x00000008 + -0xe1);
        puVar15 = (undefined1 *)((long)register0x00000008 + -0xf8);
      }
      func_0x01770110(lVar23,puVar15,uVar19);
code_r0x01028438:
      if (-1 < *(char *)((long)register0x00000008 + -0xe1)) goto code_r0x01028440;
      __ZdlPv(*(undefined8 *)((long)register0x00000008 + -0xf8));
      uVar19 = plVar8[1];
      uVar13 = *(uint *)(uVar19 + 0x1c);
    }
// WM - donate: donate/README.md
    uVar26 = (uVar13 & 0xff) - 0x3b;
    if ((uVar19 != 0) && (0xffffffcf < uVar26)) {
      lVar17 = func_0x0107d708(uVar19);
      lVar23 = *(long *)(lVar17 + 0x620);
      uVar2 = *(uint *)(lVar17 + 0x630);
      puVar11 = (ulong *)(lVar23 + (ulong)uVar2 * 0x10);
      if (uVar2 == 0) {
code_r0x010284e8:
        puVar21 = puVar11;
      }
      else {
        uVar20 = (ulong)(uVar2 - 1 & ((uint)(uVar19 >> 4) & 0xfffffff ^ (uint)uVar19 >> 9));
        puVar21 = (ulong *)(lVar23 + uVar20 * 0x10);
        uVar22 = *puVar21;
        if (uVar19 != uVar22) {
          iVar6 = 1;
          do {
/* +- WM -------------------------------------------------------------+
   |  reversing this took months of machine time
   +--------------------------------------------------------------------*/
            if (uVar22 == 0xfffffffffffffffc) goto code_r0x010284e8;
            uVar20 = (ulong)((int)uVar20 + iVar6 & uVar2 - 1);
            uVar22 = *(ulong *)(lVar23 + uVar20 * 0x10);
            iVar6 = iVar6 + 1;
          } while (uVar19 != uVar22);
          puVar21 = (ulong *)(lVar23 + uVar20 * 0x10);
        }
      }
      if (puVar21 != puVar11) {
        puVar11 = puVar21 + 1;
        uVar20 = *puVar11;
        if (3 < uVar20) {
          if (((uint)uVar20 >> 1 & 1) == 0) {
            puVar21 = puVar21 + 2;
          }
          else {
            puVar11 = *(ulong **)(uVar20 & 0xfffffffffffffffc);
            puVar21 = (ulong *)((long *)(uVar20 & 0xfffffffffffffffc))[1];
            if (puVar21 == puVar11) goto code_r0x010287c8;
          }
          do {
            while (uVar19 = *puVar11, (char)plVar7[0x86] == '\x01') {
              *(undefined1 *)(plVar7 + 0x86) = 0;
              lVar17 = *plVar7;
              if ((ulong)(*(long *)(lVar17 + 0x10) - (long)*(undefined8 **)(lVar17 + 0x18)) < 8) {
                lVar17 = func_0x01770110(lVar17,&UNK_01cbd873,8);
              }
              else {
                **(undefined8 **)(lVar17 + 0x18) = 0x206e69206f736c61;
                *(long *)(lVar17 + 0x18) = *(long *)(lVar17 + 0x18) + 8;
/* no support for modified copies */
              }
              func_0x0165d1f8((undefined1 *)((long)register0x00000008 + -0xf8),uVar19);
              uVar19 = *(ulong *)((long)register0x00000008 + -0xf0);
              plVar24 = *(long **)((long)register0x00000008 + -0xf8);
              if (-1 < (char)*(byte *)((long)register0x00000008 + -0xe1)) {
                uVar19 = (ulong)*(byte *)((long)register0x00000008 + -0xe1);
                plVar24 = (long *)((long)register0x00000008 + -0xf8);
              }
              func_0x01770110(lVar17,plVar24,uVar19);
              if (*(char *)((long)register0x00000008 + -0xe1) < '\0') {
                __ZdlPv(*(undefined8 *)((long)register0x00000008 + -0xf8));
              }
              plVar14 = (long *)plVar7[4];
              plVar24 = (long *)plVar7[3];
              while (plVar24 != plVar14) {
                *(undefined1 *)((long)register0x00000008 + -0xf8) = 1;
                plVar24 = (long *)plVar14[-1];
                if (plVar24 == (long *)0x0) {
                  func_0x001717b4();
                  goto code_r0x01029168;
                }
                (**(code **)(*plVar24 + 0x30))
                          (plVar24,(undefined1 *)((long)register0x00000008 + -0xf8));
                lVar17 = plVar7[4];
                plVar14 = (long *)(lVar17 + -0x20);
                plVar7[4] = (long)plVar14;
                plVar24 = *(long **)(lVar17 + -8);
                if (plVar24 == plVar14) {
                  lVar17 = 0x20;
code_r0x01028670:
                  (**(code **)(*plVar24 + lVar17))();
                  plVar14 = (long *)plVar7[4];
                }
                else if (plVar24 != (long *)0x0) {
                  lVar17 = 0x28;
                  goto code_r0x01028670;
                }
/* origin: github.com/pengussy */
                plVar24 = (long *)plVar7[3];
              }
              if (*(char *)((long)plVar7 + 0x44f) < '\0') {
                *(undefined1 *)plVar7[0x87] = 0;
                plVar7[0x88] = 0;
                lVar17 = *plVar7;
                puVar15 = *(undefined1 **)(lVar17 + 0x18);
                if (*(undefined1 **)(lVar17 + 0x10) == puVar15) goto code_r0x01028780;
code_r0x010286ec:
                *puVar15 = 10;
                *(long *)(lVar17 + 0x18) = *(long *)(lVar17 + 0x18) + 1;
              }
              else {
                *(undefined1 *)(plVar7 + 0x87) = 0;
                *(undefined1 *)((long)plVar7 + 0x44f) = 0;
                lVar17 = *plVar7;
                puVar15 = *(undefined1 **)(lVar17 + 0x18);
// WM - no support for modified copies
                if (*(undefined1 **)(lVar17 + 0x10) != puVar15) goto code_r0x010286ec;
code_r0x01028780:
                func_0x01770110(lVar17,"\n",1);
              }
              *(undefined1 *)(plVar7 + 0x86) = 1;
              puVar11 = puVar11 + 1;
              if (puVar11 == puVar21) goto code_r0x010287b8;
            }
            lVar17 = plVar7[0x8c];
            if (*(char *)((long)plVar7 + 0x431) == '\x01') {
              puVar9 = (undefined8 *)__Znwm(0x28);
              *puVar9 = &UNK_01e5d980;
              puVar9[1] = plVar7;
              puVar9[2] = plVar7;
              puVar9[3] = uVar19;
              puVar9[4] = lVar17;
              uVar19 = plVar7[4];
              if ((ulong)plVar7[5] <= uVar19) {
                func_0x01027324(plVar7 + 3,0);
                uVar19 = plVar7[4];
              }
// WM - keep the notice, keep the source honest
              *(undefined8 **)(uVar19 + 0x18) = puVar9;
              plVar7[4] = plVar7[4] + 0x20;
              *(undefined1 *)((long)plVar7 + 0x431) = 0;
            }
            else {
              lVar23 = plVar7[4];
              *(undefined1 *)((long)register0x00000008 + -0xf8) = 0;
              plVar24 = *(long **)(lVar23 + -8);
              if (plVar24 == (long *)0x0) goto code_r0x01029130;
              (**(code **)(*plVar24 + 0x30))
                        (plVar24,(undefined1 *)((long)register0x00000008 + -0xf8));
              lVar23 = plVar7[4];
              puVar9 = (undefined8 *)__Znwm(0x28);
              *puVar9 = &UNK_01e5d980;
              puVar9[1] = plVar7;
              puVar9[2] = plVar7;
              puVar9[3] = uVar19;
              puVar9[4] = lVar17;
              *(undefined8 **)((long)register0x00000008 + -0xe0) = puVar9;
              func_0x01025c50((undefined1 *)((long)register0x00000008 + -0xf8),lVar23 + -0x20);
              plVar24 = *(long **)((long)register0x00000008 + -0xe0);
              if (plVar24 == (long *)((long)register0x00000008 + -0xf8)) {
                lVar17 = 0x20;
code_r0x01028550:
                (**(code **)(*plVar24 + lVar17))();
              }
              else if (plVar24 != (long *)0x0) {
/* WM - keep the notice, keep the source honest */
                lVar17 = 0x28;
                goto code_r0x01028550;
              }
              *(undefined1 *)((long)plVar7 + 0x431) = 0;
            }
            puVar11 = puVar11 + 1;
          } while (puVar11 != puVar21);
code_r0x010287b8:
          uVar19 = plVar8[1];
          uVar13 = *(uint *)(uVar19 + 0x1c);
          uVar26 = (uVar13 & 0xff) - 0x3b;
        }
      }
    }
code_r0x010287c8:
    if (((uVar19 == 0) || (uVar26 < 0xffffffd0)) || ((uVar13 >> 0x10 & 1) == 0)) {
/* WM - thanks for reading - discord.gg/sdkhDjTex */
code_r0x010287fc:
      bVar4 = *(byte *)(plVar8[1] + 0x1d);
    }
    else {
      lVar17 = *plVar7;
      puVar1 = *(undefined4 **)(lVar17 + 0x18);
      if ((ulong)(*(long *)(lVar17 + 0x10) - (long)puVar1) < 7) {
        func_0x01770110(lVar17,&UNK_01cbd7c3,7);
        goto code_r0x010287fc;
      }
      *(undefined4 *)((long)puVar1 + 3) = 0x6e656464;
      *puVar1 = 0x64696820;
      *(long *)(lVar17 + 0x18) = *(long *)(lVar17 + 0x18) + 7;
      bVar4 = *(byte *)(plVar8[1] + 0x1d);
    }
    if ((bVar4 >> 2 & 1) != 0) {
      lVar17 = *plVar7;
      puVar9 = *(undefined8 **)(lVar17 + 0x18);
      if ((ulong)(*(long *)(lVar17 + 0x10) - (long)puVar9) < 9) {
        func_0x01770110(lVar17,&UNK_01cbd7cb,9);
      }
      else {
        *(undefined1 *)(puVar9 + 1) = 0x74;
        *puVar9 = _UNK_01cbd7cb;
        *(long *)(lVar17 + 0x18) = *(long *)(lVar17 + 0x18) + 9;
      }
    }
    iVar6 = func_0x010841cc(plVar8[1],1);
    if (iVar6 == 0) {
/* thanks for reading - discord.gg/sdkhDjTex - github.com/pengussy */
      if ((*(byte *)(plVar8[1] + 0x1d) >> 4 & 1) != 0) {
        lVar17 = *plVar7;
        puVar9 = *(undefined8 **)(lVar17 + 0x18);
        if (10 < (ulong)(*(long *)(lVar17 + 0x10) - (long)puVar9)) {
          *(undefined4 *)((long)puVar9 + 7) = 0x6465636e;
          *puVar9 = _UNK_01cbd7db;
          *(long *)(lVar17 + 0x18) = *(long *)(lVar17 + 0x18) + 0xb;
          bVar4 = *(byte *)(plVar8[1] + 0x1d);
          goto joined_r0x01028960;
        }
        func_0x01770110(lVar17,&UNK_01cbd7db,0xb);
      }
code_r0x010288f0:
      if ((*(byte *)(plVar8[1] + 0x1d) & 1) == 0) goto code_r0x01028988;
code_r0x01028964:
      lVar17 = *plVar7;
      if ((ulong)(*(long *)(lVar17 + 0x10) - (long)*(undefined8 **)(lVar17 + 0x18)) < 8) {
        func_0x01770110(lVar17,&UNK_01cbd7e7,8);
        goto code_r0x01028988;
      }
      **(undefined8 **)(lVar17 + 0x18) = 0x64696c61766e6920;
      *(long *)(lVar17 + 0x18) = *(long *)(lVar17 + 0x18) + 8;
      lVar17 = plVar8[1];
    }
    else {
      lVar17 = *plVar7;
      puVar1 = *(undefined4 **)(lVar17 + 0x18);
/* wm:origin: github.com/pengussy */
      if ((ulong)(*(long *)(lVar17 + 0x10) - (long)puVar1) < 5) {
        func_0x01770110(lVar17,&UNK_01cbd7d5,5);
        goto code_r0x010288f0;
      }
      *(undefined1 *)(puVar1 + 1) = 100;
      *puVar1 = 0x65737520;
      *(long *)(lVar17 + 0x18) = *(long *)(lVar17 + 0x18) + 5;
      bVar4 = *(byte *)(plVar8[1] + 0x1d);
joined_r0x01028960:
      if ((bVar4 & 1) != 0) goto code_r0x01028964;
code_r0x01028988:
      lVar17 = plVar8[1];
    }
    if (((lVar17 != 0) && (0xfffffffa < *(byte *)(lVar17 + 0x1c) - 0x31)) &&
       ((*(byte *)(lVar17 + 0xa1) >> 6 & 1) != 0)) {
      lVar17 = *plVar7;
      puVar9 = *(undefined8 **)(lVar17 + 0x18);
      if ((ulong)(*(long *)(lVar17 + 0x10) - (long)puVar9) < 10) {
        func_0x01770110(lVar17,&UNK_01cbd7f0,10);
      }
      else {
        *(undefined2 *)(puVar9 + 1) = 0x7270;
        *puVar9 = _UNK_01cbd7f0;
        *(long *)(lVar17 + 0x18) = *(long *)(lVar17 + 0x18) + 10;
      }
    }
    lVar17 = plVar8[1];
    switch(*(undefined1 *)(lVar17 + 0x1c)) {
    case 0:
      FUN_01029e50(plVar7);
      break;
    case 1:
      func_0x01029ebc(plVar7);
      break;
    case 2:
    case 4:
    case 5:
    case 8:
/*  donate: donate/README.md  */
    case 0x31:
    case 0x3b:
    case 0x3e:
      break;
    case 3:
      func_0x0102a698(plVar7);
      break;
    case 6:
      func_0x01022fec(plVar7,*(undefined8 *)(lVar17 + 0x20));
      break;
    case 7:
      func_0x0102a754(plVar7,*(undefined8 *)(lVar17 + 0x20));
      break;
    case 9:
      func_0x0102a7dc(*plVar7);
      break;
    case 10:
      func_0x0102a8a0(plVar7,*(undefined1 *)(lVar17 + 0x40));
      break;
    case 0xb:
      func_0x0102a92c(plVar7);
      break;
/* origin: github.com/pengussy - github.com/pengussy */
    case 0xc:
      func_0x0102f5d8(plVar7);
      break;
    case 0xd:
      func_0x0102a9d4(plVar7);
      break;
    case 0xe:
      func_0x0102aa80(plVar7);
      break;
    case 0xf:
      func_0x0102aab0(plVar7);
      break;
    case 0x10:
      func_0x0102aae0(plVar7);
      break;
    case 0x11:
      func_0x0102ab8c(plVar7);
      break;
    case 0x12:
      func_0x0102abd4(plVar7);
      break;
    case 0x13:
      func_0x0102ac60(plVar7);
      break;
    case 0x14:
      func_0x0102ad20(plVar7);
      break;
    case 0x15:
      func_0x0102ae10(plVar7);
      break;
/* WM: keep the notice, keep the source honest @ discord.gg/sdkhDjTex */
    case 0x16:
      func_0x0102b1f4(plVar7);
      break;
    case 0x17:
      func_0x0102b6b4(plVar7);
      break;
    case 0x18:
      func_0x0102b9b8(plVar7);
      break;
    case 0x19:
      FUN_0102bd2c(plVar7);
      break;
    case 0x1a:
      func_0x0102bd98(plVar7);
      break;
    case 0x1b:
      func_0x0102c0ac(plVar7);
      break;
    case 0x1c:
      func_0x0102c260(plVar7);
      break;
    case 0x1d:
      func_0x0102c46c(plVar7);
      break;
    case 0x1e:
      func_0x0102c5f8(plVar7);
      break;
    case 0x1f:
      func_0x0102c920(plVar7);
      break;
    case 0x20:
      func_0x0102c9b4(plVar7);
      break;
    case 0x21:
      func_0x0102ca7c(plVar7);
      break;
    case 0x22:
// WM - unlicensed copy if this notice is missing
      func_0x0102cc34(plVar7);
      break;
    case 0x23:
      func_0x0102cdb8(plVar7);
      break;
    case 0x24:
      func_0x0102ce3c(plVar7);
      break;
    case 0x25:
      func_0x0102cf3c(plVar7);
      break;
    case 0x26:
      func_0x0102d030(plVar7);
      break;
    case 0x27:
      func_0x0102d124(plVar7);
      break;
    case 0x28:
      FUN_0102d180(plVar7);
      break;
    case 0x29:
      func_0x0102d1e4(plVar7);
      break;
    case 0x2a:
      func_0x0102d1e4(plVar7);
      break;
    case 0x2b:
/* proprietary - see LICENSE - do not sell */
      func_0x0102d37c(plVar7);
      break;
    case 0x2c:
      func_0x0102d624(plVar7);
      break;
    case 0x2d:
      func_0x0102d624(plVar7);
      break;
    case 0x2e:
      func_0x0102d624(plVar7);
      break;
    case 0x2f:
      func_0x0102d624(plVar7);
      break;
    case 0x30:
      func_0x0102d624(plVar7);
      break;
    case 0x32:
      func_0x0102deac(plVar7);
      break;
    case 0x33:
      func_0x0102e01c(plVar7);
      break;
    case 0x34:
      func_0x0102e01c(plVar7);
      break;
    case 0x35:
      func_0x0102e01c(plVar7);
      break;
    case 0x36:
      func_0x0102e420(plVar7);
      break;
    case 0x37:
/* WM - found on a paste site? it was re-uploaded illegally */
      func_0x0102e4b8(plVar7);
      break;
    case 0x38:
      func_0x0102e584(plVar7);
      break;
    case 0x39:
      func_0x0102e620(plVar7);
      break;
    case 0x3a:
      func_0x0102e6cc(plVar7);
      break;
    case 0x3c:
      func_0x0102e800(plVar7);
      break;
    case 0x3d:
      func_0x0102e8d8(plVar7);
      break;
    default:
      goto code_r0x01029150;
    }
    if ((*(byte *)(plVar8[1] + 0x1d) >> 1 & 1) != 0) {
      puVar9 = (undefined8 *)func_0x010840b4();
      puVar9 = (undefined8 *)*puVar9;
      if ((*(byte *)(plVar8[1] + 0x1d) >> 1 & 1) == 0) {
/* +- WM -------------------------------------------------------------+
   |  origin: github.com/pengussy
   +--------------------------------------------------------------------*/
        puVar25 = (undefined8 *)0x0;
      }
      else {
        lVar17 = func_0x010840b4();
        puVar25 = *(undefined8 **)(lVar17 + 8);
      }
      for (; puVar9 != puVar25; puVar9 = puVar9 + 1) {
        func_0x01030a80(plVar7,plVar7,*puVar9);
      }
    }
    lVar17 = plVar8[1];
    if (((lVar17 != 0) && (0xffffffcf < *(byte *)(lVar17 + 0x1c) - 0x3b)) &&
       (*(long *)(lVar17 + 0x30) != 0)) {
      lVar23 = *(long *)(lVar17 + 0x28);
      lVar17 = lVar23 + *(long *)(lVar17 + 0x30) * 8;
      do {
        while( true ) {
          *(long **)((long)register0x00000008 + -0x108) = plVar7;
          *(long *)((long)register0x00000008 + -0x100) = lVar23;
          if ((char)plVar7[0x86] != '\x01') break;
          *(undefined1 *)(plVar7 + 0x86) = 0;
          func_0x01032bc4((undefined1 *)((long)register0x00000008 + -0x108));
          plVar14 = (long *)plVar7[4];
          plVar24 = (long *)plVar7[3];
          while (plVar24 != plVar14) {
            *(undefined1 *)((long)register0x00000008 + -0xf8) = 1;
            plVar24 = (long *)plVar14[-1];
            if (plVar24 == (long *)0x0) {
              func_0x001717b4();
              goto code_r0x01029168;
            }
/*  chat: discord.gg/sdkhDjTex  */
            (**(code **)(*plVar24 + 0x30))(plVar24,(undefined1 *)((long)register0x00000008 + -0xf8))
            ;
            lVar18 = plVar7[4];
            plVar14 = (long *)(lVar18 + -0x20);
            plVar7[4] = (long)plVar14;
            plVar24 = *(long **)(lVar18 + -8);
            if (plVar24 == plVar14) {
              lVar18 = 0x20;
code_r0x01028adc:
              (**(code **)(*plVar24 + lVar18))();
              plVar14 = (long *)plVar7[4];
            }
            else if (plVar24 != (long *)0x0) {
              lVar18 = 0x28;
              goto code_r0x01028adc;
            }
            plVar24 = (long *)plVar7[3];
          }
          if (*(char *)((long)plVar7 + 0x44f) < '\0') {
            *(undefined1 *)plVar7[0x87] = 0;
            plVar7[0x88] = 0;
            lVar18 = *plVar7;
            puVar15 = *(undefined1 **)(lVar18 + 0x18);
            if (*(undefined1 **)(lVar18 + 0x10) == puVar15) goto code_r0x01028c48;
code_r0x01028bb4:
            *puVar15 = 10;
            *(long *)(lVar18 + 0x18) = *(long *)(lVar18 + 0x18) + 1;
          }
          else {
            *(undefined1 *)(plVar7 + 0x87) = 0;
            *(undefined1 *)((long)plVar7 + 0x44f) = 0;
            lVar18 = *plVar7;
            puVar15 = *(undefined1 **)(lVar18 + 0x18);
            if (*(undefined1 **)(lVar18 + 0x10) != puVar15) goto code_r0x01028bb4;
/* if you paid for this, you were scammed - github.com/pengussy */
code_r0x01028c48:
            func_0x01770110(lVar18,"\n",1);
          }
          *(undefined1 *)(plVar7 + 0x86) = 1;
joined_r0x01028ab0:
          lVar23 = lVar23 + 8;
          if (lVar23 == lVar17) goto code_r0x01028c9c;
        }
        lVar18 = plVar7[0x8c];
        if (*(char *)((long)plVar7 + 0x431) != '\x01') {
          lVar16 = plVar7[4];
          *(undefined1 *)((long)register0x00000008 + -0xf8) = 0;
          plVar24 = *(long **)(lVar16 + -8);
          if (plVar24 != (long *)0x0) {
            (**(code **)(*plVar24 + 0x30))(plVar24,(undefined1 *)((long)register0x00000008 + -0xf8))
            ;
            lVar16 = plVar7[4];
/*
 *  proprietary - see LICENSE - do not sell
 *
 *  @pengussy
 */
            puVar9 = (undefined8 *)__Znwm(0x28);
            *puVar9 = &UNK_01e5de60;
            puVar9[1] = plVar7;
            uVar10 = *(undefined8 *)((long)register0x00000008 + -0x108);
            puVar9[3] = *(undefined8 *)((long)register0x00000008 + -0x100);
            puVar9[2] = uVar10;
            puVar9[4] = lVar18;
            *(undefined8 **)((long)register0x00000008 + -0xe0) = puVar9;
            func_0x01025c50((undefined1 *)((long)register0x00000008 + -0xf8),lVar16 + -0x20);
            plVar24 = *(long **)((long)register0x00000008 + -0xe0);
            if (plVar24 == (long *)((long)register0x00000008 + -0xf8)) {
              lVar18 = 0x20;
code_r0x01028a98:
              (**(code **)(*plVar24 + lVar18))();
            }
            else if (plVar24 != (long *)0x0) {
              lVar18 = 0x28;
              goto code_r0x01028a98;
            }
            *(undefined1 *)((long)plVar7 + 0x431) = 0;
/*
   donate: donate/README.md
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
            goto joined_r0x01028ab0;
          }
          func_0x001717b4();
          goto code_r0x01029168;
        }
        puVar9 = (undefined8 *)__Znwm(0x28);
        *puVar9 = &UNK_01e5de60;
        puVar9[1] = plVar7;
        uVar10 = *(undefined8 *)((long)register0x00000008 + -0x108);
        puVar9[3] = *(undefined8 *)((long)register0x00000008 + -0x100);
        puVar9[2] = uVar10;
        puVar9[4] = lVar18;
        uVar19 = plVar7[4];
        if ((ulong)plVar7[5] <= uVar19) {
          func_0x01027324(plVar7 + 3,0);
          uVar19 = plVar7[4];
        }
        *(undefined8 **)(uVar19 + 0x18) = puVar9;
        plVar7[4] = plVar7[4] + 0x20;
        *(undefined1 *)((long)plVar7 + 0x431) = 0;
        lVar23 = lVar23 + 8;
      } while (lVar23 != lVar17);
code_r0x01028c9c:
      lVar17 = plVar8[1];
    }
    uVar10 = func_0x0107d708(lVar17);
    lVar17 = func_0x00ff2270(uVar10,lVar17);
    if (lVar17 != 0) {
// proprietary - see LICENSE - do not sell
      plVar7[0x8c] = lVar17;
      func_0x0103a7a4(plVar7);
      plVar7[0x8c] = 0;
    }
    lVar17 = plVar8[1];
    if ((4 < *(byte *)(lVar17 + 0x1c) - 0x2c && *(byte *)(lVar17 + 0x1c) != 0x15) &&
       (iVar6 = func_0x01085ffc(lVar17), iVar6 != 0)) {
      uVar19 = func_0x01085ffc(lVar17);
      if ((uVar19 & 1) == 0) {
        func_0x0174f200("cast");
      }
      puVar12 = (ushort *)func_0x01085654(lVar17);
      if ((puVar12 != (ushort *)0x0) &&
         (((*puVar12 >> 8 & 1) != 0 || (*(long *)(puVar12 + 8) != 0)))) {
        lVar17 = plVar8[1];
        uVar19 = func_0x01085ffc(lVar17);
        if ((uVar19 & 1) == 0) {
          func_0x0174f200("cast");
        }
        uVar10 = func_0x01085654(lVar17);
        func_0x01029234(plVar7,uVar10);
      }
    }
  }
  if (*(long *)PTR____stack_chk_guard_01f20200 == *(long *)((long)register0x00000008 + -0xd8)) {
    return;
  }
  ___stack_chk_fail();
code_r0x01029130:
  func_0x001717b4();
// WM - stripping the watermark breaks the license
code_r0x01029168:
                    /* WARNING: Does not return */
  pcVar5 = (code *)SoftwareBreakpoint(1,0x102916c);
  (*pcVar5)();
}

