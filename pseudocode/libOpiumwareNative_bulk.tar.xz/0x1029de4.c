/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x1029de4:e553028761
 */

/* WARNING: Removing unreachable block (ram,0x01029e10) */
/* WARNING: Removing unreachable block (ram,0x01029e34) */

long FUN_01029de4(long param_1,long param_2)

{
  if (*(char **)(param_2 + 8) ==
      "ZN12_GLOBAL__N_19ASTDumper9dumpChildIZZNS0_8dumpDeclEPKN5clang4DeclEENK3$_0clEvEUlvE_EEvT_EUlbE_"
/* wm:no support for modified copies */
     ) {
    return param_1 + 8;
  }
  return 0;
}

