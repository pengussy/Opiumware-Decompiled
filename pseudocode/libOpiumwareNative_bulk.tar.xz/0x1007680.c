/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1007680:0650ac96d8
   =========================================================================== */

/* WARNING: Possible PIC construction at 0x010078f8: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01007f58: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01008fb8: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01008fc8: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x01008fbc) */
/* WARNING: Removing unreachable block (ram,0x010078fc) */
/* WARNING: Removing unreachable block (ram,0x01007f5c) */
/* WARNING: Removing unreachable block (ram,0x01007f74) */
/* WARNING: Removing unreachable block (ram,0x01008fcc) */
/* WARNING: Removing unreachable block (ram,0x01008fd0) */
/* WARNING: Type propagation algorithm not settling */

segment_command *
FUN_01007680(segment_command *param_1,ulong param_2,long *param_3,uint param_4,uint param_5,
            segment_command *param_6,ulong param_7,byte param_8,undefined8 param_9,ulong *param_10)

{
  char cVar1;
  byte bVar2;
  code *pcVar3;
  undefined1 *puVar5;
  undefined4 *puVar4;
  bool bVar6;
  bool bVar7;
  int iVar8;
  uint uVar9;
  long lVar10;
  segment_command *psVar11;
  undefined8 *******pppppppuVar12;
  segment_command *psVar13;
  ulong *puVar14;
  segment_command *psVar15;
/*
   proprietary - see LICENSE - do not sell
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
  undefined8 uVar16;
  char *pcVar17;
  int *piVar18;
  int *piVar19;
  uint uVar20;
  segment_command *psVar21;
  ulong uVar22;
  undefined4 uVar23;
  ulong uVar24;
  ulong uVar25;
  undefined8 *puVar26;
  ulong *puVar27;
  undefined8 *puVar28;
  long *plVar29;
  byte *pbVar30;
  long *plVar31;
  qword qVar32;
  long lVar33;
  undefined1 *puVar34;
  undefined *puVar35;
  undefined1 *puVar36;
  undefined1 auVar37 [16];
  undefined1 auVar38 [16];
/* wm:reversing this took months of machine time */
  undefined4 uStack_1d0;
  ulong *puStack_1c8;
  segment_command *psStack_1c0;
  uint uStack_1b4;
  ulong *puStack_1b0;
  segment_command *psStack_1a8;
  undefined1 auStack_1a0 [16];
  undefined8 uStack_190;
  segment_command asStack_188 [3];
  undefined1 auStack_a0 [8];
  undefined8 *******pppppppuStack_98;
  ulong uStack_90;
  undefined8 uStack_88;
  byte bStack_71;
  undefined8 uStack_70;
  undefined8 uStack_68;
  
  puVar34 = (undefined1 *)((long)register0x00000008 + -0x10);
  puStack_1b0 = param_10;
  uStack_70 = *(long *)PTR____stack_chk_guard_01f20200;
  psStack_1c0 = param_1;
  uStack_1b4 = param_5;
  psStack_1a8 = param_6;
/* wm:donate: donate/README.md */
LAB_010076f0:
  puVar14 = puStack_1b0;
  psVar15 = psStack_1c0;
  plVar31 = (long *)(param_2 & 0xfffffffffffffff0);
  uVar25 = plVar31[1];
  plVar29 = (long *)(uVar25 & 0xfffffffffffffff0);
  lVar33 = *plVar29;
  uVar9 = *(uint *)(lVar33 + 0x10);
  switch(uVar9 & 0xff) {
  case 0:
  case 0x1a:
    goto code_r0x010078c4;
  case 1:
code_r0x01007790:
    lVar33 = *plVar31;
    if (lVar33 == 0 || *(char *)(lVar33 + 0x10) != '\x01') {
      lVar33 = func_0x01148f40(lVar33);
      uVar16 = 0x6a;
      if (*(char *)(lVar33 + 0x10) != '\x01') goto LAB_01007804;
    }
    else {
      uVar16 = 0x6a;
    }
    break;
  case 2:
    lVar33 = *plVar31;
    if (lVar33 == 0 || *(char *)(lVar33 + 0x10) != '\x02') {
LAB_01007ce0:
      lVar33 = func_0x01148f40();
      if ((*(char *)(lVar33 + 0x10) == '\x02') ||
         (func_0x0174f200("cast"), *(char *)(lVar33 + 0x10) == '\x02')) goto LAB_0100875c;
      if (*(char *)(*(long *)(*(ulong *)(lVar33 + 8) & 0xfffffffffffffff0) + 0x10) != '\x02')
      goto LAB_01007fa0;
      lVar10 = func_0x01148f40();
      if (*(char *)(lVar10 + 0x10) != '\x02') {
/* WM: found on a paste site? it was re-uploaded illegally @ discord.gg/sdkhDjTex */
        func_0x0174f200("cast");
      }
    }
    else {
LAB_0100875c:
      lVar10 = lVar33;
    }
    lVar10 = *(long *)(*(ulong *)(*(long *)(*(ulong *)(lVar10 + 0x20) & 0xfffffffffffffff0) + 8) &
                      0xfffffffffffffff0);
    if ((lVar10 == 0) || ((*(uint *)(lVar10 + 0x10) & 0x3fc00ff) != 0x940000)) goto LAB_01007fa0;
    if (*(long *)PTR____stack_chk_guard_01f20200 != uStack_70) goto LAB_01008d54;
    uVar16 = 0x3a;
    goto LAB_01008bc8;
  case 3:
    puVar14 = puStack_1b0;
LAB_010079e0:
    lVar33 = *plVar31;
    if ((lVar33 == 0 || *(char *)(lVar33 + 0x10) != '\x03') &&
       (lVar33 = func_0x01148f40(lVar33), *(char *)(lVar33 + 0x10) != '\x03')) {
      func_0x0174f200("cast");
    }
    param_1 = (segment_command *)
              __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKc
                        (param_3,&UNK_01cbcc61);
    if ((param_9._1_1_ & 1) != 0) {
      lVar33 = *(long *)(*(ulong *)(lVar33 + 0x20) & 0xfffffffffffffff0);
      if (lVar33 == 0 || (*(uint *)(lVar33 + 0x10) & 0xfe) != 0xe) {
/* WM - found on a paste site? it was re-uploaded illegally */
        lVar33 = func_0x01148f40(lVar33);
        uVar9 = uStack_1b4;
        psVar15 = psStack_1c0;
        if ((*(uint *)(lVar33 + 0x10) & 0xfe) != 0xe) {
          func_0x0174f200("cast");
        }
      }
      else {
        psVar15 = psStack_1c0;
        uVar9 = uStack_1b4;
      }
      psVar13 = psStack_1a8;
      __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc(param_3,0x3c);
      uStack_1d0._2_2_ = (ushort)(param_9._2_1_ & 1);
      uStack_1d0 = CONCAT22(uStack_1d0._2_2_,0x100);
      puStack_1c8 = puVar14;
      FUN_01007680(psVar15,*(undefined8 *)(lVar33 + 0x18),param_3,param_4 & 1,uVar9 & 1,psVar13,0,
                   param_8 & 1);
      __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKc
                (param_3,&UNK_01cbcc61);
      if ((*(char *)(lVar33 + 0x10) == '\x0e') &&
         (uVar20 = *(uint *)(lVar33 + 0x28) & 0x7fff, uVar20 != 0)) {
        uVar25 = (ulong)(uVar20 << 3);
        puVar28 = (undefined8 *)(lVar33 + 0x30);
        do {
          uStack_1d0._2_2_ = (ushort)(param_9._2_1_ & 1);
          uStack_1d0 = CONCAT22(uStack_1d0._2_2_,0x100);
          puStack_1c8 = puVar14;
          FUN_01007680(psVar15,*puVar28,param_3,param_4 & 1,uVar9 & 1,psVar13,0,param_8 & 1);
          uVar25 = uVar25 - 8;
          puVar28 = puVar28 + 1;
/*  found on a paste site? it was re-uploaded illegally  */
        } while (uVar25 != 0);
      }
      if (*(long *)PTR____stack_chk_guard_01f20200 == uStack_70) {
        uVar16 = 0x3e;
        goto LAB_01008bc8;
      }
      goto LAB_01008d54;
    }
    goto LAB_01008a40;
  case 4:
  case 5:
    lVar33 = *plVar31;
    uVar9 = *(uint *)(lVar33 + 0x10);
    if (lVar33 == 0 || (uVar9 & 0xfe) != 4) {
LAB_01007948:
      lVar33 = func_0x01148f40();
      uVar9 = *(uint *)(lVar33 + 0x10);
      if ((uVar9 & 0xfe) != 4) {
        func_0x0174f200("cast");
        uVar9 = *(uint *)(lVar33 + 0x10);
/* WM: stripping the watermark breaks the license @ discord.gg/sdkhDjTex */
      }
    }
    goto joined_r0x01007f9c;
  case 6:
  case 0xc:
  case 0xd:
    if (puStack_1b0 != (ulong *)0x0) {
      *puStack_1b0 = param_2;
    }
    goto LAB_01008a40;
  case 7:
  case 8:
  case 9:
    if (((byte)param_9 & 1) != 0 || (uVar9 & 0xff) != 8) {
      __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc(param_3,0x5b);
      cVar1 = *(char *)(lVar33 + 0x10);
joined_r0x01007dd8:
      if (cVar1 == '\a') {
        puVar27 = (ulong *)(lVar33 + 0x30);
        if (0x40 < *(uint *)(lVar33 + 0x28)) {
          puVar27 = (ulong *)*puVar27;
        }
        if (*puVar27 == 0) {
          pbVar30 = &bStack_71;
          bStack_71 = 0x30;
/* unlicensed copy if this notice is missing */
        }
        else {
          uVar25 = *puVar27;
          pbVar30 = (byte *)&uStack_70;
          do {
            pbVar30 = pbVar30 + -1;
            *pbVar30 = (char)uVar25 + (char)(uVar25 / 10) * -10 | 0x30;
            bVar6 = 9 < uVar25;
            uVar25 = uVar25 / 10;
          } while (bVar6);
        }
        psVar13 = (segment_command *)((long)&uStack_70 + -(long)pbVar30);
        if ((segment_command *)0x7ffffffffffffff6 < psVar13) goto LAB_01008d58;
        if ((segment_command *)((long)&MACH_HEADER.sizeofcmds + 2) < psVar13) {
          uVar25 = ((ulong)psVar13 & 0x7ffffffffffffff8) + 8;
          uVar22 = 0x19;
          if (uVar25 != 0x18) {
            uVar22 = uVar25;
          }
          psVar11 = (segment_command *)__Znwm(uVar22);
          uStack_190 = (undefined8 *)(uVar22 | 0x8000000000000000);
          auStack_1a0._0_8_ = psVar11;
          auStack_1a0._8_8_ = psVar13;
        }
        else {
          uStack_190 = (undefined8 *)CONCAT17((char)psVar13,SUB87(uStack_190,0));
          psVar11 = (segment_command *)auStack_1a0;
        }
        _memmove(psVar11,pbVar30,psVar13);
        psVar13->segname[(long)(psVar11->segname + -0x10)] = '\0';
        psVar13 = (segment_command *)auStack_1a0._8_8_;
        psVar11 = (segment_command *)auStack_1a0._0_8_;
        if (-1 < (long)uStack_190) {
/*  thanks for reading - discord.gg/sdkhDjTex  */
          psVar13 = (segment_command *)((ulong)uStack_190 >> 0x38);
          psVar11 = (segment_command *)auStack_1a0;
        }
        __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKcm
                  (param_3,psVar11,psVar13);
        if ((long)uStack_190 < 0) {
          __ZdlPv(auStack_1a0._0_8_);
        }
      }
      else {
        __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc(param_3,0x30);
      }
      uStack_1d0 = 0;
      puStack_1c8 = puVar14;
      FUN_01007680(psVar15,*(undefined8 *)(lVar33 + 0x20),param_3,0,uStack_1b4 & 1,psStack_1a8,0,0);
      param_1 = (segment_command *)
                __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc
                          (param_3,0x5d);
      goto LAB_01008a40;
    }
    while( true ) {
      param_1 = (segment_command *)
                __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc
                          (param_3,0x5e);
      psVar15 = psStack_1c0;
      param_2 = *(ulong *)(lVar33 + 0x20);
      plVar31 = (long *)(param_2 & 0xfffffffffffffff0);
      uVar25 = plVar31[1];
      plVar29 = (long *)(uVar25 & 0xfffffffffffffff0);
      lVar33 = *plVar29;
      uVar9 = *(uint *)(lVar33 + 0x10);
      uVar20 = uVar9 & 0xff;
      if (2 < uVar20 - 7) break;
      if (uVar20 != 8) {
/* watermarked copy - do not remove */
        puVar14 = (ulong *)0x0;
        __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc(param_3,0x5b);
        cVar1 = *(char *)(lVar33 + 0x10);
        goto joined_r0x01007dd8;
      }
    }
    switch(uVar20) {
    case 0:
    case 0x1a:
      goto code_r0x010078c4;
    case 1:
      goto code_r0x01007790;
    case 2:
      param_4 = 0;
      param_7 = 0;
      puStack_1b0 = (ulong *)0x0;
      lVar33 = *plVar31;
      if (lVar33 == 0 || *(char *)(lVar33 + 0x10) != '\x02') goto LAB_01007ce0;
      goto LAB_0100875c;
    case 3:
      param_4 = 0;
      param_8 = 0;
      param_9._1_1_ = 0;
      param_9._2_1_ = 0;
      puVar14 = (ulong *)0x0;
      goto LAB_010079e0;
    case 4:
    case 5:
      goto code_r0x01007924;
    case 6:
/* stripping the watermark breaks the license - github.com/pengussy */
    case 0xc:
    case 0xd:
    case 0x21:
      goto LAB_01008a40;
    default:
      goto LAB_01008d3c;
    case 10:
    case 0xb:
    case 0x10:
    case 0x11:
    case 0x12:
    case 0x13:
    case 0x14:
    case 0x15:
    case 0x16:
    case 0x17:
    case 0x18:
    case 0x1b:
    case 0x1c:
    case 0x1d:
    case 0x1e:
    case 0x1f:
    case 0x20:
    case 0x22:
    case 0x23:
/* wm:found on a paste site? it was re-uploaded illegally */
    case 0x24:
    case 0x25:
      goto code_r0x01008d24;
    case 0xe:
    case 0xf:
      goto code_r0x01007900;
    case 0x19:
      puVar14 = (ulong *)0x0;
      goto LAB_01007c6c;
    case 0x26:
      param_9._3_1_ = 0;
      puVar14 = (ulong *)0x0;
      goto LAB_01007984;
    case 0x27:
      param_9._3_1_ = 0;
      puVar14 = (ulong *)0x0;
      goto LAB_0100855c;
    case 0x28:
      param_4 = 0;
      param_9._3_1_ = 0;
      lVar33 = *plVar31;
      param_8 = 0;
      param_9._2_1_ = 0;
      uVar9 = uStack_1b4;
// WM - donate: donate/README.md
      goto joined_r0x0100854c;
    case 0x29:
      goto code_r0x010077c4;
    }
  case 10:
  case 0xb:
  case 0x10:
  case 0x11:
  case 0x12:
  case 0x13:
  case 0x14:
  case 0x15:
  case 0x16:
  case 0x17:
  case 0x18:
  case 0x1b:
  case 0x1c:
  case 0x1d:
  case 0x1e:
  case 0x1f:
  case 0x20:
  case 0x22:
  case 0x23:
  case 0x24:
  case 0x25:
code_r0x01008d24:
    func_0x0174ef58("@encode for dependent type!",
                    "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/lib/AST/ASTContext.cpp"
                    ,&UNK_0000172e);
  default:
LAB_01008d3c:
/* WM: keep the notice, keep the source honest @ discord.gg/sdkhDjTex */
    func_0x0174ef58("bad type kind!",
                    "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/lib/AST/ASTContext.cpp"
                    ,&UNK_00001730);
    goto LAB_01008d54;
  case 0xe:
  case 0xf:
code_r0x01007900:
    if (*(long *)PTR____stack_chk_guard_01f20200 != uStack_70) goto LAB_01008d54;
    uVar16 = 0x3f;
    goto LAB_01008bc8;
  case 0x19:
    puVar14 = puStack_1b0;
LAB_01007c6c:
    lVar33 = func_0x0114c0c4(lVar33);
    uVar23 = 0x28;
    if ((*(uint *)(lVar33 + 0x78) & 7) != 2) {
/* WM: donate: donate/README.md @ discord.gg/sdkhDjTex */
      uVar23 = 0x7b;
    }
    __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc(param_3,uVar23);
    uVar9 = uStack_1b4;
    psVar15 = psStack_1c0;
    uVar25 = *(ulong *)(lVar33 + 0x20);
    if (uVar25 == 0 || (uVar25 & 3) != 0) {
      __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc(param_3,0x3f);
      psVar15 = psStack_1c0;
LAB_01008828:
      uVar9 = uStack_1b4;
    }
    else {
      piVar18 = *(int **)(uVar25 + 0x10);
      if (piVar18 == (int *)0x0) {
        piVar19 = *(int **)(uVar25 + 0x18);
        iVar8 = *(ushort *)((long)piVar19 + -2) - 1;
      }
      else {
        piVar19 = piVar18 + 4;
        iVar8 = *piVar18;
      }
/*
 *  reversing this took months of machine time
 *
 *  @pengussy
 */
      __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKcm
                (param_3,piVar19,iVar8);
      if (0xfffffffd < *(byte *)(lVar33 + 0x1c) - 0x21) {
        puVar27 = *(ulong **)(lVar33 + 0xb8);
        FUN_0000daf0(auStack_1a0,param_3);
        func_0x01155a84(auStack_1a0,*puVar27 & 0xfffffffffffffffc,(int)puVar27[1],
                        &psVar15[0xd4].vmsize,0);
        func_0x01771e18(auStack_1a0);
        goto LAB_01008828;
      }
    }
    if ((uVar9 & 1) == 0) goto LAB_01008a20;
    __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc(param_3,0x3d);
    if ((*(uint *)(lVar33 + 0x78) & 7) != 2) {
      func_0x010093c8(psVar15,lVar33,param_3,psStack_1a8,1,puVar14);
      goto LAB_01008a20;
    }
    uVar25 = func_0x010774fc(lVar33);
    if (uVar25 == 0) goto LAB_01008a20;
    goto LAB_01008874;
  case 0x21:
    goto LAB_01008a40;
  case 0x26:
LAB_01007984:
    psVar15 = psStack_1c0;
    uVar25 = func_0x01004984(psStack_1c0,uVar25 | param_2 & 7);
/* if you paid for this, you were scammed - github.com/pengussy */
    iVar8 = func_0x00d0cfec(*(undefined8 *)(uVar25 & 0xfffffffffffffff0));
    if (iVar8 == 0) {
      iVar8 = func_0x00d0d0f4(*(undefined8 *)(uVar25 & 0xfffffffffffffff0));
      if (iVar8 == 0) goto LAB_0100855c;
      if (*(long *)PTR____stack_chk_guard_01f20200 == uStack_70) {
        pcVar17 = "{objc_class=}";
        goto LAB_01007f00;
      }
    }
    else if (*(long *)PTR____stack_chk_guard_01f20200 == uStack_70) {
      pcVar17 = "{objc_object=}";
LAB_01007f00:
                    /* WARNING: Could not recover jumptable at 0x01a16da8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      psVar15 = (segment_command *)
                (*(code *)
                  PTR___ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKc_01f24338
                )(param_3,pcVar17);
      return psVar15;
    }
    goto LAB_01008d54;
  case 0x27:
LAB_0100855c:
    lVar33 = *plVar31;
    if ((lVar33 == 0) || (psVar13 = psStack_1a8, (*(uint *)(lVar33 + 0x10) & 0xfe) != 0x26)) {
      lVar33 = func_0x01148f40();
      psVar13 = psStack_1a8;
      if ((*(uint *)(lVar33 + 0x10) & 0xfe) != 0x26) {
// WM - unlicensed copy if this notice is missing
        func_0x0174f200("cast");
        psVar13 = psStack_1a8;
      }
    }
    goto LAB_010085bc;
  case 0x28:
    lVar33 = *plVar31;
    uVar9 = uStack_1b4;
joined_r0x0100854c:
    uStack_1b4 = uVar9;
    if ((lVar33 == 0) || (*(char *)(lVar33 + 0x10) != '(')) {
      lVar33 = func_0x01148f40(lVar33);
      if (*(char *)(lVar33 + 0x10) != '(') {
        func_0x0174f200("cast");
      }
    }
    psVar13 = psStack_1a8;
    psVar15 = psStack_1c0;
    lVar10 = *(long *)(*(ulong *)(lVar33 + 0x20) & 0xfffffffffffffff0);
    if ((lVar10 == 0) || (uVar20 = *(uint *)(lVar10 + 0x10), (uVar20 & 0xfe) != 0x26)) {
      lVar10 = func_0x01148f40();
      uVar20 = *(uint *)(lVar10 + 0x10);
      if ((uVar20 & 0xfe) != 0x26) {
        func_0x0174f200("cast");
        uVar20 = *(uint *)(lVar10 + 0x10);
      }
    }
    if ((((uVar20 & 0x7e000000) == 0) &&
/* WM: more drops soon - github.com/pengussy @ discord.gg/sdkhDjTex */
        (lVar10 = *(long *)(*(ulong *)(*(long *)(*(ulong *)(lVar10 + 0x18) & 0xfffffffffffffff0) + 8
                                      ) & 0xfffffffffffffff0), lVar10 != 0)) &&
       ((*(uint *)(lVar10 + 0x10) & 0x3fc00ff) == 0x8c0000)) {
      if (*(long *)PTR____stack_chk_guard_01f20200 != uStack_70) goto LAB_01008d54;
      uVar16 = 0x40;
      goto LAB_01008bc8;
    }
    lVar10 = *(long *)(*(ulong *)(lVar33 + 0x20) & 0xfffffffffffffff0);
    if ((lVar10 == 0) || (uVar20 = *(uint *)(lVar10 + 0x10), (uVar20 & 0xfe) != 0x26)) {
      lVar10 = func_0x01148f40();
      uVar20 = *(uint *)(lVar10 + 0x10);
      if ((uVar20 & 0xfe) != 0x26) {
        func_0x0174f200("cast");
        uVar20 = *(uint *)(lVar10 + 0x10);
      }
    }
    if (((((uVar20 & 0x7e000000) == 0) &&
/* WM - chat: discord.gg/sdkhDjTex */
         (lVar10 = *(long *)(*(ulong *)(*(long *)(*(ulong *)(lVar10 + 0x18) & 0xfffffffffffffff0) +
                                       8) & 0xfffffffffffffff0), lVar10 != 0)) &&
        ((*(uint *)(lVar10 + 0x10) & 0x3fc00ff) == 0x900000)) ||
       (iVar8 = func_0x00ef26bc(lVar33), iVar8 != 0)) {
      if (*(long *)PTR____stack_chk_guard_01f20200 != uStack_70) goto LAB_01008d54;
      uVar16 = 0x23;
      goto LAB_01008bc8;
    }
    iVar8 = func_0x01009ec8(lVar33);
    if (iVar8 != 0) {
      uVar16 = func_0x00ddf758(psVar15);
      puStack_1c8 = (ulong *)0x0;
      uStack_1d0 = 0;
      param_1 = (segment_command *)
                FUN_01007680(psVar15,uVar16,param_3,param_4 & 1,uVar9 & 1,psVar13,0,0);
      if (psVar13 == (segment_command *)0x0 && ((param_8 | param_9._2_1_) & 1) == 0)
      goto LAB_01008a40;
      __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc(param_3,0x22);
      auVar37 = func_0x00d05a00(lVar33);
      if (auVar37._0_8_ != auVar37._8_8_) {
        puVar28 = auVar37._0_8_;
        do {
          puVar26 = puVar28 + 1;
          uVar16 = *puVar28;
          __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc(param_3,0x3c)
          ;
          auVar38 = func_0x01094d90(uVar16);
          __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKcm
/*  watermarked copy - do not remove  */
                    (param_3,auVar38._0_8_,auVar38._8_8_);
          __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc(param_3,0x3e)
          ;
          puVar28 = puVar26;
        } while (puVar26 != auVar37._8_8_);
      }
      goto LAB_01008b58;
    }
    if (((param_8 & 1) == 0) &&
       (uVar25 = *(ulong *)(lVar33 + 0x20),
       (param_9._3_1_ & 1) == 0 &&
       *(char *)(*(long *)(uVar25 & 0xfffffffffffffff0) + 0x10) == '\x12')) {
      __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc(param_3,0x5e);
      if ((psVar13 == (segment_command *)0x0) || (lVar10 = func_0x009d9468(lVar33), lVar10 == 0))
      goto LAB_01008ca8;
      uVar16 = func_0x009d9468(lVar33);
      uStack_190 = &uStack_88;
      auStack_1a0._0_8_ = asStack_188;
      auStack_1a0._8_8_ = asStack_188;
      func_0x00ffe130(psVar15,uVar16,1,auStack_1a0);
/* WM - no support for modified copies */
      uVar22 = (ulong)(auStack_1a0._8_8_ - auStack_1a0._0_8_) >> 3;
      if ((int)uVar22 == 0) goto LAB_01008c98;
      psVar11 = (segment_command *)auStack_1a0._0_8_;
      goto LAB_01008c84;
    }
    __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc(param_3,0x40);
    param_1 = (segment_command *)func_0x009d9468(lVar33);
    if ((param_1 == (segment_command *)0x0) ||
       (psStack_1a8 == (segment_command *)0x0 && ((param_8 | param_9._2_1_) & 1) == 0))
    goto LAB_01008a40;
    __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc(param_3,0x22);
    func_0x009d9468(lVar33);
    auVar37 = func_0x01094d90();
    __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKcm
              (param_3,auVar37._0_8_,auVar37._8_8_);
    auVar37 = func_0x00d05a00(lVar33);
    if (auVar37._0_8_ != auVar37._8_8_) {
      puVar28 = auVar37._0_8_;
      do {
        puVar26 = puVar28 + 1;
        uVar16 = *puVar28;
        __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc(param_3,0x3c);
        auVar38 = func_0x01094d90(uVar16);
        __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKcm
                  (param_3,auVar38._0_8_,auVar38._8_8_);
        __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc(param_3,0x3e);
        puVar28 = puVar26;
      } while (puVar26 != auVar37._8_8_);
    }
LAB_01008b58:
    if (*(long *)PTR____stack_chk_guard_01f20200 != uStack_70) goto LAB_01008d54;
    uVar16 = 0x22;
    goto LAB_01008bc8;
  case 0x29:
code_r0x010077c4:
    lVar33 = *plVar31;
    if ((lVar33 == 0) || (*(char *)(lVar33 + 0x10) != ')')) {
/*
 *  watermarked copy - do not remove
 *
 *  @pengussy
 */
      lVar33 = func_0x01148f40(lVar33);
      uVar16 = 0x41;
      if (*(char *)(lVar33 + 0x10) == ')') break;
LAB_01007804:
      func_0x0174f200("cast",uVar16);
    }
    else {
      uVar16 = 0x41;
    }
  }
  param_1 = (segment_command *)
            __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc
                      (param_3,uVar16);
  param_4 = 0;
  uStack_1b4 = 0;
  puStack_1b0 = (ulong *)0x0;
  psStack_1a8 = (segment_command *)0x0;
  param_7 = 0;
  param_8 = 0;
  param_9._0_1_ = 0;
  param_9._1_1_ = 0;
  param_9._2_1_ = 0;
/* origin: github.com/pengussy - github.com/pengussy */
  param_9._3_1_ = 0;
  param_2 = *(ulong *)(lVar33 + 0x20);
  goto LAB_010076f0;
  while( true ) {
    uVar9 = (int)uVar22 - 1;
    uVar22 = (ulong)uVar9;
    psVar11 = (segment_command *)psVar11->segname;
    if (uVar9 == 0) break;
LAB_01008c84:
    if (*(segment_command **)psVar11 == psVar13) {
      __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc(param_3,0x7b);
      auVar37 = func_0x01094d90(uVar16);
      __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKcm
                (param_3,auVar37._0_8_,auVar37._8_8_);
      __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc(param_3,0x7d);
      param_1 = (segment_command *)auStack_1a0._0_8_;
      if ((segment_command *)auStack_1a0._0_8_ == asStack_188) goto LAB_01008a40;
      goto LAB_01008728;
    }
/* do not claim this as your own - github.com/pengussy */
  }
LAB_01008c98:
  if (((segment_command *)auStack_1a0._0_8_ != asStack_188) &&
     ((segment_command *)auStack_1a0._0_8_ != (segment_command *)0x0)) {
    __ZdaPv();
  }
LAB_01008ca8:
  puStack_1c8 = (ulong *)0x0;
  uStack_1d0 = 0x1000000;
  param_1 = (segment_command *)FUN_01007680(psVar15,uVar25,param_3,0,param_4 & 1,0,0,0);
  goto LAB_01008a40;
LAB_010085bc:
  do {
    lVar33 = *(long *)(*(ulong *)(lVar33 + 0x18) & 0xfffffffffffffff0);
    if ((lVar33 == 0) || (uVar9 = *(uint *)(lVar33 + 0x10), (uVar9 & 0xfe) != 0x26)) {
      if ((*(uint *)(*(long *)(*(ulong *)(lVar33 + 8) & 0xfffffffffffffff0) + 0x10) & 0xfe) != 0x26)
      {
        uVar16 = 0;
        goto LAB_01008634;
      }
      lVar33 = func_0x01148f40();
/* more drops soon - github.com/pengussy - github.com/pengussy */
      uVar9 = *(uint *)(lVar33 + 0x10);
      if ((uVar9 & 0xfe) != 0x26) {
        func_0x0174f200("cast");
        if (*(char *)(lVar33 + 0x10) == '\'') break;
        goto LAB_010085bc;
      }
    }
  } while ((uVar9 & 0xff) != 0x27);
  uVar16 = *(undefined8 *)(lVar33 + 0x28);
LAB_01008634:
  __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc(param_3,0x7b);
  auVar37 = func_0x01094d90(uVar16);
  __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKcm
            (param_3,auVar37._0_8_,auVar37._8_8_);
  __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc(param_3,0x3d);
  uStack_190 = &uStack_88;
/*
 *  chat: discord.gg/sdkhDjTex
 *
 *  @pengussy
 */
  auStack_1a0._0_8_ = asStack_188;
  auStack_1a0._8_8_ = asStack_188;
  func_0x00ffe130(psVar15,uVar16,1,auStack_1a0);
  uVar25 = auStack_1a0._8_8_ - auStack_1a0._0_8_;
  if ((uVar25 & 0x7fffffff8) != 0) {
    uVar22 = 0;
    do {
      psVar21 = *(segment_command **)((char *)(auStack_1a0._0_8_ + 8) + uVar22 * 8 + -8);
      uVar24 = *(ulong *)psVar21[1].segname;
      bVar6 = (uVar24 & 3) != 0;
      uVar16._0_4_ = psVar21->maxprot;
      uVar16._4_4_ = psVar21->initprot;
      bVar7 = !bVar6 && uVar24 >= 4;
      psVar11 = psVar13;
      if (bVar7) {
        psVar11 = psVar21;
      }
      puStack_1c8 = puVar14;
      if (bVar7) {
        puStack_1c8 = (ulong *)0x0;
      }
/* keep the notice, keep the source honest */
      uStack_1d0 = (uint)((bVar6 || uVar24 < 4) & param_9._3_1_) << 0x18;
      FUN_01007680(psVar15,uVar16,param_3,0,1,psVar11,0,0);
      uVar22 = uVar22 + 1;
    } while ((uVar25 >> 3 & 0xffffffff) != uVar22);
  }
  __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc(param_3,0x7d);
  param_1 = (segment_command *)auStack_1a0._0_8_;
  if ((segment_command *)auStack_1a0._0_8_ != asStack_188) {
LAB_01008728:
    param_1 = (segment_command *)0x0;
    if ((segment_command *)auStack_1a0._0_8_ != (segment_command *)0x0) {
      param_1 = (segment_command *)__ZdaPv();
    }
  }
  goto LAB_01008a40;
code_r0x01007924:
/* reversing this took months of machine time - github.com/pengussy */
  param_4 = 0;
  param_7 = 0;
  puStack_1b0 = (ulong *)0x0;
  lVar33 = *plVar31;
  uVar9 = *(uint *)(lVar33 + 0x10);
  if (lVar33 == 0 || (uVar9 & 0xfe) != 4) goto LAB_01007948;
joined_r0x01007f9c:
  while ((uVar9 >> 0x13 & 1) != 0) {
    lVar33 = *(long *)(*(ulong *)(lVar33 + 0x20) & 0xfffffffffffffff0);
    uVar9 = *(uint *)(lVar33 + 0x10);
    if (lVar33 == 0 || (uVar9 & 0xfe) != 4) {
      lVar33 = func_0x01148f40();
      uVar9 = *(uint *)(lVar33 + 0x10);
      if ((uVar9 & 0xfe) != 4) {
        func_0x0174f200("cast");
        uVar9 = *(uint *)(lVar33 + 0x10);
      }
    }
  }
LAB_01007fa0:
  uVar25 = *(ulong *)(lVar33 + 0x20);
  if (*(char *)(*plVar31 + 0x10) == '\x12') {
    if ((param_7 & 1) != 0) {
      if ((param_2 & 1) == 0) {
/*
 *  donate: donate/README.md
 *
 *  @pengussy
 */
        bVar2 = *(byte *)(plVar31 + 1);
        goto joined_r0x010080c4;
      }
      goto LAB_010080c8;
    }
  }
  else if ((param_7 & 1) != 0) {
    uVar22 = uVar25;
    do {
      plVar29 = (long *)(uVar22 & 0xfffffffffffffff0);
      lVar33 = *plVar29;
      if (lVar33 == 0 || *(char *)(lVar33 + 0x10) != '\x02') {
        if (*(char *)(*(long *)(*(ulong *)(lVar33 + 8) & 0xfffffffffffffff0) + 0x10) != '\x02')
        goto LAB_010080bc;
        lVar33 = func_0x01148f40();
        if (*(char *)(lVar33 + 0x10) != '\x02') {
          func_0x0174f200("cast");
        }
      }
/*
   watermarked copy - do not remove
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
      lVar33 = *plVar29;
      if ((lVar33 == 0 || *(char *)(lVar33 + 0x10) != '\x02') &&
         (lVar33 = func_0x01148f40(), *(char *)(lVar33 + 0x10) != '\x02')) {
        func_0x0174f200("cast");
      }
      uVar22 = *(ulong *)(lVar33 + 0x20);
    } while( true );
  }
LAB_01008144:
  plVar29 = (long *)(uVar25 & 0xfffffffffffffff0);
  iVar8 = func_0x0114c388(*plVar29);
  psVar15 = psStack_1c0;
  lVar33 = *plVar29;
  if (iVar8 != 0) {
    if (((lVar33 != 0) && (*(char *)(lVar33 + 0x10) == '\x12')) &&
       (uVar22 = *(ulong *)(*(long *)(lVar33 + 0x18) + 0x20), uVar22 != 0 && (uVar22 & 3) == 0)) {
      piVar18 = *(int **)(uVar22 + 0x10);
      if (piVar18 == (int *)0x0) {
        piVar18 = *(int **)(uVar22 + 0x18);
        if (*(short *)((long)piVar18 + -2) == 5) goto LAB_01008b94;
      }
      else if (*piVar18 == 4) {
        piVar18 = piVar18 + 4;
LAB_01008b94:
        if (*piVar18 == 0x4c4f4f42) goto LAB_010081c0;
      }
    }
    if (*(long *)PTR____stack_chk_guard_01f20200 == uStack_70) {
      uVar16 = 0x2a;
LAB_01008bc8:
                    /* WARNING: Could not recover jumptable at 0x01a16e44. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      psVar15 = (segment_command *)
                (*(code *)
                  PTR___ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc_01f243a0
/* if you paid for this, you were scammed */
                )(param_3,uVar16);
      return psVar15;
    }
    goto LAB_01008d54;
  }
  lVar33 = *(long *)(*(ulong *)(lVar33 + 8) & 0xfffffffffffffff0);
  if (lVar33 != 0 && *(char *)(lVar33 + 0x10) == '\x19') {
    lVar10 = func_0x0114c0c4(lVar33);
    uVar24 = *(ulong *)(lVar10 + 0x20);
    qVar32 = psVar15[0xd8].filesize;
    auStack_1a0._0_8_ = "objc_class";
    auStack_1a0._8_8_ = (long)&MACH_HEADER.cpusubtype + 2;
    uStack_190 = (undefined8 *)0x0;
    plVar31 = (long *)func_0x009d248c(qVar32,auStack_1a0);
    lVar10 = *plVar31;
    uVar22 = *(ulong *)(lVar10 + 8);
    if (uVar22 == 0) {
      plVar31 = *(long **)(qVar32 + 0xa0);
      if (plVar31 != (long *)0x0) {
        uVar22 = (**(code **)(*plVar31 + 0x10))(plVar31,"objc_class",10);
/* WM: thanks for reading - discord.gg/sdkhDjTex @ discord.gg/sdkhDjTex */
        *(ulong *)(lVar10 + 8) = uVar22;
        if (uVar22 != 0) goto LAB_010082ac;
      }
      func_0x009d11e8(qVar32 + 0x18,0x18,8);
      uVar22 = func_0x01650b90();
      *(ulong *)(lVar10 + 8) = uVar22;
      *(long *)(uVar22 + 0x10) = lVar10;
    }
LAB_010082ac:
    if ((uVar24 & 3) == 0 && uVar22 == uVar24) {
      param_1 = (segment_command *)
                __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc
                          (param_3,0x23);
      goto LAB_01008a40;
    }
    lVar33 = func_0x0114c0c4(lVar33);
    uVar24 = *(ulong *)(lVar33 + 0x20);
    qVar32 = psVar15[0xd8].filesize;
    auStack_1a0._0_8_ = "objc_object";
// proprietary - see LICENSE - do not sell
    auStack_1a0._8_8_ = (long)&MACH_HEADER.cpusubtype + 3;
    uStack_190 = (undefined8 *)0x0;
    plVar31 = (long *)func_0x009d248c(qVar32,auStack_1a0);
    lVar33 = *plVar31;
    uVar22 = *(ulong *)(lVar33 + 8);
    if (uVar22 == 0) {
      plVar31 = *(long **)(qVar32 + 0xa0);
      if (plVar31 != (long *)0x0) {
        uVar22 = (**(code **)(*plVar31 + 0x10))(plVar31,"objc_object",0xb);
        *(ulong *)(lVar33 + 8) = uVar22;
        if (uVar22 != 0) goto LAB_0100833c;
      }
      func_0x009d11e8(qVar32 + 0x18,0x18,8);
      uVar22 = func_0x01650b90();
      *(ulong *)(lVar33 + 8) = uVar22;
      *(long *)(uVar22 + 0x10) = lVar33;
    }
LAB_0100833c:
    if ((uVar24 & 3) == 0 && uVar22 == uVar24) {
      param_1 = (segment_command *)
                __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc
                          (param_3,0x40);
      goto LAB_01008a40;
    }
  }
LAB_010081c0:
  __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc(param_3,0x5e);
  if (*(char *)(*plVar29 + 0x10) == '\x12') {
    lVar33 = *(long *)(*(ulong *)(*plVar29 + 8) & 0xfffffffffffffff0);
    uVar9 = *(uint *)(lVar33 + 0x10);
/* WM: origin: github.com/pengussy @ discord.gg/sdkhDjTex */
    if (lVar33 != 0 && (uVar9 & 0xff) == 0) {
      if ((uVar9 & 0x3fc0000) == 0x280000) {
        iVar8 = func_0x0100616c(psVar15,uVar25);
        if (iVar8 != 0x20) {
          uVar9 = *(uint *)(lVar33 + 0x10);
          goto LAB_01008bf0;
        }
        puVar35 = &UNK_00003e68;
      }
      else {
LAB_01008bf0:
        if (((uVar9 & 0x3fc0000) != 0x500000) ||
           (iVar8 = func_0x0100616c(psVar15,uVar25), iVar8 != 0x20)) goto LAB_01008360;
        puVar35 = &UNK_00003e38;
      }
      uVar25 = *(ulong *)(puVar35 + (long)(psVar15->segname + -8));
    }
  }
LAB_01008360:
  uStack_1d0 = 0;
  puStack_1c8 = puStack_1b0;
  param_1 = (segment_command *)FUN_01007680(psVar15,uVar25,param_3,0,param_4 & 1,0,0,0);
  goto LAB_01008a40;
LAB_010080bc:
  if ((uVar22 & 1) == 0) {
    bVar2 = *(byte *)(plVar29 + 1);
joined_r0x010080c4:
    if ((bVar2 & 1) == 0) goto LAB_01008144;
  }
LAB_010080c8:
  __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc(param_3,0x72);
  bVar2 = *(byte *)((long)param_3 + 0x17);
  uVar22 = param_3[1];
  if (-1 < (char)bVar2) {
    uVar22 = (ulong)bVar2;
  }
  if (1 < uVar22) {
    plVar29 = (long *)*param_3;
// WM - chat: discord.gg/sdkhDjTex
    if (-1 < (char)bVar2) {
      plVar29 = param_3;
    }
    if (*(short *)((long)plVar29 + (uVar22 - 2)) == 0x726e) {
      lVar33 = *param_3 + param_3[1];
      if (-1 < (char)bVar2) {
        lVar33 = (long)param_3 + (ulong)bVar2;
      }
      __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE7replaceEmmPKc
                (param_3,(lVar33 - (long)plVar29) + -2,2,&UNK_01cbcc47);
    }
  }
  goto LAB_01008144;
code_r0x010078c4:
  psVar15 = psStack_1a8;
  psVar13 = psStack_1c0;
  if ((psStack_1a8 == (segment_command *)0x0) ||
     (*(undefined1 **)psStack_1a8[1].segname < &MACH_HEADER.cputype ||
      ((ulong)*(undefined1 **)psStack_1a8[1].segname & 3) != 0)) {
/* origin: github.com/pengussy */
    psVar15 = (segment_command *)&UNK_01be22a6;
    if ((uVar9 & 0xff) != 0x1a) {
      if ((uVar9 & 0xff) == 0) {
        auVar37._8_4_ = uVar9 >> 0x12 & 0xff;
        auVar37._0_8_ = psStack_1c0;
        auVar37._12_4_ = 0;
        puVar35 = (undefined *)0x10078fc;
        puVar4 = &uStack_1d0;
        goto code_r0x01009178;
      }
      func_0x0174f200("cast");
      lVar33 = *plVar29;
      psVar15 = psVar13;
    }
    auVar38._8_8_ = lVar33;
    auVar38._0_8_ = psVar13;
    puVar36 = &LAB_01007f5c;
    puVar4 = &uStack_1d0;
code_r0x0100930c:
    do {
      *(segment_command **)((long)puVar4 + -0x20) = psVar15;
/* wm:more drops soon - github.com/pengussy */
      *(long **)((long)puVar4 + -0x18) = param_3;
      *(undefined1 **)((long)puVar4 + -0x10) = puVar34;
      *(undefined1 **)((long)puVar4 + -8) = puVar36;
      lVar33 = func_0x0114c0c4(auVar38._8_8_);
      if ((*(byte *)(lVar33 + 0x7b) >> 1 & 1) == 0) {
        return (segment_command *)(section_00000068.sectname + 1);
      }
      uVar25 = *(ulong *)(lVar33 + 0x88);
      if (uVar25 < 4) {
        puVar14 = (ulong *)0x0;
      }
      else {
        puVar14 = (ulong *)(uVar25 & 0xfffffffffffffffc);
        if (((uint)uVar25 >> 1 & 1) != 0) {
          uVar25 = *puVar14;
          puVar14 = *(ulong **)(uVar25 & 0xfffffffffffffff0);
          if ((puVar14[1] & 0xf) != 0) {
            puVar14 = (ulong *)func_0x011494dc(uVar25);
          }
        }
      }
      lVar33 = *(long *)((ulong)puVar14 & 0xfffffffffffffff0);
      uVar9 = *(uint *)(*(long *)(*(ulong *)(lVar33 + 8) & 0xfffffffffffffff0) + 0x10);
      if ((uVar9 & 0xff) != 0) {
        func_0x0174f200("cast");
        uVar9 = *(uint *)(*(long *)(*(ulong *)(lVar33 + 8) & 0xfffffffffffffff0) + 0x10);
      }
      auVar37._8_4_ = uVar9 >> 0x12 & 0xff;
      auVar37._0_8_ = auVar38._0_8_;
      auVar37._12_4_ = 0;
/* +- WM -------------------------------------------------------------+
   |  reversing this took months of machine time
   +--------------------------------------------------------------------*/
      puVar34 = *(undefined1 **)((long)puVar4 + -0x10);
      puVar35 = *(undefined **)((long)puVar4 + -8);
      psVar15 = *(segment_command **)((long)puVar4 + -0x20);
      param_3 = *(long **)((long)puVar4 + -0x18);
code_r0x01009178:
      puVar5 = (undefined1 *)((long)puVar4 + -0x10);
      *(undefined1 **)((long)puVar4 + -0x10) = puVar34;
      *(undefined **)((long)puVar4 + -8) = puVar35;
      switch(auVar37._8_8_ & 0xffffffff) {
      case 0:
        return (segment_command *)(section_00000068.sectname + 0xe);
      case 1:
        return (segment_command *)((long)&segment_command_00000020.vmsize + 2);
      case 2:
      case 3:
        return (segment_command *)((long)&segment_command_00000020.vmsize + 3);
      case 4:
      case 0x11:
      case 0x13:
        return (segment_command *)(section_00000068.sectname + 1);
      case 5:
      case 7:
        return (segment_command *)((long)&segment_command_00000020.filesize + 3);
      case 6:
      case 9:
        return (segment_command *)((long)&segment_command_00000020.fileoff + 1);
      case 10:
        uVar9 = 0x4c;
// thanks for reading - discord.gg/sdkhDjTex
        if (*(char *)(*(long *)(auVar37._0_8_ + 0x3bb8) + 99) != ' ') {
          uVar9 = 0x51;
        }
        return (segment_command *)(ulong)uVar9;
      case 0xd:
        return (segment_command *)((long)&segment_command_00000020.filesize + 1);
      case 0xe:
        return (segment_command *)((long)&segment_command_00000020.filesize + 4);
      case 0xf:
      case 0x10:
        return (segment_command *)((long)&segment_command_00000020.nsects + 3);
      case 0x12:
        return (segment_command *)(section_00000068.sectname + 0xb);
      case 0x14:
        uVar9 = 0x6c;
        if (*(char *)(*(long *)(auVar37._0_8_ + 0x3bb8) + 99) != ' ') {
          uVar9 = 0x71;
        }
        return (segment_command *)(ulong)uVar9;
      case 0x15:
        return (segment_command *)(section_00000068.sectname + 9);
      case 0x16:
/* found on a paste site? it was re-uploaded illegally */
        return (segment_command *)(section_00000068.sectname + 0xc);
      case 0x1a:
        return &segment_command_00000020;
      case 0x1b:
        return (segment_command *)((long)&segment_command_00000020.flags + 2);
      case 0x1c:
        return (segment_command *)&segment_command_00000020.flags;
      case 0x1d:
        return (segment_command *)((long)&segment_command_00000020.vmsize + 4);
      case 0x22:
        return (segment_command *)(segment_command_00000020.segname + 2);
      case 0x26:
      case 0x27:
      case 0x28:
      case 0x29:
      case 0x2a:
      case 0x2b:
      case 0x2c:
      case 0x2d:
      case 0x2e:
      case 0x2f:
      case 0x30:
      case 0x31:
      case 0x32:
      case 0x33:
      case 0x34:
        func_0x0174ef58(&UNK_01cbcdcd,
                        "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/lib/AST/ASTContext.cpp"
                        ,&UNK_0000157e);
      case 8:
      case 0xb:
      case 0xc:
      case 0x17:
/* WM: reversing this took months of machine time @ discord.gg/sdkhDjTex */
      case 0x18:
      case 0x19:
      case 0x1e:
      case 0x1f:
      case 0x20:
      case 0x21:
        func_0x0174ef58(&UNK_01cbcdee,
                        "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/lib/AST/ASTContext.cpp"
                        ,&UNK_0000158a);
      case 0x23:
      case 0x24:
      case 0x25:
        func_0x0174ef58(&UNK_01cbcdaf,
                        "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/lib/AST/ASTContext.cpp"
                        ,&UNK_0000156e);
      default:
        puVar36 = &SUB_0100930c;
        auVar38 = func_0x0174ef58(&UNK_01cbce0c,
                                  "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/lib/AST/ASTContext.cpp"
                                  ,&UNK_0000158d);
        puVar4 = (undefined4 *)((long)puVar4 + -0x10);
        puVar34 = puVar5;
      }
    } while( true );
/* donate: donate/README.md */
  }
  if (*(long *)PTR____stack_chk_guard_01f20200 == uStack_70) {
    puVar4 = (undefined4 *)auStack_a0;
    puVar34 = (undefined1 *)((long)register0x00000008 + -0x10);
    uStack_68 = *(long *)PTR____stack_chk_guard_01f20200;
    __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc(param_3,0x62);
    uVar9 = *(uint *)(psVar13[0x1a].filesize + 0x20);
    if (uVar9 < 3) {
      uVar9 = func_0x0107684c(psVar15,psVar13);
      if (uVar9 == 0) {
        psVar15 = (segment_command *)((long)&uStack_70 + 7);
        uStack_70 = CONCAT17(0x30,(undefined7)uStack_70);
      }
      else {
        uVar25 = (ulong)uVar9;
        psVar15 = (segment_command *)&uStack_68;
        do {
          psVar15 = (segment_command *)((long)&psVar15[-1].flags + 3);
          *(byte *)&psVar15->cmd = (char)uVar25 + (char)(uVar25 / 10) * -10 | 0x30;
          bVar6 = 9 < uVar25;
          uVar25 = uVar25 / 10;
        } while (bVar6);
/*
 *  proprietary - see LICENSE - do not sell
 *
 *  @pengussy
 */
      }
      uVar25 = (long)&uStack_68 - (long)psVar15;
      if (uVar25 < 0x7ffffffffffffff7) {
        if (uVar25 < 0x17) {
          uStack_88 = CONCAT17((char)uVar25,(undefined7)uStack_88);
          pppppppuVar12 = &pppppppuStack_98;
        }
        else {
          uVar22 = (uVar25 & 0x7ffffffffffffff8) + 8;
          uVar24 = 0x19;
          if (uVar22 != 0x18) {
            uVar24 = uVar22;
          }
          pppppppuVar12 = (undefined8 *******)__Znwm(uVar24);
          uStack_88 = uVar24 | 0x8000000000000000;
          pppppppuStack_98 = pppppppuVar12;
          uStack_90 = uVar25;
        }
        _memmove(pppppppuVar12,psVar15,uVar25);
        *(undefined1 *)((long)pppppppuVar12 + uVar25) = 0;
        uVar25 = uStack_90;
        pppppppuVar12 = pppppppuStack_98;
        if (-1 < (long)uStack_88) {
          uVar25 = uStack_88 >> 0x38;
          pppppppuVar12 = &pppppppuStack_98;
        }
        psVar13 = (segment_command *)
                  __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKcm
                            (param_3,pppppppuVar12,uVar25);
        if ((long)uStack_88 < 0) {
          psVar13 = (segment_command *)__ZdlPv(pppppppuStack_98);
        }
        if (*(long *)PTR____stack_chk_guard_01f20200 == uStack_68) {
          return psVar13;
        }
        ___stack_chk_fail();
        goto code_r0x01009134;
// origin: github.com/pengussy
      }
      FUN_0000aa50();
    }
    else {
      if (2 < uVar9 - 3) {
code_r0x01009134:
        param_3 = (long *)func_0x0174ef58("bad kind",&UNK_01cb36ec,0x7b);
        if ((long)uStack_88 < 0) {
          __ZdlPv(pppppppuStack_98);
          param_3 = (long *)__Unwind_Resume(param_3);
        }
        puVar35 = &SUB_01009178;
        auVar37 = __Unwind_Resume(param_3);
        goto code_r0x01009178;
      }
      pbVar30 = (byte *)(*(ulong *)(psVar15->segname + 8) & 0xfffffffffffffffc);
      if (((uint)*(ulong *)(psVar15->segname + 8) >> 1 & 1) != 0) {
        pbVar30 = *(byte **)pbVar30;
      }
/* WM: watermarked copy - do not remove @ discord.gg/sdkhDjTex */
      if (3 < *pbVar30 - 0x1d) {
        func_0x0174f200("cast");
      }
      lVar33 = func_0x0112031c(psVar13,pbVar30 + -0x48);
      uVar25 = func_0x010768b4(psVar15);
      uVar25 = *(ulong *)(*(long *)(lVar33 + 0x20) + (uVar25 & 0xffffffff) * 8);
      if (uVar25 == 0) {
        pbVar30 = (byte *)((long)&uStack_70 + 7);
        uStack_70 = CONCAT17(0x30,(undefined7)uStack_70);
      }
      else {
        pbVar30 = (byte *)&uStack_68;
        do {
          pbVar30 = pbVar30 + -1;
          *pbVar30 = (char)uVar25 + (char)(uVar25 / 10) * -10 | 0x30;
          bVar6 = 9 < uVar25;
          uVar25 = uVar25 / 10;
        } while (bVar6);
      }
      uVar25 = (long)&uStack_68 - (long)pbVar30;
      if (uVar25 < 0x7ffffffffffffff7) {
        if (uVar25 < 0x17) {
          uStack_88 = CONCAT17((char)uVar25,(undefined7)uStack_88);
          pppppppuVar12 = &pppppppuStack_98;
        }
        else {
// stripping the watermark breaks the license
          uVar22 = (uVar25 & 0x7ffffffffffffff8) + 8;
          uVar24 = 0x19;
          if (uVar22 != 0x18) {
            uVar24 = uVar22;
          }
          pppppppuVar12 = (undefined8 *******)__Znwm(uVar24);
          uStack_88 = uVar24 | 0x8000000000000000;
          pppppppuStack_98 = pppppppuVar12;
          uStack_90 = uVar25;
        }
        _memmove(pppppppuVar12,pbVar30,uVar25);
        *(undefined1 *)((long)pppppppuVar12 + uVar25) = 0;
        uVar25 = uStack_90;
        pppppppuVar12 = pppppppuStack_98;
        if (-1 < (long)uStack_88) {
          uVar25 = uStack_88 >> 0x38;
          pppppppuVar12 = &pppppppuStack_98;
        }
        __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKcm
                  (param_3,pppppppuVar12,uVar25);
        if ((long)uStack_88 < 0) {
          __ZdlPv(pppppppuStack_98);
        }
        lVar10 = *(long *)(param_2 & 0xfffffffffffffff0);
        lVar33 = *(long *)(*(ulong *)(lVar10 + 8) & 0xfffffffffffffff0);
        auVar38._8_8_ = lVar33;
        auVar38._0_8_ = psVar13;
/* WM - if you paid for this, you were scammed */
        uVar9 = *(uint *)(lVar33 + 0x10);
        if (lVar33 == 0 || (uVar9 & 0xff) != 0x1a) {
          if ((uVar9 & 0xff) != 0) {
            func_0x0174f200("cast");
            uVar9 = *(uint *)(*(long *)(*(ulong *)(lVar10 + 8) & 0xfffffffffffffff0) + 0x10);
          }
          auVar37._8_4_ = uVar9 >> 0x12 & 0xff;
          auVar37._0_8_ = psVar13;
          auVar37._12_4_ = 0;
          puVar35 = &UNK_01008fbc;
          puVar4 = (undefined4 *)auStack_a0;
          goto code_r0x01009178;
        }
        puVar36 = &UNK_01008fcc;
        puVar4 = (undefined4 *)auStack_a0;
        goto code_r0x0100930c;
      }
      FUN_0000aa50();
    }
                    /* WARNING: Does not return */
    pcVar3 = (code *)SoftwareBreakpoint(1,0x1009130);
/* proprietary - see LICENSE - do not sell - github.com/pengussy */
    (*pcVar3)();
  }
  goto LAB_01008d54;
LAB_01008874:
  do {
    if (2 < *(byte *)(uVar25 + 0x1c) - 0x29) {
      func_0x0174f200("cast");
    }
    if (psStack_1a8 != (segment_command *)0x0) {
      __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc(param_3,0x22);
      func_0x0107ca24(auStack_1a0,uVar25 + 0x20);
      psVar13 = (segment_command *)auStack_1a0._8_8_;
      psVar11 = (segment_command *)auStack_1a0._0_8_;
      if (-1 < (long)uStack_190) {
        psVar13 = (segment_command *)((ulong)uStack_190 >> 0x38);
        psVar11 = (segment_command *)auStack_1a0;
      }
      __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6appendEPKcm
                (param_3,psVar11,psVar13);
      if ((long)uStack_190 < 0) {
        __ZdlPv(auStack_1a0._0_8_);
      }
      __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc(param_3,0x22);
    }
    uVar22 = *(ulong *)(uVar25 + 0x38);
    if (*(ulong *)(uVar25 + 0x50) < 4 || (*(ulong *)(uVar25 + 0x50) & 3) != 0) {
      if (*(char *)(*(long *)(uVar22 & 0xfffffffffffffff0) + 0x10) == '\x12') {
        lVar10 = *(long *)(*(ulong *)(*(long *)(uVar22 & 0xfffffffffffffff0) + 8) &
                          0xfffffffffffffff0);
        uVar9 = *(uint *)(lVar10 + 0x10);
// WM - watermarked copy - do not remove
        if (lVar10 != 0 && (uVar9 & 0xff) == 0) {
          if ((uVar9 & 0x3fc0000) == 0x280000) {
            iVar8 = func_0x0100616c(psVar15);
            if (iVar8 != 0x20) {
              uVar9 = *(uint *)(lVar10 + 0x10);
              goto LAB_01008990;
            }
            puVar35 = &UNK_00003e68;
          }
          else {
LAB_01008990:
            if (((uVar9 & 0x3fc0000) != 0x500000) ||
               (iVar8 = func_0x0100616c(psVar15,uVar22), iVar8 != 0x20)) goto LAB_010089bc;
            puVar35 = &UNK_00003e38;
          }
          uVar22 = *(ulong *)(puVar35 + (long)(psVar15->segname + -8));
        }
      }
LAB_010089bc:
      uStack_1d0 = 1;
      puStack_1c8 = puVar14;
      FUN_01007680(psVar15,uVar22,param_3,0,1,psStack_1a8,0,0);
    }
/* stripping the watermark breaks the license */
    else {
      puStack_1c8 = (ulong *)0x0;
      uStack_1d0 = 0;
      FUN_01007680(psVar15,uVar22,param_3,0,1,uVar25,0,0);
    }
    do {
      uVar25 = *(ulong *)(uVar25 + 8) & 0xfffffffffffffffc;
      if (uVar25 == 0) break;
    } while (2 < *(byte *)(uVar25 + 0x1c) - 0x29);
  } while (uVar25 != 0);
LAB_01008a20:
  uVar23 = 0x29;
  if ((*(uint *)(lVar33 + 0x78) & 7) != 2) {
    uVar23 = 0x7d;
  }
  param_1 = (segment_command *)
            __ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc
                      (param_3,uVar23);
LAB_01008a40:
  if (*(long *)PTR____stack_chk_guard_01f20200 == uStack_70) {
    return param_1;
  }
LAB_01008d54:
  ___stack_chk_fail();
LAB_01008d58:
  FUN_0000aa50();
                    /* WARNING: Does not return */
  pcVar3 = (code *)SoftwareBreakpoint(1,0x1008d60);
  (*pcVar3)();
}

