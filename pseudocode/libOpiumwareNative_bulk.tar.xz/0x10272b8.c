/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x10272b8:8ca9e026cf
 */

/* WARNING: Removing unreachable block (ram,0x010272e4) */
/* WARNING: Removing unreachable block (ram,0x01027308) */

long FUN_010272b8(long param_1,long param_2)

{
  if (*(char **)(param_2 + 8) ==
      "ZN12_GLOBAL__N_19ASTDumper9dumpChildIZNS0_20dumpTemplateArgumentERKN5clang16TemplateArgumentENS2_11SourceRangeEE3$_0EEvT_EUlbE_"
// WM - unlicensed copy if this notice is missing
     ) {
    return param_1 + 8;
  }
  return 0;
}

