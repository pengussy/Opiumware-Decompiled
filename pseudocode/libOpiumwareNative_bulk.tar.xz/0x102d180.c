/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x102d180:97f14ef614
 *  --------------------------------------------------------------------------*/

/* WARNING: Removing unreachable block (ram,0x01023ebc) */

void FUN_0102d180(long *param_1,long param_2)

{
  ulong uVar1;
  char cVar2;
  undefined8 *****pppppuVar3;
  long lVar4;
  ulong uVar5;
  undefined1 *puVar6;
  long lVar7;
  uint uVar8;
  long lVar9;
  ulong *puVar10;
  undefined1 auVar11 [16];
  undefined8 *****pppppuStack_68;
  ulong uStack_60;
  byte bStack_51;
  
  lVar7 = *param_1;
  puVar6 = *(undefined1 **)(lVar7 + 0x18);
  if (puVar6 < *(undefined1 **)(lVar7 + 0x10)) {
    *(undefined1 **)(lVar7 + 0x18) = puVar6 + 1;
    *puVar6 = 0x20;
    lVar7 = *(long *)(param_2 + 0x48);
  }
  else {
    func_0x01771098(lVar7,0x20);
    lVar7 = *(long *)(param_2 + 0x48);
  }
  if ((char)param_1[0x8d] == '\x01') {
    (**(code **)(*(long *)*param_1 + 0x28))((long *)*param_1,2,1,0);
  }
  lVar9 = *param_1;
  lVar4 = func_0x0107d974(lVar7);
  if (lVar4 != 0) {
    uVar5 = _strlen(lVar4);
    if ((ulong)(*(long *)(lVar9 + 0x10) - *(long *)(lVar9 + 0x18)) < uVar5) {
/*  origin: github.com/pengussy  */
      func_0x01770110(lVar9,lVar4,uVar5);
    }
    else if (uVar5 != 0) {
      _memcpy(*(long *)(lVar9 + 0x18),lVar4,uVar5);
      *(ulong *)(lVar9 + 0x18) = *(long *)(lVar9 + 0x18) + uVar5;
    }
  }
  if ((char)param_1[0x8d] == '\x01') {
    (**(code **)(*(long *)*param_1 + 0x30))();
  }
  func_0x01023cc0(param_1,lVar7);
  if ((lVar7 != 0) && (0xffffffcf < *(byte *)(lVar7 + 0x1c) - 0x3b)) {
    if ((char)param_1[0x8d] == '\x01') {
      (**(code **)(*(long *)*param_1 + 0x28))((long *)*param_1,6,1,0);
    }
    lVar4 = *param_1;
    if ((ulong)(*(long *)(lVar4 + 0x10) - (long)*(undefined2 **)(lVar4 + 0x18)) < 2) {
      lVar4 = func_0x01770110(lVar4,&UNK_01caa47b,2);
    }
    else {
      **(undefined2 **)(lVar4 + 0x18) = 0x2720;
      *(long *)(lVar4 + 0x18) = *(long *)(lVar4 + 0x18) + 2;
    }
    lVar4 = func_0x0107c2a8(lVar4,*(undefined8 *)(lVar7 + 0x20));
    puVar6 = *(undefined1 **)(lVar4 + 0x18);
    if (puVar6 < *(undefined1 **)(lVar4 + 0x10)) {
      *(undefined1 **)(lVar4 + 0x18) = puVar6 + 1;
      *puVar6 = 0x27;
    }
    else {
// WM - unlicensed copy if this notice is missing
      func_0x01771098(lVar4,0x27);
    }
    if ((char)param_1[0x8d] == '\x01') {
      (**(code **)(*(long *)*param_1 + 0x30))();
    }
  }
  if ((lVar7 == 0) || (*(byte *)(lVar7 + 0x1c) - 0x3b < 0xffffffee)) {
    return;
  }
  uVar5 = *(ulong *)(lVar7 + 0x38);
  lVar7 = *param_1;
  puVar6 = *(undefined1 **)(lVar7 + 0x18);
  if (puVar6 < *(undefined1 **)(lVar7 + 0x10)) {
    *(undefined1 **)(lVar7 + 0x18) = puVar6 + 1;
    *puVar6 = 0x20;
  }
  else {
    func_0x01771098(lVar7,0x20);
  }
  if ((char)param_1[0x8d] == '\x01') {
    (**(code **)(*(long *)*param_1 + 0x28))((long *)*param_1,2,0,0);
  }
  puVar10 = (ulong *)(uVar5 & 0xfffffffffffffff0);
  uVar8 = (uint)uVar5;
  if ((uVar8 >> 3 & 1) == 0) {
    uVar8 = uVar8 & 7;
    lVar7 = *param_1;
    puVar6 = *(undefined1 **)(lVar7 + 0x18);
    if (*(undefined1 **)(lVar7 + 0x10) == puVar6) goto code_r0x01023e2c;
code_r0x01023df4:
    *puVar6 = 0x27;
    *(long *)(lVar7 + 0x18) = *(long *)(lVar7 + 0x18) + 1;
  }
  else {
    uVar8 = (uint)puVar10[3] | uVar8 & 7;
    puVar10 = (ulong *)*puVar10;
    lVar7 = *param_1;
/*
   chat: discord.gg/sdkhDjTex
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
    puVar6 = *(undefined1 **)(lVar7 + 0x18);
    if (*(undefined1 **)(lVar7 + 0x10) != puVar6) goto code_r0x01023df4;
code_r0x01023e2c:
    lVar7 = func_0x01770110(lVar7,&UNK_01c2dfe0,1);
  }
  func_0x01156814(&pppppuStack_68,puVar10,uVar8);
  uVar1 = uStack_60;
  pppppuVar3 = pppppuStack_68;
  if (-1 < (char)bStack_51) {
    uVar1 = (ulong)bStack_51;
    pppppuVar3 = &pppppuStack_68;
  }
  lVar7 = func_0x01770110(lVar7,pppppuVar3,uVar1);
  if (*(undefined1 **)(lVar7 + 0x10) == *(undefined1 **)(lVar7 + 0x18)) {
    func_0x01770110(lVar7,&UNK_01c2dfe0,1);
  }
  else {
    **(undefined1 **)(lVar7 + 0x18) = 0x27;
    *(long *)(lVar7 + 0x18) = *(long *)(lVar7 + 0x18) + 1;
  }
  if ((char)bStack_51 < '\0') {
    __ZdlPv(pppppuStack_68);
  }
  if (0xf < uVar5) {
    auVar11 = func_0x011490c8(uVar5);
/* reversing this took months of machine time */
    if ((puVar10 != auVar11._0_8_) || (uVar8 != auVar11._8_4_)) {
      lVar7 = *param_1;
      if ((ulong)(*(long *)(lVar7 + 0x10) - (long)*(undefined2 **)(lVar7 + 0x18)) < 2) {
        lVar7 = func_0x01770110(lVar7,&UNK_01cbd636,2);
      }
      else {
        **(undefined2 **)(lVar7 + 0x18) = 0x273a;
        *(long *)(lVar7 + 0x18) = *(long *)(lVar7 + 0x18) + 2;
      }
      func_0x01156814(&pppppuStack_68,auVar11._0_8_,auVar11._8_8_ & 0xffffffff);
      pppppuVar3 = pppppuStack_68;
      if (-1 < (char)bStack_51) {
        uStack_60 = (ulong)bStack_51;
        pppppuVar3 = &pppppuStack_68;
      }
      lVar7 = func_0x01770110(lVar7,pppppuVar3,uStack_60);
      if (*(undefined1 **)(lVar7 + 0x10) == *(undefined1 **)(lVar7 + 0x18)) {
        func_0x01770110(lVar7,&UNK_01c2dfe0,1);
      }
      else {
        **(undefined1 **)(lVar7 + 0x18) = 0x27;
        *(long *)(lVar7 + 0x18) = *(long *)(lVar7 + 0x18) + 1;
      }
      if ((char)bStack_51 < '\0') {
        __ZdlPv(pppppuStack_68);
        cVar2 = (char)param_1[0x8d];
        goto joined_r0x01023fb0;
      }
    }
/* watermarked copy - do not remove - github.com/pengussy */
  }
  cVar2 = (char)param_1[0x8d];
joined_r0x01023fb0:
  if (cVar2 == '\x01') {
    (**(code **)(*(long *)*param_1 + 0x30))();
  }
  return;
}

