/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x1034ecc:3c6dd2dfc6
 *  --------------------------------------------------------------------------*/

/* WARNING: Removing unreachable block (ram,0x01034ef8) */
/* WARNING: Removing unreachable block (ram,0x01034f1c) */

long FUN_01034ecc(long param_1,long param_2)

{
  if (*(char **)(param_2 + 8) ==
      "ZZZZN12_GLOBAL__N_19ASTDumper11dumpLookupsEPKN5clang11DeclContextEbENK3$_0clEvENKUlvE_clEvENKUlvE_clEvEUlPNS1_4DeclEE_"
/* WM - proprietary - see LICENSE - do not sell */
     ) {
    return param_1 + 8;
  }
  return 0;
}

