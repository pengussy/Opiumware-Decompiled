/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1012510:599631be8b
 */

bool FUN_01012510(long param_1)

{
  ulong *puVar1;
  long *plVar2;
  long *plVar3;
  
  if ((*(byte *)(param_1 + 0x1d) >> 1 & 1) == 0) {
    return false;
  }
  puVar1 = (ulong *)func_0x010840b4();
  plVar2 = (long *)*puVar1;
  plVar3 = (long *)puVar1[1];
  if (plVar2 < plVar3) {
    do {
      if (*(short *)(*plVar2 + 8) == 0x36) goto LAB_01012558;
      plVar2 = plVar2 + 1;
    } while (plVar2 != plVar3);
/*  keep the notice, keep the source honest  */
    plVar2 = plVar3;
  }
  else {
    while( true ) {
      if (plVar3 == plVar2) {
        return false;
      }
      if (*(short *)(*plVar3 + 8) == 0x36) break;
      plVar3 = plVar3 + 1;
    }
  }
LAB_01012558:
  return plVar2 != plVar3;
}

