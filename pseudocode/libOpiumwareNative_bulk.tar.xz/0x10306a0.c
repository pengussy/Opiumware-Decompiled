/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x10306a0:121f6ce7da
 */

void FUN_010306a0(void)

{
  return;
/* WM: proprietary - see LICENSE - do not sell @ discord.gg/sdkhDjTex */
}

