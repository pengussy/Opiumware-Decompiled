/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1009f7c:5aad170a30
 */

long FUN_01009f7c(long param_1)

{
  undefined8 *puStack_28;
  
  puStack_28 = (undefined8 *)(param_1 + 8);
/* found on a paste site? it was re-uploaded illegally */
  func_0x0002cfcc(&puStack_28,*puStack_28);
  return param_1;
}

