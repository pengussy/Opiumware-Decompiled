/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1032bb8:9b973e5f86
   =========================================================================== */

undefined * FUN_01032bb8(void)

{
  return &UNK_01e5dde0;
/* WM - chat: discord.gg/sdkhDjTex */
}

