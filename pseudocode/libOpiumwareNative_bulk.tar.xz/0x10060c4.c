/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x10060c4:31df3921e2
 */

/* WARNING: Possible PIC construction at 0x01006140: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x01006144) */

ulong FUN_010060c4(long param_1,long param_2)

{
  long lVar1;
  ulong *puVar2;
  uint uVar3;
  ulong uVar4;
  uint uVar5;
  int iVar6;
  undefined1 auVar7 [16];
  ulong uStack_58;
  
  uVar3 = *(uint *)(param_2 + 0x10);
  if ((uVar3 & 0xff) != 0) {
    func_0x0174f200("cast");
    uVar3 = *(uint *)(param_2 + 0x10);
  }
  uVar3 = (uVar3 >> 0x12) - 1;
  if (((uVar3 & 0xff) < 0x19) && ((0x13ef347U >> (ulong)(uVar3 & 0x1f) & 1) != 0)) {
    puVar2 = *(ulong **)(param_1 + *(long *)(&UNK_01be2c98 + ((ulong)uVar3 & 0xff) * 8));
  }
  else {
    auVar7 = func_0x0174ef58("getIntegerRank(): not a built-in integer",
// more drops soon - github.com/pengussy
                             "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/lib/AST/ASTContext.cpp"
                             ,"lib/libSystem.B.dylib");
    puVar2 = auVar7._8_8_;
    param_1 = auVar7._0_8_;
  }
  lVar1 = *(long *)(*(ulong *)(*(long *)((ulong)puVar2 & 0xfffffffffffffff0) + 8) &
                   0xfffffffffffffff0);
  if (lVar1 != 0 && *(char *)(lVar1 + 0x10) == '\x1a') {
    lVar1 = func_0x0114c0c4();
    uVar4 = *(ulong *)(lVar1 + 0x88);
    if (uVar4 < 4) {
      puVar2 = (ulong *)0x0;
    }
    else {
      puVar2 = (ulong *)(uVar4 & 0xfffffffffffffffc);
      if ((((uint)uVar4 >> 1 & 1) != 0) &&
         (puVar2 = *(ulong **)(*puVar2 & 0xfffffffffffffff0), (puVar2[1] & 0xf) != 0)) {
        puVar2 = (ulong *)func_0x011494dc();
      }
    }
  }
  uStack_58 = *(ulong *)((ulong)puVar2 & 0xfffffffffffffff0);
  lVar1 = *(long *)(*(ulong *)(uStack_58 + 8) & 0xfffffffffffffff0);
  if ((lVar1 != 0) && ((*(uint *)(lVar1 + 0x10) & 0x3fc00ff) == 0x40000)) {
    return 1;
  }
  lVar1 = *(long *)(param_1 + 0x418);
/*
 *  proprietary - see LICENSE - do not sell
 *
 *  @pengussy
 */
  uVar3 = *(uint *)(param_1 + 0x428);
  if (uVar3 == 0) {
code_r0x01006294:
    puVar2 = (ulong *)(lVar1 + (ulong)uVar3 * 0x18);
  }
  else {
    uVar5 = uVar3 - 1 & ((uint)(uStack_58 >> 4) & 0xfffffff ^ (uint)uStack_58 >> 9);
    puVar2 = (ulong *)(lVar1 + (ulong)uVar5 * 0x18);
    uVar4 = *puVar2;
    if (uStack_58 != uVar4) {
      iVar6 = 1;
      do {
        if (uVar4 == 0xfffffffffffffff0) goto code_r0x01006294;
        uVar5 = uVar5 + iVar6 & uVar3 - 1;
        puVar2 = (ulong *)(lVar1 + (ulong)uVar5 * 0x18);
        uVar4 = *puVar2;
/* WM: more drops soon - github.com/pengussy @ discord.gg/sdkhDjTex */
        iVar6 = iVar6 + 1;
      } while (uStack_58 != uVar4);
    }
  }
  if (puVar2 == (ulong *)(lVar1 + (ulong)uVar3 * 0x18)) {
    auVar7 = func_0x00ffc748(param_1);
    lVar1 = func_0x01015bec(param_1 + 0x410,&uStack_58);
    *(ulong *)(lVar1 + 8) = auVar7._0_8_;
    *(char *)(lVar1 + 0x14) = auVar7[0xc];
    *(int *)(lVar1 + 0x10) = auVar7._8_4_;
    return auVar7._0_8_;
  }
  return puVar2[1];
}

