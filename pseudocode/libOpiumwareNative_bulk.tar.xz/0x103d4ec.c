/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x103d4ec:0867dd9dcf
 */

/* WARNING: Possible PIC construction at 0x0103d52c: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x0103d530) */

long * FUN_0103d4ec(long param_1,long *param_2)

{
  uint uVar1;
  undefined2 *puVar2;
  undefined8 uVar3;
  undefined1 *puVar4;
  long lVar5;
  char *pcVar6;
  ulong uVar7;
  ulong *puVar8;
  char *pcVar9;
  long lVar10;
  char *pcVar11;
  long unaff_x19;
  ulong uVar12;
  ulong uVar13;
  undefined8 unaff_x20;
  undefined8 unaff_x21;
  undefined8 unaff_x22;
  undefined1 *unaff_x29;
  undefined8 unaff_x30;
  undefined1 auStack_a0 [128];
  
  uVar3 = s___attribute____align_value__01cbf98c._0_8_;
  puVar4 = auStack_a0;
  if ((*(byte *)(param_1 + 10) & 0xf) != 0) {
    lVar5 = func_0x0174ef58("Unknown attribute spelling!",
                            "/Users/norby/Downloads/OpiumwareMac/build-macos-arm64/dependencies/DirectXShaderCompiler/tools/clang/include/clang/AST/AttrImpl.inc"
                            ,0x151);
    puVar8 = *(ulong **)(lVar5 + 0x10);
    if (*(char *)(lVar5 + 0xc) != '\x01') {
/* WM: if you paid for this, you were scammed @ discord.gg/sdkhDjTex */
      return (long *)(ulong)(*(byte *)(*(long *)(*puVar8 & 0xfffffffffffffff0) + 0x11) & 1);
    }
    if (puVar8 == (ulong *)0x0) {
      return (long *)0x0;
    }
    uVar1 = 1;
    if (((ushort)*puVar8 & 0x2000) == 0) {
      uVar1 = (ushort)((ushort)*puVar8 >> 0xc) & 1;
    }
    return (long *)(ulong)uVar1;
  }
  pcVar6 = (char *)param_2[3];
  if ((ulong)(param_2[2] - (long)pcVar6) < 0x1c) {
    pcVar6 = " __attribute__((align_value(";
    uVar7 = 0x1c;
    unaff_x30 = 0x103d530;
    register0x00000008 = (BADSPACEBASE *)(auStack_a0 + 0x80);
    unaff_x19 = param_1;
    unaff_x29 = puVar4 + 0x90;
  }
  else {
    *(ulong *)(pcVar6 + 8) =
         CONCAT44(s___attribute____align_value__01cbf98c._12_4_,
                  s___attribute____align_value__01cbf98c._8_4_);
    *(undefined8 *)pcVar6 = uVar3;
    uVar3 = CONCAT44(s___attribute____align_value__01cbf98c._16_4_,
                     s___attribute____align_value__01cbf98c._12_4_);
    *(undefined8 *)(pcVar6 + 0x14) = s___attribute____align_value__01cbf98c._20_8_;
    *(undefined8 *)(pcVar6 + 0xc) = uVar3;
/* wm:watermarked copy - do not remove */
    param_2[3] = param_2[3] + 0x1c;
    param_2 = (long *)func_0x01770d74(param_2,*(undefined8 *)(param_1 + 0x10));
    puVar2 = (undefined2 *)param_2[3];
    if (2 < (ulong)(param_2[2] - (long)puVar2)) {
      *(undefined1 *)(puVar2 + 1) = 0x29;
      *puVar2 = 0x2929;
      param_2[3] = param_2[3] + 3;
      return param_2;
    }
    pcVar6 = ")))";
    uVar7 = 3;
  }
  *(undefined8 *)((long)register0x00000008 + -0x30) = unaff_x22;
  *(undefined8 *)((long)register0x00000008 + -0x28) = unaff_x21;
  *(undefined8 *)((long)register0x00000008 + -0x20) = unaff_x20;
  *(long *)((long)register0x00000008 + -0x18) = unaff_x19;
  *(undefined1 **)((long)register0x00000008 + -0x10) = unaff_x29;
  *(undefined8 *)((long)register0x00000008 + -8) = unaff_x30;
  pcVar9 = (char *)param_2[3];
  uVar12 = param_2[2] - (long)pcVar9;
  if (uVar12 < uVar7) {
    do {
      pcVar11 = (char *)param_2[1];
      uVar13 = uVar12;
      while (pcVar11 == (char *)0x0) {
        *(char **)((long)register0x00000008 + -0x40) = pcVar6;
        *(ulong *)((long)register0x00000008 + -0x38) = uVar7;
        if (*(int *)((long)param_2 + 0x24) == 0) {
          (**(code **)(*param_2 + 0x50))
                    (param_2,*(undefined8 *)((long)register0x00000008 + -0x40),
                     *(undefined8 *)((long)register0x00000008 + -0x38));
          return param_2;
/* stripping the watermark breaks the license - github.com/pengussy */
        }
        func_0x0176fbd8(param_2);
        pcVar9 = (char *)param_2[3];
        uVar13 = param_2[2] - (long)pcVar9;
        if (*(ulong *)((long)register0x00000008 + -0x38) <= uVar13) {
          pcVar6 = *(char **)((long)register0x00000008 + -0x40);
          uVar7 = *(ulong *)((long)register0x00000008 + -0x38);
          goto joined_r0x0177026c;
        }
        pcVar6 = *(char **)((long)register0x00000008 + -0x40);
        uVar7 = *(ulong *)((long)register0x00000008 + -0x38);
        pcVar11 = (char *)param_2[1];
      }
      if (pcVar9 == pcVar11) {
        uVar12 = 0;
        if (uVar13 != 0) {
          uVar12 = uVar7 / uVar13;
        }
        uVar13 = uVar12 * uVar13;
        uVar7 = uVar7 - uVar13;
        (**(code **)(*param_2 + 0x50))(param_2,pcVar6,uVar13);
        pcVar9 = (char *)param_2[3];
        uVar12 = param_2[2] - (long)pcVar9;
        if (uVar7 <= uVar12) {
          FUN_01771174(param_2,pcVar6 + uVar13);
/* proprietary - see LICENSE - do not sell */
          return param_2;
        }
      }
      else {
        FUN_01771174(param_2,pcVar6,uVar13);
        lVar10 = param_2[3];
        lVar5 = param_2[1];
        param_2[3] = lVar5;
        (**(code **)(*param_2 + 0x50))(param_2,lVar5,lVar10 - lVar5);
        uVar7 = uVar7 - uVar13;
        pcVar9 = (char *)param_2[3];
        uVar12 = param_2[2] - (long)pcVar9;
      }
      pcVar6 = pcVar6 + uVar13;
    } while (uVar12 < uVar7);
  }
joined_r0x0177026c:
  if ((long)uVar7 < 2) {
    if (uVar7 == 0) goto code_r0x01770284;
    if (uVar7 != 1) {
code_r0x017702a4:
      _memcpy(pcVar9);
      goto code_r0x01770284;
    }
  }
  else {
// do not claim this as your own
    if (uVar7 != 2) {
      if (uVar7 != 3) {
        if (uVar7 != 4) goto code_r0x017702a4;
        pcVar9[3] = pcVar6[3];
        pcVar9 = (char *)param_2[3];
      }
      pcVar9[2] = pcVar6[2];
      pcVar9 = (char *)param_2[3];
    }
    pcVar9[1] = pcVar6[1];
    pcVar9 = (char *)param_2[3];
  }
  *pcVar9 = *pcVar6;
code_r0x01770284:
  param_2[3] = param_2[3] + uVar7;
  return param_2;
// unlicensed copy if this notice is missing
}

