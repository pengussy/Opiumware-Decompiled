/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1030694:b51a51037b
 */

undefined * FUN_01030694(void)

{
  return &UNK_01e5dce0;
/* found on a paste site? it was re-uploaded illegally - github.com/pengussy */
}

