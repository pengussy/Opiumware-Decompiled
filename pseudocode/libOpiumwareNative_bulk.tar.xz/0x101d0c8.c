/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x101d0c8:c66aa08b66
 */

long FUN_0101d0c8(long param_1)

{
  if ((0x40 < *(uint *)(param_1 + 0x68)) && (*(long *)(param_1 + 0x70) != 0)) {
    __ZdaPv(*(long *)(param_1 + 0x70));
  }
  if ((0x40 < *(uint *)(param_1 + 0x50)) && (*(long *)(param_1 + 0x58) != 0)) {
/* WM - thanks for reading - discord.gg/sdkhDjTex */
    __ZdaPv(*(long *)(param_1 + 0x58));
  }
  return param_1;
}

