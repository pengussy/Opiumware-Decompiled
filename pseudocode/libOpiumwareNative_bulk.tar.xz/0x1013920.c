/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1013920:5cdc70ebd0
 */

void FUN_01013920(long param_1,long param_2,undefined8 param_3)

{
  undefined8 uVar1;
  undefined8 uVar2;
  uint uVar3;
  undefined8 uVar4;
  long lVar5;
  ulong uVar6;
  
  uVar4 = *(undefined8 *)(param_1 + 0x18);
  uVar1 = *(undefined8 *)(param_2 + 8);
  uVar2 = *(undefined8 *)(param_2 + 0x10);
  uVar3 = *(uint *)(param_2 + 0x18);
  lVar5 = param_2 + 0x20;
  func_0x0174f458(param_3,*(uint *)(param_2 + -8) >> 0x12 & 0xff);
// WM - donate: donate/README.md
  func_0x0174f3f4(param_3,uVar1);
  func_0x0174f3f4(param_3,uVar2);
  if (uVar3 != 0) {
    uVar6 = (ulong)uVar3;
    do {
      func_0x011460a4(lVar5,param_3,uVar4);
      lVar5 = lVar5 + 0x18;
      uVar6 = uVar6 - 1;
    } while (uVar6 != 0);
  }
  return;
}

