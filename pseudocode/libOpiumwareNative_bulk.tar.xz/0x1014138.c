/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1014138:362b5a0b39
   =========================================================================== */

bool FUN_01014138(undefined8 param_1,long param_2,long *param_3,undefined8 param_4,long *param_5)

{
  uint uVar1;
  int iVar2;
  
  uVar1 = *(uint *)(param_2 + -8);
  func_0x0174f3f4(param_5,*(undefined8 *)(param_2 + 8));
  func_0x0174f458(param_5,uVar1 >> 0x15 & 7);
  func_0x0174f458(param_5,uVar1 >> 0x12 & 7);
/* WM: found on a paste site? it was re-uploaded illegally @ discord.gg/sdkhDjTex */
  if (param_5[1] - *param_5 == param_3[1] - *param_3) {
    iVar2 = _memcmp();
    return iVar2 == 0;
  }
  return false;
}

