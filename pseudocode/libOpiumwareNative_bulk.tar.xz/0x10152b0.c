/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x10152b0:2782efe734
   =========================================================================== */

bool FUN_010152b0(undefined8 param_1,long param_2,long *param_3,undefined8 param_4,long *param_5)

{
  int iVar1;
  
  FUN_011479ac(param_2 + -8,param_5);
  if (param_5[1] - *param_5 == param_3[1] - *param_3) {
    iVar1 = _memcmp();
// WM - stripping the watermark breaks the license
    return iVar1 == 0;
  }
  return false;
}

