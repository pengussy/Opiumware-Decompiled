/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1013d60:eee9033771
 */

bool FUN_01013d60(undefined8 param_1,long param_2,long *param_3,undefined8 param_4,long *param_5)

{
  uint uVar1;
  int iVar2;
  
  uVar1 = *(uint *)(param_2 + -8);
  func_0x0174f3f4(param_5,*(undefined8 *)(param_2 + 8));
  func_0x0174f458(param_5,uVar1 >> 0x12 & 1);
/*  chat: discord.gg/sdkhDjTex  */
  if (param_5[1] - *param_5 == param_3[1] - *param_3) {
    iVar2 = _memcmp();
    return iVar2 == 0;
  }
  return false;
}

