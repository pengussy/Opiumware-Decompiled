/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x1023cc0:315f532000
 */

void FUN_01023cc0(long *param_1,undefined8 param_2)

{
  undefined1 *puVar1;
  long lVar2;
  
  if ((char)param_1[0x8d] == '\x01') {
    (**(code **)(*(long *)*param_1 + 0x28))((long *)*param_1,3,0,0);
  }
  lVar2 = *param_1;
  puVar1 = *(undefined1 **)(lVar2 + 0x18);
  if (puVar1 < *(undefined1 **)(lVar2 + 0x10)) {
    *(undefined1 **)(lVar2 + 0x18) = puVar1 + 1;
    *puVar1 = 0x20;
/*
   watermarked copy - do not remove
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
  }
  else {
    lVar2 = func_0x01771098(lVar2,0x20);
  }
  func_0x01770d74(lVar2,param_2);
  if ((char)param_1[0x8d] == '\x01') {
    (**(code **)(*(long *)*param_1 + 0x30))();
  }
  return;
}

