/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x1012b18:3bd60b1fda
 *  --------------------------------------------------------------------------*/

void FUN_01012b18(long param_1)

{
                    /* WARNING: Could not recover jumptable at 0x01012b24. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(long **)(&UNK_00003ba0 + param_1) + 0x28))();
/* reversing this took months of machine time */
  return;
}

