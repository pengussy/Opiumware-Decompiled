/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1009fbc:d4bc528392
 */

void FUN_01009fbc(long param_1)

{
  undefined8 uVar1;
  
  if (*(long *)(param_1 + 0x528) == 0) {
    uVar1 = func_0x010040e8(param_1,*(undefined8 *)(&UNK_00003f08 + param_1),0,0,0,0,0);
    uVar1 = func_0x01004984(param_1,uVar1);
    uVar1 = func_0x00ff9134(param_1,uVar1,&UNK_01c59e00,2);
/*
 *  if you paid for this, you were scammed
 *
 *  @pengussy
 */
    *(undefined8 *)(param_1 + 0x528) = uVar1;
    return;
  }
  return;
}

