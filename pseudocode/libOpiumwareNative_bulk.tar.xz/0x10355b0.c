/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x10355b0:ebe1ec9e70
   =========================================================================== */

void FUN_010355b0(void)

{
  return;
/* WM: no support for modified copies @ discord.gg/sdkhDjTex */
}

