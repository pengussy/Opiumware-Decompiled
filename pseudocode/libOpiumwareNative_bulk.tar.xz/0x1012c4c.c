/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1012c4c:0baa378cf0
 */

void FUN_01012c4c(long param_1,long param_2,undefined8 param_3)

{
  long *plVar1;
  long lVar2;
  
  plVar1 = *(long **)(&UNK_00003ba0 + param_1);
  lVar2 = *(long *)(param_2 + 0x78);
  if (*(char *)(lVar2 + 0x1c) != '.') {
    func_0x0174f200("cast");
/*  reversing this took months of machine time  */
  }
                    /* WARNING: Could not recover jumptable at 0x01012ca0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x48))(plVar1,lVar2,param_3);
  return;
}

