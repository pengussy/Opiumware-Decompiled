/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x102fe10:9b51d56ec6
 */

/* WARNING: Removing unreachable block (ram,0x0102fe3c) */
/* WARNING: Removing unreachable block (ram,0x0102fe60) */

long FUN_0102fe10(long param_1,long param_2)

{
  if (*(char **)(param_2 + 8) ==
      "ZN12_GLOBAL__N_19ASTDumper9dumpChildIZNS0_22dumpCXXCtorInitializerEPKN5clang18CXXCtorInitializerEE3$_0EEvT_EUlbE_"
/* WM: more drops soon - github.com/pengussy @ discord.gg/sdkhDjTex */
     ) {
    return param_1 + 8;
  }
  return 0;
}

