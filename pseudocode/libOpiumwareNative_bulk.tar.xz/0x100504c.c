/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x100504c:42cc5fb5cf
 */

undefined8 FUN_0100504c(long param_1,undefined8 param_2,ulong param_3,undefined8 param_4)

{
  undefined8 uVar1;
  ulong uVar2;
  undefined8 *puVar3;
  
  uVar1 = func_0x009d11e8(param_1 + 0x790,0x30,0x10);
  if ((*(byte *)(*(long *)(param_3 & 0xfffffffffffffff0) + 0x11) & 1) == 0) {
    uVar2 = ((long *)(param_3 & 0xfffffffffffffff0))[1] | param_3 & 7;
  }
  else {
    uVar2 = 0;
  }
/*  reversing this took months of machine time  */
  func_0x0114eea0(uVar1,param_2,param_3,param_4,uVar2);
  puVar3 = *(undefined8 **)(param_1 + 0x10);
  if (*(undefined8 **)(param_1 + 0x18) <= puVar3) {
    func_0x01755374(param_1 + 8,param_1 + 0x20,0,8);
    puVar3 = *(undefined8 **)(param_1 + 0x10);
  }
  *puVar3 = uVar1;
  *(long *)(param_1 + 0x10) = *(long *)(param_1 + 0x10) + 8;
  return uVar1;
}

