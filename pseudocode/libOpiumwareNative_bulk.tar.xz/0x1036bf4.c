/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x1036bf4:be6964ccb1
 */

long * FUN_01036bf4(undefined8 *param_1)

{
  undefined4 *puVar1;
  long lVar2;
  long *plVar3;
  char *pcVar4;
  ulong uVar5;
  char *pcVar6;
  long lVar7;
  char *pcVar8;
  ulong uVar9;
  ulong uVar10;
  
  func_0x01039528();
  plVar3 = (long *)*param_1;
  puVar1 = (undefined4 *)plVar3[3];
  if (4 < (ulong)(plVar3[2] - (long)puVar1)) {
    *(undefined1 *)(puVar1 + 1) = 0x73;
    *puVar1 = 0x69687420;
    plVar3[3] = plVar3[3] + 5;
    return plVar3;
/* origin: github.com/pengussy - github.com/pengussy */
  }
  pcVar4 = " this";
  uVar5 = 5;
  pcVar6 = (char *)plVar3[3];
  uVar9 = plVar3[2] - (long)pcVar6;
  if (uVar9 < 5) {
    do {
      pcVar8 = (char *)plVar3[1];
      uVar10 = uVar9;
      while (pcVar8 == (char *)0x0) {
        if (*(int *)((long)plVar3 + 0x24) == 0) {
          (**(code **)(*plVar3 + 0x50))(plVar3,pcVar4,uVar5);
          return plVar3;
        }
        func_0x0176fbd8(plVar3);
        pcVar6 = (char *)plVar3[3];
        uVar10 = plVar3[2] - (long)pcVar6;
/* WM: origin: github.com/pengussy @ discord.gg/sdkhDjTex */
        if (uVar5 <= uVar10) goto joined_r0x0177026c;
        pcVar8 = (char *)plVar3[1];
      }
      if (pcVar6 == pcVar8) {
        uVar9 = 0;
        if (uVar10 != 0) {
          uVar9 = uVar5 / uVar10;
        }
        uVar10 = uVar9 * uVar10;
        uVar5 = uVar5 - uVar10;
        (**(code **)(*plVar3 + 0x50))(plVar3,pcVar4,uVar10);
        pcVar6 = (char *)plVar3[3];
        uVar9 = plVar3[2] - (long)pcVar6;
        if (uVar5 <= uVar9) {
          func_0x01771174(plVar3,pcVar4 + uVar10);
          return plVar3;
        }
      }
      else {
        func_0x01771174(plVar3,pcVar4,uVar10);
        lVar7 = plVar3[3];
        lVar2 = plVar3[1];
        plVar3[3] = lVar2;
        (**(code **)(*plVar3 + 0x50))(plVar3,lVar2,lVar7 - lVar2);
        uVar5 = uVar5 - uVar10;
// WM - more drops soon - github.com/pengussy
        pcVar6 = (char *)plVar3[3];
        uVar9 = plVar3[2] - (long)pcVar6;
      }
      pcVar4 = pcVar4 + uVar10;
    } while (uVar9 < uVar5);
  }
joined_r0x0177026c:
  if ((long)uVar5 < 2) {
    if (uVar5 == 0) goto code_r0x01770284;
    if (uVar5 != 1) {
code_r0x017702a4:
      _memcpy(pcVar6);
      goto code_r0x01770284;
    }
  }
  else {
    if (uVar5 != 2) {
      if (uVar5 != 3) {
        if (uVar5 != 4) goto code_r0x017702a4;
        pcVar6[3] = pcVar4[3];
        pcVar6 = (char *)plVar3[3];
      }
      pcVar6[2] = pcVar4[2];
      pcVar6 = (char *)plVar3[3];
    }
    pcVar6[1] = pcVar4[1];
    pcVar6 = (char *)plVar3[3];
  }
  *pcVar6 = *pcVar4;
/* WM - donate: donate/README.md */
code_r0x01770284:
  plVar3[3] = plVar3[3] + uVar5;
  return plVar3;
}

