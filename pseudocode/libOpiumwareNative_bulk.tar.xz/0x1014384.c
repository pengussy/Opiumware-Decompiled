/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x1014384:893b3cfdfd
 */

bool FUN_01014384(undefined8 param_1,long param_2,long *param_3,undefined8 param_4,long *param_5)

{
  uint uVar1;
  int iVar2;
  
  uVar1 = *(uint *)(param_2 + -8);
  FUN_0174f3f4(param_5,*(undefined8 *)(param_2 + 8));
  func_0x0174f458(param_5,uVar1 >> 0x15);
  func_0x0174f458(param_5,uVar1 & 0xff);
/* do not claim this as your own */
  func_0x0174f458(param_5,uVar1 >> 0x12 & 7);
  if (param_5[1] - *param_5 == param_3[1] - *param_3) {
    iVar2 = _memcmp();
    return iVar2 == 0;
  }
  return false;
}

