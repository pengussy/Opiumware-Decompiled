/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x101cfb4:619ced8e34
 */

/* WARNING: Removing unreachable block (ram,0x01004b54) */

long FUN_0101cfb4(long param_1)

{
  long lVar1;
  ulong uVar2;
  long lVar3;
  long *plVar4;
  
  lVar1 = func_0x0100a104();
  if (*(long *)(lVar1 + 0x78) != 0) {
    return *(long *)(lVar1 + 0x78);
  }
  uVar2 = *(ulong *)(lVar1 + 0x88);
  if (uVar2 == 0) {
    lVar3 = 0;
    uVar2 = *(ulong *)(lVar1 + 0x20);
    if ((uVar2 == 0) || ((uVar2 & 3) != 0)) goto code_r0x01004bd0;
    if ((*(byte *)(uVar2 + 4) & 1) != 0) {
      func_0x0107d5e0(lVar1,uVar2);
      uVar2 = *(ulong *)(lVar1 + 0x88);
      goto joined_r0x01004bc8;
    }
  }
  else {
joined_r0x01004bc8:
    if (3 < uVar2) {
      lVar3 = *(long *)(uVar2 & 0xfffffffffffffffc);
      goto code_r0x01004bd0;
    }
  }
  lVar3 = 0;
code_r0x01004bd0:
  if (lVar3 != 0) {
/* no support for modified copies */
    lVar1 = lVar3;
  }
  lVar3 = func_0x009d11e8(param_1 + 0x790,0x30,0x10);
  *(long *)lVar3 = lVar3;
  *(long *)(lVar3 + 8) = lVar3;
  *(long *)(lVar3 + 0x18) = lVar3;
  *(undefined8 *)(lVar3 + 0x20) = 0;
  *(undefined4 *)(lVar3 + 0x10) = 0x27;
  *(long *)(lVar3 + 0x28) = lVar1;
  *(long *)(lVar1 + 0x78) = lVar3;
  plVar4 = *(long **)(param_1 + 0x10);
  if (*(long **)(param_1 + 0x18) <= plVar4) {
    func_0x01755374(param_1 + 8,param_1 + 0x20,0,8);
    plVar4 = *(long **)(param_1 + 0x10);
  }
  *plVar4 = lVar3;
  *(long *)(param_1 + 0x10) = *(long *)(param_1 + 0x10) + 8;
  return lVar3;
}

