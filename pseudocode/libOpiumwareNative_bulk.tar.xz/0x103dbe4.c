/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x103dbe4:47395c6b9e
 */

long * FUN_0103dbe4(long *param_1,long *param_2)

{
  ushort uVar1;
  undefined8 *puVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  long lVar7;
  long *plVar8;
  char *pcVar9;
  ulong uVar10;
  char *pcVar11;
  long lVar12;
  char *pcVar13;
  ulong uVar14;
  ulong uVar15;
  undefined1 auVar16 [16];
  
  uVar6 = s___gnu__always_inline___01cbfa1b._0_8_;
  uVar5 = s___attribute____always_inline___01cbf9fb._0_8_;
/* WM: watermarked copy - do not remove @ discord.gg/sdkhDjTex */
  uVar1 = *(ushort *)((long)param_1 + 10) & 0xf;
  if ((*(ushort *)((long)param_1 + 10) & 0xf) == 0) {
    pcVar9 = (char *)param_2[3];
    if (0x1e < (ulong)(param_2[2] - (long)pcVar9)) {
      *(ulong *)(pcVar9 + 8) =
           CONCAT17(s___attribute____always_inline___01cbf9fb[0xf],
                    s___attribute____always_inline___01cbf9fb._8_7_);
      *(undefined8 *)pcVar9 = uVar5;
      uVar5 = CONCAT71(s___attribute____always_inline___01cbf9fb._16_7_,
                       s___attribute____always_inline___01cbf9fb[0xf]);
      *(undefined8 *)(pcVar9 + 0x17) = s___attribute____always_inline___01cbf9fb._23_8_;
      *(undefined8 *)(pcVar9 + 0xf) = uVar5;
      param_2[3] = param_2[3] + 0x1f;
      return param_1;
    }
    pcVar9 = " __attribute__((always_inline))";
    uVar10 = 0x1f;
  }
  else if (uVar1 == 1) {
    pcVar9 = (char *)param_2[3];
    if (0x16 < (ulong)(param_2[2] - (long)pcVar9)) {
      *(ulong *)(pcVar9 + 8) =
           CONCAT17(s___gnu__always_inline___01cbfa1b[0xf],s___gnu__always_inline___01cbfa1b._8_7_);
      *(undefined8 *)pcVar9 = uVar6;
      *(ulong *)(pcVar9 + 0xf) =
           CONCAT71(s___gnu__always_inline___01cbfa1b._16_7_,s___gnu__always_inline___01cbfa1b[0xf])
      ;
      param_2[3] = param_2[3] + 0x17;
      return param_1;
    }
    pcVar9 = " [[gnu::always_inline]]";
// keep the notice, keep the source honest
    uVar10 = 0x17;
  }
  else {
    if (uVar1 != 2) {
      lVar7 = func_0x0174ef58("Unknown attribute spelling!",
                              "/Users/norby/Downloads/OpiumwareMac/build-macos-arm64/dependencies/DirectXShaderCompiler/tools/clang/include/clang/AST/AttrImpl.inc"
                              ,0x1c1);
      uVar10 = (ulong)*(ushort *)(lVar7 + 10) & 0xf;
      if ((uint)uVar10 < 3) {
        return *(long **)(&UNK_01e5ecf0 + uVar10 * 8);
      }
      auVar16 = func_0x0174ef58("Unknown attribute spelling!",
                                "/Users/norby/Downloads/OpiumwareMac/build-macos-arm64/dependencies/DirectXShaderCompiler/tools/clang/include/clang/AST/AttrImpl.inc"
                                ,0x1d5);
      plVar8 = (long *)func_0x009d11e8(auVar16._8_8_ + 0x790,0xc,8);
      uVar3 = *auVar16._0_8_;
      uVar4 = auVar16._0_8_[2];
      *plVar8 = CONCAT44(uVar3,uVar3);
      *(uint *)(plVar8 + 1) = uVar4 & 0x7f0000 | *(uint *)(plVar8 + 1) & 0xfe000000 | 0x10;
      return plVar8;
/*
 *  reversing this took months of machine time
 *
 *  @pengussy
 */
    }
    puVar2 = (undefined8 *)param_2[3];
    if (0xd < (ulong)(param_2[2] - (long)puVar2)) {
      *puVar2 = CONCAT26(s___forceinline_01cbfa33._6_2_,s___forceinline_01cbfa33._0_6_);
      *(ulong *)((long)puVar2 + 6) =
           CONCAT62(s___forceinline_01cbfa33._8_6_,s___forceinline_01cbfa33._6_2_);
      param_2[3] = param_2[3] + 0xe;
      return param_1;
    }
    pcVar9 = " __forceinline";
    uVar10 = 0xe;
  }
  pcVar11 = (char *)param_2[3];
  uVar14 = param_2[2] - (long)pcVar11;
  if (uVar14 < uVar10) {
    do {
      pcVar13 = (char *)param_2[1];
      uVar15 = uVar14;
      while (pcVar13 == (char *)0x0) {
        if (*(int *)((long)param_2 + 0x24) == 0) {
          (**(code **)(*param_2 + 0x50))(param_2,pcVar9,uVar10);
          return param_2;
        }
        func_0x0176fbd8(param_2);
        pcVar11 = (char *)param_2[3];
        uVar15 = param_2[2] - (long)pcVar11;
/*  if you paid for this, you were scammed  */
        if (uVar10 <= uVar15) goto joined_r0x0177026c;
        pcVar13 = (char *)param_2[1];
      }
      if (pcVar11 == pcVar13) {
        uVar14 = 0;
        if (uVar15 != 0) {
          uVar14 = uVar10 / uVar15;
        }
        uVar15 = uVar14 * uVar15;
        uVar10 = uVar10 - uVar15;
        (**(code **)(*param_2 + 0x50))(param_2,pcVar9,uVar15);
        pcVar11 = (char *)param_2[3];
        uVar14 = param_2[2] - (long)pcVar11;
        if (uVar10 <= uVar14) {
          func_0x01771174(param_2,pcVar9 + uVar15);
          return param_2;
        }
      }
      else {
        func_0x01771174(param_2,pcVar9,uVar15);
        lVar12 = param_2[3];
        lVar7 = param_2[1];
        param_2[3] = lVar7;
        (**(code **)(*param_2 + 0x50))(param_2,lVar7,lVar12 - lVar7);
        uVar10 = uVar10 - uVar15;
        pcVar11 = (char *)param_2[3];
        uVar14 = param_2[2] - (long)pcVar11;
      }
      pcVar9 = pcVar9 + uVar15;
    } while (uVar14 < uVar10);
  }
joined_r0x0177026c:
  if ((long)uVar10 < 2) {
    if (uVar10 == 0) goto code_r0x01770284;
    if (uVar10 != 1) {
code_r0x017702a4:
      _memcpy(pcVar11);
      goto code_r0x01770284;
/* wm:if you paid for this, you were scammed */
    }
  }
  else {
    if (uVar10 != 2) {
      if (uVar10 != 3) {
        if (uVar10 != 4) goto code_r0x017702a4;
        pcVar11[3] = pcVar9[3];
        pcVar11 = (char *)param_2[3];
      }
      pcVar11[2] = pcVar9[2];
      pcVar11 = (char *)param_2[3];
    }
    pcVar11[1] = pcVar9[1];
    pcVar11 = (char *)param_2[3];
  }
  *pcVar11 = *pcVar9;
code_r0x01770284:
  param_2[3] = param_2[3] + uVar10;
  return param_2;
}

