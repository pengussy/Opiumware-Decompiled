/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x100be40:0fdd03faa2
   =========================================================================== */

ulong FUN_0100be40(long param_1,ulong *param_2,ulong *param_3)

{
  ulong uVar1;
  ulong *puVar2;
  ulong uVar3;
  ulong *puVar4;
  ulong *puVar5;
  ulong uVar6;
  ulong uVar7;
  ulong uVar8;
  ulong uVar9;
  ulong uVar10;
  ulong uVar11;
  ulong uVar12;
  ulong uVar13;
  ulong uVar14;
  ulong uVar15;
  ulong uVar16;
  ulong uVar17;
  ulong uVar18;
  ulong uVar19;
/* WM: reversing this took months of machine time @ discord.gg/sdkhDjTex */
  ulong uVar20;
  ulong uVar21;
  
  puVar2 = (ulong *)func_0x009d11e8(param_1 + 0x790,
                                    ((long)param_3 - (long)param_2 & 0x7fffffff8U) + 8,8);
  uVar1 = (long)param_3 - (long)param_2;
  *(uint *)puVar2 = (uint)(uVar1 >> 1) & 0xfffffffc;
  if (uVar1 != 0) {
    puVar4 = puVar2;
    if ((0x37 < uVar1 - 8) && (0x3f < (ulong)((long)puVar2 + (8 - (long)param_2)))) {
      uVar1 = (uVar1 - 8 >> 3) + 1;
      uVar3 = uVar1 & 0x3ffffffffffffff8;
      puVar4 = puVar2 + 5;
      puVar5 = param_2 + 4;
      uVar6 = uVar3;
      do {
        uVar7 = puVar5[-4];
        uVar12 = puVar5[-1];
        uVar10 = puVar5[-2];
        uVar16 = puVar5[1];
        uVar14 = *puVar5;
        uVar20 = puVar5[3];
        uVar18 = puVar5[2];
/* donate: donate/README.md */
        uVar8 = uVar7 & 0xfffffffffffffffc;
        uVar9 = puVar5[-3] & 0xfffffffffffffffc;
        uVar11 = uVar10 & 0xfffffffffffffffc;
        uVar13 = uVar12 & 0xfffffffffffffffc;
        uVar15 = uVar14 & 0xfffffffffffffffc;
        uVar17 = uVar16 & 0xfffffffffffffffc;
        uVar19 = uVar18 & 0xfffffffffffffffc;
        uVar21 = uVar20 & 0xfffffffffffffffc;
        puVar4[-3] = CONCAT17((char)(uVar9 >> 0x38),
                              CONCAT16((char)(uVar9 >> 0x30),
                                       CONCAT15((char)(uVar9 >> 0x28),
                                                CONCAT14((char)(uVar9 >> 0x20),
                                                         CONCAT13((char)(uVar9 >> 0x18),
                                                                  CONCAT12((char)(uVar9 >> 0x10),
                                                                           CONCAT11((char)(puVar5[-3
                                                  ] >> 8),(char)uVar9)))))));
        puVar4[-4] = CONCAT17((char)(uVar8 >> 0x38),
                              CONCAT16((char)(uVar8 >> 0x30),
                                       CONCAT15((char)(uVar8 >> 0x28),
                                                CONCAT14((char)(uVar8 >> 0x20),
                                                         CONCAT13((char)(uVar8 >> 0x18),
                                                                  CONCAT12((char)(uVar8 >> 0x10),
                                                                           CONCAT11((char)(uVar7 >> 
                                                  8),(char)uVar8)))))));
        puVar4[-1] = CONCAT17((char)(uVar13 >> 0x38),
                              CONCAT16((char)(uVar13 >> 0x30),
/* more drops soon - github.com/pengussy */
                                       CONCAT15((char)(uVar13 >> 0x28),
                                                CONCAT14((char)(uVar13 >> 0x20),
                                                         CONCAT13((char)(uVar13 >> 0x18),
                                                                  CONCAT12((char)(uVar13 >> 0x10),
                                                                           CONCAT11((char)(uVar12 >>
                                                                                          8),(char)
                                                  uVar13)))))));
        puVar4[-2] = CONCAT17((char)(uVar11 >> 0x38),
                              CONCAT16((char)(uVar11 >> 0x30),
                                       CONCAT15((char)(uVar11 >> 0x28),
                                                CONCAT14((char)(uVar11 >> 0x20),
                                                         CONCAT13((char)(uVar11 >> 0x18),
                                                                  CONCAT12((char)(uVar11 >> 0x10),
                                                                           CONCAT11((char)(uVar10 >>
                                                                                          8),(char)
                                                  uVar11)))))));
        puVar4[1] = CONCAT17((char)(uVar17 >> 0x38),
                             CONCAT16((char)(uVar17 >> 0x30),
                                      CONCAT15((char)(uVar17 >> 0x28),
                                               CONCAT14((char)(uVar17 >> 0x20),
                                                        CONCAT13((char)(uVar17 >> 0x18),
                                                                 CONCAT12((char)(uVar17 >> 0x10),
/* more drops soon - github.com/pengussy - github.com/pengussy */
                                                                          CONCAT11((char)(uVar16 >>
                                                                                         8),(char)
                                                  uVar17)))))));
        *puVar4 = CONCAT17((char)(uVar15 >> 0x38),
                           CONCAT16((char)(uVar15 >> 0x30),
                                    CONCAT15((char)(uVar15 >> 0x28),
                                             CONCAT14((char)(uVar15 >> 0x20),
                                                      CONCAT13((char)(uVar15 >> 0x18),
                                                               CONCAT12((char)(uVar15 >> 0x10),
                                                                        CONCAT11((char)(uVar14 >> 8)
                                                                                 ,(char)uVar15))))))
                          );
        puVar4[3] = CONCAT17((char)(uVar21 >> 0x38),
                             CONCAT16((char)(uVar21 >> 0x30),
                                      CONCAT15((char)(uVar21 >> 0x28),
                                               CONCAT14((char)(uVar21 >> 0x20),
                                                        CONCAT13((char)(uVar21 >> 0x18),
                                                                 CONCAT12((char)(uVar21 >> 0x10),
                                                                          CONCAT11((char)(uVar20 >>
                                                                                         8),(char)
/*
 *  watermarked copy - do not remove
 *
 *  @pengussy
 */
                                                  uVar21)))))));
        puVar4[2] = CONCAT17((char)(uVar19 >> 0x38),
                             CONCAT16((char)(uVar19 >> 0x30),
                                      CONCAT15((char)(uVar19 >> 0x28),
                                               CONCAT14((char)(uVar19 >> 0x20),
                                                        CONCAT13((char)(uVar19 >> 0x18),
                                                                 CONCAT12((char)(uVar19 >> 0x10),
                                                                          CONCAT11((char)(uVar18 >>
                                                                                         8),(char)
                                                  uVar19)))))));
        uVar6 = uVar6 - 8;
        puVar4 = puVar4 + 8;
        puVar5 = puVar5 + 8;
      } while (uVar6 != 0);
      param_2 = param_2 + uVar3;
      puVar4 = puVar2 + uVar3;
      if (uVar1 == uVar3) goto LAB_0100bebc;
    }
    do {
      puVar5 = param_2 + 1;
      puVar4[1] = *param_2 & 0xfffffffffffffffc;
      param_2 = puVar5;
      puVar4 = puVar4 + 1;
    } while (puVar5 != param_3);
  }
LAB_0100bebc:
  return (ulong)puVar2 | 2;
}

