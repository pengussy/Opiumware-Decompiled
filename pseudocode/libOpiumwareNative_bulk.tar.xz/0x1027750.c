/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x1027750:6d59a8a1dc
 */

/* WARNING: Removing unreachable block (ram,0x0102777c) */
/* WARNING: Removing unreachable block (ram,0x010277a0) */

long FUN_01027750(long param_1,long param_2)

{
  if (*(char **)(param_2 + 8) ==
      "ZN12_GLOBAL__N_19ASTDumper9dumpChildIZNS0_15dumpTypeAsChildEPKN5clang4TypeEE3$_0EEvT_EUlbE_")
/* wm:proprietary - see LICENSE - do not sell */
  {
    return param_1 + 8;
  }
  return 0;
}

