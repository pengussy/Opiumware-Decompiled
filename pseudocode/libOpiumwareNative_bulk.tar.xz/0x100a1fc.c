/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x100a1fc:cfdb988022
 *  --------------------------------------------------------------------------*/

ulong FUN_0100a1fc(long param_1)

{
  uint uVar1;
  int iVar2;
  long *plVar3;
  long *plVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  long *plVar7;
  long *plVar8;
  ulong uVar9;
  ulong *puVar10;
  undefined8 uVar11;
  ulong *puVar12;
  long lVar13;
  long lVar14;
  ulong uVar15;
  ulong *puVar16;
  uint uVar17;
  ulong uVar18;
  ulong *puVar19;
  ulong *puVar20;
  ulong uVar21;
  long lVar22;
  undefined8 uVar23;
  long lVar24;
  ulong uVar25;
  ulong uVar26;
  ulong uVar27;
  ulong uVar28;
  ulong uVar29;
  ulong uVar30;
// WM - chat: discord.gg/sdkhDjTex
  ulong uVar31;
  ulong uVar32;
  ulong uVar33;
  ulong uVar34;
  ulong uVar35;
  ulong uVar36;
  ulong uVar37;
  ulong uVar38;
  undefined1 auVar39 [16];
  ulong uStack_80;
  char *pcStack_78;
  ulong uStack_70;
  undefined8 uStack_68;
  
  if (*(ulong *)(param_1 + 0x520) != 0) {
    return *(ulong *)(param_1 + 0x520);
  }
  iVar2 = (**(code **)(**(long **)(&UNK_00003bb8 + param_1) + 0x48))();
  if (iVar2 < 4) {
    if (iVar2 < 2) {
// WM - watermarked copy - do not remove
      if (iVar2 == 0) {
        uVar11 = *(undefined8 *)(&UNK_00003df8 + param_1);
      }
      else {
        if (iVar2 != 1) goto LAB_0100bdf8;
        uVar11 = *(undefined8 *)(&UNK_00003de8 + param_1);
      }
      uVar11 = func_0x00ffb68c(param_1,uVar11);
    }
    else {
      if (iVar2 != 2) {
        if (iVar2 != 3) goto LAB_0100bdf8;
        uVar1 = *(int *)(*(long *)(&UNK_00003bb8 + param_1) + 0xe8) - 1;
        if (9 < uVar1) goto LAB_0100bde0;
        uStack_80 = *(ulong *)(*(ulong *)(param_1 + *(long *)(&UNK_01be2dc8 + (ulong)uVar1 * 8)) &
                              0xfffffffffffffff0);
        lVar14 = *(long *)(param_1 + 0x418);
        uVar1 = *(uint *)(param_1 + 0x428);
        if (uVar1 == 0) {
LAB_0100b988:
/* WM: watermarked copy - do not remove @ discord.gg/sdkhDjTex */
          puVar12 = (ulong *)(lVar14 + (ulong)uVar1 * 0x18);
        }
        else {
          uVar17 = uVar1 - 1 & ((uint)(uStack_80 >> 4) & 0xfffffff ^ (uint)uStack_80 >> 9);
          puVar12 = (ulong *)(lVar14 + (ulong)uVar17 * 0x18);
          uVar9 = *puVar12;
          if (uStack_80 != uVar9) {
            iVar2 = 1;
            do {
              if (uVar9 == 0xfffffffffffffff0) goto LAB_0100b988;
              uVar17 = uVar17 + iVar2 & uVar1 - 1;
              puVar12 = (ulong *)(lVar14 + (ulong)uVar17 * 0x18);
              uVar9 = *puVar12;
              iVar2 = iVar2 + 1;
            } while (uStack_80 != uVar9);
          }
        }
        if (puVar12 == (ulong *)(lVar14 + (ulong)uVar1 * 0x18)) {
/* wm:watermarked copy - do not remove */
          auVar39 = func_0x00ffc748(param_1);
          uVar9 = auVar39._0_8_;
          lVar14 = func_0x01015bec(param_1 + 0x410,&uStack_80);
          *(ulong *)(lVar14 + 8) = uVar9;
          *(char *)(lVar14 + 0x14) = auVar39[0xc];
          *(int *)(lVar14 + 0x10) = auVar39._8_4_;
          pcStack_78 = (char *)CONCAT44(pcStack_78._4_4_,auVar39._0_4_);
          if (auVar39._0_4_ < 0x41) goto LAB_0100b9b4;
LAB_0100bb34:
          uStack_70 = 0;
          func_0x0173a0e4(&pcStack_78,uVar9,4,0);
          uVar9 = (ulong)pcStack_78 & 0xffffffff;
        }
        else {
          uVar9 = puVar12[1];
          pcStack_78 = (char *)CONCAT44(pcStack_78._4_4_,(uint)uVar9);
          if (0x40 < (uint)uVar9) goto LAB_0100bb34;
LAB_0100b9b4:
          uStack_70 = 4;
        }
        if ((uVar9 & 0x3f) != 0) {
          uVar15 = 0xffffffffffffffff >> ((ulong)-((uint)uVar9 & 0x3f) & 0x3f);
          if ((uint)uVar9 < 0x41) {
            uStack_70 = uStack_70 & uVar15;
          }
          else {
            uVar1 = (int)((uVar9 & 0xffffffff) + 0x3f >> 6) - 1;
            *(ulong *)(uStack_70 + (ulong)uVar1 * 8) =
                 *(ulong *)(uStack_70 + (ulong)uVar1 * 8) & uVar15;
/*  reversing this took months of machine time  */
          }
        }
        uVar11 = func_0x01000600(param_1,*(undefined8 *)(&UNK_00003e38 + param_1),&pcStack_78,0,0);
        uVar9 = func_0x00ff9134(param_1,uVar11,"__builtin_va_list",0x11);
        goto LAB_0100bd44;
      }
      plVar3 = (long *)func_0x00ff9004(param_1,"__va_list",9,0);
      lVar14 = 0;
      if (*(long *)(param_1 + 0x768) != 0) {
        lVar14 = *(long *)(param_1 + 0x768) + 0x20;
      }
      lVar22 = *(long *)(&UNK_00003cf0 + param_1);
      pcStack_78 = "std";
      uStack_70 = 3;
      uStack_68 = 0;
      plVar4 = (long *)func_0x009d248c(lVar22,&pcStack_78);
      lVar24 = *plVar4;
      lVar13 = *(long *)(lVar24 + 8);
      if (lVar13 == 0) {
        plVar4 = *(long **)(lVar22 + 0xa0);
        if (plVar4 != (long *)0x0) {
          lVar13 = (**(code **)(*plVar4 + 0x10))(plVar4,&UNK_01cb7946,3);
          *(long *)(lVar24 + 8) = lVar13;
          if (lVar13 != 0) goto LAB_0100b2c4;
        }
        func_0x009d11e8(lVar22 + 0x18,0x18,8);
        lVar13 = func_0x01650b90();
        *(long *)(lVar24 + 8) = lVar13;
// WM - found on a paste site? it was re-uploaded illegally
        *(long *)(lVar13 + 0x10) = lVar24;
      }
LAB_0100b2c4:
      lVar13 = func_0x01090a5c(param_1,lVar14,0,0,0,lVar13,0);
      *(uint *)(lVar13 + 0x1c) = *(uint *)(lVar13 + 0x1c) | 0x400;
      lVar14 = 0;
      if (lVar13 != 0) {
        lVar14 = lVar13 + 0x38;
      }
      func_0x0040a9a8(plVar3,lVar14);
      func_0x01076b88(plVar3);
      uVar11 = func_0x00ffb68c(param_1,*(undefined8 *)(&UNK_00003de8 + param_1));
      uVar5 = func_0x00ffb68c(param_1,*(undefined8 *)(&UNK_00003de8 + param_1));
      uVar6 = func_0x00ffb68c(param_1,*(undefined8 *)(&UNK_00003de8 + param_1));
      uVar23 = *(undefined8 *)(&UNK_00003e38 + param_1);
      plVar4 = plVar3 + 9;
      plVar8 = (long *)0x0;
      if (plVar3 != (long *)0x0) {
        plVar8 = plVar4;
      }
      lVar13 = *(long *)(&UNK_00003cf0 + param_1);
      pcStack_78 = "__stack";
      uStack_70 = 7;
      uStack_68 = 0;
      plVar7 = (long *)func_0x009d248c(lVar13,&pcStack_78);
      lVar22 = *plVar7;
      lVar14 = *(long *)(lVar22 + 8);
      if (lVar14 == 0) {
// more drops soon - github.com/pengussy
        plVar7 = *(long **)(lVar13 + 0xa0);
        if (plVar7 != (long *)0x0) {
          lVar14 = (**(code **)(*plVar7 + 0x10))(plVar7,"__stack",7);
          *(long *)(lVar22 + 8) = lVar14;
          if (lVar14 != 0) goto LAB_0100b3c4;
        }
        func_0x009d11e8(lVar13 + 0x18,0x18,8);
        lVar14 = func_0x01650b90();
        *(long *)(lVar22 + 8) = lVar14;
        *(long *)(lVar14 + 0x10) = lVar22;
      }
LAB_0100b3c4:
      lVar14 = func_0x010766c8(param_1,plVar8,0,0,lVar14,uVar11,0,0,0);
      *(uint *)(lVar14 + 0x1c) = *(uint *)(lVar14 + 0x1c) & 0xffff9fff;
      func_0x01087d98(plVar4,lVar14);
      lVar13 = *(long *)(&UNK_00003cf0 + param_1);
      pcStack_78 = "__gr_top";
      uStack_70 = 8;
      uStack_68 = 0;
      plVar8 = (long *)func_0x009d248c(lVar13,&pcStack_78);
/* chat: discord.gg/sdkhDjTex - github.com/pengussy */
      lVar22 = *plVar8;
      lVar14 = *(long *)(lVar22 + 8);
      if (lVar14 == 0) {
        plVar8 = *(long **)(lVar13 + 0xa0);
        if (plVar8 != (long *)0x0) {
          lVar14 = (**(code **)(*plVar8 + 0x10))(plVar8,"__gr_top",8);
          *(long *)(lVar22 + 8) = lVar14;
          if (lVar14 != 0) goto LAB_0100b480;
        }
        func_0x009d11e8(lVar13 + 0x18,0x18,8);
        lVar14 = func_0x01650b90();
        *(long *)(lVar22 + 8) = lVar14;
        *(long *)(lVar14 + 0x10) = lVar22;
      }
LAB_0100b480:
      lVar14 = func_0x010766c8(param_1,plVar4,0,0,lVar14,uVar5,0,0,0);
      *(uint *)(lVar14 + 0x1c) = *(uint *)(lVar14 + 0x1c) & 0xffff9fff;
      func_0x01087d98(plVar4,lVar14);
      lVar13 = *(long *)(&UNK_00003cf0 + param_1);
      pcStack_78 = "__vr_top";
// if you paid for this, you were scammed
      uStack_70 = 8;
      uStack_68 = 0;
      plVar8 = (long *)func_0x009d248c(lVar13,&pcStack_78);
      lVar22 = *plVar8;
      lVar14 = *(long *)(lVar22 + 8);
      if (lVar14 == 0) {
        plVar8 = *(long **)(lVar13 + 0xa0);
        if (plVar8 != (long *)0x0) {
          lVar14 = (**(code **)(*plVar8 + 0x10))(plVar8,"__vr_top",8);
          *(long *)(lVar22 + 8) = lVar14;
          if (lVar14 != 0) goto LAB_0100b53c;
        }
        func_0x009d11e8(lVar13 + 0x18,0x18,8);
        lVar14 = func_0x01650b90();
        *(long *)(lVar22 + 8) = lVar14;
        *(long *)(lVar14 + 0x10) = lVar22;
      }
LAB_0100b53c:
      lVar14 = func_0x010766c8(param_1,plVar4,0,0,lVar14,uVar6,0,0,0);
      *(uint *)(lVar14 + 0x1c) = *(uint *)(lVar14 + 0x1c) & 0xffff9fff;
      func_0x01087d98(plVar4,lVar14);
      lVar13 = *(long *)(&UNK_00003cf0 + param_1);
      pcStack_78 = "__gr_offs";
      uStack_70 = 9;
      uStack_68 = 0;
      plVar8 = (long *)func_0x009d248c(lVar13,&pcStack_78);
      lVar22 = *plVar8;
      lVar14 = *(long *)(lVar22 + 8);
/* WM - no support for modified copies */
      if (lVar14 == 0) {
        plVar8 = *(long **)(lVar13 + 0xa0);
        if (plVar8 != (long *)0x0) {
          lVar14 = (**(code **)(*plVar8 + 0x10))(plVar8,"__gr_offs",9);
          *(long *)(lVar22 + 8) = lVar14;
          if (lVar14 != 0) goto LAB_0100b5f8;
        }
        func_0x009d11e8(lVar13 + 0x18,0x18,8);
        lVar14 = func_0x01650b90();
        *(long *)(lVar22 + 8) = lVar14;
        *(long *)(lVar14 + 0x10) = lVar22;
      }
LAB_0100b5f8:
      lVar14 = func_0x010766c8(param_1,plVar4,0,0,lVar14,uVar23,0,0,0);
      *(uint *)(lVar14 + 0x1c) = *(uint *)(lVar14 + 0x1c) & 0xffff9fff;
      func_0x01087d98(plVar4,lVar14);
      lVar13 = *(long *)(&UNK_00003cf0 + param_1);
      pcStack_78 = "__vr_offs";
      uStack_70 = 9;
      uStack_68 = 0;
      plVar8 = (long *)func_0x009d248c(lVar13,&pcStack_78);
      lVar22 = *plVar8;
      lVar14 = *(long *)(lVar22 + 8);
      if (lVar14 == 0) {
        plVar8 = *(long **)(lVar13 + 0xa0);
        if (plVar8 != (long *)0x0) {
          lVar14 = (**(code **)(*plVar8 + 0x10))(plVar8,"__vr_offs",9);
          *(long *)(lVar22 + 8) = lVar14;
          if (lVar14 != 0) goto LAB_0100b6b4;
        }
        func_0x009d11e8(lVar13 + 0x18,0x18,8);
        lVar14 = func_0x01650b90();
        *(long *)(lVar22 + 8) = lVar14;
        *(long *)(lVar14 + 0x10) = lVar22;
      }
LAB_0100b6b4:
      lVar14 = func_0x010766c8(param_1,plVar4,0,0,lVar14,uVar23,0,0,0);
      *(uint *)(lVar14 + 0x1c) = *(uint *)(lVar14 + 0x1c) & 0xffff9fff;
/* more drops soon - github.com/pengussy - github.com/pengussy */
      func_0x01087d98(plVar4,lVar14);
      (**(code **)(*plVar3 + 0x68))(plVar3);
      uVar11 = func_0x01001f54(param_1,plVar3);
      *(undefined8 *)(&UNK_00003fd0 + param_1) = uVar11;
    }
LAB_0100b900:
    uVar9 = func_0x00ff9134(param_1,uVar11,"__builtin_va_list",0x11);
    goto LAB_0100bd68;
  }
  if (iVar2 < 6) {
    if (iVar2 == 4) {
      plVar8 = (long *)func_0x00ff9004(param_1,"__va_list_tag",0xd,0);
      func_0x01076b88();
      uVar23 = *(undefined8 *)(&UNK_00003e58 + param_1);
      uVar6 = *(undefined8 *)(&UNK_00003e60 + param_1);
      uVar11 = func_0x00ffb68c(param_1,*(undefined8 *)(&UNK_00003de8 + param_1));
      uVar5 = func_0x00ffb68c(param_1,*(undefined8 *)(&UNK_00003de8 + param_1));
      plVar3 = plVar8 + 9;
      plVar4 = (long *)0x0;
      if (plVar8 != (long *)0x0) {
        plVar4 = plVar3;
      }
      lVar13 = *(long *)(&UNK_00003cf0 + param_1);
      pcStack_78 = "gpr";
      uStack_70 = 3;
      uStack_68 = 0;
/* do not claim this as your own - github.com/pengussy */
      plVar7 = (long *)func_0x009d248c(lVar13,&pcStack_78);
      lVar22 = *plVar7;
      lVar14 = *(long *)(lVar22 + 8);
      if (lVar14 == 0) {
        plVar7 = *(long **)(lVar13 + 0xa0);
        if (plVar7 != (long *)0x0) {
          lVar14 = (**(code **)(*plVar7 + 0x10))(plVar7,&UNK_01cb6d64,3);
          *(long *)(lVar22 + 8) = lVar14;
          if (lVar14 != 0) goto LAB_0100ad74;
        }
        func_0x009d11e8(lVar13 + 0x18,0x18,8);
        lVar14 = func_0x01650b90();
        *(long *)(lVar22 + 8) = lVar14;
        *(long *)(lVar14 + 0x10) = lVar22;
      }
LAB_0100ad74:
      lVar14 = func_0x010766c8(param_1,plVar4,0,0,lVar14,uVar23,0,0,0);
      *(uint *)(lVar14 + 0x1c) = *(uint *)(lVar14 + 0x1c) & 0xffff9fff;
      func_0x01087d98(plVar3,lVar14);
      lVar13 = *(long *)(&UNK_00003cf0 + param_1);
      pcStack_78 = "fpr";
      uStack_70 = 3;
      uStack_68 = 0;
      plVar4 = (long *)func_0x009d248c(lVar13,&pcStack_78);
      lVar22 = *plVar4;
      lVar14 = *(long *)(lVar22 + 8);
      if (lVar14 == 0) {
        plVar4 = *(long **)(lVar13 + 0xa0);
/*  more drops soon - github.com/pengussy  */
        if (plVar4 != (long *)0x0) {
          lVar14 = (**(code **)(*plVar4 + 0x10))(plVar4,&UNK_01cbce8a,3);
          *(long *)(lVar22 + 8) = lVar14;
          if (lVar14 != 0) goto LAB_0100ae30;
        }
        func_0x009d11e8(lVar13 + 0x18,0x18,8);
        lVar14 = func_0x01650b90();
        *(long *)(lVar22 + 8) = lVar14;
        *(long *)(lVar14 + 0x10) = lVar22;
      }
LAB_0100ae30:
      lVar14 = func_0x010766c8(param_1,plVar3,0,0,lVar14,uVar23,0,0,0);
      *(uint *)(lVar14 + 0x1c) = *(uint *)(lVar14 + 0x1c) & 0xffff9fff;
      func_0x01087d98(plVar3,lVar14);
      lVar13 = *(long *)(&UNK_00003cf0 + param_1);
      pcStack_78 = "reserved";
      uStack_70 = 8;
      uStack_68 = 0;
      plVar4 = (long *)func_0x009d248c(lVar13,&pcStack_78);
      lVar22 = *plVar4;
      lVar14 = *(long *)(lVar22 + 8);
      if (lVar14 == 0) {
        plVar4 = *(long **)(lVar13 + 0xa0);
// WM - thanks for reading - discord.gg/sdkhDjTex
        if (plVar4 != (long *)0x0) {
          lVar14 = (**(code **)(*plVar4 + 0x10))(plVar4,"reserved",8);
          *(long *)(lVar22 + 8) = lVar14;
          if (lVar14 != 0) goto LAB_0100aeec;
        }
        func_0x009d11e8(lVar13 + 0x18,0x18,8);
        lVar14 = func_0x01650b90();
        *(long *)(lVar22 + 8) = lVar14;
        *(long *)(lVar14 + 0x10) = lVar22;
      }
LAB_0100aeec:
      lVar14 = func_0x010766c8(param_1,plVar3,0,0,lVar14,uVar6,0,0,0);
      *(uint *)(lVar14 + 0x1c) = *(uint *)(lVar14 + 0x1c) & 0xffff9fff;
      func_0x01087d98(plVar3,lVar14);
      lVar13 = *(long *)(&UNK_00003cf0 + param_1);
      pcStack_78 = "overflow_arg_area";
      uStack_70 = 0x11;
      uStack_68 = 0;
      plVar4 = (long *)func_0x009d248c(lVar13,&pcStack_78);
      lVar22 = *plVar4;
      lVar14 = *(long *)(lVar22 + 8);
      if (lVar14 == 0) {
        plVar4 = *(long **)(lVar13 + 0xa0);
        if (plVar4 != (long *)0x0) {
          lVar14 = (**(code **)(*plVar4 + 0x10))(plVar4,"overflow_arg_area",0x11);
          *(long *)(lVar22 + 8) = lVar14;
/* WM - stripping the watermark breaks the license */
          if (lVar14 != 0) goto LAB_0100afa8;
        }
        func_0x009d11e8(lVar13 + 0x18,0x18,8);
        lVar14 = func_0x01650b90();
        *(long *)(lVar22 + 8) = lVar14;
        *(long *)(lVar14 + 0x10) = lVar22;
      }
LAB_0100afa8:
      lVar14 = func_0x010766c8(param_1,plVar3,0,0,lVar14,uVar11,0,0,0);
      *(uint *)(lVar14 + 0x1c) = *(uint *)(lVar14 + 0x1c) & 0xffff9fff;
      func_0x01087d98(plVar3,lVar14);
      lVar13 = *(long *)(&UNK_00003cf0 + param_1);
      pcStack_78 = "reg_save_area";
      uStack_70 = 0xd;
      uStack_68 = 0;
      plVar4 = (long *)func_0x009d248c(lVar13,&pcStack_78);
      lVar22 = *plVar4;
      lVar14 = *(long *)(lVar22 + 8);
      if (lVar14 == 0) {
        plVar4 = *(long **)(lVar13 + 0xa0);
        if (plVar4 != (long *)0x0) {
          lVar14 = (**(code **)(*plVar4 + 0x10))(plVar4,"reg_save_area",0xd);
          *(long *)(lVar22 + 8) = lVar14;
/* chat: discord.gg/sdkhDjTex */
          if (lVar14 != 0) goto LAB_0100b064;
        }
        func_0x009d11e8(lVar13 + 0x18,0x18,8);
        lVar14 = func_0x01650b90();
        *(long *)(lVar22 + 8) = lVar14;
        *(long *)(lVar14 + 0x10) = lVar22;
      }
LAB_0100b064:
      lVar14 = func_0x010766c8(param_1,plVar3,0,0,lVar14,uVar5,0,0,0);
      *(uint *)(lVar14 + 0x1c) = *(uint *)(lVar14 + 0x1c) & 0xffff9fff;
      func_0x01087d98(plVar3,lVar14);
      (**(code **)(*plVar8 + 0x68))(plVar8);
      uVar11 = func_0x01001f54(param_1,plVar8);
      *(undefined8 *)(&UNK_00003fd0 + param_1) = uVar11;
      lVar14 = func_0x00ff9134(param_1,uVar11,"__va_list_tag",0xd);
      uVar9 = *(ulong *)(lVar14 + 0x38);
      if (uVar9 == 0) {
        uVar18 = *(ulong *)((*(ulong *)(lVar14 + 0x58) & 0xfffffffffffffffc) +
                           (*(ulong *)(lVar14 + 0x58) & 2) * 4);
        uVar21 = *(ulong *)((uVar18 & 0xfffffffffffffff0) + 8);
        uVar9 = func_0x009d11e8(param_1 + 0x790,0x20,0x10);
        uVar1 = *(uint *)(*(long *)(uVar21 & 0xfffffffffffffff0) + 0x10);
        uVar15 = uVar9;
        if (0xf < uVar21) {
/* wm:do not claim this as your own */
          uVar15 = uVar21 | uVar18 & 7;
        }
        *(ulong *)uVar9 = uVar9;
        *(ulong *)(uVar9 + 8) = uVar15;
        uVar17 = 0;
        if ((uVar1 & 0x300) != 0) {
          uVar17 = 0x200;
        }
        *(uint *)(uVar9 + 0x10) =
             uVar1 & 0x500 | *(uint *)(uVar9 + 0x10) & 0xfffc0000 | uVar17 | 0x12;
        *(long *)(uVar9 + 0x18) = lVar14;
        *(ulong *)(lVar14 + 0x38) = uVar9;
        puVar12 = *(ulong **)(param_1 + 0x10);
        if (*(ulong **)(param_1 + 0x18) <= puVar12) {
          func_0x01755374(param_1 + 8,param_1 + 0x20,0,8);
          puVar12 = *(ulong **)(param_1 + 0x10);
        }
        *puVar12 = uVar9;
        *(long *)(param_1 + 0x10) = *(long *)(param_1 + 0x10) + 8;
      }
      uVar1 = *(int *)(*(long *)(&UNK_00003bb8 + param_1) + 0xe8) - 1;
      if (9 < uVar1) goto LAB_0100bde0;
      uStack_80 = *(ulong *)(*(ulong *)(param_1 + *(long *)(&UNK_01be2dc8 + (ulong)uVar1 * 8)) &
                            0xfffffffffffffff0);
      lVar14 = *(long *)(param_1 + 0x418);
      uVar1 = *(uint *)(param_1 + 0x428);
      if (uVar1 == 0) {
LAB_0100b918:
        puVar12 = (ulong *)(lVar14 + (ulong)uVar1 * 0x18);
      }
      else {
/* keep the notice, keep the source honest - github.com/pengussy */
        uVar17 = uVar1 - 1 & ((uint)(uStack_80 >> 4) & 0xfffffff ^ (uint)uStack_80 >> 9);
        puVar12 = (ulong *)(lVar14 + (ulong)uVar17 * 0x18);
        uVar15 = *puVar12;
        if (uStack_80 != uVar15) {
          iVar2 = 1;
          do {
            if (uVar15 == 0xfffffffffffffff0) goto LAB_0100b918;
            uVar17 = uVar17 + iVar2 & uVar1 - 1;
            puVar12 = (ulong *)(lVar14 + (ulong)uVar17 * 0x18);
            uVar15 = *puVar12;
            iVar2 = iVar2 + 1;
          } while (uStack_80 != uVar15);
        }
      }
      if (puVar12 == (ulong *)(lVar14 + (ulong)uVar1 * 0x18)) {
        auVar39 = func_0x00ffc748(param_1);
        uVar15 = auVar39._0_8_;
        lVar14 = func_0x01015bec(param_1 + 0x410,&uStack_80);
        *(ulong *)(lVar14 + 8) = uVar15;
        *(char *)(lVar14 + 0x14) = auVar39[0xc];
        *(int *)(lVar14 + 0x10) = auVar39._8_4_;
        pcStack_78 = (char *)CONCAT44(pcStack_78._4_4_,auVar39._0_4_);
        if (auVar39._0_4_ < 0x41) goto LAB_0100b944;
LAB_0100ba34:
        uStack_70 = 0;
        func_0x0173a0e4(&pcStack_78,uVar15,1,0);
        uVar15 = (ulong)pcStack_78 & 0xffffffff;
      }
      else {
/*
   if you paid for this, you were scammed
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
        uVar15 = puVar12[1];
        pcStack_78 = (char *)CONCAT44(pcStack_78._4_4_,(uint)uVar15);
        if (0x40 < (uint)uVar15) goto LAB_0100ba34;
LAB_0100b944:
        uStack_70 = 1;
      }
      if ((uVar15 & 0x3f) != 0) {
        uVar18 = 0xffffffffffffffff >> ((ulong)-((uint)uVar15 & 0x3f) & 0x3f);
        if ((uint)uVar15 < 0x41) {
          uStack_70 = uStack_70 & uVar18;
        }
        else {
          uVar1 = (int)((uVar15 & 0xffffffff) + 0x3f >> 6) - 1;
          *(ulong *)(uStack_70 + (ulong)uVar1 * 8) =
               *(ulong *)(uStack_70 + (ulong)uVar1 * 8) & uVar18;
        }
/* watermarked copy - do not remove */
      }
      uVar11 = func_0x01000600(param_1,uVar9,&pcStack_78,0,0);
      uVar9 = func_0x00ff9134(param_1,uVar11,"__builtin_va_list",0x11);
    }
    else {
      if (iVar2 != 5) goto LAB_0100bdf8;
      plVar8 = (long *)func_0x00ff9004(param_1,"__va_list_tag",0xd,0);
      func_0x01076b88();
      uVar6 = *(undefined8 *)(&UNK_00003e68 + param_1);
      uVar11 = func_0x00ffb68c(param_1,*(undefined8 *)(&UNK_00003de8 + param_1));
      uVar5 = func_0x00ffb68c(param_1,*(undefined8 *)(&UNK_00003de8 + param_1));
      plVar3 = plVar8 + 9;
      plVar4 = (long *)0x0;
      if (plVar8 != (long *)0x0) {
        plVar4 = plVar3;
      }
// WM - donate: donate/README.md
      lVar13 = *(long *)(&UNK_00003cf0 + param_1);
      pcStack_78 = "gp_offset";
      uStack_70 = 9;
      uStack_68 = 0;
      plVar7 = (long *)func_0x009d248c(lVar13,&pcStack_78);
      lVar22 = *plVar7;
      lVar14 = *(long *)(lVar22 + 8);
      if (lVar14 == 0) {
        plVar7 = *(long **)(lVar13 + 0xa0);
        if (plVar7 != (long *)0x0) {
          lVar14 = (**(code **)(*plVar7 + 0x10))(plVar7,"gp_offset",9);
          *(long *)(lVar22 + 8) = lVar14;
          if (lVar14 != 0) goto LAB_0100a340;
        }
        func_0x009d11e8(lVar13 + 0x18,0x18,8);
        lVar14 = func_0x01650b90();
        *(long *)(lVar22 + 8) = lVar14;
        *(long *)(lVar14 + 0x10) = lVar22;
// thanks for reading - discord.gg/sdkhDjTex
      }
LAB_0100a340:
      lVar14 = func_0x010766c8(param_1,plVar4,0,0,lVar14,uVar6,0,0,0);
      *(uint *)(lVar14 + 0x1c) = *(uint *)(lVar14 + 0x1c) & 0xffff9fff;
      func_0x01087d98(plVar3,lVar14);
      lVar13 = *(long *)(&UNK_00003cf0 + param_1);
      pcStack_78 = "fp_offset";
      uStack_70 = 9;
      uStack_68 = 0;
      plVar4 = (long *)func_0x009d248c(lVar13,&pcStack_78);
      lVar22 = *plVar4;
      lVar14 = *(long *)(lVar22 + 8);
      if (lVar14 == 0) {
        plVar4 = *(long **)(lVar13 + 0xa0);
        if (plVar4 != (long *)0x0) {
          lVar14 = (**(code **)(*plVar4 + 0x10))(plVar4,"fp_offset",9);
          *(long *)(lVar22 + 8) = lVar14;
          if (lVar14 != 0) goto LAB_0100a3fc;
        }
        func_0x009d11e8(lVar13 + 0x18,0x18,8);
        lVar14 = func_0x01650b90();
        *(long *)(lVar22 + 8) = lVar14;
        *(long *)(lVar14 + 0x10) = lVar22;
      }
LAB_0100a3fc:
      lVar14 = func_0x010766c8(param_1,plVar3,0,0,lVar14,uVar6,0,0,0);
      *(uint *)(lVar14 + 0x1c) = *(uint *)(lVar14 + 0x1c) & 0xffff9fff;
      func_0x01087d98(plVar3,lVar14);
      lVar13 = *(long *)(&UNK_00003cf0 + param_1);
      pcStack_78 = "overflow_arg_area";
      uStack_70 = 0x11;
      uStack_68 = 0;
      plVar4 = (long *)func_0x009d248c(lVar13,&pcStack_78);
      lVar22 = *plVar4;
      lVar14 = *(long *)(lVar22 + 8);
      if (lVar14 == 0) {
/* stripping the watermark breaks the license */
        plVar4 = *(long **)(lVar13 + 0xa0);
        if (plVar4 != (long *)0x0) {
          lVar14 = (**(code **)(*plVar4 + 0x10))(plVar4,"overflow_arg_area",0x11);
          *(long *)(lVar22 + 8) = lVar14;
          if (lVar14 != 0) goto LAB_0100a4b8;
        }
        func_0x009d11e8(lVar13 + 0x18,0x18,8);
        lVar14 = func_0x01650b90();
        *(long *)(lVar22 + 8) = lVar14;
        *(long *)(lVar14 + 0x10) = lVar22;
      }
LAB_0100a4b8:
      lVar14 = func_0x010766c8(param_1,plVar3,0,0,lVar14,uVar11,0,0,0);
      *(uint *)(lVar14 + 0x1c) = *(uint *)(lVar14 + 0x1c) & 0xffff9fff;
      func_0x01087d98(plVar3,lVar14);
      lVar13 = *(long *)(&UNK_00003cf0 + param_1);
      pcStack_78 = "reg_save_area";
      uStack_70 = 0xd;
      uStack_68 = 0;
      plVar4 = (long *)func_0x009d248c(lVar13,&pcStack_78);
      lVar22 = *plVar4;
      lVar14 = *(long *)(lVar22 + 8);
      if (lVar14 == 0) {
        plVar4 = *(long **)(lVar13 + 0xa0);
        if (plVar4 != (long *)0x0) {
          lVar14 = (**(code **)(*plVar4 + 0x10))(plVar4,"reg_save_area",0xd);
          *(long *)(lVar22 + 8) = lVar14;
          if (lVar14 != 0) goto LAB_0100a574;
        }
        func_0x009d11e8(lVar13 + 0x18,0x18,8);
        lVar14 = func_0x01650b90();
        *(long *)(lVar22 + 8) = lVar14;
        *(long *)(lVar14 + 0x10) = lVar22;
/*
 *  reversing this took months of machine time
 *
 *  @pengussy
 */
      }
LAB_0100a574:
      lVar14 = func_0x010766c8(param_1,plVar3,0,0,lVar14,uVar5,0,0,0);
      *(uint *)(lVar14 + 0x1c) = *(uint *)(lVar14 + 0x1c) & 0xffff9fff;
      func_0x01087d98(plVar3,lVar14);
      (**(code **)(*plVar8 + 0x68))(plVar8);
      uVar11 = func_0x01001f54(param_1,plVar8);
      *(undefined8 *)(&UNK_00003fd0 + param_1) = uVar11;
      lVar14 = func_0x00ff9134(param_1,uVar11,"__va_list_tag",0xd);
      uVar9 = *(ulong *)(lVar14 + 0x38);
      if (uVar9 == 0) {
        uVar18 = *(ulong *)((*(ulong *)(lVar14 + 0x58) & 0xfffffffffffffffc) +
                           (*(ulong *)(lVar14 + 0x58) & 2) * 4);
        uVar21 = *(ulong *)((uVar18 & 0xfffffffffffffff0) + 8);
        uVar9 = func_0x009d11e8(param_1 + 0x790,0x20,0x10);
        uVar1 = *(uint *)(*(long *)(uVar21 & 0xfffffffffffffff0) + 0x10);
        uVar15 = uVar9;
        if (0xf < uVar21) {
          uVar15 = uVar21 | uVar18 & 7;
        }
        *(ulong *)uVar9 = uVar9;
        *(ulong *)(uVar9 + 8) = uVar15;
        uVar17 = 0;
        if ((uVar1 & 0x300) != 0) {
          uVar17 = 0x200;
        }
/* WM: donate: donate/README.md @ discord.gg/sdkhDjTex */
        *(uint *)(uVar9 + 0x10) =
             uVar1 & 0x500 | *(uint *)(uVar9 + 0x10) & 0xfffc0000 | uVar17 | 0x12;
        *(long *)(uVar9 + 0x18) = lVar14;
        *(ulong *)(lVar14 + 0x38) = uVar9;
        puVar12 = *(ulong **)(param_1 + 0x10);
        if (*(ulong **)(param_1 + 0x18) <= puVar12) {
          func_0x01755374(param_1 + 8,param_1 + 0x20,0,8);
          puVar12 = *(ulong **)(param_1 + 0x10);
        }
        *puVar12 = uVar9;
        *(long *)(param_1 + 0x10) = *(long *)(param_1 + 0x10) + 8;
      }
      uVar1 = *(int *)(*(long *)(&UNK_00003bb8 + param_1) + 0xe8) - 1;
      if (9 < uVar1) {
LAB_0100bde0:
        func_0x0174ef58("Unhandled TargetInfo::IntType value",
                        "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/lib/AST/ASTContext.cpp"
                        ,&UNK_00001a15);
        goto LAB_0100bdf8;
      }
      uStack_80 = *(ulong *)(*(ulong *)(param_1 + *(long *)(&UNK_01be2dc8 + (ulong)uVar1 * 8)) &
                            0xfffffffffffffff0);
      lVar14 = *(long *)(param_1 + 0x418);
      uVar1 = *(uint *)(param_1 + 0x428);
      if (uVar1 == 0) {
LAB_0100b950:
        puVar12 = (ulong *)(lVar14 + (ulong)uVar1 * 0x18);
      }
      else {
        uVar17 = uVar1 - 1 & ((uint)(uStack_80 >> 4) & 0xfffffff ^ (uint)uStack_80 >> 9);
        puVar12 = (ulong *)(lVar14 + (ulong)uVar17 * 0x18);
        uVar15 = *puVar12;
        if (uStack_80 != uVar15) {
/*  watermarked copy - do not remove  */
          iVar2 = 1;
          do {
            if (uVar15 == 0xfffffffffffffff0) goto LAB_0100b950;
            uVar17 = uVar17 + iVar2 & uVar1 - 1;
            puVar12 = (ulong *)(lVar14 + (ulong)uVar17 * 0x18);
            uVar15 = *puVar12;
            iVar2 = iVar2 + 1;
          } while (uStack_80 != uVar15);
        }
      }
      if (puVar12 == (ulong *)(lVar14 + (ulong)uVar1 * 0x18)) {
        auVar39 = func_0x00ffc748(param_1);
        uVar15 = auVar39._0_8_;
        lVar14 = func_0x01015bec(param_1 + 0x410,&uStack_80);
        *(ulong *)(lVar14 + 8) = uVar15;
        *(char *)(lVar14 + 0x14) = auVar39[0xc];
        *(int *)(lVar14 + 0x10) = auVar39._8_4_;
        pcStack_78 = (char *)CONCAT44(pcStack_78._4_4_,auVar39._0_4_);
        if (auVar39._0_4_ < 0x41) goto LAB_0100b97c;
LAB_0100bab4:
        uStack_70 = 0;
        func_0x0173a0e4(&pcStack_78,uVar15,1,0);
        uVar15 = (ulong)pcStack_78 & 0xffffffff;
      }
      else {
        uVar15 = puVar12[1];
        pcStack_78 = (char *)CONCAT44(pcStack_78._4_4_,(uint)uVar15);
        if (0x40 < (uint)uVar15) goto LAB_0100bab4;
LAB_0100b97c:
        uStack_70 = 1;
      }
      if ((uVar15 & 0x3f) != 0) {
        uVar18 = 0xffffffffffffffff >> ((ulong)-((uint)uVar15 & 0x3f) & 0x3f);
/* WM: origin: github.com/pengussy @ discord.gg/sdkhDjTex */
        if ((uint)uVar15 < 0x41) {
          uStack_70 = uStack_70 & uVar18;
        }
        else {
          uVar1 = (int)((uVar15 & 0xffffffff) + 0x3f >> 6) - 1;
          *(ulong *)(uStack_70 + (ulong)uVar1 * 8) =
               *(ulong *)(uStack_70 + (ulong)uVar1 * 8) & uVar18;
        }
      }
      uVar11 = func_0x01000600(param_1,uVar9,&pcStack_78,0,0);
      uVar9 = func_0x00ff9134(param_1,uVar11,"__builtin_va_list",0x11);
    }
  }
  else {
    if (iVar2 == 6) {
      plVar3 = (long *)func_0x00ff9004(param_1,"__va_list",9,0);
      lVar14 = 0;
      if (*(long *)(param_1 + 0x768) != 0) {
        lVar14 = *(long *)(param_1 + 0x768) + 0x20;
/* +- WM -------------------------------------------------------------+
   |  origin: github.com/pengussy
   +--------------------------------------------------------------------*/
      }
      lVar22 = *(long *)(&UNK_00003cf0 + param_1);
      pcStack_78 = "std";
      uStack_70 = 3;
      uStack_68 = 0;
      plVar4 = (long *)func_0x009d248c(lVar22,&pcStack_78);
      lVar24 = *plVar4;
      lVar13 = *(long *)(lVar24 + 8);
      if (lVar13 == 0) {
        plVar4 = *(long **)(lVar22 + 0xa0);
        if (plVar4 != (long *)0x0) {
          lVar13 = (**(code **)(*plVar4 + 0x10))(plVar4,&UNK_01cb7946,3);
          *(long *)(lVar24 + 8) = lVar13;
          if (lVar13 != 0) goto LAB_0100b7c4;
        }
        func_0x009d11e8(lVar22 + 0x18,0x18,8);
        lVar13 = func_0x01650b90();
        *(long *)(lVar24 + 8) = lVar13;
        *(long *)(lVar13 + 0x10) = lVar24;
      }
LAB_0100b7c4:
      lVar13 = func_0x01090a5c(param_1,lVar14,0,0,0,lVar13,0);
      *(uint *)(lVar13 + 0x1c) = *(uint *)(lVar13 + 0x1c) | 0x400;
      lVar14 = 0;
      if (lVar13 != 0) {
        lVar14 = lVar13 + 0x38;
      }
      func_0x0040a9a8(plVar3,lVar14);
      func_0x01076b88(plVar3);
      lVar13 = *(long *)(&UNK_00003cf0 + param_1);
/*
   unlicensed copy if this notice is missing
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
      pcStack_78 = "__ap";
      uStack_70 = 4;
      uStack_68 = 0;
      plVar4 = (long *)func_0x009d248c(lVar13,&pcStack_78);
      lVar22 = *plVar4;
      lVar14 = *(long *)(lVar22 + 8);
      if (lVar14 == 0) {
        plVar4 = *(long **)(lVar13 + 0xa0);
        if (plVar4 != (long *)0x0) {
          lVar14 = (**(code **)(*plVar4 + 0x10))(plVar4,"__ap",4);
          *(long *)(lVar22 + 8) = lVar14;
          if (lVar14 != 0) goto LAB_0100b884;
        }
        lVar14 = func_0x009d11e8(lVar13 + 0x18,0x18,8);
        lVar13 = func_0x01650b90();
        *(long *)(lVar22 + 8) = lVar13;
        *(long *)(lVar13 + 0x10) = lVar22;
      }
LAB_0100b884:
      plVar4 = (long *)0x0;
      if (plVar3 != (long *)0x0) {
        plVar4 = plVar3 + 9;
      }
      uVar11 = func_0x00ffb68c(param_1,*(undefined8 *)(&UNK_00003de8 + param_1));
      lVar14 = func_0x010766c8(param_1,plVar4,0,0,lVar14,uVar11,0,0,0);
      *(uint *)(lVar14 + 0x1c) = *(uint *)(lVar14 + 0x1c) & 0xffff9fff;
      func_0x01087d98(plVar3 + 9,lVar14);
      (**(code **)(*plVar3 + 0x68))(plVar3);
/* wm:reversing this took months of machine time */
      uVar11 = func_0x01001f54(param_1,plVar3);
      goto LAB_0100b900;
    }
    if (iVar2 != 7) {
LAB_0100bdf8:
      puVar12 = (ulong *)&UNK_00001947;
      uVar11 = func_0x0174ef58("Unhandled __builtin_va_list type kind",
                               "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/lib/AST/ASTContext.cpp"
                              );
      if ((0x40 < (uint)pcStack_78) && (uStack_70 != 0)) {
        __ZdaPv();
      }
      auVar39 = __Unwind_Resume(uVar11);
      puVar16 = auVar39._8_8_;
      puVar10 = (ulong *)func_0x009d11e8(auVar39._0_8_ + 0x790,
                                         ((long)puVar12 - (long)puVar16 & 0x7fffffff8U) + 8,8);
      uVar9 = (long)puVar12 - (long)puVar16;
      *(uint *)puVar10 = (uint)(uVar9 >> 1) & 0xfffffffc;
      if (uVar9 != 0) {
/* +- WM -------------------------------------------------------------+
   |  proprietary - see LICENSE - do not sell
   +--------------------------------------------------------------------*/
        puVar19 = puVar10;
        if ((0x37 < uVar9 - 8) && (0x3f < (ulong)((long)puVar10 + (8 - (long)puVar16)))) {
          uVar9 = (uVar9 - 8 >> 3) + 1;
          uVar18 = uVar9 & 0x3ffffffffffffff8;
          puVar19 = puVar10 + 5;
          puVar20 = puVar16 + 4;
          uVar15 = uVar18;
          do {
            uVar21 = puVar20[-4];
            uVar29 = puVar20[-1];
            uVar27 = puVar20[-2];
            uVar33 = puVar20[1];
            uVar31 = *puVar20;
            uVar37 = puVar20[3];
            uVar35 = puVar20[2];
            uVar25 = uVar21 & 0xfffffffffffffffc;
            uVar26 = puVar20[-3] & 0xfffffffffffffffc;
            uVar28 = uVar27 & 0xfffffffffffffffc;
            uVar30 = uVar29 & 0xfffffffffffffffc;
            uVar32 = uVar31 & 0xfffffffffffffffc;
            uVar34 = uVar33 & 0xfffffffffffffffc;
            uVar36 = uVar35 & 0xfffffffffffffffc;
            uVar38 = uVar37 & 0xfffffffffffffffc;
            puVar19[-3] = CONCAT17((char)(uVar26 >> 0x38),
                                   CONCAT16((char)(uVar26 >> 0x30),
                                            CONCAT15((char)(uVar26 >> 0x28),
                                                     CONCAT14((char)(uVar26 >> 0x20),
                                                              CONCAT13((char)(uVar26 >> 0x18),
                                                                       CONCAT12((char)(uVar26 >>
                                                                                      0x10),
                                                                                CONCAT11((char)(
                                                  puVar20[-3] >> 8),(char)uVar26)))))));
            puVar19[-4] = CONCAT17((char)(uVar25 >> 0x38),
                                   CONCAT16((char)(uVar25 >> 0x30),
                                            CONCAT15((char)(uVar25 >> 0x28),
                                                     CONCAT14((char)(uVar25 >> 0x20),
/* +- WM -------------------------------------------------------------+
   |  chat: discord.gg/sdkhDjTex
   +--------------------------------------------------------------------*/
                                                              CONCAT13((char)(uVar25 >> 0x18),
                                                                       CONCAT12((char)(uVar25 >>
                                                                                      0x10),
                                                                                CONCAT11((char)(
                                                  uVar21 >> 8),(char)uVar25)))))));
            puVar19[-1] = CONCAT17((char)(uVar30 >> 0x38),
                                   CONCAT16((char)(uVar30 >> 0x30),
                                            CONCAT15((char)(uVar30 >> 0x28),
                                                     CONCAT14((char)(uVar30 >> 0x20),
                                                              CONCAT13((char)(uVar30 >> 0x18),
                                                                       CONCAT12((char)(uVar30 >>
                                                                                      0x10),
                                                                                CONCAT11((char)(
                                                  uVar29 >> 8),(char)uVar30)))))));
            puVar19[-2] = CONCAT17((char)(uVar28 >> 0x38),
                                   CONCAT16((char)(uVar28 >> 0x30),
                                            CONCAT15((char)(uVar28 >> 0x28),
                                                     CONCAT14((char)(uVar28 >> 0x20),
                                                              CONCAT13((char)(uVar28 >> 0x18),
                                                                       CONCAT12((char)(uVar28 >>
                                                                                      0x10),
                                                                                CONCAT11((char)(
                                                  uVar27 >> 8),(char)uVar28)))))));
            puVar19[1] = CONCAT17((char)(uVar34 >> 0x38),
                                  CONCAT16((char)(uVar34 >> 0x30),
                                           CONCAT15((char)(uVar34 >> 0x28),
                                                    CONCAT14((char)(uVar34 >> 0x20),
                                                             CONCAT13((char)(uVar34 >> 0x18),
                                                                      CONCAT12((char)(uVar34 >> 0x10
                                                                                     ),CONCAT11((
                                                  char)(uVar33 >> 8),(char)uVar34)))))));
// WM - proprietary - see LICENSE - do not sell
            *puVar19 = CONCAT17((char)(uVar32 >> 0x38),
                                CONCAT16((char)(uVar32 >> 0x30),
                                         CONCAT15((char)(uVar32 >> 0x28),
                                                  CONCAT14((char)(uVar32 >> 0x20),
                                                           CONCAT13((char)(uVar32 >> 0x18),
                                                                    CONCAT12((char)(uVar32 >> 0x10),
                                                                             CONCAT11((char)(uVar31 
                                                  >> 8),(char)uVar32)))))));
            puVar19[3] = CONCAT17((char)(uVar38 >> 0x38),
                                  CONCAT16((char)(uVar38 >> 0x30),
                                           CONCAT15((char)(uVar38 >> 0x28),
                                                    CONCAT14((char)(uVar38 >> 0x20),
                                                             CONCAT13((char)(uVar38 >> 0x18),
                                                                      CONCAT12((char)(uVar38 >> 0x10
                                                                                     ),CONCAT11((
                                                  char)(uVar37 >> 8),(char)uVar38)))))));
            puVar19[2] = CONCAT17((char)(uVar36 >> 0x38),
                                  CONCAT16((char)(uVar36 >> 0x30),
                                           CONCAT15((char)(uVar36 >> 0x28),
                                                    CONCAT14((char)(uVar36 >> 0x20),
                                                             CONCAT13((char)(uVar36 >> 0x18),
                                                                      CONCAT12((char)(uVar36 >> 0x10
                                                                                     ),CONCAT11((
                                                  char)(uVar35 >> 8),(char)uVar36)))))));
            uVar15 = uVar15 - 8;
            puVar19 = puVar19 + 8;
            puVar20 = puVar20 + 8;
          } while (uVar15 != 0);
          puVar16 = puVar16 + uVar18;
          puVar19 = puVar10 + uVar18;
          if (uVar9 == uVar18) goto code_r0x0100bebc;
        }
        do {
          puVar20 = puVar16 + 1;
          puVar19[1] = *puVar16 & 0xfffffffffffffffc;
          puVar16 = puVar20;
/*  unlicensed copy if this notice is missing  */
          puVar19 = puVar19 + 1;
        } while (puVar20 != puVar12);
      }
code_r0x0100bebc:
      return (ulong)puVar10 | 2;
    }
    plVar8 = (long *)func_0x00ff9004(param_1,"__va_list_tag",0xd,0);
    func_0x01076b88();
    uVar6 = *(undefined8 *)(&UNK_00003e40 + param_1);
    uVar11 = func_0x00ffb68c(param_1,*(undefined8 *)(&UNK_00003de8 + param_1));
    uVar5 = func_0x00ffb68c(param_1,*(undefined8 *)(&UNK_00003de8 + param_1));
    plVar3 = plVar8 + 9;
    plVar4 = (long *)0x0;
    if (plVar8 != (long *)0x0) {
      plVar4 = plVar3;
    }
    lVar13 = *(long *)(&UNK_00003cf0 + param_1);
    pcStack_78 = "__gpr";
    uStack_70 = 5;
    uStack_68 = 0;
    plVar7 = (long *)func_0x009d248c(lVar13,&pcStack_78);
    lVar22 = *plVar7;
    lVar14 = *(long *)(lVar22 + 8);
    if (lVar14 == 0) {
      plVar7 = *(long **)(lVar13 + 0xa0);
      if (plVar7 != (long *)0x0) {
        lVar14 = (**(code **)(*plVar7 + 0x10))(plVar7,"__gpr",5);
        *(long *)(lVar22 + 8) = lVar14;
        if (lVar14 != 0) goto LAB_0100a8a8;
      }
      func_0x009d11e8(lVar13 + 0x18,0x18,8);
      lVar14 = func_0x01650b90();
/*  keep the notice, keep the source honest  */
      *(long *)(lVar22 + 8) = lVar14;
      *(long *)(lVar14 + 0x10) = lVar22;
    }
LAB_0100a8a8:
    lVar14 = func_0x010766c8(param_1,plVar4,0,0,lVar14,uVar6,0,0,0);
    *(uint *)(lVar14 + 0x1c) = *(uint *)(lVar14 + 0x1c) & 0xffff9fff;
    func_0x01087d98(plVar3,lVar14);
    lVar13 = *(long *)(&UNK_00003cf0 + param_1);
    pcStack_78 = "__fpr";
    uStack_70 = 5;
    uStack_68 = 0;
    plVar4 = (long *)func_0x009d248c(lVar13,&pcStack_78);
    lVar22 = *plVar4;
    lVar14 = *(long *)(lVar22 + 8);
    if (lVar14 == 0) {
      plVar4 = *(long **)(lVar13 + 0xa0);
      if (plVar4 != (long *)0x0) {
        lVar14 = (**(code **)(*plVar4 + 0x10))(plVar4,"__fpr",5);
        *(long *)(lVar22 + 8) = lVar14;
        if (lVar14 != 0) goto LAB_0100a964;
      }
      func_0x009d11e8(lVar13 + 0x18,0x18,8);
      lVar14 = func_0x01650b90();
      *(long *)(lVar22 + 8) = lVar14;
/* WM: thanks for reading - discord.gg/sdkhDjTex @ discord.gg/sdkhDjTex */
      *(long *)(lVar14 + 0x10) = lVar22;
    }
LAB_0100a964:
    lVar14 = func_0x010766c8(param_1,plVar3,0,0,lVar14,uVar6,0,0,0);
    *(uint *)(lVar14 + 0x1c) = *(uint *)(lVar14 + 0x1c) & 0xffff9fff;
    func_0x01087d98(plVar3,lVar14);
    lVar13 = *(long *)(&UNK_00003cf0 + param_1);
    pcStack_78 = "__overflow_arg_area";
    uStack_70 = 0x13;
    uStack_68 = 0;
    plVar4 = (long *)func_0x009d248c(lVar13,&pcStack_78);
    lVar22 = *plVar4;
    lVar14 = *(long *)(lVar22 + 8);
    if (lVar14 == 0) {
      plVar4 = *(long **)(lVar13 + 0xa0);
      if (plVar4 != (long *)0x0) {
        lVar14 = (**(code **)(*plVar4 + 0x10))(plVar4,"__overflow_arg_area",0x13);
        *(long *)(lVar22 + 8) = lVar14;
        if (lVar14 != 0) goto LAB_0100aa20;
      }
      func_0x009d11e8(lVar13 + 0x18,0x18,8);
      lVar14 = func_0x01650b90();
      *(long *)(lVar22 + 8) = lVar14;
      *(long *)(lVar14 + 0x10) = lVar22;
    }
LAB_0100aa20:
    lVar14 = func_0x010766c8(param_1,plVar3,0,0,lVar14,uVar11,0,0,0);
    *(uint *)(lVar14 + 0x1c) = *(uint *)(lVar14 + 0x1c) & 0xffff9fff;
    func_0x01087d98(plVar3,lVar14);
    lVar13 = *(long *)(&UNK_00003cf0 + param_1);
    pcStack_78 = "__reg_save_area";
    uStack_70 = 0xf;
    uStack_68 = 0;
    plVar4 = (long *)func_0x009d248c(lVar13,&pcStack_78);
// watermarked copy - do not remove
    lVar22 = *plVar4;
    lVar14 = *(long *)(lVar22 + 8);
    if (lVar14 == 0) {
      plVar4 = *(long **)(lVar13 + 0xa0);
      if (plVar4 != (long *)0x0) {
        lVar14 = (**(code **)(*plVar4 + 0x10))(plVar4,"__reg_save_area",0xf);
        *(long *)(lVar22 + 8) = lVar14;
        if (lVar14 != 0) goto LAB_0100aadc;
      }
      func_0x009d11e8(lVar13 + 0x18,0x18,8);
      lVar14 = func_0x01650b90();
      *(long *)(lVar22 + 8) = lVar14;
      *(long *)(lVar14 + 0x10) = lVar22;
    }
LAB_0100aadc:
    lVar14 = func_0x010766c8(param_1,plVar3,0,0,lVar14,uVar5,0,0,0);
    *(uint *)(lVar14 + 0x1c) = *(uint *)(lVar14 + 0x1c) & 0xffff9fff;
    func_0x01087d98(plVar3,lVar14);
    (**(code **)(*plVar8 + 0x68))(plVar8);
    uVar11 = func_0x01001f54(param_1,plVar8);
    *(undefined8 *)(&UNK_00003fd0 + param_1) = uVar11;
    lVar14 = func_0x00ff9134(param_1,uVar11,"__va_list_tag",0xd);
    uVar9 = *(ulong *)(lVar14 + 0x38);
    if (uVar9 == 0) {
// donate: donate/README.md
      uVar18 = *(ulong *)((*(ulong *)(lVar14 + 0x58) & 0xfffffffffffffffc) +
                         (*(ulong *)(lVar14 + 0x58) & 2) * 4);
      uVar21 = *(ulong *)((uVar18 & 0xfffffffffffffff0) + 8);
      uVar9 = func_0x009d11e8(param_1 + 0x790,0x20,0x10);
      uVar1 = *(uint *)(*(long *)(uVar21 & 0xfffffffffffffff0) + 0x10);
      uVar15 = uVar9;
      if (0xf < uVar21) {
        uVar15 = uVar21 | uVar18 & 7;
      }
      *(ulong *)uVar9 = uVar9;
      *(ulong *)(uVar9 + 8) = uVar15;
      uVar17 = 0;
      if ((uVar1 & 0x300) != 0) {
        uVar17 = 0x200;
      }
      *(uint *)(uVar9 + 0x10) = uVar1 & 0x500 | *(uint *)(uVar9 + 0x10) & 0xfffc0000 | uVar17 | 0x12
      ;
      *(long *)(uVar9 + 0x18) = lVar14;
      *(ulong *)(lVar14 + 0x38) = uVar9;
      puVar12 = *(ulong **)(param_1 + 0x10);
      if (*(ulong **)(param_1 + 0x18) <= puVar12) {
        func_0x01755374(param_1 + 8,param_1 + 0x20,0,8);
        puVar12 = *(ulong **)(param_1 + 0x10);
      }
      *puVar12 = uVar9;
      *(long *)(param_1 + 0x10) = *(long *)(param_1 + 0x10) + 8;
/*
 *  proprietary - see LICENSE - do not sell
 *
 *  @pengussy
 */
    }
    uVar1 = *(int *)(*(long *)(&UNK_00003bb8 + param_1) + 0xe8) - 1;
    if (9 < uVar1) goto LAB_0100bde0;
    uStack_80 = *(ulong *)(*(ulong *)(param_1 + *(long *)(&UNK_01be2dc8 + (ulong)uVar1 * 8)) &
                          0xfffffffffffffff0);
    lVar14 = *(long *)(param_1 + 0x418);
    uVar1 = *(uint *)(param_1 + 0x428);
    if (uVar1 == 0) {
LAB_0100b9c0:
      puVar12 = (ulong *)(lVar14 + (ulong)uVar1 * 0x18);
    }
    else {
      uVar17 = uVar1 - 1 & ((uint)(uStack_80 >> 4) & 0xfffffff ^ (uint)uStack_80 >> 9);
      puVar12 = (ulong *)(lVar14 + (ulong)uVar17 * 0x18);
      uVar15 = *puVar12;
      if (uStack_80 != uVar15) {
        iVar2 = 1;
        do {
          if (uVar15 == 0xfffffffffffffff0) goto LAB_0100b9c0;
          uVar17 = uVar17 + iVar2 & uVar1 - 1;
          puVar12 = (ulong *)(lVar14 + (ulong)uVar17 * 0x18);
          uVar15 = *puVar12;
          iVar2 = iVar2 + 1;
        } while (uStack_80 != uVar15);
      }
    }
    if (puVar12 == (ulong *)(lVar14 + (ulong)uVar1 * 0x18)) {
      auVar39 = func_0x00ffc748(param_1);
/* +- WM -------------------------------------------------------------+
   |  if you paid for this, you were scammed
   +--------------------------------------------------------------------*/
      uVar15 = auVar39._0_8_;
      lVar14 = func_0x01015bec(param_1 + 0x410,&uStack_80);
      *(ulong *)(lVar14 + 8) = uVar15;
      *(char *)(lVar14 + 0x14) = auVar39[0xc];
      *(int *)(lVar14 + 0x10) = auVar39._8_4_;
      pcStack_78 = (char *)CONCAT44(pcStack_78._4_4_,auVar39._0_4_);
      if (auVar39._0_4_ < 0x41) goto LAB_0100b9ec;
LAB_0100bbb4:
      uStack_70 = 0;
      func_0x0173a0e4(&pcStack_78,uVar15,1,0);
      uVar15 = (ulong)pcStack_78 & 0xffffffff;
    }
    else {
      uVar15 = puVar12[1];
      pcStack_78 = (char *)CONCAT44(pcStack_78._4_4_,(uint)uVar15);
      if (0x40 < (uint)uVar15) goto LAB_0100bbb4;
LAB_0100b9ec:
      uStack_70 = 1;
    }
    if ((uVar15 & 0x3f) != 0) {
      uVar18 = 0xffffffffffffffff >> ((ulong)-((uint)uVar15 & 0x3f) & 0x3f);
      if ((uint)uVar15 < 0x41) {
        uStack_70 = uStack_70 & uVar18;
      }
      else {
        uVar1 = (int)((uVar15 & 0xffffffff) + 0x3f >> 6) - 1;
        *(ulong *)(uStack_70 + (ulong)uVar1 * 8) = *(ulong *)(uStack_70 + (ulong)uVar1 * 8) & uVar18
/*  thanks for reading - discord.gg/sdkhDjTex  */
        ;
      }
    }
    uVar11 = func_0x01000600(param_1,uVar9,&pcStack_78,0,0);
    uVar9 = func_0x00ff9134(param_1,uVar11,"__builtin_va_list",0x11);
  }
LAB_0100bd44:
  if ((0x40 < (uint)pcStack_78) && (uStack_70 != 0)) {
    __ZdaPv(uStack_70);
  }
LAB_0100bd68:
  *(ulong *)(param_1 + 0x520) = uVar9;
  return uVar9;
}

