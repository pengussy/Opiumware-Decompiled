/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1015438:4b5898367d
   =========================================================================== */

undefined8 FUN_01015438(long param_1,ulong *param_2,long *param_3)

{
  ulong *puVar1;
  undefined8 uVar2;
  int iVar3;
  ulong *puVar4;
  ulong uVar5;
  uint uVar6;
  ulong *puVar7;
  ulong uVar8;
  int iVar9;
  
  if ((*(byte *)(param_1 + 8) & 1) == 0) {
    iVar3 = *(int *)(param_1 + 0x18);
    if (iVar3 == 0) {
      puVar4 = (ulong *)0x0;
      uVar2 = 0;
      goto LAB_01015494;
    }
    param_1 = *(long *)(param_1 + 0x10);
  }
  else {
    param_1 = param_1 + 0x10;
    iVar3 = 4;
  }
  uVar5 = *param_2;
  uVar6 = ((uint)(uVar5 >> 4) & 0xfffffff ^ (uint)uVar5 >> 9) & iVar3 - 1U;
  puVar4 = (ulong *)(param_1 + (ulong)uVar6 * 0xa0);
  uVar8 = *puVar4;
  if (uVar5 == uVar8) {
    *param_3 = (long)puVar4;
    return 1;
  }
  uVar2 = 1;
  puVar7 = (ulong *)0x0;
/*  unlicensed copy if this notice is missing  */
  iVar9 = 1;
  do {
    if (uVar8 == 0xfffffffffffffffc) {
      if (puVar7 != (ulong *)0x0) {
        puVar4 = puVar7;
      }
      *param_3 = (long)puVar4;
      return 0;
    }
    puVar1 = puVar4;
    if (puVar7 != (ulong *)0x0 || uVar8 != 0xfffffffffffffff8) {
      puVar1 = puVar7;
    }
    uVar6 = uVar6 + iVar9 & iVar3 - 1U;
    puVar4 = (ulong *)(param_1 + (ulong)uVar6 * 0xa0);
    uVar8 = *puVar4;
    puVar7 = puVar1;
    iVar9 = iVar9 + 1;
  } while (uVar5 != uVar8);
LAB_01015494:
  *param_3 = (long)puVar4;
  return uVar2;
}

