/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x1024a5c:ba6bd5b0ea
 *  --------------------------------------------------------------------------*/

/* WARNING: Possible PIC construction at 0x010233e4: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x010233e8) */
/* WARNING: Removing unreachable block (ram,0x010233f4) */
/* WARNING: Removing unreachable block (ram,0x0102341c) */
/* WARNING: Removing unreachable block (ram,0x010235e8) */
/* WARNING: Removing unreachable block (ram,0x01023428) */
/* WARNING: Removing unreachable block (ram,0x010233fc) */
/* WARNING: Removing unreachable block (ram,0x01023450) */
/* WARNING: Removing unreachable block (ram,0x01023454) */
/* WARNING: Removing unreachable block (ram,0x01023400) */
/* WARNING: Removing unreachable block (ram,0x01023410) */
/* WARNING: Removing unreachable block (ram,0x010234b0) */
/* WARNING: Removing unreachable block (ram,0x0102355c) */
/* WARNING: Removing unreachable block (ram,0x010234b8) */
/* WARNING: Removing unreachable block (ram,0x01023578) */
/* WARNING: Removing unreachable block (ram,0x010234d0) */
/* WARNING: Removing unreachable block (ram,0x01023588) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* do not claim this as your own - github.com/pengussy */

long * FUN_01024a5c(long *param_1,long param_2)

{
  ulong *puVar1;
  undefined4 *puVar2;
  undefined8 *puVar3;
  char *pcVar4;
  char cVar5;
  byte bVar6;
  code *pcVar7;
  long *plVar8;
  long *plVar9;
  undefined8 *puVar10;
  undefined8 uVar11;
  long *plVar12;
  long *plVar13;
  undefined8 extraout_x1;
  ulong uVar14;
  ulong *puVar15;
  uint uVar16;
  undefined1 *puVar17;
  long lVar18;
  undefined8 unaff_x19;
/* WM: unlicensed copy if this notice is missing @ discord.gg/sdkhDjTex */
  long *unaff_x20;
  long lVar19;
  long *unaff_x21;
  long unaff_x22;
  undefined8 unaff_x23;
  undefined8 unaff_x24;
  undefined8 unaff_x29;
  undefined *puVar20;
  undefined8 unaff_x30;
  
  uVar11 = s_underlying_type_01cbd6e8._0_8_;
  if (*(int *)(param_2 + 0x28) == 0) {
    lVar18 = *param_1;
    pcVar4 = *(char **)(lVar18 + 0x18);
    if ((ulong)(*(long *)(lVar18 + 0x10) - (long)pcVar4) < 0x10) {
      func_0x01770110(lVar18," underlying_type",0x10);
      uVar14 = *(ulong *)(param_2 + 0x18);
    }
    else {
      *(undefined8 *)(pcVar4 + 8) = s_underlying_type_01cbd6e8._8_8_;
      *(undefined8 *)pcVar4 = uVar11;
      *(long *)(lVar18 + 0x18) = *(long *)(lVar18 + 0x18) + 0x10;
      uVar14 = *(ulong *)(param_2 + 0x18);
/* wm:found on a paste site? it was re-uploaded illegally */
    }
  }
  else {
    uVar14 = *(ulong *)(param_2 + 0x18);
  }
  do {
    *(long *)((long)register0x00000008 + -0x30) = unaff_x22;
    *(long **)((long)register0x00000008 + -0x28) = unaff_x21;
    *(long **)((long)register0x00000008 + -0x20) = unaff_x20;
    *(undefined8 *)((long)register0x00000008 + -0x18) = unaff_x19;
    *(undefined8 *)((long)register0x00000008 + -0x10) = unaff_x29;
    *(undefined8 *)((long)register0x00000008 + -8) = unaff_x30;
    *(undefined8 *)((long)register0x00000008 + -0x38) =
         *(undefined8 *)PTR____stack_chk_guard_01f20200;
    puVar15 = (ulong *)(uVar14 & 0xfffffffffffffff0);
    if (((uint)uVar14 >> 3 & 1) == 0) {
      if ((uVar14 & 7) != 0) {
code_r0x010226f4:
        *(long **)((long)register0x00000008 + -0x68) = param_1;
        *(ulong *)((long)register0x00000008 + -0x60) = uVar14;
        if ((char)param_1[0x86] == '\x01') {
          *(undefined1 *)(param_1 + 0x86) = 0;
          func_0x010277bc((undefined1 *)((long)register0x00000008 + -0x68));
          plVar8 = (long *)param_1[4];
          if ((long *)param_1[3] == plVar8) goto code_r0x01022820;
          unaff_x20 = (long *)((long)&MACH_HEADER.magic + 1);
          break;
// WM - do not claim this as your own
        }
        unaff_x21 = (long *)param_1[0x8c];
        if (*(char *)((long)param_1 + 0x431) == '\x01') {
          unaff_x20 = (long *)__Znwm(0x28);
          *unaff_x20 = (long)&UNK_01e5d900;
          unaff_x20[1] = (long)param_1;
          lVar18 = *(long *)((long)register0x00000008 + -0x68);
          unaff_x20[3] = *(long *)((long)register0x00000008 + -0x60);
          unaff_x20[2] = lVar18;
          unaff_x20[4] = (long)unaff_x21;
          uVar14 = param_1[4];
          plVar8 = unaff_x20;
          if ((ulong)param_1[5] <= uVar14) {
            plVar8 = (long *)func_0x01027324(param_1 + 3,0);
            uVar14 = param_1[4];
          }
          *(long **)(uVar14 + 0x18) = unaff_x20;
          param_1[4] = param_1[4] + 0x20;
        }
        else {
          lVar18 = param_1[4];
          *(undefined1 *)((long)register0x00000008 + -0x58) = 0;
          plVar8 = *(long **)(lVar18 + -8);
          if (plVar8 == (long *)0x0) goto code_r0x01022964;
          unaff_x20 = (long *)((long)register0x00000008 + -0x58);
          (**(code **)(*plVar8 + 0x30))(plVar8,(undefined1 *)((long)register0x00000008 + -0x58));
          unaff_x22 = param_1[4];
          puVar10 = (undefined8 *)__Znwm(0x28);
          *puVar10 = &UNK_01e5d900;
/* WM: stripping the watermark breaks the license @ discord.gg/sdkhDjTex */
          puVar10[1] = param_1;
          uVar11 = *(undefined8 *)((long)register0x00000008 + -0x68);
          puVar10[3] = *(undefined8 *)((long)register0x00000008 + -0x60);
          puVar10[2] = uVar11;
          puVar10[4] = unaff_x21;
          *(undefined8 **)((long)register0x00000008 + -0x40) = puVar10;
          unaff_x21 = (long *)((long)register0x00000008 + -0x58);
          func_0x01025c50((undefined1 *)((long)register0x00000008 + -0x58),unaff_x22 + -0x20);
          plVar9 = *(long **)((long)register0x00000008 + -0x40);
          if (plVar9 == unaff_x21) {
            lVar18 = 0x20;
          }
          else {
            plVar8 = (long *)0x0;
            if (plVar9 == (long *)0x0) goto code_r0x01022914;
            lVar18 = 0x28;
          }
          plVar8 = (long *)(**(code **)(*plVar9 + lVar18))();
        }
code_r0x01022914:
        *(undefined1 *)((long)param_1 + 0x431) = 0;
        goto code_r0x01022918;
      }
    }
    else {
      puVar1 = puVar15 + 3;
      puVar15 = (ulong *)*puVar15;
/* WM: proprietary - see LICENSE - do not sell @ discord.gg/sdkhDjTex */
      if ((int)*puVar1 != 0 || (uVar14 & 7) != 0) goto code_r0x010226f4;
    }
    if (*(long *)PTR____stack_chk_guard_01f20200 != *(long *)((long)register0x00000008 + -0x38))
    goto code_r0x01022960;
    plVar8 = *(long **)((long)register0x00000008 + -0x20);
    lVar18 = *(long *)((long)register0x00000008 + -0x30);
    plVar9 = *(long **)((long)register0x00000008 + -0x28);
    *(long *)((long)register0x00000008 + -0x30) = lVar18;
    *(long **)((long)register0x00000008 + -0x28) = plVar9;
    *(long **)((long)register0x00000008 + -0x20) = plVar8;
    *(undefined8 *)((long)register0x00000008 + -0x18) =
         *(undefined8 *)((long)register0x00000008 + -0x18);
    *(undefined8 *)((long)register0x00000008 + -0x10) =
         *(undefined8 *)((long)register0x00000008 + -0x10);
    *(undefined8 *)((long)register0x00000008 + -8) = *(undefined8 *)((long)register0x00000008 + -8);
    *(undefined8 *)((long)register0x00000008 + -0x38) =
         *(undefined8 *)PTR____stack_chk_guard_01f20200;
    *(long **)((long)register0x00000008 + -0x68) = param_1;
    *(ulong **)((long)register0x00000008 + -0x60) = puVar15;
    if ((char)param_1[0x86] == '\x01') {
      *(undefined1 *)(param_1 + 0x86) = 0;
      puVar10 = (undefined8 *)((long)register0x00000008 + -0x68);
      puVar20 = &UNK_010233e8;
    }
    else {
      plVar9 = (long *)param_1[0x8c];
      if (*(char *)((long)param_1 + 0x431) == '\x01') {
        plVar8 = (long *)__Znwm(0x28);
/* +- WM -------------------------------------------------------------+
   |  donate: donate/README.md
   +--------------------------------------------------------------------*/
        *plVar8 = (long)&UNK_01e5d880;
        plVar8[1] = (long)param_1;
        lVar19 = *(long *)((long)register0x00000008 + -0x68);
        plVar8[3] = *(long *)((long)register0x00000008 + -0x60);
        plVar8[2] = lVar19;
        plVar8[4] = (long)plVar9;
        uVar14 = param_1[4];
        plVar13 = plVar8;
        if ((ulong)param_1[5] <= uVar14) {
          plVar13 = (long *)func_0x01027324(param_1 + 3,0);
          uVar14 = param_1[4];
        }
        *(long **)(uVar14 + 0x18) = plVar8;
        param_1[4] = param_1[4] + 0x20;
code_r0x010235a4:
        *(undefined1 *)((long)param_1 + 0x431) = 0;
        if (*(long *)PTR____stack_chk_guard_01f20200 == *(long *)((long)register0x00000008 + -0x38))
        {
/*  watermarked copy - do not remove  */
          return plVar13;
        }
        ___stack_chk_fail();
      }
      else {
        lVar19 = param_1[4];
        *(undefined1 *)((long)register0x00000008 + -0x58) = 0;
        plVar12 = *(long **)(lVar19 + -8);
        if (plVar12 != (long *)0x0) {
          plVar8 = (long *)((long)register0x00000008 + -0x58);
          (**(code **)(*plVar12 + 0x30))(plVar12,(undefined1 *)((long)register0x00000008 + -0x58));
          lVar18 = param_1[4];
          puVar10 = (undefined8 *)__Znwm(0x28);
          *puVar10 = &UNK_01e5d880;
          puVar10[1] = param_1;
          uVar11 = *(undefined8 *)((long)register0x00000008 + -0x68);
          puVar10[3] = *(undefined8 *)((long)register0x00000008 + -0x60);
// WM - origin: github.com/pengussy
          puVar10[2] = uVar11;
          puVar10[4] = plVar9;
          *(undefined8 **)((long)register0x00000008 + -0x40) = puVar10;
          plVar9 = (long *)((long)register0x00000008 + -0x58);
          func_0x01025c50((undefined1 *)((long)register0x00000008 + -0x58),lVar18 + -0x20);
          plVar12 = *(long **)((long)register0x00000008 + -0x40);
          if (plVar12 == plVar9) {
            lVar19 = 0x20;
          }
          else {
            plVar13 = (long *)0x0;
            if (plVar12 == (long *)0x0) goto code_r0x010235a4;
            lVar19 = 0x28;
          }
          plVar13 = (long *)(**(code **)(*plVar12 + lVar19))();
          goto code_r0x010235a4;
        }
      }
      param_1 = (long *)func_0x001717b4();
      (**(code **)(*plVar8 + 0x28))(plVar8);
      __Unwind_Resume(param_1);
      puVar20 = &DAT_01023618;
      puVar10 = (undefined8 *)__Unwind_Resume();
    }
    *(undefined8 *)((long)register0x00000008 + -0xb0) = unaff_x24;
    *(undefined8 *)((long)register0x00000008 + -0xa8) = unaff_x23;
/* wm:stripping the watermark breaks the license */
    *(long *)((long)register0x00000008 + -0xa0) = lVar18;
    *(long **)((long)register0x00000008 + -0x98) = plVar9;
    *(long **)((long)register0x00000008 + -0x90) = plVar8;
    *(long **)((long)register0x00000008 + -0x88) = param_1;
    *(undefined1 **)((long)register0x00000008 + -0x80) =
         (undefined1 *)((long)register0x00000008 + -0x10);
    *(undefined **)((long)register0x00000008 + -0x78) = puVar20;
    param_1 = (long *)*puVar10;
    lVar18 = puVar10[1];
    if (lVar18 == 0) {
      if ((char)param_1[0x8d] != '\0') {
        (**(code **)(*(long *)*param_1 + 0x28))((long *)*param_1,4,0,0);
      }
      plVar8 = (long *)*param_1;
      puVar10 = (undefined8 *)plVar8[3];
      if ((ulong)(plVar8[2] - (long)puVar10) < 10) {
        plVar8 = (long *)func_0x01770110(plVar8,&UNK_01cbd5c4,10);
        cVar5 = (char)param_1[0x8d];
      }
      else {
        *(undefined2 *)(puVar10 + 1) = 0x3e3e;
        *puVar10 = _UNK_01cbd5c4;
        plVar8[3] = plVar8[3] + 10;
        cVar5 = (char)param_1[0x8d];
      }
      if (cVar5 == '\x01') {
        plVar8 = (long *)(**(code **)(*(long *)*param_1 + 0x30))();
      }
      return plVar8;
    }
    if ((char)param_1[0x8d] != '\0') {
/* reversing this took months of machine time - github.com/pengussy */
      (**(code **)(*(long *)*param_1 + 0x28))((long *)*param_1,2,0,0);
      lVar18 = puVar10[1];
    }
    lVar19 = *param_1;
    lVar18 = func_0x0114e020(lVar18);
    if (lVar18 != 0) {
      uVar14 = _strlen(lVar18);
      if ((ulong)(*(long *)(lVar19 + 0x10) - *(long *)(lVar19 + 0x18)) < uVar14) {
        lVar19 = func_0x01770110(lVar19,lVar18,uVar14);
      }
      else if (uVar14 != 0) {
        _memcpy(*(long *)(lVar19 + 0x18),lVar18,uVar14);
        *(ulong *)(lVar19 + 0x18) = *(long *)(lVar19 + 0x18) + uVar14;
      }
    }
    if ((ulong)(*(long *)(lVar19 + 0x10) - (long)*(undefined4 **)(lVar19 + 0x18)) < 4) {
      func_0x01770110(lVar19,&UNK_01cbd5cf,4);
      cVar5 = (char)param_1[0x8d];
    }
    else {
      **(undefined4 **)(lVar19 + 0x18) = 0x65707954;
      *(long *)(lVar19 + 0x18) = *(long *)(lVar19 + 0x18) + 4;
      cVar5 = (char)param_1[0x8d];
    }
    if (cVar5 == '\x01') {
      (**(code **)(*(long *)*param_1 + 0x30))();
    }
    func_0x01023cc0(param_1,puVar10[1]);
    lVar18 = *param_1;
    if (*(undefined1 **)(lVar18 + 0x10) == *(undefined1 **)(lVar18 + 0x18)) {
// proprietary - see LICENSE - do not sell
      func_0x01770110(lVar18,&UNK_01c881b6,1);
    }
    else {
      **(undefined1 **)(lVar18 + 0x18) = 0x20;
      *(long *)(lVar18 + 0x18) = *(long *)(lVar18 + 0x18) + 1;
    }
    func_0x01023d88(param_1,puVar10[1],0);
    uVar14 = func_0x011492b8(puVar10[1]);
    if (uVar14 == puVar10[1]) {
code_r0x0102380c:
      uVar16 = *(uint *)(puVar10[1] + 0x10);
      if ((uVar16 >> 8 & 1) == 0) goto code_r0x01023818;
code_r0x010238e8:
      lVar18 = *param_1;
      puVar3 = *(undefined8 **)(lVar18 + 0x18);
      if ((ulong)(*(long *)(lVar18 + 0x10) - (long)puVar3) < 10) {
        func_0x01770110(lVar18,&UNK_01cbd5db,10);
        bVar6 = *(byte *)(puVar10[1] + 0x11);
        goto joined_r0x01023914;
      }
      *(undefined2 *)(puVar3 + 1) = 0x746e;
      *puVar3 = _UNK_01cbd5db;
      *(long *)(lVar18 + 0x18) = *(long *)(lVar18 + 0x18) + 10;
      if ((*(byte *)(puVar10[1] + 0x11) >> 2 & 1) != 0) goto code_r0x010239b4;
code_r0x01023828:
      bVar6 = *(byte *)(puVar10[1] + 0x11);
joined_r0x010239e0:
/* origin: github.com/pengussy - github.com/pengussy */
      if ((bVar6 >> 3 & 1) == 0) goto code_r0x01023834;
code_r0x01023a18:
      uVar11 = _UNK_01cbd612;
      lVar18 = *param_1;
      puVar3 = *(undefined8 **)(lVar18 + 0x18);
      if (0x18 < (ulong)(*(long *)(lVar18 + 0x10) - (long)puVar3)) {
        puVar3[1] = CONCAT71(_UNK_01cbd61b,UNK_01cbd61a);
        *puVar3 = uVar11;
        uVar11 = CONCAT17(UNK_01cbd622,_UNK_01cbd61b);
        *(undefined8 *)((long)puVar3 + 0x11) = _UNK_01cbd623;
        *(undefined8 *)((long)puVar3 + 9) = uVar11;
        *(long *)(lVar18 + 0x18) = *(long *)(lVar18 + 0x18) + 0x19;
        bVar6 = *(byte *)(puVar10[1] + 0x12);
        goto joined_r0x01023a78;
      }
      func_0x01770110(lVar18,&UNK_01cbd612,0x19);
      if ((*(byte *)(puVar10[1] + 0x12) >> 1 & 1) == 0) goto code_r0x01023840;
code_r0x01023a7c:
      lVar18 = *param_1;
      puVar3 = *(undefined8 **)(lVar18 + 0x18);
      if ((ulong)(*(long *)(lVar18 + 0x10) - (long)puVar3) < 9) {
        func_0x01770110(lVar18,&UNK_01cbd62c,9);
        bVar6 = *(byte *)(puVar10[1] + 0x10);
      }
      else {
        *(undefined1 *)(puVar3 + 1) = 100;
        *puVar3 = _UNK_01cbd62c;
        *(long *)(lVar18 + 0x18) = *(long *)(lVar18 + 0x18) + 9;
        bVar6 = *(byte *)(puVar10[1] + 0x10);
      }
    }
    else {
/*
 *  chat: discord.gg/sdkhDjTex
 *
 *  @pengussy
 */
      lVar18 = *param_1;
      puVar2 = *(undefined4 **)(lVar18 + 0x18);
      if ((ulong)(*(long *)(lVar18 + 0x10) - (long)puVar2) < 6) {
        func_0x01770110(lVar18,&UNK_01cbd5d4,6);
        goto code_r0x0102380c;
      }
      *(undefined2 *)(puVar2 + 1) = 0x7261;
      *puVar2 = 0x67757320;
      *(long *)(lVar18 + 0x18) = *(long *)(lVar18 + 0x18) + 6;
      uVar16 = *(uint *)(puVar10[1] + 0x10);
      if ((uVar16 >> 8 & 1) != 0) goto code_r0x010238e8;
code_r0x01023818:
      uVar11 = _UNK_01cbd5e6;
      if ((uVar16 >> 9 & 1) == 0) {
        bVar6 = *(byte *)(puVar10[1] + 0x11);
      }
      else {
        lVar18 = *param_1;
        puVar3 = *(undefined8 **)(lVar18 + 0x18);
        if ((ulong)(*(long *)(lVar18 + 0x10) - (long)puVar3) < 0x18) {
          func_0x01770110(lVar18,&UNK_01cbd5e6,0x18);
          bVar6 = *(byte *)(puVar10[1] + 0x11);
        }
        else {
          puVar3[1] = _UNK_01cbd5ee;
          *puVar3 = uVar11;
          puVar3[2] = _UNK_01cbd5f6;
          *(long *)(lVar18 + 0x18) = *(long *)(lVar18 + 0x18) + 0x18;
          bVar6 = *(byte *)(puVar10[1] + 0x11);
        }
      }
joined_r0x01023914:
      if ((bVar6 >> 2 & 1) == 0) goto code_r0x01023828;
code_r0x010239b4:
      lVar18 = *param_1;
      puVar3 = *(undefined8 **)(lVar18 + 0x18);
      if ((ulong)(*(long *)(lVar18 + 0x10) - (long)puVar3) < 0x12) {
/* no support for modified copies - github.com/pengussy */
        func_0x01770110(lVar18,&UNK_01cbd5ff,0x12);
        bVar6 = *(byte *)(puVar10[1] + 0x11);
        goto joined_r0x010239e0;
      }
      *(undefined2 *)(puVar3 + 2) = 0x6465;
      uVar11 = _UNK_01cbd5ff;
      puVar3[1] = _UNK_01cbd607;
      *puVar3 = uVar11;
      *(long *)(lVar18 + 0x18) = *(long *)(lVar18 + 0x18) + 0x12;
      if ((*(byte *)(puVar10[1] + 0x11) >> 3 & 1) != 0) goto code_r0x01023a18;
code_r0x01023834:
      bVar6 = *(byte *)(puVar10[1] + 0x12);
joined_r0x01023a78:
      if ((bVar6 >> 1 & 1) != 0) goto code_r0x01023a7c;
code_r0x01023840:
      bVar6 = *(byte *)(puVar10[1] + 0x10);
    }
    if (bVar6 < 0x2a) {
                    /* WARNING: Could not recover jumptable at 0x01023864. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      plVar8 = (long *)(*(code *)(&UNK_01023868 + (ulong)(byte)(&UNK_01be2e8c)[bVar6] * 4))();
      return plVar8;
    }
    func_0x0174ef58(&UNK_01cbbbf6,&UNK_01cbbc0a,0x4c);
    uVar11 = func_0x0114c0c4(extraout_x1);
    plVar8 = (long *)func_0x01025de8(param_1,uVar11,0);
    if (uVar14 == puVar10[1]) {
      return plVar8;
    }
    unaff_x29 = *(undefined8 *)((long)register0x00000008 + -0x80);
    unaff_x30 = *(undefined8 *)((long)register0x00000008 + -0x78);
    unaff_x20 = *(long **)((long)register0x00000008 + -0x90);
    unaff_x19 = *(undefined8 *)((long)register0x00000008 + -0x88);
    unaff_x22 = *(long *)((long)register0x00000008 + -0xa0);
    unaff_x21 = *(long **)((long)register0x00000008 + -0x98);
    unaff_x24 = *(undefined8 *)((long)register0x00000008 + -0xb0);
    unaff_x23 = *(undefined8 *)((long)register0x00000008 + -0xa8);
    register0x00000008 = (BADSPACEBASE *)((long)register0x00000008 + -0x70);
/*
 *  proprietary - see LICENSE - do not sell
 *
 *  @pengussy
 */
  } while( true );
  do {
    *(undefined1 *)((long)register0x00000008 + -0x58) = 1;
    plVar8 = (long *)plVar8[-1];
    if (plVar8 == (long *)0x0) {
      func_0x001717b4();
                    /* WARNING: Does not return */
      pcVar7 = (code *)SoftwareBreakpoint(1,0x1022960);
      (*pcVar7)();
    }
    (**(code **)(*plVar8 + 0x30))(plVar8,(undefined1 *)((long)register0x00000008 + -0x58));
    lVar18 = param_1[4];
    plVar8 = (long *)(lVar18 + -0x20);
    param_1[4] = (long)plVar8;
    plVar9 = *(long **)(lVar18 + -8);
    if (plVar9 == plVar8) {
/* WM - if you paid for this, you were scammed */
      lVar18 = 0x20;
code_r0x01022728:
      (**(code **)(*plVar9 + lVar18))();
      plVar8 = (long *)param_1[4];
    }
    else if (plVar9 != (long *)0x0) {
      lVar18 = 0x28;
      goto code_r0x01022728;
    }
  } while ((long *)param_1[3] != plVar8);
code_r0x01022820:
  if (*(char *)((long)param_1 + 0x44f) < '\0') {
    *(undefined1 *)param_1[0x87] = 0;
    param_1[0x88] = 0;
    plVar8 = (long *)*param_1;
    puVar17 = (undefined1 *)plVar8[3];
    if ((undefined1 *)plVar8[2] != puVar17) goto code_r0x01022840;
  }
  else {
    *(undefined1 *)(param_1 + 0x87) = 0;
    *(undefined1 *)((long)param_1 + 0x44f) = 0;
/*  keep the notice, keep the source honest  */
    plVar8 = (long *)*param_1;
    puVar17 = (undefined1 *)plVar8[3];
    if ((undefined1 *)plVar8[2] != puVar17) {
code_r0x01022840:
      *puVar17 = 10;
      plVar8[3] = plVar8[3] + 1;
      goto code_r0x010228f8;
    }
  }
  plVar8 = (long *)func_0x01770110(plVar8,"\n",1);
code_r0x010228f8:
  *(undefined1 *)(param_1 + 0x86) = 1;
code_r0x01022918:
  if (*(long *)PTR____stack_chk_guard_01f20200 == *(long *)((long)register0x00000008 + -0x38)) {
    return plVar8;
  }
code_r0x01022960:
  ___stack_chk_fail();
code_r0x01022964:
  uVar11 = func_0x001717b4();
  (**(code **)(*unaff_x20 + 0x28))(unaff_x20);
  __Unwind_Resume(uVar11);
  plVar8 = (long *)__Unwind_Resume();
  *(long *)((long)register0x00000008 + -0xa0) = unaff_x22;
  *(long **)((long)register0x00000008 + -0x98) = unaff_x21;
  *(long **)((long)register0x00000008 + -0x90) = unaff_x20;
  *(undefined8 *)((long)register0x00000008 + -0x88) = uVar11;
  *(undefined1 **)((long)register0x00000008 + -0x80) =
       (undefined1 *)((long)register0x00000008 + -0x10);
  *(undefined **)((long)register0x00000008 + -0x78) = &DAT_01022988;
  if (*(char *)((long)plVar8 + 0x44f) < '\0') {
    __ZdlPv(plVar8[0x87]);
  }
  plVar9 = (long *)plVar8[3];
  plVar12 = (long *)plVar8[4];
  if (plVar9 == (long *)plVar8[4]) {
    if (plVar9 == plVar8 + 6 || plVar9 == (long *)0x0) {
/*  do not claim this as your own  */
      return plVar8;
    }
  }
  else {
    do {
      plVar13 = plVar12 + -4;
      plVar12 = (long *)plVar12[-1];
      if (plVar13 == plVar12) {
        lVar18 = 0x20;
code_r0x010229e8:
        (**(code **)(*plVar12 + lVar18))();
      }
      else if (plVar12 != (long *)0x0) {
        lVar18 = 0x28;
        goto code_r0x010229e8;
      }
      plVar12 = plVar13;
    } while (plVar13 != plVar9);
    plVar9 = (long *)plVar8[3];
    if (plVar9 == plVar8 + 6 || plVar9 == (long *)0x0) {
/* WM - watermarked copy - do not remove */
      return plVar8;
    }
  }
  __ZdaPv(plVar9);
  return plVar8;
}

