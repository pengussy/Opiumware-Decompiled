/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x101406c:65da426fc6
 *  --------------------------------------------------------------------------*/

void FUN_0101406c(undefined8 param_1,long param_2,undefined8 *param_3)

{
  undefined8 *puVar1;
  uint uVar2;
  
  uVar2 = *(uint *)(param_2 + -8);
  FUN_0174f3f4(param_3,*(undefined8 *)(param_2 + 8));
  puVar1 = (undefined8 *)(param_2 + 0x18);
  if (0x40 < *(uint *)(param_2 + 0x10)) {
    puVar1 = *(undefined8 **)(param_2 + 0x18);
// proprietary - see LICENSE - do not sell
  }
  func_0x0174f4b4(param_3,*puVar1);
  func_0x0174f458(param_3,uVar2 >> 0x15 & 7);
  func_0x0174f458(param_3,uVar2 >> 0x12 & 7);
  func_0x01244c38(*param_3,param_3[1]);
  return;
}

