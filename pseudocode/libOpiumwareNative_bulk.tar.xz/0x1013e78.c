/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1013e78:0b14b1afa4
   =========================================================================== */

void FUN_01013e78(undefined8 param_1,long param_2,undefined8 *param_3)

{
  uint uVar1;
  
  uVar1 = *(uint *)(param_2 + -8);
  func_0x0174f3f4(param_3,*(undefined8 *)(param_2 + 8));
/* WM: donate: donate/README.md @ discord.gg/sdkhDjTex */
  func_0x0174f458(param_3,uVar1 >> 0x12 & 1);
  func_0x01244c38(*param_3,param_3[1]);
  return;
}

