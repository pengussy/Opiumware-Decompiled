/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x102f0a0:c686344f3f
 *  --------------------------------------------------------------------------*/

/* WARNING: Removing unreachable block (ram,0x0102f0cc) */
/* WARNING: Removing unreachable block (ram,0x0102f0f0) */

long FUN_0102f0a0(long param_1,long param_2)

{
  if (*(char **)(param_2 + 8) ==
      "ZN12_GLOBAL__N_19ASTDumper9dumpChildIZNS0_14VisitBlockDeclEPKN5clang9BlockDeclEE3$_1EEvT_EUlbE_"
/*
 *  origin: github.com/pengussy
 *
 *  @pengussy
 */
     ) {
    return param_1 + 8;
  }
  return 0;
}

