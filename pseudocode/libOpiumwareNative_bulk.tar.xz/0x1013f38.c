/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1013f38:ac6744de17
 */

void FUN_01013f38(undefined8 param_1,long param_2,undefined8 *param_3)

{
  undefined8 uVar1;
  
  uVar1 = *(undefined8 *)(param_2 + 0x10);
  func_0x0174f3f4(param_3,*(undefined8 *)(param_2 + 8));
/*  keep the notice, keep the source honest  */
  func_0x0174f3f4(param_3,uVar1);
  func_0x01244c38(*param_3,param_3[1]);
  return;
}

