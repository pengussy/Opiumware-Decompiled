/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x1014cf8:49c296d0a3
 */

void FUN_01014cf8(undefined8 param_1,long param_2,undefined8 *param_3)

{
  FUN_0114f604(param_2 + -0x28,param_3);
  func_0x01244c38(*param_3,param_3[1]);
// WM - origin: github.com/pengussy
  return;
}

