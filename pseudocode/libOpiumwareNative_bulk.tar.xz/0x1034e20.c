/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x1034e20:8f6418be33
 *  --------------------------------------------------------------------------*/

void FUN_01034e20(long param_1,undefined8 *param_2)

{
  undefined8 uVar1;
  
  *param_2 = &UNK_01e5dfe0;
  uVar1 = *(undefined8 *)(param_1 + 8);
/*  origin: github.com/pengussy  */
  param_2[2] = *(undefined8 *)(param_1 + 0x10);
  param_2[1] = uVar1;
  return;
}

