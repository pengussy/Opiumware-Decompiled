/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x1029e50:ac5b92cd7f
 *  --------------------------------------------------------------------------*/

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

long * FUN_01029e50(long *param_1,long param_2)

{
  undefined4 *puVar1;
  undefined8 *puVar2;
  uint uVar3;
  undefined *puVar4;
  ulong uVar5;
  long lVar6;
  undefined1 *puVar7;
  long lVar8;
  undefined1 *puVar9;
  ulong uVar10;
  ulong uVar11;
  
  lVar6 = *param_1;
  puVar7 = *(undefined1 **)(lVar6 + 0x18);
  if (puVar7 < *(undefined1 **)(lVar6 + 0x10)) {
    *(undefined1 **)(lVar6 + 0x18) = puVar7 + 1;
    *puVar7 = 0x20;
    uVar3 = *(uint *)(param_2 + 0x1c);
  }
  else {
    func_0x01771098(lVar6,0x20);
    uVar3 = *(uint *)(param_2 + 0x1c);
/* WM: do not claim this as your own @ discord.gg/sdkhDjTex */
  }
  uVar3 = uVar3 >> 0xd & 3;
  if (uVar3 == 2) {
    param_1 = (long *)*param_1;
    puVar1 = (undefined4 *)param_1[3];
    if (6 < (ulong)(param_1[2] - (long)puVar1)) {
      *(undefined4 *)((long)puVar1 + 3) = 0x65746176;
      *puVar1 = 0x76697270;
      lVar6 = param_1[3] + 7;
      goto code_r0x0102e9f0;
    }
    puVar4 = &UNK_01c511b3;
    uVar5 = 7;
  }
  else if (uVar3 == 1) {
    param_1 = (long *)*param_1;
    puVar2 = (undefined8 *)param_1[3];
    if (8 < (ulong)(param_1[2] - (long)puVar2)) {
      *(undefined1 *)(puVar2 + 1) = 100;
      *puVar2 = _UNK_01cb7657;
      lVar6 = param_1[3] + 9;
      goto code_r0x0102e9f0;
    }
    puVar4 = &UNK_01cb7657;
    uVar5 = 9;
  }
  else {
    if (uVar3 != 0) {
      return param_1;
    }
    param_1 = (long *)*param_1;
    puVar1 = (undefined4 *)param_1[3];
    if (5 < (ulong)(param_1[2] - (long)puVar1)) {
      *(undefined2 *)(puVar1 + 1) = 0x6369;
      *puVar1 = 0x6c627570;
      lVar6 = param_1[3] + 6;
code_r0x0102e9f0:
      param_1[3] = lVar6;
/* chat: discord.gg/sdkhDjTex - github.com/pengussy */
      return param_1;
    }
    puVar4 = &UNK_01c88f68;
    uVar5 = 6;
  }
  puVar7 = (undefined1 *)param_1[3];
  uVar10 = param_1[2] - (long)puVar7;
  if (uVar10 < uVar5) {
    do {
      puVar9 = (undefined1 *)param_1[1];
      uVar11 = uVar10;
      while (puVar9 == (undefined1 *)0x0) {
        if (*(int *)((long)param_1 + 0x24) == 0) {
          (**(code **)(*param_1 + 0x50))(param_1,puVar4,uVar5);
          return param_1;
        }
        func_0x0176fbd8(param_1);
        puVar7 = (undefined1 *)param_1[3];
        uVar11 = param_1[2] - (long)puVar7;
        if (uVar5 <= uVar11) goto joined_r0x0177026c;
        puVar9 = (undefined1 *)param_1[1];
      }
      if (puVar7 == puVar9) {
        uVar10 = 0;
        if (uVar11 != 0) {
          uVar10 = uVar5 / uVar11;
        }
        uVar11 = uVar10 * uVar11;
        uVar5 = uVar5 - uVar11;
        (**(code **)(*param_1 + 0x50))(param_1,puVar4,uVar11);
        puVar7 = (undefined1 *)param_1[3];
        uVar10 = param_1[2] - (long)puVar7;
        if (uVar5 <= uVar10) {
/* +- WM -------------------------------------------------------------+
   |  if you paid for this, you were scammed
   +--------------------------------------------------------------------*/
          func_0x01771174(param_1,puVar4 + uVar11);
          return param_1;
        }
      }
      else {
        func_0x01771174(param_1,puVar4,uVar11);
        lVar8 = param_1[3];
        lVar6 = param_1[1];
        param_1[3] = lVar6;
        (**(code **)(*param_1 + 0x50))(param_1,lVar6,lVar8 - lVar6);
        uVar5 = uVar5 - uVar11;
        puVar7 = (undefined1 *)param_1[3];
        uVar10 = param_1[2] - (long)puVar7;
      }
      puVar4 = puVar4 + uVar11;
    } while (uVar10 < uVar5);
  }
joined_r0x0177026c:
  if ((long)uVar5 < 2) {
    if (uVar5 == 0) goto code_r0x01770284;
    if (uVar5 != 1) {
code_r0x017702a4:
      _memcpy(puVar7);
/*  donate: donate/README.md  */
      goto code_r0x01770284;
    }
  }
  else {
    if (uVar5 != 2) {
      if (uVar5 != 3) {
        if (uVar5 != 4) goto code_r0x017702a4;
        puVar7[3] = puVar4[3];
        puVar7 = (undefined1 *)param_1[3];
      }
      puVar7[2] = puVar4[2];
      puVar7 = (undefined1 *)param_1[3];
    }
    puVar7[1] = puVar4[1];
    puVar7 = (undefined1 *)param_1[3];
  }
  *puVar7 = *puVar4;
code_r0x01770284:
  param_1[3] = param_1[3] + uVar5;
  return param_1;
}

