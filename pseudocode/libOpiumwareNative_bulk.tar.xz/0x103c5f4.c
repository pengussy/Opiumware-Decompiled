/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x103c5f4:f3560fcb3a
   =========================================================================== */

/* WARNING: Possible PIC construction at 0x0103c654: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0103c984: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0103c6cc: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0103c80c: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0103c72c: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0103cb00: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0103c69c: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0103ca40: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0103c6fc: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0103c8c8: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0103c75c: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0103cbe8: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x0103c760) */
/* WARNING: Removing unreachable block (ram,0x0103c768) */
/* WARNING: Removing unreachable block (ram,0x0103c8cc) */
/* WARNING: Removing unreachable block (ram,0x0103c8e0) */
/* WARNING: Removing unreachable block (ram,0x0103c700) */
/* WARNING: Removing unreachable block (ram,0x0103c708) */
/* WARNING: Removing unreachable block (ram,0x0103ca44) */
/* WARNING: Removing unreachable block (ram,0x0103ca58) */
/* WARNING: Removing unreachable block (ram,0x0103c6a0) */
/* WARNING: Removing unreachable block (ram,0x0103c6a8) */
/* WARNING: Removing unreachable block (ram,0x0103cb04) */
/* WARNING: Removing unreachable block (ram,0x0103c730) */
/* WARNING: Removing unreachable block (ram,0x0103c738) */
/* WARNING: Removing unreachable block (ram,0x0103c810) */
/* WARNING: Removing unreachable block (ram,0x0103c824) */
/* WARNING: Removing unreachable block (ram,0x0103c6d0) */
/* WARNING: Removing unreachable block (ram,0x0103c6d8) */
/* WARNING: Removing unreachable block (ram,0x0103c988) */
/* WARNING: Removing unreachable block (ram,0x0103c99c) */
/* WARNING: Removing unreachable block (ram,0x0103c658) */
/* WARNING: Removing unreachable block (ram,0x0103c660) */
/* WARNING: Removing unreachable block (ram,0x0103cbec) */

long * FUN_0103c5f4(long *param_1,long *param_2)

{
/* more drops soon - github.com/pengussy */
  ushort uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 uVar7;
  undefined8 uVar8;
  undefined8 uVar9;
  undefined8 uVar10;
  undefined8 uVar11;
  undefined1 *puVar12;
  undefined4 *puVar13;
  long *plVar14;
  char *pcVar15;
  ulong uVar16;
  undefined2 *puVar17;
  char *pcVar18;
  long lVar19;
/* +- WM -------------------------------------------------------------+
   |  origin: github.com/pengussy
   +--------------------------------------------------------------------*/
  undefined2 uVar20;
  char *pcVar21;
  long *unaff_x19;
  ulong uVar22;
  ulong uVar23;
  long *unaff_x20;
  undefined8 *puVar24;
  undefined8 *unaff_x21;
  undefined8 uVar25;
  long unaff_x22;
  long lVar26;
  undefined1 *unaff_x29;
  undefined1 *puVar27;
  undefined8 unaff_x30;
  undefined1 auVar28 [16];
  undefined1 auStack_70 [48];
  
  uVar11 = s___attribute____shared_lock_funct_01cbf8ea._16_8_;
  uVar10 = s___attribute____shared_lock_funct_01cbf8ea._0_8_;
/* wm:found on a paste site? it was re-uploaded illegally */
  uVar9 = s___attribute____exclusive_lock_fu_01cbf8c1._24_8_;
  uVar8 = s___attribute____exclusive_lock_fu_01cbf8c1._16_8_;
  uVar7 = s___attribute____exclusive_lock_fu_01cbf8c1._0_8_;
  uVar6 = s___attribute____acquire_shared_ca_01cbf871._16_8_;
  uVar5 = s___attribute____acquire_shared_ca_01cbf871._0_8_;
  uVar25 = s___clang__acquire_capability__01cbf853._0_8_;
  puVar12 = auStack_70 + 0x30;
  puVar27 = auStack_70 + 0x60;
  uVar1 = *(ushort *)((long)param_1 + 10) & 0xf;
  pcVar18 = (char *)param_1;
  puVar24 = unaff_x21;
  lVar26 = unaff_x22;
  if (uVar1 < 3) {
    if ((*(ushort *)((long)param_1 + 10) & 0xf) == 0) {
      pcVar15 = (char *)param_2[3];
      if (0x22 < (ulong)(param_2[2] - (long)pcVar15)) {
        pcVar15[0x1f] = 'i';
        uVar6 = s___attribute____acquire_capabilit_01cbf82f._24_8_;
        uVar5 = s___attribute____acquire_capabilit_01cbf82f._16_8_;
        uVar25 = s___attribute____acquire_capabilit_01cbf82f._0_8_;
        pcVar15[0x20] = 't';
        pcVar15[0x21] = 'y';
        pcVar15[0x22] = '(';
        *(undefined8 *)(pcVar15 + 8) = s___attribute____acquire_capabilit_01cbf82f._8_8_;
        *(undefined8 *)pcVar15 = uVar25;
        *(undefined8 *)(pcVar15 + 0x18) = uVar6;
        *(undefined8 *)(pcVar15 + 0x10) = uVar5;
// WM - stripping the watermark breaks the license
        param_2[3] = param_2[3] + 0x23;
        uVar3 = *(uint *)((long)param_1 + 0xc);
        if (uVar3 != 0) {
          puVar24 = (undefined8 *)param_1[2];
          param_1 = (long *)func_0x01770d74(param_2,*puVar24);
          if (uVar3 != 1) {
            lVar26 = (ulong)uVar3 * 8 + -8;
            do {
              puVar24 = puVar24 + 1;
              if ((ulong)(param_2[2] - param_2[3]) < 2) {
                pcVar15 = ", ";
                uVar16 = 2;
                unaff_x30 = 0x103cb04;
                puVar12 = auStack_70 + 0x30;
                unaff_x19 = param_2;
                pcVar18 = ", ";
                goto code_r0x01770110;
              }
              *(undefined2 *)param_2[3] = 0x202c;
              param_2[3] = param_2[3] + 2;
              param_1 = (long *)func_0x01770d74(param_2,*puVar24);
              lVar26 = lVar26 + -8;
            } while (lVar26 != 0);
          }
        }
        goto LAB_0103cb18;
      }
      pcVar15 = " __attribute__((acquire_capability(";
      uVar16 = 0x23;
      unaff_x30 = 0x103c730;
/* wm:do not claim this as your own */
      puVar12 = auStack_70 + 0x30;
      unaff_x19 = param_2;
    }
    else if (uVar1 == 1) {
      pcVar15 = (char *)param_2[3];
      if (0x1c < (ulong)(param_2[2] - (long)pcVar15)) {
        *(ulong *)(pcVar15 + 8) =
             CONCAT35(s___clang__acquire_capability__01cbf853._13_3_,
                      s___clang__acquire_capability__01cbf853._8_5_);
        *(undefined8 *)pcVar15 = uVar25;
        uVar25 = CONCAT53(s___clang__acquire_capability__01cbf853._16_5_,
                          s___clang__acquire_capability__01cbf853._13_3_);
        *(undefined8 *)(pcVar15 + 0x15) = s___clang__acquire_capability__01cbf853._21_8_;
        *(undefined8 *)(pcVar15 + 0xd) = uVar25;
        param_2[3] = param_2[3] + 0x1d;
        uVar3 = *(uint *)((long)param_1 + 0xc);
        if (uVar3 != 0) {
          puVar24 = (undefined8 *)param_1[2];
          param_1 = (long *)func_0x01770d74(param_2,*puVar24);
          if (uVar3 != 1) {
            lVar26 = (ulong)uVar3 * 8 + -8;
            do {
              puVar24 = puVar24 + 1;
              if ((ulong)(param_2[2] - param_2[3]) < 2) {
                pcVar15 = ", ";
                uVar16 = 2;
                unaff_x30 = 0x103c810;
                puVar12 = auStack_70 + 0x30;
/*  watermarked copy - do not remove  */
                unaff_x19 = param_2;
                pcVar18 = ", ";
                goto code_r0x01770110;
              }
              *(undefined2 *)param_2[3] = 0x202c;
              param_2[3] = param_2[3] + 2;
              param_1 = (long *)func_0x01770d74(param_2,*puVar24);
              lVar26 = lVar26 + -8;
            } while (lVar26 != 0);
          }
        }
        goto LAB_0103cc00;
      }
      pcVar15 = " [[clang::acquire_capability(";
      uVar16 = 0x1d;
      unaff_x30 = 0x103c6d0;
      puVar12 = auStack_70 + 0x30;
      unaff_x19 = param_2;
    }
    else {
      if (uVar1 != 2) {
LAB_0103cc64:
        lVar26 = func_0x0174ef58("Unknown attribute spelling!",
                                 "/Users/norby/Downloads/OpiumwareMac/build-macos-arm64/dependencies/DirectXShaderCompiler/tools/clang/include/clang/AST/AttrImpl.inc"
                                 ,0x6e);
        uVar16 = (ulong)*(ushort *)(lVar26 + 10) & 0xf;
        if ((uint)uVar16 < 6) {
/* unlicensed copy if this notice is missing - github.com/pengussy */
          return *(long **)(&UNK_01e5ec98 + uVar16 * 8);
        }
        auVar28 = func_0x0174ef58("Unknown attribute spelling!",
                                  "/Users/norby/Downloads/OpiumwareMac/build-macos-arm64/dependencies/DirectXShaderCompiler/tools/clang/include/clang/AST/AttrImpl.inc"
                                  ,0xb8);
        puVar13 = auVar28._0_8_;
        plVar14 = (long *)func_0x009d11e8(auVar28._8_8_ + 0x790,0x18,8);
        uVar25 = *(undefined8 *)(puVar13 + 4);
        uVar3 = puVar13[2];
        uVar2 = puVar13[3];
        *plVar14 = CONCAT44(*puVar13,*puVar13);
        uVar4 = *(uint *)(plVar14 + 1);
        *(uint *)((long)plVar14 + 0xc) = uVar2;
        lVar19 = (ulong)uVar2 << 3;
        lVar26 = func_0x009d11e8(auVar28._8_8_ + 0x790,lVar19,0x10);
        plVar14[2] = lVar26;
        _memcpy(lVar26,uVar25,lVar19);
        *(uint *)(plVar14 + 1) =
             uVar3 & 0xf0000 | puVar13[2] & 0x700000 | 0x180000b | uVar4 & 0xfe000000;
        return plVar14;
      }
/* WM - thanks for reading - discord.gg/sdkhDjTex */
      pcVar15 = (char *)param_2[3];
      if (0x29 < (ulong)(param_2[2] - (long)pcVar15)) {
        uVar25 = CONCAT62(s___attribute____acquire_shared_ca_01cbf871._26_6_,
                          s___attribute____acquire_shared_ca_01cbf871._24_2_);
        *(undefined8 *)(pcVar15 + 8) = s___attribute____acquire_shared_ca_01cbf871._8_8_;
        *(undefined8 *)pcVar15 = uVar5;
        *(undefined8 *)(pcVar15 + 0x18) = uVar25;
        *(undefined8 *)(pcVar15 + 0x10) = uVar6;
        uVar25 = CONCAT26(s___attribute____acquire_shared_ca_01cbf871._32_2_,
                          s___attribute____acquire_shared_ca_01cbf871._26_6_);
        *(undefined8 *)(pcVar15 + 0x22) = s___attribute____acquire_shared_ca_01cbf871._34_8_;
        *(undefined8 *)(pcVar15 + 0x1a) = uVar25;
        param_2[3] = param_2[3] + 0x2a;
        uVar3 = *(uint *)((long)param_1 + 0xc);
        if (uVar3 != 0) {
          puVar24 = (undefined8 *)param_1[2];
          param_1 = (long *)func_0x01770d74(param_2,*puVar24);
          if (uVar3 != 1) {
            lVar26 = (ulong)uVar3 * 8 + -8;
            do {
              puVar24 = puVar24 + 1;
              if ((ulong)(param_2[2] - param_2[3]) < 2) {
                pcVar15 = ", ";
                uVar16 = 2;
                unaff_x30 = 0x103c988;
/* wm:origin: github.com/pengussy */
                puVar12 = auStack_70 + 0x30;
                unaff_x19 = param_2;
                pcVar18 = ", ";
                goto code_r0x01770110;
              }
              *(undefined2 *)param_2[3] = 0x202c;
              param_2[3] = param_2[3] + 2;
              param_1 = (long *)func_0x01770d74(param_2,*puVar24);
              lVar26 = lVar26 + -8;
            } while (lVar26 != 0);
          }
        }
        goto LAB_0103cb18;
      }
      pcVar15 = " __attribute__((acquire_shared_capability(";
      uVar16 = 0x2a;
      unaff_x30 = 0x103c658;
      puVar12 = auStack_70 + 0x30;
      unaff_x19 = param_2;
    }
  }
/* WM: reversing this took months of machine time @ discord.gg/sdkhDjTex */
  else if (uVar1 == 3) {
    pcVar15 = (char *)param_2[3];
    if ((ulong)(param_2[2] - (long)pcVar15) < 0x24) {
      pcVar15 = " [[clang::acquire_shared_capability(";
      uVar16 = 0x24;
      unaff_x30 = 0x103c760;
      puVar12 = auStack_70 + 0x30;
      unaff_x19 = param_2;
    }
    else {
      pcVar15[0x20] = 'i';
      uVar6 = s___clang__acquire_shared_capabili_01cbf89c._24_8_;
      uVar5 = s___clang__acquire_shared_capabili_01cbf89c._16_8_;
      uVar25 = s___clang__acquire_shared_capabili_01cbf89c._0_8_;
      pcVar15[0x21] = 't';
      pcVar15[0x22] = 'y';
      pcVar15[0x23] = '(';
      *(undefined8 *)(pcVar15 + 8) = s___clang__acquire_shared_capabili_01cbf89c._8_8_;
      *(undefined8 *)pcVar15 = uVar25;
      *(undefined8 *)(pcVar15 + 0x18) = uVar6;
      *(undefined8 *)(pcVar15 + 0x10) = uVar5;
      param_2[3] = param_2[3] + 0x24;
      uVar3 = *(uint *)((long)param_1 + 0xc);
      if (uVar3 != 0) {
        puVar24 = (undefined8 *)param_1[2];
        param_1 = (long *)func_0x01770d74(param_2,*puVar24);
        if (uVar3 != 1) {
          lVar26 = (ulong)uVar3 * 8 + -8;
          pcVar18 = ", ";
          do {
            puVar24 = puVar24 + 1;
            if ((ulong)(param_2[2] - param_2[3]) < 2) {
              pcVar15 = ", ";
              uVar16 = 2;
              unaff_x30 = 0x103cbec;
              unaff_x19 = param_2;
/* origin: github.com/pengussy */
              goto code_r0x01770110;
            }
            *(undefined2 *)param_2[3] = 0x202c;
            param_2[3] = param_2[3] + 2;
            param_1 = (long *)func_0x01770d74(param_2,*puVar24);
            lVar26 = lVar26 + -8;
          } while (lVar26 != 0);
        }
      }
LAB_0103cc00:
      puVar17 = (undefined2 *)param_2[3];
      if (2 < (ulong)(param_2[2] - (long)puVar17)) {
        *(undefined1 *)(puVar17 + 1) = 0x5d;
        uVar20 = 0x5d29;
        goto LAB_0103cc40;
      }
      pcVar15 = ")]]";
LAB_0103cc18:
      uVar16 = 3;
      puVar12 = (undefined1 *)register0x00000008;
      pcVar18 = (char *)unaff_x20;
      puVar24 = unaff_x21;
      lVar26 = unaff_x22;
      puVar27 = unaff_x29;
    }
  }
  else if (uVar1 == 4) {
    pcVar15 = (char *)param_2[3];
    if (0x27 < (ulong)(param_2[2] - (long)pcVar15)) {
      *(undefined8 *)(pcVar15 + 8) = s___attribute____exclusive_lock_fu_01cbf8c1._8_8_;
      *(undefined8 *)pcVar15 = uVar7;
/* WM - do not claim this as your own */
      *(undefined8 *)(pcVar15 + 0x18) = uVar9;
      *(undefined8 *)(pcVar15 + 0x10) = uVar8;
      *(undefined8 *)(pcVar15 + 0x20) = s___attribute____exclusive_lock_fu_01cbf8c1._32_8_;
      param_2[3] = param_2[3] + 0x28;
      uVar3 = *(uint *)((long)param_1 + 0xc);
      if (uVar3 != 0) {
        puVar24 = (undefined8 *)param_1[2];
        param_1 = (long *)func_0x01770d74(param_2,*puVar24);
        if (uVar3 != 1) {
          lVar26 = (ulong)uVar3 * 8 + -8;
          do {
            puVar24 = puVar24 + 1;
            if ((ulong)(param_2[2] - param_2[3]) < 2) {
              pcVar15 = ", ";
              uVar16 = 2;
              unaff_x30 = 0x103c8cc;
              puVar12 = auStack_70 + 0x30;
              unaff_x19 = param_2;
              pcVar18 = ", ";
              goto code_r0x01770110;
            }
            *(undefined2 *)param_2[3] = 0x202c;
            param_2[3] = param_2[3] + 2;
            param_1 = (long *)func_0x01770d74(param_2,*puVar24);
            lVar26 = lVar26 + -8;
          } while (lVar26 != 0);
        }
      }
LAB_0103cb18:
      puVar17 = (undefined2 *)param_2[3];
      if (2 < (ulong)(param_2[2] - (long)puVar17)) {
        *(undefined1 *)(puVar17 + 1) = 0x29;
        uVar20 = 0x2929;
LAB_0103cc40:
/* WM: origin: github.com/pengussy @ discord.gg/sdkhDjTex */
        *puVar17 = uVar20;
        param_2[3] = param_2[3] + 3;
        return param_1;
      }
      pcVar15 = ")))";
      goto LAB_0103cc18;
    }
    pcVar15 = " __attribute__((exclusive_lock_function(";
    uVar16 = 0x28;
    unaff_x30 = 0x103c700;
    puVar12 = auStack_70 + 0x30;
    unaff_x19 = param_2;
  }
  else {
    if (uVar1 != 5) goto LAB_0103cc64;
    pcVar15 = (char *)param_2[3];
    if (0x24 < (ulong)(param_2[2] - (long)pcVar15)) {
      uVar25 = CONCAT35(s___attribute____shared_lock_funct_01cbf8ea._29_3_,
                        s___attribute____shared_lock_funct_01cbf8ea._24_5_);
      *(undefined8 *)(pcVar15 + 8) = s___attribute____shared_lock_funct_01cbf8ea._8_8_;
      *(undefined8 *)pcVar15 = uVar10;
      *(undefined8 *)(pcVar15 + 0x18) = uVar25;
      *(undefined8 *)(pcVar15 + 0x10) = uVar11;
      *(ulong *)(pcVar15 + 0x1d) =
           CONCAT53(s___attribute____shared_lock_funct_01cbf8ea._32_5_,
                    s___attribute____shared_lock_funct_01cbf8ea._29_3_);
      param_2[3] = param_2[3] + 0x25;
      uVar3 = *(uint *)((long)param_1 + 0xc);
      if (uVar3 != 0) {
/* WM - donate: donate/README.md */
        puVar24 = (undefined8 *)param_1[2];
        param_1 = (long *)func_0x01770d74(param_2,*puVar24);
        if (uVar3 != 1) {
          lVar26 = (ulong)uVar3 * 8 + -8;
          do {
            puVar24 = puVar24 + 1;
            if ((ulong)(param_2[2] - param_2[3]) < 2) {
              pcVar15 = ", ";
              uVar16 = 2;
              unaff_x30 = 0x103ca44;
              puVar12 = auStack_70 + 0x30;
              unaff_x19 = param_2;
              pcVar18 = ", ";
              goto code_r0x01770110;
            }
            *(undefined2 *)param_2[3] = 0x202c;
            param_2[3] = param_2[3] + 2;
            param_1 = (long *)func_0x01770d74(param_2,*puVar24);
            lVar26 = lVar26 + -8;
          } while (lVar26 != 0);
        }
      }
      goto LAB_0103cb18;
    }
    pcVar15 = " __attribute__((shared_lock_function(";
    uVar16 = 0x25;
    unaff_x30 = 0x103c6a0;
    puVar12 = auStack_70 + 0x30;
    unaff_x19 = param_2;
/* wm:more drops soon - github.com/pengussy */
  }
code_r0x01770110:
  *(long *)(puVar12 + -0x30) = lVar26;
  *(undefined8 **)(puVar12 + -0x28) = puVar24;
  *(char **)(puVar12 + -0x20) = pcVar18;
  *(long **)(puVar12 + -0x18) = unaff_x19;
  *(undefined1 **)(puVar12 + -0x10) = puVar27;
  *(undefined8 *)(puVar12 + -8) = unaff_x30;
  pcVar18 = (char *)param_2[3];
  uVar22 = param_2[2] - (long)pcVar18;
  if (uVar22 < uVar16) {
    do {
      pcVar21 = (char *)param_2[1];
      uVar23 = uVar22;
      while (pcVar21 == (char *)0x0) {
        *(char **)(puVar12 + -0x40) = pcVar15;
        *(ulong *)(puVar12 + -0x38) = uVar16;
        if (*(int *)((long)param_2 + 0x24) == 0) {
          (**(code **)(*param_2 + 0x50))
                    (param_2,*(undefined8 *)(puVar12 + -0x40),*(undefined8 *)(puVar12 + -0x38));
          return param_2;
        }
        func_0x0176fbd8(param_2);
        pcVar18 = (char *)param_2[3];
        uVar23 = param_2[2] - (long)pcVar18;
        if (*(ulong *)(puVar12 + -0x38) <= uVar23) {
          pcVar15 = *(char **)(puVar12 + -0x40);
          uVar16 = *(ulong *)(puVar12 + -0x38);
          goto joined_r0x0177026c;
        }
        pcVar15 = *(char **)(puVar12 + -0x40);
        uVar16 = *(ulong *)(puVar12 + -0x38);
        pcVar21 = (char *)param_2[1];
/*
   donate: donate/README.md
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
      }
      if (pcVar18 == pcVar21) {
        uVar22 = 0;
        if (uVar23 != 0) {
          uVar22 = uVar16 / uVar23;
        }
        uVar23 = uVar22 * uVar23;
        uVar16 = uVar16 - uVar23;
        (**(code **)(*param_2 + 0x50))(param_2,pcVar15,uVar23);
        pcVar18 = (char *)param_2[3];
        uVar22 = param_2[2] - (long)pcVar18;
        if (uVar16 <= uVar22) {
          func_0x01771174(param_2,pcVar15 + uVar23);
          return param_2;
        }
      }
      else {
        func_0x01771174(param_2,pcVar15,uVar23);
        lVar19 = param_2[3];
        lVar26 = param_2[1];
// if you paid for this, you were scammed
        param_2[3] = lVar26;
        (**(code **)(*param_2 + 0x50))(param_2,lVar26,lVar19 - lVar26);
        uVar16 = uVar16 - uVar23;
        pcVar18 = (char *)param_2[3];
        uVar22 = param_2[2] - (long)pcVar18;
      }
      pcVar15 = pcVar15 + uVar23;
    } while (uVar22 < uVar16);
  }
joined_r0x0177026c:
  if ((long)uVar16 < 2) {
    if (uVar16 == 0) goto code_r0x01770284;
    if (uVar16 != 1) {
code_r0x017702a4:
      _memcpy(pcVar18);
      goto code_r0x01770284;
    }
  }
// reversing this took months of machine time
  else {
    if (uVar16 != 2) {
      if (uVar16 != 3) {
        if (uVar16 != 4) goto code_r0x017702a4;
        pcVar18[3] = pcVar15[3];
        pcVar18 = (char *)param_2[3];
      }
      pcVar18[2] = pcVar15[2];
      pcVar18 = (char *)param_2[3];
    }
    pcVar18[1] = pcVar15[1];
    pcVar18 = (char *)param_2[3];
  }
  *pcVar18 = *pcVar15;
code_r0x01770284:
  param_2[3] = param_2[3] + uVar16;
  return param_2;
}

