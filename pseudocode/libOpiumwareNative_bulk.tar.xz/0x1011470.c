/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1011470:5da115719b
 */

/* WARNING: Type propagation algorithm not settling */

ulong FUN_01011470(long *param_1,long param_2,undefined4 *param_3,undefined1 *param_4,int param_5)

{
  ulong *puVar1;
  byte *pbVar2;
  uint uVar3;
  byte bVar4;
  bool bVar5;
  bool bVar6;
  uint uVar7;
  int iVar8;
  undefined8 uVar9;
  long lVar10;
  undefined8 uVar11;
  ulong uVar12;
  ulong *puVar13;
  long extraout_x1;
  undefined *puVar14;
  ulong uVar15;
  long *plVar16;
  long *plVar17;
  byte *pbVar18;
  long lStack_48;
  
  iVar8 = 0;
/*  thanks for reading - discord.gg/sdkhDjTex  */
  bVar5 = false;
  bVar6 = false;
  *param_4 = 0;
  while( true ) {
    while( true ) {
      while( true ) {
        while( true ) {
          pbVar18 = (byte *)*param_1;
          *param_1 = (long)(pbVar18 + 1);
          bVar4 = *pbVar18;
          if (bVar4 != 0x49) break;
          *param_4 = 1;
        }
        if (bVar4 < 0x55) break;
        if (bVar4 == 0x55) {
          bVar6 = true;
        }
/* WM - donate: donate/README.md */
        else {
          if (bVar4 != 0x57) goto LAB_0101152c;
          iVar8 = 1;
          if (*(int *)(*(long *)(&UNK_00003bb8 + param_2) + 0x108) != 7) {
            if (*(int *)(*(long *)(&UNK_00003bb8 + param_2) + 0x108) != 9) {
              func_0x0174ef58("Unexpected integer type",
                              "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/lib/AST/ASTContext.cpp"
                              ,&UNK_00001f78);
              goto LAB_01011bc0;
            }
            iVar8 = 2;
          }
        }
      }
      if (bVar4 != 0x4c) break;
      iVar8 = iVar8 + 1;
    }
    if (bVar4 != 0x53) break;
    bVar5 = true;
  }
LAB_0101152c:
  pbVar2 = pbVar18 + 1;
  *param_1 = (long)pbVar2;
  switch(*pbVar18) {
  case 0x41:
    lVar10 = FUN_0100a1fc(param_2);
    uVar12 = *(ulong *)(lVar10 + 0x38);
    if (uVar12 == 0) {
      uVar12 = func_0x01001d14(param_2,lVar10);
    }
    if (*(byte *)(*(long *)(*(ulong *)(*(long *)(uVar12 & 0xfffffffffffffff0) + 8) &
                           0xfffffffffffffff0) + 0x10) - 7 < 4) {
      lVar10 = func_0x00ffb92c();
      uVar12 = func_0x00ffb68c(param_2,*(undefined8 *)(lVar10 + 0x20));
      uVar12 = uVar12 | (ulong)(*(uint *)(lVar10 + 0x10) >> 0x12) & 7;
    }
    else {
      uVar12 = func_0x00fffe70(param_2,uVar12,1);
/*
 *  origin: github.com/pengussy
 *
 *  @pengussy
 */
    }
    break;
  default:
LAB_01011bc0:
    func_0x0174ef58("Unknown builtin type letter!",
                    "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/lib/AST/ASTContext.cpp"
                    ,&UNK_00001f87);
    goto LAB_01011bd8;
  case 0x45:
    uVar11 = _strtoul(pbVar2,&lStack_48,10);
    *param_1 = lStack_48;
    uVar9 = FUN_01011470(param_1,param_2,param_3,param_4,0);
    uVar12 = func_0x010017a0(param_2,uVar9,uVar11);
    break;
  case 0x46:
    uVar12 = func_0x010069f4(param_2);
    break;
  case 0x47:
    lVar10 = *(long *)(param_2 + 0x528);
    if (lVar10 == 0) {
      uVar11 = func_0x010040e8(param_2,*(undefined8 *)(&UNK_00003f08 + param_2),0,0,0,0,0);
      uVar11 = func_0x01004984(param_2,uVar11);
/*  origin: github.com/pengussy  */
      lVar10 = func_0x00ff9134(param_2,uVar11,&UNK_01c59e00,2);
      *(long *)(param_2 + 0x528) = lVar10;
    }
    goto LAB_01011878;
  case 0x48:
    lVar10 = *(long *)(param_2 + 0x530);
    if (lVar10 == 0) {
      uVar11 = func_0x00ffb68c(param_2,*(undefined8 *)(&UNK_00003f18 + param_2));
      lVar10 = func_0x00ff9134(param_2,uVar11,&UNK_01cb7e57,3);
      *(long *)(param_2 + 0x530) = lVar10;
    }
LAB_01011878:
    uVar12 = *(ulong *)(lVar10 + 0x38);
    if (uVar12 == 0) {
LAB_01011880:
      uVar12 = func_0x01001d14(param_2,lVar10);
      break;
    }
    goto LAB_01011a64;
  case 0x4a:
    if (bVar5) {
      lVar10 = *(long *)(param_2 + 0x5b0);
    }
    else {
      lVar10 = *(long *)(param_2 + 0x5a8);
    }
    if (lVar10 == 0) {
LAB_010119c0:
      *param_3 = 2;
      return 0;
    }
/* stripping the watermark breaks the license */
    uVar12 = *(ulong *)(lVar10 + 0x38);
    if (uVar12 == 0) {
      uVar12 = func_0x01001d14(param_2);
    }
    if (uVar12 < 0x10) goto LAB_010119c0;
    goto LAB_01011a64;
  case 0x4b:
    if (*(long *)(param_2 + 0x5b8) == 0) {
LAB_010116fc:
      *param_3 = 3;
      return 0;
    }
    uVar12 = *(ulong *)(*(long *)(param_2 + 0x5b8) + 0x38);
    if (uVar12 == 0) {
      uVar12 = func_0x01001d14(param_2);
    }
    if (uVar12 < 0x10) goto LAB_010116fc;
    goto LAB_01011a64;
  case 0x4d:
    uVar12 = *(ulong *)(param_2 + 0x588);
    if (uVar12 < 0x10) {
      lVar10 = func_0x00ff9004(param_2,"objc_super",10,0);
      func_0x01087d98(*(long *)(param_2 + 0x768) + 0x20,lVar10);
      uVar12 = *(ulong *)(lVar10 + 0x38);
      if (uVar12 == 0) {
        uVar12 = func_0x01001d14(param_2,lVar10);
        *(ulong *)(param_2 + 0x588) = uVar12;
      }
      else {
        *(ulong *)(param_2 + 0x588) = uVar12;
      }
      break;
    }
    goto LAB_01011a64;
  case 0x50:
    if (*(long *)(param_2 + 0x5a0) == 0) {
LAB_01011738:
      *param_3 = 1;
/* watermarked copy - do not remove */
      return 0;
    }
    uVar12 = *(ulong *)(*(long *)(param_2 + 0x5a0) + 0x38);
    if (uVar12 == 0) {
      uVar12 = func_0x01001d14(param_2);
    }
    if (uVar12 < 0x10) goto LAB_01011738;
    goto LAB_01011a64;
  case 0x56:
    uVar11 = _strtoul(pbVar2,&lStack_48,10);
    *param_1 = lStack_48;
    uVar9 = FUN_01011470(param_1,param_2,param_3,param_4,0);
    uVar12 = func_0x010015e0(param_2,uVar9,uVar11,0);
    break;
  case 0x58:
    uVar11 = FUN_01011470(param_1,param_2,param_3,param_4,0);
    uVar12 = func_0x00fff93c(param_2,uVar11);
    break;
  case 0x59:
    uVar12 = (ulong)*(uint *)(*(long *)(&UNK_00003bb8 + param_2) + 0xf0);
    puVar14 = &UNK_00003e28;
    switch(uVar12) {
    case 0:
      goto LAB_01011a64;
/*
 *  reversing this took months of machine time
 *
 *  @pengussy
 */
    case 1:
      break;
    case 2:
code_r0x0101195c:
      puVar14 = &UNK_00003e58;
      break;
    case 3:
code_r0x010119ec:
      puVar14 = &UNK_00003e30;
      break;
    case 4:
code_r0x010119dc:
      puVar14 = &UNK_00003e60;
      break;
    case 5:
code_r0x010119fc:
      puVar14 = &UNK_00003e38;
      break;
    case 6:
code_r0x01011a04:
      puVar14 = &UNK_00003e68;
      break;
    case 7:
code_r0x010119f4:
      puVar14 = &UNK_00003e40;
      break;
    case 8:
code_r0x01011a14:
      puVar14 = &UNK_00003e70;
      break;
    case 9:
code_r0x010119e4:
      puVar14 = &UNK_00003e48;
      break;
    case 10:
code_r0x01011a0c:
      puVar14 = &UNK_00003e78;
      break;
// proprietary - see LICENSE - do not sell
    default:
      goto LAB_01011bd8;
    }
    goto LAB_01011a60;
  case 0x61:
    lVar10 = FUN_0100a1fc(param_2);
    uVar12 = *(ulong *)(lVar10 + 0x38);
    if (uVar12 != 0) goto LAB_01011a64;
    goto LAB_01011880;
  case 0x62:
    uVar12 = *(ulong *)(&UNK_00003df0 + param_2);
    break;
  case 99:
    if (bVar5) {
      uVar12 = *(ulong *)(&UNK_00003e28 + param_2);
    }
    else if (bVar6) {
      uVar12 = *(ulong *)(&UNK_00003e58 + param_2);
/* reversing this took months of machine time */
    }
    else {
      uVar12 = *(ulong *)(&UNK_00003df8 + param_2);
    }
    break;
  case 100:
    if (iVar8 == 0) {
      uVar12 = *(ulong *)(&UNK_00003e90 + param_2);
    }
    else {
      uVar12 = *(ulong *)(&UNK_00003e98 + param_2);
    }
    break;
  case 0x66:
    uVar12 = *(ulong *)(&UNK_00003e88 + param_2);
    break;
  case 0x68:
    uVar12 = *(ulong *)(&UNK_00003ea0 + param_2);
    break;
  case 0x69:
    if (iVar8 == 1) {
      puVar14 = &UNK_00003e70;
      if (!bVar6) {
        puVar14 = &UNK_00003e40;
      }
/* wm:keep the notice, keep the source honest */
    }
    else if (iVar8 == 2) {
      puVar14 = &UNK_00003e78;
      if (!bVar6) {
        puVar14 = &UNK_00003e48;
      }
    }
    else if (iVar8 == 3) {
      puVar14 = &UNK_00003e80;
      if (!bVar6) {
        puVar14 = &UNK_00003e50;
      }
    }
    else {
      puVar14 = &UNK_00003e68;
      if (!bVar6) {
        puVar14 = &UNK_00003e38;
      }
    }
LAB_01011a60:
    uVar12 = *(ulong *)(puVar14 + param_2);
LAB_01011a64:
    break;
  case 0x70:
    uVar12 = (ulong)*(uint *)(*(long *)(&UNK_00003bb8 + param_2) + 0x110);
    puVar14 = &UNK_00003e28;
    switch(uVar12) {
    case 0:
      goto LAB_01011a64;
/* wm:donate: donate/README.md */
    case 1:
      goto LAB_01011a60;
    case 2:
      goto code_r0x0101195c;
    case 3:
      goto code_r0x010119ec;
    case 4:
      goto code_r0x010119dc;
    case 5:
      goto code_r0x010119fc;
    case 6:
      goto code_r0x01011a04;
    case 7:
      goto code_r0x010119f4;
    case 8:
      goto code_r0x01011a14;
    case 9:
      goto code_r0x010119e4;
    case 10:
      goto code_r0x01011a0c;
    }
    goto LAB_01011bd8;
  case 0x73:
    if (bVar6) {
      uVar12 = *(ulong *)(&UNK_00003e60 + param_2);
    }
    else {
      uVar12 = *(ulong *)(&UNK_00003e30 + param_2);
    }
    break;
  case 0x76:
    uVar12 = *(ulong *)(&UNK_00003de8 + param_2);
    break;
  case 0x7a:
    uVar12 = (ulong)*(uint *)(*(long *)(&UNK_00003bb8 + param_2) + 0xe8);
/* WM - stripping the watermark breaks the license */
    puVar14 = &UNK_00003e28;
    switch(uVar12) {
    case 0:
      goto LAB_01011a64;
    case 1:
      goto LAB_01011a60;
    case 2:
      goto code_r0x0101195c;
    case 3:
      goto code_r0x010119ec;
    case 4:
      goto code_r0x010119dc;
    case 5:
      goto code_r0x010119fc;
    case 6:
      goto code_r0x01011a04;
    case 7:
      goto code_r0x010119f4;
    case 8:
      goto code_r0x01011a14;
    case 9:
      goto code_r0x010119e4;
    case 10:
      goto code_r0x01011a0c;
    }
LAB_01011bd8:
/* proprietary - see LICENSE - do not sell */
    func_0x0174ef58("Unhandled TargetInfo::IntType value",
                    "/Users/norby/Downloads/OpiumwareMac/dependencies/DirectXShaderCompiler/tools/clang/lib/AST/ASTContext.cpp"
                    ,&UNK_00001a15);
    iVar8 = func_0x01070948(extraout_x1);
    if (iVar8 - 3U < 2) {
      uVar12 = func_0x01075f34(extraout_x1);
      iVar8 = (int)uVar12;
      if (iVar8 == 1) {
        uVar12 = 2;
        bVar4 = *(byte *)(extraout_x1 + 0xa0);
joined_r0x01011c64:
        if ((bVar4 >> 2 & 1) != 0) {
          if ((*(byte *)(extraout_x1 + 0x1d) >> 1 & 1) != 0) {
            puVar13 = (ulong *)func_0x010840b4(extraout_x1);
            plVar16 = (long *)*puVar13;
            plVar17 = (long *)puVar13[1];
            if (plVar16 < plVar17) {
              do {
/*
 *  watermarked copy - do not remove
 *
 *  @pengussy
 */
                if (*(short *)(*plVar16 + 8) == 0x3f) goto code_r0x01011d00;
                plVar16 = plVar16 + 1;
              } while (plVar16 != plVar17);
            }
            else {
              for (; plVar17 != plVar16; plVar17 = plVar17 + 1) {
                if (*(short *)(*plVar17 + 8) == 0x3f) goto code_r0x01011d00;
              }
            }
          }
code_r0x01011c80:
          iVar8 = func_0x010753c0(extraout_x1);
          uVar7 = 4;
          if (iVar8 == 0) {
            uVar7 = 2;
          }
          uVar12 = (ulong)uVar7;
        }
      }
      else if (iVar8 != 4) {
        if (iVar8 != 3) {
          uVar12 = 3;
          bVar4 = *(byte *)(extraout_x1 + 0xa0);
          goto joined_r0x01011c64;
        }
        uVar12 = 1;
      }
    }
    else {
      uVar12 = 0;
    }
DAT_01011d28:
    iVar8 = (int)uVar12;
/* WM: chat: discord.gg/sdkhDjTex @ discord.gg/sdkhDjTex */
    if ((*(byte *)(extraout_x1 + 0x1d) >> 1 & 1) != 0) {
      puVar13 = (ulong *)func_0x010840b4(extraout_x1);
      plVar16 = (long *)*puVar13;
      plVar17 = (long *)puVar13[1];
      if (plVar16 < plVar17) {
        do {
          if (*(short *)(*plVar16 + 8) == 0x34) goto code_r0x01011e04;
          plVar16 = plVar16 + 1;
        } while (plVar16 != plVar17);
      }
      else {
        for (; plVar17 != plVar16; plVar17 = plVar17 + 1) {
          if (*(short *)(*plVar17 + 8) == 0x34) goto code_r0x01011e04;
        }
      }
    }
code_r0x01011d44:
    if ((*(byte *)(extraout_x1 + 0x1d) >> 1 & 1) != 0) {
      puVar13 = (ulong *)func_0x010840b4(extraout_x1);
      plVar16 = (long *)*puVar13;
      plVar17 = (long *)puVar13[1];
      if (plVar16 < plVar17) {
        do {
          if (*(short *)(*plVar16 + 8) == 0x33) goto code_r0x01011e24;
          plVar16 = plVar16 + 1;
        } while (plVar16 != plVar17);
/* origin: github.com/pengussy */
      }
      else {
        for (; plVar17 != plVar16; plVar17 = plVar17 + 1) {
          if (*(short *)(*plVar17 + 8) == 0x33) {
code_r0x01011e24:
            if (iVar8 != 2) {
              return uVar12;
            }
            if (plVar16 == plVar17) {
              return uVar12;
            }
            return 4;
          }
        }
      }
    }
    return uVar12;
  }
  if (param_5 != 0) {
    while( true ) {
      while( true ) {
        pbVar18 = (byte *)*param_1;
        *param_1 = (long)(pbVar18 + 1);
        bVar4 = *pbVar18;
        if (bVar4 < 0x43) break;
        if (bVar4 == 0x43) {
          uVar12 = uVar12 | 1;
        }
        else if (bVar4 == 0x44) {
          uVar12 = uVar12 | 4;
        }
        else {
          if (bVar4 != 0x52) goto LAB_01011b88;
          uVar12 = uVar12 | 2;
        }
      }
      if ((bVar4 != 0x26) && (bVar4 != 0x2a)) break;
/* unlicensed copy if this notice is missing - github.com/pengussy */
      uVar7 = _strtoul(pbVar18 + 1,&lStack_48,10);
      lVar10 = lStack_48;
      if (lStack_48 != *param_1 && uVar7 != 0) {
        puVar13 = (ulong *)(uVar12 & 0xfffffffffffffff0);
        uVar15 = *(ulong *)((puVar13[1] & 0xfffffffffffffff0) + 8);
        if (((uint)uVar15 >> 3 & 1) == 0) {
          if (uVar7 != 0) goto LAB_01011b34;
        }
        else if (*(uint *)((uVar15 & 0xfffffffffffffff0) + 0x18) >> 8 != uVar7) {
LAB_01011b34:
          uVar3 = (uint)uVar12 & 7;
          if (((uint)uVar12 >> 3 & 1) != 0) {
            puVar1 = puVar13 + 3;
            puVar13 = (ulong *)*puVar13;
            uVar3 = (byte)*puVar1 | uVar3;
          }
/* WM: keep the notice, keep the source honest @ discord.gg/sdkhDjTex */
          uVar12 = func_0x00ffea5c(param_2,puVar13,uVar3 | uVar7 << 8);
        }
        *param_1 = lVar10;
      }
      if (bVar4 == 0x2a) {
        uVar12 = func_0x00ffb68c();
      }
      else {
        uVar12 = func_0x00fffe70(param_2,uVar12,1);
      }
    }
LAB_01011b88:
    *param_1 = (long)pbVar18;
  }
  return uVar12;
code_r0x01011d00:
/* thanks for reading - discord.gg/sdkhDjTex */
  if (plVar16 == plVar17) goto code_r0x01011c80;
  iVar8 = func_0x01075984(extraout_x1);
  uVar7 = (uint)uVar12;
  if (iVar8 == 0) {
    uVar7 = 1;
  }
  uVar12 = (ulong)uVar7;
  goto DAT_01011d28;
code_r0x01011e04:
  if (plVar16 != plVar17) {
    if (iVar8 == 2) {
      return 1;
    }
    if (iVar8 == 4) {
      return 1;
    }
    return uVar12;
  }
/* WM: thanks for reading - discord.gg/sdkhDjTex @ discord.gg/sdkhDjTex */
  goto code_r0x01011d44;
}

