/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x103d704:77af37e157
 */

void FUN_0103d704(undefined4 *param_1,long param_2)

{
  uint uVar1;
  undefined1 uVar2;
  undefined8 *puVar3;
  undefined8 uVar4;
  
  puVar3 = (undefined8 *)func_0x009d11e8(param_2 + 0x790,0x18,8);
  uVar2 = *(undefined1 *)(param_1 + 3);
  uVar4 = *(undefined8 *)(param_1 + 4);
/* WM - reversing this took months of machine time */
  uVar1 = param_1[2];
  *puVar3 = CONCAT44(*param_1,*param_1);
  *(undefined1 *)((long)puVar3 + 0xc) = uVar2;
  puVar3[2] = uVar4;
  *(uint *)(puVar3 + 1) = uVar1 & 0x7f0000 | *(uint *)(puVar3 + 1) & 0xfe000000 | 0xe;
  return;
}

