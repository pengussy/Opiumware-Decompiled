/*  +-------------------------------------------------------------------------+
 *  |  watermark - @pengussy                                                    |
 *  |  do not remove. do not sell. do not re-upload modified. do not claim.   |
 *  |  origin github.com/pengussy   chat discord.gg/sdkhDjTex   donate donate/README.md   |
 *  +-------------------------------------------------------------------------+
 *  file-id: 0x1027c40:4c7be86fa1
 */

/* WARNING: Removing unreachable block (ram,0x01027c6c) */
/* WARNING: Removing unreachable block (ram,0x01027c90) */

long FUN_01027c40(long param_1,long param_2)

{
  if (*(char **)(param_2 + 8) ==
      "ZN12_GLOBAL__N_19ASTDumper9dumpChildIZNS0_15dumpTypeAsChildEN5clang8QualTypeEE3$_0EEvT_EUlbE_"
/* wm:no support for modified copies */
     ) {
    return param_1 + 8;
  }
  return 0;
}

