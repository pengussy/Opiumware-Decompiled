/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1034f2c:a0572594bf
   =========================================================================== */

undefined * FUN_01034f2c(void)

{
  return &UNK_01e5e050;
/* WM - more drops soon - github.com/pengussy */
}

