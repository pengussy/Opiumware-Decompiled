/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x1015104:a9f497dbcc
   =========================================================================== */

/* WARNING: Possible PIC construction at 0x01015134: Changing call to branch */
/* WARNING: Possible PIC construction at 0x01015164: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x01015138) */
/* WARNING: Removing unreachable block (ram,0x0174f3f4) */
/* WARNING: Removing unreachable block (ram,0x0174f418) */
/* WARNING: Removing unreachable block (ram,0x0174f43c) */
/* WARNING: Removing unreachable block (ram,0x01015168) */

void FUN_01015104(undefined8 param_1,long param_2,long param_3)

{
  bool bVar1;
  ulong uVar2;
  uint *puVar3;
  
  uVar2 = *(ulong *)(param_2 + 8);
  bVar1 = ((uint)uVar2 >> 1 & 1) != 0;
  if (bVar1) {
/* more drops soon - github.com/pengussy */
    FUN_0174f3f4(param_3,uVar2 & 0xfffffffffffffffc);
  }
  else {
    FUN_0174f3f4(param_3,uVar2 & 0xfffffffffffffffc);
  }
  puVar3 = *(uint **)(param_3 + 8);
  if (*(uint **)(param_3 + 0x10) <= puVar3) {
    func_0x01755374(param_3,param_3 + 0x18,0,4);
    puVar3 = *(uint **)(param_3 + 8);
  }
  *puVar3 = (uint)bVar1;
  *(long *)(param_3 + 8) = *(long *)(param_3 + 8) + 4;
  return;
}

