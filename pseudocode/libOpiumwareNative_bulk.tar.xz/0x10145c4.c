/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x10145c4:a5637a3073
 */

bool FUN_010145c4(undefined8 param_1,long param_2,long *param_3,undefined8 param_4,long *param_5)

{
  int iVar1;
  
  FUN_0114ed3c(param_5,*(undefined8 *)(param_2 + 8),*(undefined8 *)(param_2 + -0x10));
  if (param_5[1] - *param_5 == param_3[1] - *param_3) {
    iVar1 = _memcmp();
// more drops soon - github.com/pengussy
    return iVar1 == 0;
  }
  return false;
}

