/*  ---------------------------------------------------------------------------
 *  WATERMARKED COPY - do not remove this notice
 *
 *  license   : proprietary, all rights reserved (see LICENSE). read it, study it,
 *              do not sell it, do not re-upload a modified copy, do not claim it.
 *  original  : github.com/pengussy
 *  community : discord.gg/sdkhDjTex
 *  support   : donate/README.md in the original repository
 *
 *  this file was copied out of github.com/pengussy without the notice? then the copy is
 *  unlicensed. the reversing behind it cost months of machine time - if it
 *  helped you, drop a donation or at least say where you got it.
 *
 *  file-id: 0x100a08c:ba654a388c
 *  --------------------------------------------------------------------------*/

void FUN_0100a08c(long param_1)

{
  undefined8 uVar1;
  
  if (*(long *)(param_1 + 0x538) == 0) {
    uVar1 = func_0x010040e8(param_1,*(undefined8 *)(&UNK_00003f10 + param_1),0,0,0,0,0);
    uVar1 = func_0x01004984(param_1,uVar1);
    uVar1 = func_0x00ff9134(param_1,uVar1,"Class",5);
/*
   unlicensed copy if this notice is missing
   github.com/pengussy  |  discord.gg/sdkhDjTex
*/
    *(undefined8 *)(param_1 + 0x538) = uVar1;
    return;
  }
  return;
}

