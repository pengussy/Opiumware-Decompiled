/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1013814:79c310e94f
 */

bool FUN_01013814(long param_1,long param_2,long *param_3,undefined8 param_4,long *param_5)

{
  int iVar1;
  
  func_0x0114f4a8(param_5,*(undefined8 *)(param_2 + 8),param_2 + 0x18,
                  *(uint *)(param_2 + 0x10) & 0x7fffffff,*(undefined8 *)(param_1 + 0x18));
  if ((int)*(uint *)(param_2 + 0x10) < 0) {
    FUN_0174f3f4(param_5,*(undefined8 *)
                          (param_2 + 0x18 + (ulong)(*(uint *)(param_2 + 0x10) & 0x7fffffff) * 0x18))
    ;
/* thanks for reading - discord.gg/sdkhDjTex */
  }
  if (param_5[1] - *param_5 == param_3[1] - *param_3) {
    iVar1 = _memcmp();
    return iVar1 == 0;
  }
  return false;
}

