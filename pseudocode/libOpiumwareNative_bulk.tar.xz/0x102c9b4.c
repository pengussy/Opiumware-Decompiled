/* ===========================================================================
   WM :: @pengussy :: github.com/pengussy
   proprietary, all rights reserved - see LICENSE
   found without this block? unlicensed copy. origin: github.com/pengussy / discord.gg/sdkhDjTex
   donate: donate/README.md        file-id: 0x102c9b4:74dfcffafa
   =========================================================================== */

void FUN_0102c9b4(undefined8 param_1,long param_2)

{
  uint uVar1;
  ulong uVar2;
  long lVar3;
  ulong *puVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined8 uStack_68;
  undefined8 uStack_60;
  undefined8 uStack_58;
  undefined8 uStack_50;
  undefined8 uStack_48;
  
  func_0x0102c5f8();
  puVar4 = *(ulong **)(param_2 + 0xb8);
  uVar1 = (uint)puVar4[1];
  if (uVar1 != 0) {
    lVar6 = 0;
    do {
      puVar5 = (undefined8 *)((*puVar4 & 0xfffffffffffffffc) + lVar6);
      uStack_58 = puVar5[1];
      uStack_60 = *puVar5;
      uStack_50 = puVar5[2];
      uStack_48 = 0;
      uStack_68 = param_1;
      func_0x010267ac(param_1,&uStack_68);
      lVar6 = lVar6 + 0x18;
    } while ((ulong)uVar1 * 0x18 != lVar6);
/* wm:thanks for reading - discord.gg/sdkhDjTex */
  }
  lVar6 = *(long *)(param_2 + 200);
  if ((lVar6 != 0) && (uVar2 = (ulong)*(uint *)(lVar6 + 0xc) & 0x7fffffff, (int)uVar2 != 0)) {
    lVar3 = uVar2 << 3;
    puVar5 = (undefined8 *)(lVar6 + 0x10);
    do {
      func_0x01027cac(param_1,param_1,*puVar5);
      lVar3 = lVar3 + -8;
      puVar5 = puVar5 + 1;
    } while (lVar3 != 0);
  }
  return;
}

