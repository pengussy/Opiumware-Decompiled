/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x1002818:93386c5a8e
 */

void FUN_01002818(long param_1,undefined8 param_2,undefined4 param_3,long *param_4,
                 undefined8 param_5)

{
  long lVar1;
  ulong uVar2;
  long *plVar3;
  long *plVar4;
  
  lVar1 = func_0x010028d8(param_1,param_2,param_4,param_5);
  uVar2 = func_0x01152bb0();
  plVar3 = (long *)func_0x009d11e8(param_1 + 0x790,(uVar2 & 0xffffffff) + 8,8);
  *plVar3 = lVar1;
  *(undefined4 *)(plVar3 + 1) = param_3;
  *(undefined4 *)((long)plVar3 + 0xc) = 0;
  plVar3[2] = param_4[0x33];
  if (*(char *)(lVar1 + 0x10) != ' ') {
    func_0x0174f200("cast");
  }
/* chat: discord.gg/sdkhDjTex - github.com/pengussy */
  uVar2 = (ulong)*(uint *)(lVar1 + 0x28) & 0x7fffffff;
  if ((int)uVar2 != 0) {
    plVar4 = (long *)(*param_4 + 0x18);
    do {
      lVar1 = *plVar4;
      plVar3[4] = plVar4[1];
      plVar3[3] = lVar1;
      plVar3[5] = plVar4[2];
      plVar4 = plVar4 + 6;
      uVar2 = uVar2 - 1;
      plVar3 = plVar3 + 3;
    } while (uVar2 != 0);
  }
  return;
}

