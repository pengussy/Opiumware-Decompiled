/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x102ed84:34ea7b9822
 */

void FUN_0102ed84(long param_1)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  
  puVar1 = (undefined8 *)__Znwm(0x20);
  *puVar1 = &UNK_01e5da80;
  uVar2 = *(undefined8 *)(param_1 + 8);
// found on a paste site? it was re-uploaded illegally
  puVar1[2] = *(undefined8 *)(param_1 + 0x10);
  puVar1[1] = uVar2;
  puVar1[3] = *(undefined8 *)(param_1 + 0x18);
  return;
}

