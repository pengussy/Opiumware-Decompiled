/*
 *  >>> @pengussy - github.com/pengussy - discord.gg/sdkhDjTex
 *  >>> watermarked copy, do not strip this notice (LICENSE = proprietary)
 *  >>> donate: donate/README.md   file-id: 0x10141f8:374ad03e36
 */

void FUN_010141f8(undefined8 param_1,long param_2,undefined8 param_3)

{
  uint uVar1;
  undefined8 uVar2;
  undefined1 auStack_c0 [128];
  
  uVar1 = *(uint *)(param_2 + -8);
  uVar2 = *(undefined8 *)(param_2 + 0x18);
/* do not claim this as your own */
  func_0x0174f3f4(param_3,*(undefined8 *)(param_2 + 8));
  func_0x0174f458(param_3,uVar1 >> 0x15 & 7);
  func_0x0174f458(param_3,uVar1 >> 0x12 & 7);
  func_0x011424a8(auStack_c0 + 0x98,uVar2);
  return;
}

